using Microsoft.Extensions.Configuration;
using LMROCR_Solution.Models;
using LMROCR_Solution.Services;
using System.Diagnostics;
using System.Text;
using PDFtoImage;
using ClosedXML.Excel;

namespace LMROCR_Solution
{
    public partial class Form1 : Form
    {
        // ── State ────────────────────────────────────────────────────────────
        private string?    _selectedFilePath;
        private OcrResult? _lastResult;
        private readonly IConfiguration _configuration;

        // ── Viewer state ─────────────────────────────────────────────────────
        private List<Bitmap> _docPages    = new();
        private int          _currentPage = 0;
        private float        _zoomFactor  = 1.0f;
        private const float  ZoomStep     = 0.25f;
        private const float  ZoomMin      = 0.25f;
        private const float  ZoomMax      = 4.0f;

        // ── Live timer ───────────────────────────────────────────────────────
        private readonly System.Windows.Forms.Timer _liveTimer = new() { Interval = 100 };
        private Stopwatch _processingStopwatch = new();

        // ── Tab colors ────────────────────────────────────────────────────────
        private static readonly Color TabActiveBack   = Color.FromArgb(30, 45, 75);
        private static readonly Color TabActiveText   = Color.White;
        private static readonly Color TabInactiveBack = Color.FromArgb(55, 70, 95);
        private static readonly Color TabInactiveText = Color.FromArgb(180, 200, 230);

        public Form1()
        {
            InitializeComponent();

            _configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: false)
                .Build();

            cmbOcrEngine.SelectedIndex = 0;
            btnRunOcr.Enabled   = false;
            btnSaveJson.Enabled = false;
            btnExportCsv.Enabled = false;

            _liveTimer.Tick += LiveTimer_Tick;

            // Hover effects on key buttons
            ApplyHoverEffect(btnRunOcr,   Color.FromArgb(39, 174, 96),  Color.FromArgb(30, 145, 78));
            ApplyHoverEffect(btnUpload,   Color.FromArgb(52, 73, 94),   Color.FromArgb(70, 95, 120));
            ApplyHoverEffect(btnSaveJson, Color.FromArgb(52, 73, 94),   Color.FromArgb(70, 95, 120));
            ApplyHoverEffect(btnExportCsv, Color.FromArgb(39, 174, 96), Color.FromArgb(30, 145, 78));
            ApplyHoverEffect(btnPricingInfo, Color.FromArgb(65, 75, 95), Color.FromArgb(85, 100, 125));
        }

        // ────────────────────────────────────────────────────────────────────
        // FORM LOAD
        // ────────────────────────────────────────────────────────────────────
        private void Form1_Load(object sender, EventArgs e)
        {
            // Set initial 60/40 split: document viewer = 60%, output panel = 40%
            // The splitter remains draggable after this initial layout.
            pnlLeft.Width = (int)(ClientSize.Width * 0.60);
        }

        // ────────────────────────────────────────────────────────────────────
        // UPLOAD
        // ────────────────────────────────────────────────────────────────────
        private void btnUpload_Click(object sender, EventArgs e)
        {
            using var dialog = new OpenFileDialog
            {
                Title  = "Select Document for OCR",
                Filter = "All Supported|*.pdf;*.jpg;*.jpeg;*.png;*.tiff;*.bmp" +
                         "|PDF Files|*.pdf" +
                         "|Image Files|*.jpg;*.jpeg;*.png;*.tiff;*.bmp",
                FilterIndex = 1
            };

            if (dialog.ShowDialog() != DialogResult.OK) return;

            _selectedFilePath = dialog.FileName;
            lblFilePath.Text  = Path.GetFileName(_selectedFilePath);
            lblFilePath.ForeColor = Color.FromArgb(255, 255, 200);

            btnRunOcr.Enabled = true;
            SetStatusReady("File loaded — ready to process");

            // Load document preview
            LoadDocumentPreview(_selectedFilePath);
        }

        // ────────────────────────────────────────────────────────────────────
        // DOCUMENT VIEWER
        // ────────────────────────────────────────────────────────────────────
        private void LoadDocumentPreview(string filePath)
        {
            DisposeDocPages();
            _currentPage = 0;

        try
        {
            var ext = Path.GetExtension(filePath).ToLowerInvariant();
            if (ext == ".pdf")
            {
                // WithFormFill renders AcroForm widgets (checkboxes, text fields, radio buttons)
                // WithAnnotations renders non-interactive annotations (links, highlights, etc.)
                var opts = new RenderOptions(
                    Dpi: 200,
                    WithAnnotations: true,
                    WithFormFill: true);

                List<byte[]> pngBytes;
                using (var fs = File.OpenRead(filePath))
                {
                    pngBytes = Conversion.ToImages(fs, options: opts)
                        .Select(bmp =>
                        {
                            using (bmp)
                            using (var ms2 = new MemoryStream())
                            {
                                bmp.Encode(ms2, SkiaSharp.SKEncodedImageFormat.Png, 90);
                                return ms2.ToArray();
                            }
                        }).ToList();
                }
                foreach (var bytes in pngBytes)
                {
                    using var ms = new MemoryStream(bytes);
                    _docPages.Add(new Bitmap(ms));
                }
            }
            else
            {
                // Image files (PNG, JPG, TIFF, BMP) — checkboxes are visual elements
                // in the pixel data, so they render natively without special handling.
                // Azure Doc Intel detects selection marks from images via ML-based vision.
                _docPages.Add(new Bitmap(filePath));
            }
        }
        catch (Exception ex)
        {
            // Preview failed – show placeholder, log to debug
            System.Diagnostics.Debug.WriteLine($"Preview error: {ex.Message}");
        }
            ShowCurrentPage();
        }

        private void ShowCurrentPage()
        {
            if (_docPages.Count == 0)
            {
                picDocument.Visible   = false;
                lblNoDocument.Visible = true;
                lblPageNav.Text       = "-- / --";
                return;
            }

            lblNoDocument.Visible = false;
            picDocument.Visible   = true;

            var bmp  = _docPages[_currentPage];
            int newW = (int)(bmp.Width  * _zoomFactor);
            int newH = (int)(bmp.Height * _zoomFactor);

            picDocument.Size     = new Size(newW, newH);
            picDocument.Image    = bmp;
            picDocument.SizeMode = PictureBoxSizeMode.StretchImage;
            picDocument.Location = new Point(10, 10);

            // Scroll canvas to show the image
            pnlViewerCanvas.AutoScrollMinSize = new Size(newW + 20, newH + 20);

            lblPageNav.Text  = $"{_currentPage + 1} / {_docPages.Count}";
            lblZoomLevel.Text = $"{(int)(_zoomFactor * 100)}%";

            btnPrevPage.Enabled = _currentPage > 0;
            btnNextPage.Enabled = _currentPage < _docPages.Count - 1;
        }

        private void btnZoomIn_Click(object sender, EventArgs e)
        {
            if (_zoomFactor < ZoomMax) { _zoomFactor = Math.Min(ZoomMax, _zoomFactor + ZoomStep); ShowCurrentPage(); }
        }

        private void btnZoomOut_Click(object sender, EventArgs e)
        {
            if (_zoomFactor > ZoomMin) { _zoomFactor = Math.Max(ZoomMin, _zoomFactor - ZoomStep); ShowCurrentPage(); }
        }

        private void btnZoomReset_Click(object sender, EventArgs e)
        {
            _zoomFactor = 1.0f;
            ShowCurrentPage();
        }

        private void btnPrevPage_Click(object sender, EventArgs e)
        {
            if (_currentPage > 0) { _currentPage--; ShowCurrentPage(); }
        }

        private void btnNextPage_Click(object sender, EventArgs e)
        {
            if (_currentPage < _docPages.Count - 1) { _currentPage++; ShowCurrentPage(); }
        }

        private void DisposeDocPages()
        {
            foreach (var b in _docPages) b.Dispose();
            _docPages.Clear();
        }

        // ────────────────────────────────────────────────────────────────────
        // RUN OCR
        // ────────────────────────────────────────────────────────────────────
        private async void btnRunOcr_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_selectedFilePath) || !File.Exists(_selectedFilePath))
            {
                MessageBox.Show("Please select a valid file first.", "Invalid File",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbOcrEngine.SelectedItem is not string engineName)
            {
                MessageBox.Show("Please select an OCR engine.", "No Engine",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SetProcessingState(true);
            _processingStopwatch.Restart();
            _liveTimer.Start();

            try
            {
                var service = OcrServiceFactory.Create(engineName, _configuration);
                _lastResult = await service.ProcessAsync(_selectedFilePath);

                _liveTimer.Stop();
                _processingStopwatch.Stop();

                DisplayResults(_lastResult);

                var elapsed = _processingStopwatch.Elapsed;
                lblTime.Text = $"⏱  {elapsed.TotalSeconds:F2}s";
                SetStatusCompleted(engineName, _lastResult.AverageConfidence, _lastResult.ModelUsed);

                btnSaveJson.Enabled  = true;
                btnExportCsv.Enabled = true;
            }
            catch (Exception ex)
            {
                _liveTimer.Stop();
                _processingStopwatch.Stop();
                lblTime.Text         = $"⏱  {_processingStopwatch.Elapsed.TotalSeconds:F2}s";
                SetStatusError();
                MessageBox.Show($"OCR processing failed:\n\n{ex.Message}", "OCR Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetProcessingState(false);
            }
        }

        // ────────────────────────────────────────────────────────────────────
        // LIVE TIMER
        // ────────────────────────────────────────────────────────────────────
        private void LiveTimer_Tick(object? sender, EventArgs e)
        {
            lblTime.Text = $"⏱  {_processingStopwatch.Elapsed.TotalSeconds:F1}s";
        }

        // ────────────────────────────────────────────────────────────────────
        // STATE HELPERS
        // ────────────────────────────────────────────────────────────────────
        private void SetProcessingState(bool isProcessing)
        {
            btnRunOcr.Enabled    = !isProcessing;
            btnUpload.Enabled    = !isProcessing;
            cmbOcrEngine.Enabled = !isProcessing;

            if (isProcessing)
            {
                lblStatusIcon.ForeColor = Color.FromArgb(255, 200, 50);
                lblStatus.Text          = "Processing…";
                lblStatus.ForeColor     = Color.FromArgb(255, 220, 100);
                lblConfidence.Text      = "Confidence: --";
                lblModel.Text           = "Model: --";
                lblPages.Text           = "Pages: --";
                lblTime.Text            = "⏱  0.0s";

                dgvExtractedText.Rows.Clear();
                dgvStructuredFields.Rows.Clear();
                tvDocStructure.Nodes.Clear();
                txtJsonResponse.Clear();

                btnSaveJson.Enabled  = false;
                btnExportCsv.Enabled = false;
            }
        }

        private void SetStatusReady(string msg)
        {
            lblStatusIcon.ForeColor = Color.FromArgb(100, 210, 100);
            lblStatus.Text          = msg;
            lblStatus.ForeColor     = Color.FromArgb(200, 225, 245);
        }

        private void SetStatusCompleted(string engine, double confidence, string modelUsed)
        {
            lblStatusIcon.ForeColor = Color.FromArgb(100, 210, 100);
            // Keep short to prevent overflow into lblModel
            var shortEngine = engine switch
            {
                "Azure Document Intelligence" => "Azure Doc Intel",
                "Hybrid (ADI + OSS LLM)" => "Hybrid ADI+LLM",
                "Hybrid (Tesseract + OSS LLM)" => "Hybrid Tess+LLM",
                _ => engine
            };
            lblStatus.Text          = $"Completed  ·  {shortEngine}";
            lblStatus.ForeColor     = Color.FromArgb(140, 230, 140);
            lblModel.Text           = $"Model: {GetModelDisplayName(engine, modelUsed)}";
            lblModel.ForeColor      = Color.FromArgb(160, 200, 255);
        }

        private void SetStatusError()
        {
            lblStatusIcon.ForeColor = Color.FromArgb(230, 80, 80);
            lblStatus.Text          = "Error";
            lblStatus.ForeColor     = Color.FromArgb(255, 120, 120);
        }

        // ────────────────────────────────────────────────────────────────────
        // DISPLAY RESULTS
        // ────────────────────────────────────────────────────────────────────
        private void DisplayResults(OcrResult result)
        {
            BuildExtractedGrid(result);

            dgvStructuredFields.Rows.Clear();
            foreach (var field in result.StructuredFields)
            {
                // Section header rows carry a synthetic Confidence=100 — show "—" so
                // users don't mistake it for a genuine OCR or extraction score.
                var isSectionHeader = field.Key.StartsWith("──");
                var confDisplay     = isSectionHeader ? "—" : $"{field.Confidence:F1}";
                var rowIndex = dgvStructuredFields.Rows.Add(field.Key, field.Value, confDisplay);
                var row      = dgvStructuredFields.Rows[rowIndex];

                if (isSectionHeader)
                {
                    row.DefaultCellStyle.Font      = new Font(dgvStructuredFields.Font, FontStyle.Bold);
                    row.DefaultCellStyle.BackColor = Color.FromArgb(30, 45, 75);
                    row.DefaultCellStyle.ForeColor = Color.FromArgb(180, 210, 240);
                }
                else if (field.Key.StartsWith("Step ") || field.Key == "Engine Mode"
                         || field.Key == "ADI Confidence" || field.Key == "LLM Model"
                         || field.Key == "Result" || field.Key == "Action Required")
                {
                    // Hybrid pipeline status rows — distinct styling
                    row.DefaultCellStyle.BackColor = Color.FromArgb(25, 40, 65);
                    row.DefaultCellStyle.ForeColor = Color.FromArgb(160, 200, 240);
                    if (field.Value.Contains("✔"))
                        row.DefaultCellStyle.ForeColor = Color.FromArgb(100, 220, 130);
                    else if (field.Value.Contains("❌") || field.Value.Contains("⚠"))
                        row.DefaultCellStyle.ForeColor = Color.FromArgb(255, 160, 80);
                }
                else if (field.Confidence < 80)
                    row.Cells["colConfidence"].Style.ForeColor = Color.FromArgb(220, 80, 80);
                else if (field.Confidence < 90)
                    row.Cells["colConfidence"].Style.ForeColor = Color.FromArgb(220, 140, 40);
                else
                    row.Cells["colConfidence"].Style.ForeColor = Color.FromArgb(39, 174, 96);
            }

            BuildDocumentTree(result);
            txtJsonResponse.Text = result.RawJson;

            // Auto-size the Field column to content after populating (cap at 480px)
            dgvStructuredFields.AutoResizeColumn(0, DataGridViewAutoSizeColumnMode.AllCellsExceptHeader);
            if (dgvStructuredFields.Columns[0].Width > 480)
                dgvStructuredFields.Columns[0].Width = 480;

            var conf = result.AverageConfidence;
            lblConfidence.Text      = $"OCR Confidence: {conf:F1}%";
            lblConfidence.ForeColor = conf switch
            {
                < 80 => Color.FromArgb(240, 100, 80),
                < 90 => Color.FromArgb(255, 180, 50),
                _    => Color.FromArgb(100, 220, 130)
            };
            lblPages.Text = $"Pages: {result.Pages}";

            // Highlight LLM-corrected rows in the Structured Fields tab
            if (result.HasLlmCorrections)
            {
                foreach (DataGridViewRow row in dgvStructuredFields.Rows)
                {
                    var key = row.Cells["colField"].Value?.ToString() ?? "";
                    if (key.StartsWith("  ✏"))
                    {
                        row.DefaultCellStyle.BackColor = Color.FromArgb(20, 60, 60);
                        row.DefaultCellStyle.ForeColor = Color.FromArgb(100, 220, 200);
                    }
                }

                var corrCount = result.HybridCorrections.Count(c => c.WasApplied);
                if (corrCount > 0)
                    SetStatusReady($"Hybrid complete — {corrCount} LLM correction(s) applied");
            }
        }

        // ────────────────────────────────────────────────────────────────────
        // EXTRACTED TEXT GRID
        // ────────────────────────────────────────────────────────────────────
        private void BuildExtractedGrid(OcrResult result)
        {
            dgvExtractedText.SuspendLayout();
            dgvExtractedText.Rows.Clear();

            if (result.Paragraphs.Count > 0)
            {
                foreach (var para in result.Paragraphs)
                {
                    var role   = string.IsNullOrEmpty(para.Role) ? "body" : para.Role;
                    var rowIdx = dgvExtractedText.Rows.Add(
                        para.PageNumber == 0 ? "" : para.PageNumber.ToString(),
                        role, para.Content);
                    var row = dgvExtractedText.Rows[rowIdx];

                    switch (role.ToLowerInvariant())
                    {
                        case "title":
                            row.DefaultCellStyle.Font      = new Font(dgvExtractedText.Font, FontStyle.Bold);
                            row.DefaultCellStyle.BackColor = Color.FromArgb(208, 228, 255);
                            row.DefaultCellStyle.ForeColor = Color.FromArgb(20, 40, 100);
                            break;
                        case "sectionheading":
                            row.DefaultCellStyle.Font      = new Font(dgvExtractedText.Font, FontStyle.Bold);
                            row.DefaultCellStyle.BackColor = Color.FromArgb(232, 242, 255);
                            break;
                        case "pageheader":
                        case "pagefooter":
                            row.DefaultCellStyle.BackColor = Color.FromArgb(245, 246, 248);
                            row.DefaultCellStyle.ForeColor = Color.FromArgb(130, 145, 165);
                            break;
                        case "pagenumber":
                            row.DefaultCellStyle.BackColor = Color.FromArgb(250, 251, 252);
                            row.DefaultCellStyle.ForeColor = Color.FromArgb(160, 170, 185);
                            break;
                        case "footnote":
                            row.DefaultCellStyle.ForeColor = Color.FromArgb(110, 120, 140);
                            row.DefaultCellStyle.Font      = new Font(dgvExtractedText.Font.FontFamily, 8.5F);
                            break;
                    }
                }

                foreach (var table in result.Tables)
                {
                    var headerRow = dgvExtractedText.Rows.Add(
                        table.PageNumber == 0 ? "" : table.PageNumber.ToString(),
                        "table",
                        $"[Table: {table.RowCount} rows × {table.ColumnCount} cols]");
                    dgvExtractedText.Rows[headerRow].DefaultCellStyle.BackColor = Color.FromArgb(255, 245, 215);
                    dgvExtractedText.Rows[headerRow].DefaultCellStyle.Font      =
                        new Font(dgvExtractedText.Font, FontStyle.Bold);

                    for (int r = 0; r < table.RowCount; r++)
                    {
                        var parts = new List<string>();
                        for (int c = 0; c < table.ColumnCount; c++)
                            parts.Add(table.DisplayGrid[r, c] ?? "");
                        var isHeader = table.Cells.Any(cl => cl.RowIndex == r &&
                            cl.Kind.Contains("Header", StringComparison.OrdinalIgnoreCase));
                        var rowType = isHeader ? "table-header" : "table-row";
                        var ri      = dgvExtractedText.Rows.Add("", rowType, string.Join(" │ ", parts));
                        if (isHeader)
                        {
                            dgvExtractedText.Rows[ri].DefaultCellStyle.BackColor = Color.FromArgb(255, 235, 175);
                            dgvExtractedText.Rows[ri].DefaultCellStyle.Font =
                                new Font(dgvExtractedText.Font, FontStyle.Bold);
                        }
                    }
                }
            }
            else if (result.StructuredFields.Count > 0 &&
                     result.StructuredFields.Any(f => f.Key.StartsWith("Line")))
            {
                foreach (var field in result.StructuredFields.Where(f => f.Key.StartsWith("Line")))
                {
                    var rowIdx = dgvExtractedText.Rows.Add("1", "line", field.Value);
                    var row    = dgvExtractedText.Rows[rowIdx];
                    if (field.Confidence < 70)
                        row.DefaultCellStyle.ForeColor = Color.FromArgb(220, 80, 80);
                    else if (field.Confidence < 85)
                        row.DefaultCellStyle.ForeColor = Color.FromArgb(200, 130, 40);
                }
            }
            else
            {
                var lines = result.ExtractedText.Split('\n', StringSplitOptions.RemoveEmptyEntries);
                int page  = 1;
                foreach (var line in lines)
                {
                    if (line.StartsWith("─── Page"))
                    {
                        if (int.TryParse(
                            System.Text.RegularExpressions.Regex.Match(line, @"\d+").Value,
                            out int p)) page = p;
                        var sepIdx = dgvExtractedText.Rows.Add("", $"page {page}", "");
                        dgvExtractedText.Rows[sepIdx].DefaultCellStyle.BackColor = Color.FromArgb(30, 45, 75);
                        dgvExtractedText.Rows[sepIdx].DefaultCellStyle.ForeColor = Color.White;
                        dgvExtractedText.Rows[sepIdx].DefaultCellStyle.Font      =
                            new Font(dgvExtractedText.Font, FontStyle.Bold);
                        continue;
                    }
                    dgvExtractedText.Rows.Add(page.ToString(), "text", line);
                }
            }

            dgvExtractedText.ResumeLayout();

            // Auto-size Role/Type column to content after populating (cap at 200px)
            dgvExtractedText.AutoResizeColumn(1, DataGridViewAutoSizeColumnMode.AllCellsExceptHeader);
            if (dgvExtractedText.Columns[1].Width > 200)
                dgvExtractedText.Columns[1].Width = 200;
        }

        // ────────────────────────────────────────────────────────────────────
        // DOCUMENT STRUCTURE TREE
        // ────────────────────────────────────────────────────────────────────
        private void BuildDocumentTree(OcrResult result)
        {
            tvDocStructure.BeginUpdate();
            tvDocStructure.Nodes.Clear();

            if (result.DocumentPages.Count > 0)
            {
                var pagesNode = new TreeNode($"📄 Pages ({result.DocumentPages.Count})");
                foreach (var p in result.DocumentPages)
                {
                    var pn = new TreeNode($"Page {p.PageNumber}  [{p.Width:F0}×{p.Height:F0} {p.Unit}]");
                    pn.Nodes.Add($"Words: {p.WordCount}");
                    pn.Nodes.Add($"Lines: {p.LineCount}");
                    pagesNode.Nodes.Add(pn);
                }
                pagesNode.Expand();
                tvDocStructure.Nodes.Add(pagesNode);
            }

            if (result.Paragraphs.Count > 0)
            {
                var parasNode = new TreeNode($"📝 Paragraphs ({result.Paragraphs.Count})");
                var byRole    = result.Paragraphs.GroupBy(p => string.IsNullOrEmpty(p.Role) ? "body" : p.Role);
                foreach (var grp in byRole)
                {
                    var roleNode = new TreeNode($"{grp.Key} ({grp.Count()})");
                    foreach (var para in grp)
                    {
                        var preview = para.Content.Length > 80 ? para.Content[..80] + "…" : para.Content;
                        roleNode.Nodes.Add($"[P{para.PageNumber}] {preview}");
                    }
                    parasNode.Nodes.Add(roleNode);
                }
                tvDocStructure.Nodes.Add(parasNode);
            }

            if (result.KeyValuePairs.Count > 0)
            {
                var kvNode = new TreeNode($"🔑 Form Fields ({result.KeyValuePairs.Count})");
                var filled = result.KeyValuePairs.Where(k => !k.IsEmpty).ToList();
                var empty  = result.KeyValuePairs.Where(k => k.IsEmpty).ToList();

                if (filled.Count > 0)
                {
                    var filledNode = new TreeNode($"✅ Filled ({filled.Count})");
                    foreach (var kv in filled)
                        filledNode.Nodes.Add($"[P{kv.PageNumber}] {kv.Key}: {kv.Value}  ({kv.Confidence:F1}%)");
                    kvNode.Nodes.Add(filledNode);
                    filledNode.Expand();
                }
                if (empty.Count > 0)
                {
                    var emptyNode = new TreeNode($"□ Empty / Blank ({empty.Count})");
                    foreach (var kv in empty)
                        emptyNode.Nodes.Add($"[P{kv.PageNumber}] {kv.Key}");
                    kvNode.Nodes.Add(emptyNode);
                    emptyNode.Expand();
                }
                kvNode.Expand();
                tvDocStructure.Nodes.Add(kvNode);
            }

            if (result.SelectionMarks.Count > 0)
            {
                var smNode     = new TreeNode($"☑ Checkboxes ({result.SelectionMarks.Count})");
                var selected   = result.SelectionMarks.Where(s => s.State.Equals("selected",   StringComparison.OrdinalIgnoreCase)).ToList();
                var unselected = result.SelectionMarks.Where(s => s.State.Equals("unselected", StringComparison.OrdinalIgnoreCase)).ToList();

                if (selected.Count > 0)
                {
                    var selNode = new TreeNode($"☑ Selected ({selected.Count})");
                    foreach (var s in selected)
                        selNode.Nodes.Add($"[P{s.PageNumber}] {s.DisplayLabel}  ({s.Confidence:F1}%)");
                    smNode.Nodes.Add(selNode);
                    selNode.Expand();
                }
                if (unselected.Count > 0)
                {
                    var unselNode = new TreeNode($"☐ Unselected ({unselected.Count})");
                    foreach (var s in unselected)
                        unselNode.Nodes.Add($"[P{s.PageNumber}] {s.DisplayLabel}  ({s.Confidence:F1}%)");
                    smNode.Nodes.Add(unselNode);
                    unselNode.Expand();
                }
                smNode.Expand();
                tvDocStructure.Nodes.Add(smNode);
            }

            if (result.Tables.Count > 0)
            {
                var tablesNode = new TreeNode($"📊 Tables ({result.Tables.Count})");
                for (int ti = 0; ti < result.Tables.Count; ti++)
                {
                    var t  = result.Tables[ti];
                    var tn = new TreeNode($"Table {ti + 1}  (Page {t.PageNumber}, {t.RowCount}×{t.ColumnCount})");
                    for (int r = 0; r < t.RowCount; r++)
                    {
                        var rowParts = new List<string>();
                        for (int c = 0; c < t.ColumnCount; c++)
                            rowParts.Add(t.DisplayGrid[r, c] ?? "");
                        var isHeader = t.Cells.Any(cl => cl.RowIndex == r &&
                            cl.Kind.Contains("Header", StringComparison.OrdinalIgnoreCase));
                        tn.Nodes.Add($"{(isHeader ? "►" : " ")} Row {r + 1}: {string.Join(" │ ", rowParts)}");
                    }
                    tablesNode.Nodes.Add(tn);
                    tn.Expand();
                }
                tablesNode.Expand();
                tvDocStructure.Nodes.Add(tablesNode);
            }

            // ── Hybrid Pipeline Info ────────────────────────────────────────
            if (result.HybridCorrections.Count > 0)
            {
                var hybridNode = new TreeNode($"🔀 Hybrid Pipeline");

                var appliedCorr = result.HybridCorrections.Where(c => c.WasApplied).ToList();
                var skipped     = result.HybridCorrections.Where(c => c.Stage == "LLM Pass Skipped").ToList();
                var errors      = result.HybridCorrections.Where(c => c.Stage is "LLM Error" or "Parse Error" or "Ollama Unavailable").ToList();
                var summaries   = result.HybridCorrections.Where(c => c.Stage == "Page Summary").ToList();

                hybridNode.Nodes.Add($"Total Corrections: {appliedCorr.Count} applied, {result.HybridCorrections.Count} total records");

                if (errors.Count > 0)
                {
                    var errNode = new TreeNode($"⚠ Issues ({errors.Count})");
                    foreach (var err in errors)
                        errNode.Nodes.Add($"[{err.Stage}] {err.CorrectedText}");
                    errNode.Expand();
                    hybridNode.Nodes.Add(errNode);
                }

                if (skipped.Count > 0)
                {
                    var skipNode = new TreeNode($"✔ Skipped ({skipped.Count})");
                    foreach (var s in skipped)
                        skipNode.Nodes.Add(s.CorrectedText);
                    skipNode.Expand();
                    hybridNode.Nodes.Add(skipNode);
                }

                if (appliedCorr.Count > 0)
                {
                    var corrNode = new TreeNode($"✏ Applied Corrections ({appliedCorr.Count})");
                    foreach (var c in appliedCorr)
                    {
                        var preview = $"[P{c.PageNumber}] \"{c.OriginalText}\" → \"{c.CorrectedText}\" ({c.LlmConfidence:P0})";
                        corrNode.Nodes.Add(preview);
                    }
                    corrNode.Expand();
                    hybridNode.Nodes.Add(corrNode);
                }

                if (summaries.Count > 0)
                {
                    var sumNode = new TreeNode($"📋 Page Summaries ({summaries.Count})");
                    foreach (var s in summaries)
                        sumNode.Nodes.Add($"[P{s.PageNumber}] {s.CorrectedText}");
                    sumNode.Expand();
                    hybridNode.Nodes.Add(sumNode);
                }

                hybridNode.Expand();
                tvDocStructure.Nodes.Add(hybridNode);
            }

            tvDocStructure.EndUpdate();
        }

        // ────────────────────────────────────────────────────────────────────
        // TAB OWNER-DRAW (professional styled tabs)
        // ────────────────────────────────────────────────────────────────────
        private void tabResults_DrawItem(object? sender, DrawItemEventArgs e)
        {
            var tab     = (TabControl)sender!;
            var tabPage = tab.TabPages[e.Index];
            var isSelected = e.Index == tab.SelectedIndex;

            var backColor = isSelected ? TabActiveBack : TabInactiveBack;
            var textColor = isSelected ? TabActiveText : TabInactiveText;

            using var brush = new SolidBrush(backColor);
            e.Graphics.FillRectangle(brush, e.Bounds);

            // Bottom highlight line for active tab
            if (isSelected)
            {
                using var accentPen = new Pen(Color.FromArgb(0, 153, 204), 3);
                e.Graphics.DrawLine(accentPen,
                    e.Bounds.Left, e.Bounds.Bottom - 1,
                    e.Bounds.Right, e.Bounds.Bottom - 1);
            }

            using var textBrush = new SolidBrush(textColor);
            var font = new Font("Segoe UI", 10.5F, isSelected ? FontStyle.Bold : FontStyle.Regular);
            var sf   = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            e.Graphics.DrawString(tabPage.Text, font, textBrush, e.Bounds, sf);
        }

        // ────────────────────────────────────────────────────────────────────
        // SAVE / EXPORT
        // ────────────────────────────────────────────────────────────────────
        private void btnSaveJson_Click(object sender, EventArgs e)
        {
            if (_lastResult is null || string.IsNullOrEmpty(_lastResult.RawJson))
            {
                MessageBox.Show("No JSON data to save.", "Nothing to Save",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var dialog = new SaveFileDialog
            {
                Title       = "Save JSON Output",
                Filter      = "JSON Files|*.json",
                DefaultExt  = "json",
                FileName    = $"ocr_result_{DateTime.Now:yyyyMMdd_HHmmss}.json"
            };

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(dialog.FileName, _lastResult.RawJson);
                MessageBox.Show("JSON saved successfully.", "Saved",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnExportCsv_Click(object sender, EventArgs e)
        {
            if (_lastResult is null)
            {
                MessageBox.Show("No data to export.", "Nothing to Export",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var dialog = new SaveFileDialog
            {
                Title      = "Export OCR Results to Excel",
                Filter     = "Excel Files|*.xlsx",
                DefaultExt = "xlsx",
                FileName   = $"ocr_export_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
            };

            if (dialog.ShowDialog() != DialogResult.OK) return;

            try
            {
                using var wb = new XLWorkbook();

                // ── Sheet 1: Extracted Text ──────────────────────────────────
                var ws1 = wb.Worksheets.Add("Extracted Text");
                ws1.Cell(1, 1).Value = "Page";
                ws1.Cell(1, 2).Value = "Role / Type";
                ws1.Cell(1, 3).Value = "Content";
                StyleHeaderRow(ws1, 3);

                int r1 = 2;
                if (_lastResult.Paragraphs.Count > 0)
                {
                    foreach (var para in _lastResult.Paragraphs)
                    {
                        ws1.Cell(r1, 1).Value = para.PageNumber == 0 ? "" : para.PageNumber.ToString();
                        ws1.Cell(r1, 2).Value = string.IsNullOrEmpty(para.Role) ? "body" : para.Role;
                        ws1.Cell(r1, 3).Value = para.Content;
                        r1++;
                    }
                    foreach (var table in _lastResult.Tables)
                    {
                        ws1.Cell(r1, 1).Value = table.PageNumber == 0 ? "" : table.PageNumber.ToString();
                        ws1.Cell(r1, 2).Value = "table";
                        ws1.Cell(r1, 3).Value = $"[Table: {table.RowCount} rows × {table.ColumnCount} cols]";
                        r1++;
                        for (int r = 0; r < table.RowCount; r++)
                        {
                            var parts = new List<string>();
                            for (int c = 0; c < table.ColumnCount; c++)
                                parts.Add(table.DisplayGrid[r, c] ?? "");
                            ws1.Cell(r1, 1).Value = "";
                            ws1.Cell(r1, 2).Value = table.Cells.Any(cl => cl.RowIndex == r &&
                                cl.Kind.Contains("Header", StringComparison.OrdinalIgnoreCase)) ? "table-header" : "table-row";
                            ws1.Cell(r1, 3).Value = string.Join(" │ ", parts);
                            r1++;
                        }
                    }
                }
                else
                {
                    var lines = _lastResult.ExtractedText.Split('\n', StringSplitOptions.RemoveEmptyEntries);
                    foreach (var line in lines)
                    {
                        ws1.Cell(r1, 1).Value = "";
                        ws1.Cell(r1, 2).Value = "text";
                        ws1.Cell(r1, 3).Value = line;
                        r1++;
                    }
                }
                ws1.Columns().AdjustToContents(1.0, 80.0);

                // ── Sheet 2: Structured Fields ──────────────────────────────
                var ws2 = wb.Worksheets.Add("Structured Fields");
                ws2.Cell(1, 1).Value = "Field";
                ws2.Cell(1, 2).Value = "Value";
                ws2.Cell(1, 3).Value = "Confidence (%)";
                StyleHeaderRow(ws2, 3);

                int r2 = 2;
                foreach (var field in _lastResult.StructuredFields)
                {
                    ws2.Cell(r2, 1).Value = field.Key;
                    ws2.Cell(r2, 2).Value = field.Value;
                    ws2.Cell(r2, 3).Value = field.Key.StartsWith("──") ? "—" : $"{field.Confidence:F1}";
                    r2++;
                }
                ws2.Columns().AdjustToContents(1.0, 60.0);

                // ── Sheet 3: Document Structure ─────────────────────────────
                var ws3 = wb.Worksheets.Add("Document Structure");
                ws3.Cell(1, 1).Value = "Section";
                ws3.Cell(1, 2).Value = "Details";
                StyleHeaderRow(ws3, 2);

                int r3 = 2;
                // Pages
                foreach (var p in _lastResult.DocumentPages)
                {
                    ws3.Cell(r3, 1).Value = $"Page {p.PageNumber}";
                    ws3.Cell(r3, 2).Value = $"{p.Width:F0}×{p.Height:F0} {p.Unit}, {p.WordCount} words, {p.LineCount} lines";
                    r3++;
                }
                // KV Pairs
                foreach (var kv in _lastResult.KeyValuePairs)
                {
                    ws3.Cell(r3, 1).Value = $"[P{kv.PageNumber}] {kv.Key}";
                    ws3.Cell(r3, 2).Value = kv.IsEmpty ? "(empty)" : kv.Value;
                    r3++;
                }
                // Selection Marks
                foreach (var sm in _lastResult.SelectionMarks)
                {
                    var icon = sm.State.Equals("selected", StringComparison.OrdinalIgnoreCase) ? "☑" : "☐";
                    ws3.Cell(r3, 1).Value = $"{icon} [P{sm.PageNumber}] {sm.DisplayLabel}";
                    ws3.Cell(r3, 2).Value = $"{sm.State} ({sm.Confidence:F1}%)";
                    r3++;
                }
                ws3.Columns().AdjustToContents(1.0, 80.0);

                // ── Sheet 4: Full JSON (split by line to avoid 32K cell limit) ─
                var ws4 = wb.Worksheets.Add("Full JSON Response");
                ws4.Cell(1, 1).Value = "Line";
                ws4.Cell(1, 2).Value = "JSON Output";
                StyleHeaderRow(ws4, 2);

                var jsonLines = (_lastResult.RawJson ?? "").Split('\n');
                for (int jl = 0; jl < jsonLines.Length; jl++)
                {
                    var line = jsonLines[jl];
                    // Extra safety: if a single line still exceeds 32K, truncate it
                    if (line.Length > 32000)
                        line = line[..32000] + " … [truncated]";
                    ws4.Cell(jl + 2, 1).Value = jl + 1;
                    ws4.Cell(jl + 2, 2).Value = line;
                }
                ws4.Column(1).Width = 10;
                ws4.Column(2).Width = 140;

                wb.SaveAs(dialog.FileName);
                MessageBox.Show("Excel exported successfully with all sections.", "Exported",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed:\n\n{ex.Message}", "Export Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void StyleHeaderRow(ClosedXML.Excel.IXLWorksheet ws, int colCount)
        {
            for (int c = 1; c <= colCount; c++)
            {
                ws.Cell(1, c).Style.Font.Bold = true;
                ws.Cell(1, c).Style.Fill.BackgroundColor = XLColor.FromArgb(30, 45, 75);
                ws.Cell(1, c).Style.Font.FontColor = XLColor.White;
            }
        }

        // ────────────────────────────────────────────────────────────────────
        // HOVER EFFECTS
        // ────────────────────────────────────────────────────────────────────
        private static void ApplyHoverEffect(Button btn, Color normal, Color hover)
        {
            btn.MouseEnter += (_, _) => btn.BackColor = hover;
            btn.MouseLeave += (_, _) => btn.BackColor = normal;
        }

        // ────────────────────────────────────────────────────────────────────
        // MODEL DISPLAY NAME
        // ────────────────────────────────────────────────────────────────────
        private static string GetModelDisplayName(string engine, string modelUsed)
        {
            return engine switch
            {
                "Azure Document Intelligence" => string.IsNullOrEmpty(modelUsed)
                    ? "prebuilt-layout" : modelUsed,
                "Tesseract OCR"               => "LSTM (eng.traineddata)",
                "PaddleOCR"                   => "PP-OCRv4 (det+rec+cls)",
                "EasyOCR"                     => "CRAFT + ResNet (en)",
                "DocTR"                       => "fast_base + crnn_vgg16_bn",
                "Surya OCR"                   => "Surya det + rec (v0.17)",
                "Hybrid (ADI + OSS LLM)" => string.IsNullOrEmpty(modelUsed)
                    ? "ADI + Ollama LLM" : modelUsed,
                "Hybrid (Tesseract + OSS LLM)" => string.IsNullOrEmpty(modelUsed)
                    ? "Tesseract + Ollama LLM" : modelUsed,
                _                             => modelUsed ?? "Unknown"
            };
        }

        // ────────────────────────────────────────────────────────────────────
        // PRICING INFO POPUP
        // ────────────────────────────────────────────────────────────────────
        private void btnPricingInfo_Click(object sender, EventArgs e)
        {
            ShowPricingDialog();
        }

        private void ShowPricingDialog()
        {
            using var dlg  = new Form();
            dlg.Text       = "OCR Engine Pricing Information";
            dlg.Size       = new Size(960, 680);
            dlg.MinimumSize = new Size(720, 480);
            dlg.StartPosition = FormStartPosition.CenterParent;
            dlg.BackColor  = Color.FromArgb(22, 33, 62);
            dlg.ForeColor  = Color.White;
            dlg.FormBorderStyle = FormBorderStyle.Sizable;
            dlg.MaximizeBox = true;
            dlg.MinimizeBox = false;
            dlg.Font       = new Font("Segoe UI", 10.5F);

            var dgv = new DataGridView
            {
                Dock          = DockStyle.Fill,
                ReadOnly      = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                AutoSizeRowsMode  = DataGridViewAutoSizeRowsMode.AllCells,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor   = Color.FromArgb(30, 45, 75),
                GridColor         = Color.FromArgb(60, 80, 110),
                BorderStyle       = BorderStyle.None,
                EnableHeadersVisualStyles = false,
                SelectionMode     = DataGridViewSelectionMode.FullRowSelect,
                Font              = new Font("Segoe UI", 10F),
                ColumnHeadersHeight = 44,
                ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None,
            };

            dgv.DefaultCellStyle.BackColor       = Color.FromArgb(30, 45, 75);
            dgv.DefaultCellStyle.ForeColor        = Color.White;
            dgv.DefaultCellStyle.SelectionBackColor = Color.FromArgb(45, 65, 100);
            dgv.DefaultCellStyle.SelectionForeColor = Color.White;
            dgv.DefaultCellStyle.Padding          = new Padding(8, 6, 8, 6);
            dgv.DefaultCellStyle.WrapMode         = DataGridViewTriState.True;

            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(15, 25, 50);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(180, 210, 240);
            dgv.ColumnHeadersDefaultCellStyle.Font      = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            dgv.ColumnHeadersDefaultCellStyle.Padding   = new Padding(8, 6, 8, 6);

            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Engine",    HeaderText = "OCR Engine",   FillWeight = 22 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Model",     HeaderText = "Model / Tier", FillWeight = 26 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "PerDoc",    HeaderText = "Per Document", FillWeight = 16 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Per1K",     HeaderText = "1,000 Docs",   FillWeight = 18 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Per5K",     HeaderText = "5,000+ Docs",  FillWeight = 18 });

            // Group header style
            var groupStyle = new DataGridViewCellStyle
            {
                BackColor = Color.FromArgb(18, 30, 55),
                ForeColor = Color.FromArgb(130, 180, 240),
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                SelectionBackColor = Color.FromArgb(18, 30, 55),
                SelectionForeColor = Color.FromArgb(130, 180, 240),
                Padding = new Padding(6, 4, 6, 4)
            };

            // Free row style
            var freeStyle = new DataGridViewCellStyle
            {
                ForeColor = Color.FromArgb(100, 220, 130),
                SelectionForeColor = Color.FromArgb(100, 220, 130)
            };

            void AddGroupRow(string title)
            {
                int ri = dgv.Rows.Add("", "", "", "", "");
                dgv.Rows[ri].Cells[0].Value = title;
                dgv.Rows[ri].DefaultCellStyle = groupStyle;
                dgv.Rows[ri].Height = 36;
                // Merge-like: span text via column 0 with extra padding
                var mergedStyle = groupStyle.Clone();
                mergedStyle.Padding = new Padding(12, 4, 6, 4);
                dgv.Rows[ri].Cells[0].Style = mergedStyle;
            }

            void AddDataRow(string engine, string model, string perDoc, string per1K, string per5K, bool isFree = false)
            {
                int ri = dgv.Rows.Add(engine, model, perDoc, per1K, per5K);
                if (isFree)
                    dgv.Rows[ri].DefaultCellStyle = freeStyle;
            }

            // ── Azure Document Intelligence ──
            AddGroupRow("☁️  AZURE DOCUMENT INTELLIGENCE  (cloud — pay per page)");
            AddDataRow("Azure Doc Intel", "prebuilt-read",       "$0.001/pg",  "$1.00 / 1K pg",  "$0.75 / 1K pg");
            AddDataRow("Azure Doc Intel", "prebuilt-layout",     "$0.01/pg",   "$10.00 / 1K pg", "$7.50 / 1K pg");
            AddDataRow("Azure Doc Intel", "prebuilt-document",   "$0.01/pg",   "$10.00 / 1K pg", "$7.50 / 1K pg");
            AddDataRow("Azure Doc Intel", "prebuilt-invoice",    "$0.01/pg",   "$10.00 / 1K pg", "$7.50 / 1K pg");
            AddDataRow("Azure Doc Intel", "Custom models",       "$0.05/pg",   "$50.00 / 1K pg", "Contact MS");

            // ── Open-Source / Free ──
            AddGroupRow("🆓  OPEN-SOURCE ENGINES  (local — free, compute cost only)");
            AddDataRow("Tesseract OCR", "LSTM (v5)",           "Free", "Free", "Free", isFree: true);
            AddDataRow("PaddleOCR",     "PP-OCRv4",            "Free", "Free", "Free", isFree: true);
            AddDataRow("EasyOCR",       "CRAFT + ResNet",      "Free", "Free", "Free", isFree: true);
            AddDataRow("DocTR",         "fast_base + crnn",    "Free", "Free", "Free", isFree: true);
            AddDataRow("Surya OCR",     "Surya det + rec",     "Free", "Free", "Free", isFree: true);

            var lblNote = new Label
            {
                Text      = "ℹ️  Azure prices are approximate (USD, Feb 2026) and vary by region and commitment tier.\n" +
                            "    Tesseract, PaddleOCR, EasyOCR, DocTR, and Surya OCR are free & open-source — you only pay for compute.\n" +
                            "    See each provider's official pricing page for the latest rates.",
                Dock      = DockStyle.Bottom,
                Height    = 80,
                ForeColor = Color.FromArgb(160, 180, 210),
                Font      = new Font("Segoe UI", 9.5F, FontStyle.Italic),
                Padding   = new Padding(14, 8, 14, 8),
                TextAlign = ContentAlignment.MiddleLeft
            };

            dlg.Controls.Add(dgv);
            dlg.Controls.Add(lblNote);
            dlg.ShowDialog(this);
        }

        // ────────────────────────────────────────────────────────────────────
        // CLEANUP
        // ────────────────────────────────────────────────────────────────────
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
            _liveTimer.Dispose();
            DisposeDocPages();
        }
    }
}
