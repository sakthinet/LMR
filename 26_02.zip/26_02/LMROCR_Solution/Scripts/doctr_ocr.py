"""
DocTR (Document Text Recognition) wrapper script for LMROCR_Solution.
Usage: python doctr_ocr.py <file_path>
Output: JSON to stdout ONLY.  All warnings/info go to stderr.

Requires:
    pip install "python-doctr[torch]"
    pip install pypdfium2   (for PDF support if not already installed)
"""
import sys
import json
import os

# Suppress noisy warnings before imports
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
os.environ["DOCTR_CACHE_DIR"] = os.path.join(
    os.path.expanduser("~"), ".cache", "doctr"
)

# Redirect stdout so noisy imports don't pollute our JSON output
_real_stdout = sys.stdout
sys.stdout = sys.stderr


def _extract_lines(exported):
    """
    Parse DocTR export() dict into a flat list of
    {"text": ..., "confidence": ...} dicts.

    Structure: pages -> blocks -> lines -> words
    We join words per line and average word confidences.
    """
    lines = []
    for page in exported.get("pages", []):
        for block in page.get("blocks", []):
            for line in block.get("lines", []):
                words = line.get("words", [])
                if not words:
                    continue
                text = " ".join(w["value"] for w in words).strip()
                if not text:
                    continue
                avg_conf = sum(w["confidence"] for w in words) / len(words)
                lines.append({
                    "text": text,
                    "confidence": round(float(avg_conf), 4)
                })
    return lines


def main():
    if len(sys.argv) < 2:
        sys.stdout = _real_stdout
        print(json.dumps({"error": "No file path provided"}))
        sys.exit(1)

    file_path = sys.argv[1]

    try:
        from doctr.io import DocumentFile
        from doctr.models import ocr_predictor

        # Build the predictor with pretrained weights
        # fast_base (det) + crnn_vgg16_bn (rec) — good speed/accuracy balance
        model = ocr_predictor(
            det_arch="fast_base",
            reco_arch="crnn_vgg16_bn",
            pretrained=True,
            assume_straight_pages=True,
            preserve_aspect_ratio=True,
        )

        # Restore real stdout after noisy imports
        sys.stdout = _real_stdout

        ext = os.path.splitext(file_path)[1].lower()
        output = {"results": []}

        if ext == ".pdf":
            doc = DocumentFile.from_pdf(file_path)
        else:
            doc = DocumentFile.from_images(file_path)

        result = model(doc)
        exported = result.export()
        output["results"] = _extract_lines(exported)

        print(json.dumps(output))

    except ImportError:
        sys.stdout = _real_stdout
        print(json.dumps({
            "error": (
                "DocTR is not installed. Run:\n"
                '  pip install "python-doctr[torch]"'
            )
        }))
        sys.exit(1)
    except Exception as e:
        sys.stdout = _real_stdout
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
