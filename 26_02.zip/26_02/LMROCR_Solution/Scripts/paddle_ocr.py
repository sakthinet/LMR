"""
PaddleOCR wrapper script for LMROCR_Solution.
Usage: python paddle_ocr.py <file_path>
Output: JSON to stdout ONLY.  All warnings/info go to stderr.

Requires PaddleOCR >= 3.x  +  PaddlePaddle (CPU):
    pip install paddlepaddle --extra-index-url https://www.paddlepaddle.org.cn/packages/stable/cpu/
    pip install paddleocr opencv-python pypdfium2
"""
import sys
import json
import os

# ── Must be set BEFORE any paddle / paddlex imports ──────────────
os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"] = "True"
os.environ["FLAGS_call_stack_level"] = "0"
os.environ["FLAGS_use_mkldnn"] = "0"          # avoid oneDNN crash on Windows
os.environ["GLOG_v"] = "0"
os.environ["GLOG_logtostderr"] = "0"

# Redirect stdout so noisy paddle imports don't pollute our JSON output
_real_stdout = sys.stdout
sys.stdout = sys.stderr


def _extract_lines(ocr_result):
    """
    Parse a single OCRResult (PaddleOCR 3.x) into a list of
    {"text": ..., "confidence": ...} dicts.
    """
    lines = []
    texts  = ocr_result.get("rec_texts",  [])
    scores = ocr_result.get("rec_scores", [])
    for text, score in zip(texts, scores):
        t = str(text).strip()
        if t:
            lines.append({"text": t, "confidence": round(float(score), 4)})
    return lines


def main():
    if len(sys.argv) < 2:
        sys.stdout = _real_stdout
        print(json.dumps({"error": "No file path provided"}))
        sys.exit(1)

    file_path = sys.argv[1]

    try:
        from paddleocr import PaddleOCR
        import numpy as np

        # PaddleOCR 3.x – use PP-OCRv4 for much faster CPU performance.
        # PP-OCRv5 is 3-4x slower on CPU with minimal accuracy gain.
        # Disable doc preprocessors to cut startup overhead.
        ocr = PaddleOCR(
            use_textline_orientation=False,
            use_doc_orientation_classify=False,
            use_doc_unwarping=False,
            ocr_version="PP-OCRv4",
            lang="en",
            enable_mkldnn=False,
            device="cpu",
        )
        # Restore real stdout now that noisy imports are done
        sys.stdout = _real_stdout

        ext = os.path.splitext(file_path)[1].lower()
        output = {"results": []}

        if ext == ".pdf":
            try:
                import pypdfium2 as pdfium
            except ImportError:
                print(json.dumps({
                    "error": "pypdfium2 not installed. Run: pip install pypdfium2"
                }))
                sys.exit(1)

            pdf = pdfium.PdfDocument(file_path)
            for page_idx in range(len(pdf)):
                page = pdf[page_idx]
                bitmap = page.render(scale=150 / 72)   # 150 DPI – good balance
                # Convert to numpy array directly (avoid PNG encode/decode)
                np_img = np.array(bitmap.to_pil().convert("RGB"))
                for r in ocr.predict(np_img):
                    output["results"].extend(_extract_lines(r))
        else:
            # Image file — pass path directly to predict()
            for r in ocr.predict(file_path):
                output["results"].extend(_extract_lines(r))

        print(json.dumps(output))

    except ImportError:
        sys.stdout = _real_stdout
        print(json.dumps({
            "error": (
                "PaddleOCR is not installed. Run:\n"
                "  pip install paddlepaddle "
                "--extra-index-url https://www.paddlepaddle.org.cn/packages/stable/cpu/\n"
                "  pip install paddleocr opencv-python pypdfium2"
            )
        }))
        sys.exit(1)
    except Exception as e:
        sys.stdout = _real_stdout
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
