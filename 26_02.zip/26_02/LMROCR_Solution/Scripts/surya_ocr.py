"""
Surya OCR wrapper script for LMROCR_Solution.
Usage: python surya_ocr.py <file_path>
Output: JSON to stdout ONLY.  All warnings/info go to stderr.

Requires:
    pip install surya-ocr "transformers<5"
    pip install pypdfium2   (for PDF support)
"""
import sys
import json
import os
import warnings

# Suppress noisy warnings
warnings.filterwarnings("ignore")
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# Redirect stdout so noisy imports don't pollute our JSON output
_real_stdout = sys.stdout
sys.stdout = sys.stderr


def main():
    if len(sys.argv) < 2:
        sys.stdout = _real_stdout
        print(json.dumps({"error": "No file path provided"}))
        sys.exit(1)

    file_path = sys.argv[1]

    try:
        from PIL import Image
        from surya.foundation import FoundationPredictor
        from surya.recognition import RecognitionPredictor
        from surya.detection import DetectionPredictor

        # Initialize predictors (downloads models on first run)
        det_predictor = DetectionPredictor(device="cpu")
        foundation_predictor = FoundationPredictor(device="cpu")
        rec_predictor = RecognitionPredictor(foundation_predictor)

        # Restore real stdout after noisy imports
        sys.stdout = _real_stdout

        ext = os.path.splitext(file_path)[1].lower()
        images = []

        if ext == ".pdf":
            try:
                import pypdfium2 as pdfium
            except ImportError:
                print(json.dumps({
                    "error": "pypdfium2 not installed. Run: pip install pypdfium2"
                }))
                sys.exit(1)

            pdf = pdfium.PdfDocument(file_path)
            for page_idx in range(len(pdf)):
                page = pdf[page_idx]
                bitmap = page.render(scale=150 / 72)  # 150 DPI
                pil_img = bitmap.to_pil().convert("RGB")
                images.append(pil_img)
        else:
            images.append(Image.open(file_path).convert("RGB"))

        output = {"results": []}

        # Run OCR: RecognitionPredictor accepts det_predictor for detection
        results = rec_predictor(
            images,
            det_predictor=det_predictor,
            recognition_batch_size=4,
            sort_lines=True,
        )

        for ocr_result in results:
            for text_line in ocr_result.text_lines:
                text = text_line.text.strip()
                if text:
                    output["results"].append({
                        "text": text,
                        "confidence": round(float(text_line.confidence), 4)
                    })

        print(json.dumps(output))

    except ImportError as e:
        sys.stdout = _real_stdout
        print(json.dumps({
            "error": (
                f"Surya OCR import error: {e}\n"
                "Install with:\n"
                '  pip install surya-ocr "transformers<5"'
            )
        }))
        sys.exit(1)
    except Exception as e:
        sys.stdout = _real_stdout
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
