﻿namespace LMROCR_Solution
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private Panel pnlTop;
        private Panel pnlTopLeft;
        private Label lblAppTitle;
        private Button btnUpload;
        private Label lblFilePath;
        private Panel pnlTopRight;
        private ComboBox cmbOcrEngine;
        private Button btnRunOcr;
        private Panel pnlStatus;
        private Label lblStatusIcon;
        private Label lblStatus;
        private Label lblConfidence;
        private Label lblModel;
        private Label lblPages;
        private Label lblTime;
        private Panel pnlBottom;
        private Button btnSaveJson;
        private Button btnExportCsv;
        private Button btnPricingInfo;

        // Replaced SplitContainer with Panel + Splitter + Panel
        private Panel pnlLeft;
        private Splitter splitterMain;
        private Panel pnlRight;

        private Panel pnlViewer;
        private Panel pnlViewerToolbar;
        private Label lblViewerTitle;
        private Button btnZoomIn;
        private Button btnZoomOut;
        private Label lblZoomLevel;
        private Button btnPrevPage;
        private Button btnNextPage;
        private Label lblPageNav;
        private Panel pnlViewerCanvas;
        private PictureBox picDocument;
        private Label lblNoDocument;
        private TabControl tabResults;
        private TabPage tabExtractedText;
        private DataGridView dgvExtractedText;
        private DataGridViewTextBoxColumn colExtPage;
        private DataGridViewTextBoxColumn colExtRole;
        private DataGridViewTextBoxColumn colExtContent;
        private TabPage tabStructuredFields;
        private DataGridView dgvStructuredFields;
        private DataGridViewTextBoxColumn colField;
        private DataGridViewTextBoxColumn colValue;
        private DataGridViewTextBoxColumn colConfidence;
        private TabPage tabDocStructure;
        private TreeView tvDocStructure;
        private TabPage tabJsonResponse;
        private TextBox txtJsonResponse;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            pnlTop = new Panel();
            btnPricingInfo = new Button();
            lblFilePath = new Label();
            btnUpload = new Button();
            pnlTopRight = new Panel();
            btnRunOcr = new Button();
            cmbOcrEngine = new ComboBox();
            pnlTopLeft = new Panel();
            lblAppTitle = new Label();
            pnlStatus = new Panel();
            lblStatusIcon = new Label();
            lblStatus = new Label();
            lblModel = new Label();
            lblConfidence = new Label();
            lblPages = new Label();
            lblTime = new Label();
            pnlBottom = new Panel();
            btnSaveJson = new Button();
            btnExportCsv = new Button();
            pnlLeft = new Panel();
            pnlViewer = new Panel();
            pnlViewerCanvas = new Panel();
            picDocument = new PictureBox();
            lblNoDocument = new Label();
            pnlViewerToolbar = new Panel();
            lblViewerTitle = new Label();
            btnZoomOut = new Button();
            btnZoomIn = new Button();
            lblZoomLevel = new Label();
            btnPrevPage = new Button();
            btnNextPage = new Button();
            lblPageNav = new Label();
            splitterMain = new Splitter();
            pnlRight = new Panel();
            tabResults = new TabControl();
            tabExtractedText = new TabPage();
            dgvExtractedText = new DataGridView();
            colExtPage = new DataGridViewTextBoxColumn();
            colExtRole = new DataGridViewTextBoxColumn();
            colExtContent = new DataGridViewTextBoxColumn();
            tabStructuredFields = new TabPage();
            dgvStructuredFields = new DataGridView();
            colField = new DataGridViewTextBoxColumn();
            colValue = new DataGridViewTextBoxColumn();
            colConfidence = new DataGridViewTextBoxColumn();
            tabDocStructure = new TabPage();
            tvDocStructure = new TreeView();
            tabJsonResponse = new TabPage();
            txtJsonResponse = new TextBox();
            pnlTop.SuspendLayout();
            pnlTopRight.SuspendLayout();
            pnlTopLeft.SuspendLayout();
            pnlStatus.SuspendLayout();
            pnlBottom.SuspendLayout();
            pnlLeft.SuspendLayout();
            pnlViewer.SuspendLayout();
            pnlViewerCanvas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picDocument).BeginInit();
            pnlViewerToolbar.SuspendLayout();
            pnlRight.SuspendLayout();
            tabResults.SuspendLayout();
            tabExtractedText.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvExtractedText).BeginInit();
            tabStructuredFields.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvStructuredFields).BeginInit();
            tabDocStructure.SuspendLayout();
            tabJsonResponse.SuspendLayout();
            SuspendLayout();
            // 
            // pnlTop
            // 
            pnlTop.BackColor = Color.FromArgb(22, 33, 62);
            pnlTop.Controls.Add(btnPricingInfo);
            pnlTop.Controls.Add(lblFilePath);
            pnlTop.Controls.Add(btnUpload);
            pnlTop.Controls.Add(pnlTopRight);
            pnlTop.Controls.Add(pnlTopLeft);
            pnlTop.Dock = DockStyle.Top;
            pnlTop.Location = new Point(0, 0);
            pnlTop.Margin = new Padding(4, 5, 4, 5);
            pnlTop.Name = "pnlTop";
            pnlTop.Size = new Size(2000, 130);
            pnlTop.TabIndex = 5;
            // 
            // btnPricingInfo
            // 
            btnPricingInfo.BackColor = Color.FromArgb(65, 75, 95);
            btnPricingInfo.Cursor = Cursors.Hand;
            btnPricingInfo.FlatAppearance.BorderColor = Color.FromArgb(90, 110, 140);
            btnPricingInfo.FlatStyle = FlatStyle.Flat;
            btnPricingInfo.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnPricingInfo.ForeColor = Color.White;
            btnPricingInfo.Location = new Point(469, 73);
            btnPricingInfo.Margin = new Padding(4, 2, 4, 5);
            btnPricingInfo.Name = "btnPricingInfo";
            btnPricingInfo.Size = new Size(236, 47);
            btnPricingInfo.TabIndex = 6;
            btnPricingInfo.Text = "💰  Pricing Info";
            btnPricingInfo.UseVisualStyleBackColor = false;
            btnPricingInfo.Click += btnPricingInfo_Click;
            // 
            // lblFilePath
            // 
            lblFilePath.AutoEllipsis = true;
            lblFilePath.Font = new Font("Segoe UI", 10.5F);
            lblFilePath.ForeColor = Color.FromArgb(160, 190, 220);
            lblFilePath.Location = new Point(713, 14);
            lblFilePath.Margin = new Padding(4, 0, 4, 0);
            lblFilePath.Name = "lblFilePath";
            lblFilePath.Size = new Size(543, 44);
            lblFilePath.TabIndex = 0;
            lblFilePath.Text = "No file selected";
            lblFilePath.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // btnUpload
            // 
            btnUpload.BackColor = Color.FromArgb(52, 73, 94);
            btnUpload.Cursor = Cursors.Hand;
            btnUpload.FlatAppearance.BorderColor = Color.FromArgb(80, 100, 120);
            btnUpload.FlatStyle = FlatStyle.Flat;
            btnUpload.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnUpload.ForeColor = Color.White;
            btnUpload.Location = new Point(469, 14);
            btnUpload.Margin = new Padding(4, 5, 4, 5);
            btnUpload.Name = "btnUpload";
            btnUpload.Size = new Size(236, 44);
            btnUpload.TabIndex = 1;
            btnUpload.Text = "📂  Upload Document";
            btnUpload.UseVisualStyleBackColor = false;
            btnUpload.Click += btnUpload_Click;
            // 
            // pnlTopRight
            // 
            pnlTopRight.BackColor = Color.Transparent;
            pnlTopRight.Controls.Add(btnRunOcr);
            pnlTopRight.Controls.Add(cmbOcrEngine);
            pnlTopRight.Dock = DockStyle.Right;
            pnlTopRight.Location = new Point(1500, 0);
            pnlTopRight.Margin = new Padding(4, 5, 4, 5);
            pnlTopRight.Name = "pnlTopRight";
            pnlTopRight.Padding = new Padding(12, 10, 12, 10);
            pnlTopRight.Size = new Size(500, 130);
            pnlTopRight.TabIndex = 2;
            // 
            // btnRunOcr
            // 
            btnRunOcr.BackColor = Color.FromArgb(39, 174, 96);
            btnRunOcr.Cursor = Cursors.Hand;
            btnRunOcr.FlatAppearance.BorderSize = 0;
            btnRunOcr.FlatStyle = FlatStyle.Flat;
            btnRunOcr.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnRunOcr.ForeColor = Color.White;
            btnRunOcr.Location = new Point(12, 62);
            btnRunOcr.Margin = new Padding(4, 5, 4, 5);
            btnRunOcr.Name = "btnRunOcr";
            btnRunOcr.Size = new Size(476, 56);
            btnRunOcr.TabIndex = 0;
            btnRunOcr.Text = "▶  Run OCR";
            btnRunOcr.UseVisualStyleBackColor = false;
            btnRunOcr.Click += btnRunOcr_Click;
            // 
            // cmbOcrEngine
            // 
            cmbOcrEngine.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbOcrEngine.Font = new Font("Segoe UI", 11F);
            cmbOcrEngine.FormattingEnabled = true;
            cmbOcrEngine.Items.AddRange(new object[] { "Azure Document Intelligence", "Tesseract OCR", "PaddleOCR", "EasyOCR", "DocTR", "Surya OCR", "Hybrid (ADI + OSS LLM)", "Hybrid (Tesseract + OSS LLM)" });
            cmbOcrEngine.Location = new Point(12, 10);
            cmbOcrEngine.Margin = new Padding(4, 5, 4, 5);
            cmbOcrEngine.Name = "cmbOcrEngine";
            cmbOcrEngine.Size = new Size(476, 38);
            cmbOcrEngine.TabIndex = 1;
            // 
            // pnlTopLeft
            // 
            pnlTopLeft.BackColor = Color.Transparent;
            pnlTopLeft.Controls.Add(lblAppTitle);
            pnlTopLeft.Dock = DockStyle.Left;
            pnlTopLeft.Location = new Point(0, 0);
            pnlTopLeft.Margin = new Padding(4, 5, 4, 5);
            pnlTopLeft.Name = "pnlTopLeft";
            pnlTopLeft.Size = new Size(457, 130);
            pnlTopLeft.TabIndex = 3;
            // 
            // lblAppTitle
            // 
            lblAppTitle.Dock = DockStyle.Fill;
            lblAppTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblAppTitle.ForeColor = Color.White;
            lblAppTitle.Location = new Point(0, 0);
            lblAppTitle.Margin = new Padding(4, 0, 4, 0);
            lblAppTitle.Name = "lblAppTitle";
            lblAppTitle.Padding = new Padding(20, 0, 0, 0);
            lblAppTitle.Size = new Size(457, 130);
            lblAppTitle.TabIndex = 0;
            lblAppTitle.Text = "🔍  TCS OCR Engine Studio";
            lblAppTitle.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pnlStatus
            // 
            pnlStatus.BackColor = Color.FromArgb(30, 45, 75);
            pnlStatus.Controls.Add(lblStatusIcon);
            pnlStatus.Controls.Add(lblStatus);
            pnlStatus.Controls.Add(lblModel);
            pnlStatus.Controls.Add(lblConfidence);
            pnlStatus.Controls.Add(lblPages);
            pnlStatus.Controls.Add(lblTime);
            pnlStatus.Dock = DockStyle.Top;
            pnlStatus.Location = new Point(0, 130);
            pnlStatus.Margin = new Padding(4, 5, 4, 5);
            pnlStatus.Name = "pnlStatus";
            pnlStatus.Size = new Size(2000, 93);
            pnlStatus.TabIndex = 4;
            // 
            // lblStatusIcon
            // 
            lblStatusIcon.AutoSize = true;
            lblStatusIcon.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblStatusIcon.ForeColor = Color.FromArgb(100, 210, 100);
            lblStatusIcon.Location = new Point(20, 17);
            lblStatusIcon.Margin = new Padding(4, 0, 4, 0);
            lblStatusIcon.Name = "lblStatusIcon";
            lblStatusIcon.Size = new Size(26, 30);
            lblStatusIcon.TabIndex = 0;
            lblStatusIcon.Text = "●";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            lblStatus.ForeColor = Color.FromArgb(200, 225, 245);
            lblStatus.Location = new Point(46, 18);
            lblStatus.Margin = new Padding(4, 0, 4, 0);
            lblStatus.MaximumSize = new Size(268, 0);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(72, 30);
            lblStatus.TabIndex = 1;
            lblStatus.Text = "Ready";
            // 
            // lblModel
            // 
            lblModel.AutoSize = true;
            lblModel.Font = new Font("Segoe UI", 10.5F);
            lblModel.ForeColor = Color.FromArgb(160, 200, 255);
            lblModel.Location = new Point(320, 18);
            lblModel.Margin = new Padding(4, 0, 4, 0);
            lblModel.Name = "lblModel";
            lblModel.Size = new Size(99, 30);
            lblModel.TabIndex = 5;
            lblModel.Text = "Model: --";
            // 
            // lblConfidence
            // 
            lblConfidence.AutoSize = true;
            lblConfidence.Font = new Font("Segoe UI", 10.5F);
            lblConfidence.ForeColor = Color.FromArgb(180, 210, 240);
            lblConfidence.Location = new Point(620, 18);
            lblConfidence.Margin = new Padding(4, 0, 4, 0);
            lblConfidence.Name = "lblConfidence";
            lblConfidence.Size = new Size(145, 30);
            lblConfidence.TabIndex = 2;
            lblConfidence.Text = "Confidence: --";
            // 
            // lblPages
            // 
            lblPages.AutoSize = true;
            lblPages.Font = new Font("Segoe UI", 10.5F);
            lblPages.ForeColor = Color.FromArgb(180, 210, 240);
            lblPages.Location = new Point(870, 18);
            lblPages.Margin = new Padding(4, 0, 4, 0);
            lblPages.Name = "lblPages";
            lblPages.Size = new Size(94, 30);
            lblPages.TabIndex = 3;
            lblPages.Text = "Pages: --";
            // 
            // lblTime
            // 
            lblTime.AutoSize = true;
            lblTime.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblTime.ForeColor = Color.FromArgb(255, 220, 100);
            lblTime.Location = new Point(1050, 17);
            lblTime.Margin = new Padding(4, 0, 4, 0);
            lblTime.Name = "lblTime";
            lblTime.Size = new Size(137, 30);
            lblTime.TabIndex = 4;
            lblTime.Text = "⏱  Time: --";
            // 
            // pnlBottom
            // 
            pnlBottom.BackColor = Color.FromArgb(22, 33, 62);
            pnlBottom.Controls.Add(btnSaveJson);
            pnlBottom.Controls.Add(btnExportCsv);
            pnlBottom.Dock = DockStyle.Bottom;
            pnlBottom.Location = new Point(0, 1284);
            pnlBottom.Margin = new Padding(4, 5, 4, 5);
            pnlBottom.Name = "pnlBottom";
            pnlBottom.Size = new Size(2000, 83);
            pnlBottom.TabIndex = 3;
            // 
            // btnSaveJson
            // 
            btnSaveJson.BackColor = Color.FromArgb(52, 73, 94);
            btnSaveJson.Cursor = Cursors.Hand;
            btnSaveJson.FlatAppearance.BorderSize = 0;
            btnSaveJson.FlatStyle = FlatStyle.Flat;
            btnSaveJson.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnSaveJson.ForeColor = Color.White;
            btnSaveJson.Location = new Point(17, 15);
            btnSaveJson.Margin = new Padding(4, 5, 4, 5);
            btnSaveJson.Name = "btnSaveJson";
            btnSaveJson.Size = new Size(200, 53);
            btnSaveJson.TabIndex = 0;
            btnSaveJson.Text = "💾  Save JSON";
            btnSaveJson.UseVisualStyleBackColor = false;
            btnSaveJson.Click += btnSaveJson_Click;
            // 
            // btnExportCsv
            // 
            btnExportCsv.BackColor = Color.FromArgb(39, 174, 96);
            btnExportCsv.Cursor = Cursors.Hand;
            btnExportCsv.FlatAppearance.BorderSize = 0;
            btnExportCsv.FlatStyle = FlatStyle.Flat;
            btnExportCsv.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnExportCsv.ForeColor = Color.White;
            btnExportCsv.Location = new Point(229, 15);
            btnExportCsv.Margin = new Padding(4, 5, 4, 5);
            btnExportCsv.Name = "btnExportCsv";
            btnExportCsv.Size = new Size(200, 53);
            btnExportCsv.TabIndex = 1;
            btnExportCsv.Text = "📊  Export Excel";
            btnExportCsv.UseVisualStyleBackColor = false;
            btnExportCsv.Click += btnExportCsv_Click;
            // 
            // pnlLeft
            // 
            pnlLeft.BackColor = Color.FromArgb(55, 55, 65);
            pnlLeft.Controls.Add(pnlViewer);
            pnlLeft.Dock = DockStyle.Left;
            pnlLeft.Location = new Point(0, 223);
            pnlLeft.Margin = new Padding(4, 5, 4, 5);
            pnlLeft.MinimumSize = new Size(314, 0);
            pnlLeft.Name = "pnlLeft";
            pnlLeft.Size = new Size(714, 1061);
            pnlLeft.TabIndex = 2;
            // 
            // pnlViewer
            // 
            pnlViewer.BackColor = Color.FromArgb(55, 55, 65);
            pnlViewer.Controls.Add(pnlViewerCanvas);
            pnlViewer.Controls.Add(pnlViewerToolbar);
            pnlViewer.Dock = DockStyle.Fill;
            pnlViewer.Location = new Point(0, 0);
            pnlViewer.Margin = new Padding(4, 5, 4, 5);
            pnlViewer.Name = "pnlViewer";
            pnlViewer.Size = new Size(714, 1061);
            pnlViewer.TabIndex = 0;
            // 
            // pnlViewerCanvas
            // 
            pnlViewerCanvas.AutoScroll = true;
            pnlViewerCanvas.BackColor = Color.FromArgb(55, 55, 65);
            pnlViewerCanvas.Controls.Add(picDocument);
            pnlViewerCanvas.Controls.Add(lblNoDocument);
            pnlViewerCanvas.Dock = DockStyle.Fill;
            pnlViewerCanvas.Location = new Point(0, 70);
            pnlViewerCanvas.Margin = new Padding(4, 5, 4, 5);
            pnlViewerCanvas.Name = "pnlViewerCanvas";
            pnlViewerCanvas.Size = new Size(714, 991);
            pnlViewerCanvas.TabIndex = 0;
            // 
            // picDocument
            // 
            picDocument.BackColor = Color.Transparent;
            picDocument.Location = new Point(14, 17);
            picDocument.Margin = new Padding(4, 5, 4, 5);
            picDocument.Name = "picDocument";
            picDocument.Size = new Size(543, 867);
            picDocument.SizeMode = PictureBoxSizeMode.Zoom;
            picDocument.TabIndex = 0;
            picDocument.TabStop = false;
            picDocument.Visible = false;
            // 
            // lblNoDocument
            // 
            lblNoDocument.Dock = DockStyle.Fill;
            lblNoDocument.Font = new Font("Segoe UI", 13F);
            lblNoDocument.ForeColor = Color.FromArgb(100, 120, 150);
            lblNoDocument.Location = new Point(0, 0);
            lblNoDocument.Margin = new Padding(4, 0, 4, 0);
            lblNoDocument.Name = "lblNoDocument";
            lblNoDocument.Size = new Size(714, 991);
            lblNoDocument.TabIndex = 1;
            lblNoDocument.Text = "📄\n\nUpload a document\nto preview it here";
            lblNoDocument.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlViewerToolbar
            // 
            pnlViewerToolbar.BackColor = Color.FromArgb(40, 40, 50);
            pnlViewerToolbar.Controls.Add(lblViewerTitle);
            pnlViewerToolbar.Controls.Add(btnZoomOut);
            pnlViewerToolbar.Controls.Add(btnZoomIn);
            pnlViewerToolbar.Controls.Add(lblZoomLevel);
            pnlViewerToolbar.Controls.Add(btnPrevPage);
            pnlViewerToolbar.Controls.Add(btnNextPage);
            pnlViewerToolbar.Controls.Add(lblPageNav);
            pnlViewerToolbar.Dock = DockStyle.Top;
            pnlViewerToolbar.Location = new Point(0, 0);
            pnlViewerToolbar.Margin = new Padding(4, 5, 4, 5);
            pnlViewerToolbar.Name = "pnlViewerToolbar";
            pnlViewerToolbar.Padding = new Padding(9, 10, 9, 10);
            pnlViewerToolbar.Size = new Size(714, 70);
            pnlViewerToolbar.TabIndex = 1;
            // 
            // lblViewerTitle
            // 
            lblViewerTitle.AutoSize = true;
            lblViewerTitle.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            lblViewerTitle.ForeColor = Color.FromArgb(170, 195, 220);
            lblViewerTitle.Location = new Point(11, 22);
            lblViewerTitle.Margin = new Padding(4, 0, 4, 0);
            lblViewerTitle.Name = "lblViewerTitle";
            lblViewerTitle.Size = new Size(198, 30);
            lblViewerTitle.TabIndex = 0;
            lblViewerTitle.Text = "Document Preview";
            // 
            // btnZoomOut
            // 
            btnZoomOut.BackColor = Color.FromArgb(65, 75, 95);
            btnZoomOut.Cursor = Cursors.Hand;
            btnZoomOut.FlatAppearance.BorderColor = Color.FromArgb(90, 110, 140);
            btnZoomOut.FlatStyle = FlatStyle.Flat;
            btnZoomOut.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnZoomOut.ForeColor = Color.White;
            btnZoomOut.Location = new Point(230, 12);
            btnZoomOut.Margin = new Padding(4, 5, 4, 5);
            btnZoomOut.Name = "btnZoomOut";
            btnZoomOut.Size = new Size(40, 47);
            btnZoomOut.TabIndex = 1;
            btnZoomOut.Text = "−";
            btnZoomOut.UseVisualStyleBackColor = false;
            btnZoomOut.Click += btnZoomOut_Click;
            // 
            // btnZoomIn
            // 
            btnZoomIn.BackColor = Color.FromArgb(65, 75, 95);
            btnZoomIn.Cursor = Cursors.Hand;
            btnZoomIn.FlatAppearance.BorderColor = Color.FromArgb(90, 110, 140);
            btnZoomIn.FlatStyle = FlatStyle.Flat;
            btnZoomIn.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnZoomIn.ForeColor = Color.White;
            btnZoomIn.Location = new Point(275, 12);
            btnZoomIn.Margin = new Padding(4, 5, 4, 5);
            btnZoomIn.Name = "btnZoomIn";
            btnZoomIn.Size = new Size(40, 47);
            btnZoomIn.TabIndex = 2;
            btnZoomIn.Text = "+";
            btnZoomIn.UseVisualStyleBackColor = false;
            btnZoomIn.Click += btnZoomIn_Click;
            // 
            // lblZoomLevel
            // 
            lblZoomLevel.AutoSize = true;
            lblZoomLevel.Font = new Font("Segoe UI", 10F);
            lblZoomLevel.ForeColor = Color.FromArgb(180, 200, 225);
            lblZoomLevel.Location = new Point(375, 22);
            lblZoomLevel.Margin = new Padding(4, 0, 4, 0);
            lblZoomLevel.Name = "lblZoomLevel";
            lblZoomLevel.Size = new Size(61, 28);
            lblZoomLevel.TabIndex = 4;
            lblZoomLevel.Text = "100%";
            // 
            // btnPrevPage
            // 
            btnPrevPage.BackColor = Color.FromArgb(65, 75, 95);
            btnPrevPage.Cursor = Cursors.Hand;
            btnPrevPage.FlatAppearance.BorderColor = Color.FromArgb(90, 110, 140);
            btnPrevPage.FlatStyle = FlatStyle.Flat;
            btnPrevPage.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnPrevPage.ForeColor = Color.White;
            btnPrevPage.Location = new Point(440, 12);
            btnPrevPage.Margin = new Padding(4, 5, 4, 5);
            btnPrevPage.Name = "btnPrevPage";
            btnPrevPage.Size = new Size(40, 47);
            btnPrevPage.TabIndex = 5;
            btnPrevPage.Text = "◄";
            btnPrevPage.UseVisualStyleBackColor = false;
            btnPrevPage.Click += btnPrevPage_Click;
            // 
            // btnNextPage
            // 
            btnNextPage.BackColor = Color.FromArgb(65, 75, 95);
            btnNextPage.Cursor = Cursors.Hand;
            btnNextPage.FlatAppearance.BorderColor = Color.FromArgb(90, 110, 140);
            btnNextPage.FlatStyle = FlatStyle.Flat;
            btnNextPage.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            btnNextPage.ForeColor = Color.White;
            btnNextPage.Location = new Point(486, 12);
            btnNextPage.Margin = new Padding(4, 5, 4, 5);
            btnNextPage.Name = "btnNextPage";
            btnNextPage.Size = new Size(40, 47);
            btnNextPage.TabIndex = 6;
            btnNextPage.Text = "►";
            btnNextPage.UseVisualStyleBackColor = false;
            btnNextPage.Click += btnNextPage_Click;
            // 
            // lblPageNav
            // 
            lblPageNav.AutoSize = true;
            lblPageNav.Font = new Font("Segoe UI", 10F);
            lblPageNav.ForeColor = Color.FromArgb(180, 200, 225);
            lblPageNav.Location = new Point(534, 22);
            lblPageNav.Margin = new Padding(4, 0, 4, 0);
            lblPageNav.Name = "lblPageNav";
            lblPageNav.Size = new Size(62, 28);
            lblPageNav.TabIndex = 7;
            lblPageNav.Text = "-- / --";
            // 
            // splitterMain
            // 
            splitterMain.BackColor = Color.FromArgb(80, 100, 130);
            splitterMain.Cursor = Cursors.VSplit;
            splitterMain.Location = new Point(714, 223);
            splitterMain.Margin = new Padding(4, 5, 4, 5);
            splitterMain.MinExtra = 400;
            splitterMain.MinSize = 220;
            splitterMain.Name = "splitterMain";
            splitterMain.Size = new Size(7, 1061);
            splitterMain.TabIndex = 1;
            splitterMain.TabStop = false;
            // 
            // pnlRight
            // 
            pnlRight.BackColor = Color.FromArgb(248, 250, 252);
            pnlRight.Controls.Add(tabResults);
            pnlRight.Dock = DockStyle.Fill;
            pnlRight.Location = new Point(721, 223);
            pnlRight.Margin = new Padding(4, 5, 4, 5);
            pnlRight.MinimumSize = new Size(571, 0);
            pnlRight.Name = "pnlRight";
            pnlRight.Size = new Size(1279, 1061);
            pnlRight.TabIndex = 0;
            // 
            // tabResults
            // 
            tabResults.Controls.Add(tabExtractedText);
            tabResults.Controls.Add(tabStructuredFields);
            tabResults.Controls.Add(tabDocStructure);
            tabResults.Controls.Add(tabJsonResponse);
            tabResults.Dock = DockStyle.Fill;
            tabResults.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabResults.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            tabResults.ItemSize = new Size(220, 36);
            tabResults.Location = new Point(0, 0);
            tabResults.Margin = new Padding(4, 5, 4, 5);
            tabResults.Name = "tabResults";
            tabResults.SelectedIndex = 0;
            tabResults.Size = new Size(1279, 1061);
            tabResults.SizeMode = TabSizeMode.Fixed;
            tabResults.TabIndex = 0;
            tabResults.DrawItem += tabResults_DrawItem;
            // 
            // tabExtractedText
            // 
            tabExtractedText.BackColor = Color.FromArgb(248, 250, 252);
            tabExtractedText.Controls.Add(dgvExtractedText);
            tabExtractedText.Location = new Point(4, 40);
            tabExtractedText.Margin = new Padding(4, 5, 4, 5);
            tabExtractedText.Name = "tabExtractedText";
            tabExtractedText.Padding = new Padding(6, 7, 6, 7);
            tabExtractedText.Size = new Size(1271, 1017);
            tabExtractedText.TabIndex = 0;
            tabExtractedText.Text = "Extracted Text";
            // 
            // dgvExtractedText
            // 
            dgvExtractedText.AllowUserToAddRows = false;
            dgvExtractedText.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(246, 249, 253);
            dgvExtractedText.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvExtractedText.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvExtractedText.BackgroundColor = Color.White;
            dgvExtractedText.BorderStyle = BorderStyle.None;
            dgvExtractedText.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(30, 45, 75);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(30, 45, 75);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvExtractedText.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvExtractedText.ColumnHeadersHeight = 40;
            dgvExtractedText.Columns.AddRange(new DataGridViewColumn[] { colExtPage, colExtRole, colExtContent });
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Window;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 10.5F);
            dataGridViewCellStyle4.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle4.Padding = new Padding(5, 4, 5, 4);
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(198, 220, 246);
            dataGridViewCellStyle4.SelectionForeColor = Color.Black;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dgvExtractedText.DefaultCellStyle = dataGridViewCellStyle4;
            dgvExtractedText.Dock = DockStyle.Fill;
            dgvExtractedText.EnableHeadersVisualStyles = false;
            dgvExtractedText.Font = new Font("Segoe UI", 10.5F);
            dgvExtractedText.GridColor = Color.FromArgb(220, 226, 236);
            dgvExtractedText.Location = new Point(6, 7);
            dgvExtractedText.Margin = new Padding(4, 5, 4, 5);
            dgvExtractedText.Name = "dgvExtractedText";
            dgvExtractedText.ReadOnly = true;
            dgvExtractedText.RowHeadersVisible = false;
            dgvExtractedText.RowHeadersWidth = 62;
            dgvExtractedText.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvExtractedText.Size = new Size(1259, 1003);
            dgvExtractedText.TabIndex = 0;
            // 
            // colExtPage
            // 
            colExtPage.HeaderText = "Page";
            colExtPage.MinimumWidth = 8;
            colExtPage.Name = "colExtPage";
            colExtPage.ReadOnly = true;
            colExtPage.Width = 55;
            // 
            // colExtRole
            // 
            colExtRole.HeaderText = "Role / Type";
            colExtRole.MinimumWidth = 8;
            colExtRole.Name = "colExtRole";
            colExtRole.ReadOnly = true;
            colExtRole.Width = 160;
            // 
            // colExtContent
            // 
            colExtContent.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            colExtContent.DefaultCellStyle = dataGridViewCellStyle3;
            colExtContent.HeaderText = "Content";
            colExtContent.MinimumWidth = 8;
            colExtContent.Name = "colExtContent";
            colExtContent.ReadOnly = true;
            // 
            // tabStructuredFields
            // 
            tabStructuredFields.BackColor = Color.FromArgb(248, 250, 252);
            tabStructuredFields.Controls.Add(dgvStructuredFields);
            tabStructuredFields.Location = new Point(4, 40);
            tabStructuredFields.Margin = new Padding(4, 5, 4, 5);
            tabStructuredFields.Name = "tabStructuredFields";
            tabStructuredFields.Padding = new Padding(6, 7, 6, 7);
            tabStructuredFields.Size = new Size(1271, 1047);
            tabStructuredFields.TabIndex = 1;
            tabStructuredFields.Text = "Structured Fields";
            // 
            // dgvStructuredFields
            // 
            dgvStructuredFields.AllowUserToAddRows = false;
            dgvStructuredFields.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(246, 249, 253);
            dgvStructuredFields.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            dgvStructuredFields.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvStructuredFields.BackgroundColor = Color.White;
            dgvStructuredFields.BorderStyle = BorderStyle.None;
            dgvStructuredFields.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(30, 45, 75);
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 10.5F, FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = Color.White;
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(30, 45, 75);
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dgvStructuredFields.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dgvStructuredFields.ColumnHeadersHeight = 40;
            dgvStructuredFields.Columns.AddRange(new DataGridViewColumn[] { colField, colValue, colConfidence });
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = SystemColors.Window;
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 10.5F);
            dataGridViewCellStyle8.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle8.Padding = new Padding(5, 4, 5, 4);
            dataGridViewCellStyle8.SelectionBackColor = Color.FromArgb(198, 220, 246);
            dataGridViewCellStyle8.SelectionForeColor = Color.Black;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            dgvStructuredFields.DefaultCellStyle = dataGridViewCellStyle8;
            dgvStructuredFields.Dock = DockStyle.Fill;
            dgvStructuredFields.EnableHeadersVisualStyles = false;
            dgvStructuredFields.Font = new Font("Segoe UI", 10.5F);
            dgvStructuredFields.GridColor = Color.FromArgb(220, 226, 236);
            dgvStructuredFields.Location = new Point(6, 7);
            dgvStructuredFields.Margin = new Padding(4, 5, 4, 5);
            dgvStructuredFields.Name = "dgvStructuredFields";
            dgvStructuredFields.ReadOnly = true;
            dgvStructuredFields.RowHeadersVisible = false;
            dgvStructuredFields.RowHeadersWidth = 62;
            dgvStructuredFields.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvStructuredFields.Size = new Size(1259, 1033);
            dgvStructuredFields.TabIndex = 0;
            // 
            // colField
            // 
            colField.HeaderText = "Field";
            colField.MinimumWidth = 120;
            colField.Name = "colField";
            colField.ReadOnly = true;
            colField.Width = 320;
            // 
            // colValue
            // 
            colValue.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.True;
            colValue.DefaultCellStyle = dataGridViewCellStyle7;
            colValue.HeaderText = "Value";
            colValue.MinimumWidth = 8;
            colValue.Name = "colValue";
            colValue.ReadOnly = true;
            // 
            // colConfidence
            // 
            colConfidence.HeaderText = "Confidence (%)";
            colConfidence.MinimumWidth = 100;
            colConfidence.Name = "colConfidence";
            colConfidence.ReadOnly = true;
            colConfidence.Width = 145;
            // 
            // tabDocStructure
            // 
            tabDocStructure.BackColor = Color.FromArgb(248, 250, 252);
            tabDocStructure.Controls.Add(tvDocStructure);
            tabDocStructure.Location = new Point(4, 40);
            tabDocStructure.Margin = new Padding(4, 5, 4, 5);
            tabDocStructure.Name = "tabDocStructure";
            tabDocStructure.Padding = new Padding(6, 7, 6, 7);
            tabDocStructure.Size = new Size(1271, 1047);
            tabDocStructure.TabIndex = 2;
            tabDocStructure.Text = "Document Structure";
            // 
            // tvDocStructure
            // 
            tvDocStructure.BackColor = Color.White;
            tvDocStructure.BorderStyle = BorderStyle.None;
            tvDocStructure.Dock = DockStyle.Fill;
            tvDocStructure.Font = new Font("Segoe UI", 11F);
            tvDocStructure.ForeColor = Color.FromArgb(30, 40, 60);
            tvDocStructure.HideSelection = false;
            tvDocStructure.ItemHeight = 28;
            tvDocStructure.Location = new Point(6, 7);
            tvDocStructure.Margin = new Padding(4, 5, 4, 5);
            tvDocStructure.Name = "tvDocStructure";
            tvDocStructure.Size = new Size(1259, 1033);
            tvDocStructure.TabIndex = 0;
            // 
            // tabJsonResponse
            // 
            tabJsonResponse.BackColor = Color.FromArgb(28, 30, 42);
            tabJsonResponse.Controls.Add(txtJsonResponse);
            tabJsonResponse.Location = new Point(4, 40);
            tabJsonResponse.Margin = new Padding(4, 5, 4, 5);
            tabJsonResponse.Name = "tabJsonResponse";
            tabJsonResponse.Padding = new Padding(6, 7, 6, 7);
            tabJsonResponse.Size = new Size(1271, 1047);
            tabJsonResponse.TabIndex = 3;
            tabJsonResponse.Text = "Full JSON Response";
            // 
            // txtJsonResponse
            // 
            txtJsonResponse.BackColor = Color.FromArgb(28, 30, 42);
            txtJsonResponse.BorderStyle = BorderStyle.None;
            txtJsonResponse.Dock = DockStyle.Fill;
            txtJsonResponse.Font = new Font("Consolas", 11F);
            txtJsonResponse.ForeColor = Color.FromArgb(200, 225, 175);
            txtJsonResponse.Location = new Point(6, 7);
            txtJsonResponse.Margin = new Padding(4, 5, 4, 5);
            txtJsonResponse.Multiline = true;
            txtJsonResponse.Name = "txtJsonResponse";
            txtJsonResponse.ReadOnly = true;
            txtJsonResponse.ScrollBars = ScrollBars.Both;
            txtJsonResponse.Size = new Size(1259, 1033);
            txtJsonResponse.TabIndex = 0;
            txtJsonResponse.WordWrap = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 250, 252);
            ClientSize = new Size(2000, 1367);
            Controls.Add(pnlRight);
            Controls.Add(splitterMain);
            Controls.Add(pnlLeft);
            Controls.Add(pnlBottom);
            Controls.Add(pnlStatus);
            Controls.Add(pnlTop);
            Margin = new Padding(4, 5, 4, 5);
            MinimumSize = new Size(1419, 1119);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TCS OCR Engine Studio";
            Load += Form1_Load;
            pnlTop.ResumeLayout(false);
            pnlTopRight.ResumeLayout(false);
            pnlTopLeft.ResumeLayout(false);
            pnlStatus.ResumeLayout(false);
            pnlStatus.PerformLayout();
            pnlBottom.ResumeLayout(false);
            pnlLeft.ResumeLayout(false);
            pnlViewer.ResumeLayout(false);
            pnlViewerCanvas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)picDocument).EndInit();
            pnlViewerToolbar.ResumeLayout(false);
            pnlViewerToolbar.PerformLayout();
            pnlRight.ResumeLayout(false);
            tabResults.ResumeLayout(false);
            tabExtractedText.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvExtractedText).EndInit();
            tabStructuredFields.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvStructuredFields).EndInit();
            tabDocStructure.ResumeLayout(false);
            tabJsonResponse.ResumeLayout(false);
            tabJsonResponse.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
    }
}
