# OCR Engine Studio - Configuration & Troubleshooting

## Fixes Applied

### 1. SplitterDistance Runtime Error - FIXED ✅
**Error**: `System.InvalidOperationException: 'SplitterDistance must be between Panel1MinSize and Width - Panel2MinSize.'`

**Root Cause**: The `SplitContainer` was trying to set the splitter position before the form was properly sized.

**Solution**: Updated `Form1_Load` to:
- Calculate minimum required width
- Check if form is large enough before setting splitter
- Use safe min/max bounds for the splitter distance

### 2. Azure Document Intelligence Authentication Error
**Error**: `Access denied due to invalid subscription key or wrong API endpoint` (HTTP 401)

**Current Configuration**:
```json
{
  "Azure": {
    "Endpoint": "https://testlmr.cognitiveservices.azure.com/",
    "ApiKey": "6t1X44lBfLbT1TO7cb3GVP8bvSXle7lFHU5ENoFiGrDpqcs99cLzJQQJ99CBACYeBjFXJ3w3AAALACOGBlAl"
  }
}
```

**Troubleshooting Steps**:

#### Step 1: Verify Azure Resource
1. Go to Azure Portal → Your Document Intelligence resource (`testlmr`)
2. Click "Keys and Endpoint" in the left menu
3. Verify:
   - **Location/Region**: `eastus`
   - **Endpoint**: Should match exactly
   - **KEY 1**: Should match exactly (case-sensitive!)

#### Step 2: Check Endpoint Format
Azure Document Intelligence accepts two formats:
- ✅ `https://testlmr.cognitiveservices.azure.com/`
- ✅ `https://eastus.api.cognitive.microsoft.com/formrecognizer/`

If the current endpoint doesn't work, try the regional format:
```json
"Endpoint": "https://eastus.api.cognitive.microsoft.com/formrecognizer/"
```

#### Step 3: Verify API Key
- API keys are case-sensitive
- No spaces before/after
- Use KEY 1 or KEY 2 (both should work)
- Try regenerating a key if still failing

#### Step 4: Check Resource Status
- Ensure the resource is in "Running" state
- Ensure billing is active (free tier works for testing)
- Check quotas haven't been exceeded

### 3. Enhanced Error Messages
The application now shows:
- Which endpoint was used
- First 8 characters of the API key (for verification)
- Specific HTTP status codes
- Suggested fixes

---

## Testing Instructions

### Test 1: Verify SplitterDistance Fix
1. Run the application
2. Application should start without errors
3. Resize the window - no crashes should occur

### Test 2: Verify Azure Connection
1. Click "Upload Document"
2. Select a PDF or image file
3. Select "Azure Document Intelligence" from dropdown
4. Click "Run OCR"
5. **If you get error**: Note the exact endpoint and key prefix shown
6. Compare with Azure Portal values

### Test 3: Alternative OCR Engines
If Azure fails, test the other engines:

**Tesseract** (should work):
- Only supports images (not PDF)
- Uses local `tessdata` folder

**EasyOCR** (should work):
- Python required
- `easyocr` package installed

**PaddleOCR** (may not work):
- Requires Python 3.10-3.12
- Your Python 3.14 is too new

---

## Common Azure Issues

### Issue: "401 Unauthorized"
**Solution**: Wrong API key or endpoint
- Double-check spelling/capitalization
- Ensure no extra spaces
- Try KEY 2 instead of KEY 1

### Issue: "403 Forbidden"
**Solution**: Resource quota exceeded or billing issue
- Check Azure Portal for alerts
- Verify free tier quota (500 pages/month)

### Issue: "404 Not Found"
**Solution**: Wrong endpoint URL
- Check resource name in URL matches Azure Portal
- Try regional endpoint format

### Issue: "429 Too Many Requests"
**Solution**: Rate limit exceeded
- Wait a few minutes
- Free tier: max 20 requests/minute

---

## Next Steps

1. **Run the application** to verify the SplitterDistance fix
2. **Test with a document** using Azure DI
3. **If Azure fails**, copy the error message showing endpoint/key
4. **Verify in Azure Portal** that values match exactly
5. **Try alternative endpoint format** if needed

The application will now show detailed diagnostic information when Azure fails, making it easier to identify the exact issue.
