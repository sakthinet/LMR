# OCR Engines Comparison — LMROCR_Solution

> Last updated: June 2025

This document compares the **6 OCR engines** integrated into the LMROCR_Solution application.

---

## Quick Comparison Table

| Feature | Azure Doc Intel | Tesseract OCR | PaddleOCR | EasyOCR | DocTR | Surya OCR |
|---|---|---|---|---|---|---|
| **Type** | Cloud API | Local (C#) | Local (Python) | Local (Python) | Local (Python) | Local (Python) |
| **Cost** | Pay-per-page | Free | Free | Free | Free | Free |
| **License** | Proprietary | Apache 2.0 | Apache 2.0 | Apache 2.0 | Apache 2.0 | GPL 3.0 |
| **GPU Required** | N/A (cloud) | No | No (optional) | No (optional) | No (optional) | No (optional) |
| **PDF Support** | Native | Via PDFtoImage | Via pypdfium2 | Via pypdfium2 | Native | Via pypdfium2 |
| **Multilingual** | 300+ langs | 100+ langs | 80+ langs | 80+ langs | 9 langs | 90+ langs |
| **Handwriting** | Yes | Limited | Limited | Limited | No | Yes |
| **Table Extraction** | Yes | No | No | No | No | No |
| **Layout Analysis** | Yes | Basic | Basic | No | Yes | Yes |
| **Internet Required** | Yes | No | No | No | No | No |

---

## Detailed Engine Profiles

### 1. Azure Document Intelligence (Cloud)

- **Provider:** Microsoft Azure
- **Model Used:** `prebuilt-layout`
- **Technology:** Cloud-based deep learning models
- **Pricing:**
  - `prebuilt-read`: \$0.001/page
  - `prebuilt-layout`: \$0.01/page
  - `prebuilt-document` / `prebuilt-invoice`: \$0.01/page
  - Custom models: \$0.05/page
- **Strengths:**
  - Highest accuracy across all document types
  - Rich structured output (tables, key-value pairs, selection marks)
  - Handles complex layouts, handwriting, and forms
  - No local compute needed
  - Continuous model improvements by Microsoft
- **Weaknesses:**
  - Requires internet connection and Azure subscription
  - Per-page cost adds up at scale
  - Data leaves your network (privacy consideration)
  - Latency depends on network speed
- **Best For:** Production workloads requiring highest accuracy, structured data extraction, form processing

---

### 2. Tesseract OCR (Local C#)

- **Provider:** Google (open-source)
- **Model Used:** `LSTM (eng.traineddata)`
- **Technology:** LSTM neural network, NuGet package (`Tesseract` for .NET)
- **Runtime:** C# — no Python required
- **Pricing:** Free
- **Strengths:**
  - Mature, battle-tested (20+ years)
  - Fastest startup — no Python or model download needed
  - Smallest memory footprint
  - 100+ language support
  - No external dependencies beyond NuGet
- **Weaknesses:**
  - Lower accuracy on complex layouts
  - Struggles with low-quality scans, skewed text, colored backgrounds
  - No built-in table or structure extraction
  - Requires well-preprocessed images for best results
- **Best For:** Clean, well-scanned documents with simple layouts; environments where Python is unavailable

---

### 3. PaddleOCR (Local Python)

- **Provider:** Baidu (open-source)
- **Model Used:** `PP-OCRv4 (det + rec + cls)`
- **Technology:** PaddlePaddle deep learning framework
- **Runtime:** Python 3.12 via subprocess
- **Pricing:** Free
- **Strengths:**
  - Excellent accuracy-to-speed ratio
  - Strong on dense text, multi-line documents
  - Good CJK (Chinese/Japanese/Korean) support
  - Active development with regular model updates
  - Lightweight compared to Transformer-based models
- **Weaknesses:**
  - First-run model download (~150 MB)
  - PaddlePaddle framework less common than PyTorch/TensorFlow
  - Python version sensitivity (requires Python ≤ 3.12)
  - oneDNN issues on some Windows machines (mitigated via `FLAGS_use_mkldnn=0`)
- **Speed:** ~16 seconds/page on CPU (PP-OCRv4)
- **Best For:** High-throughput document processing, multilingual documents with CJK content

---

### 4. EasyOCR (Local Python)

- **Provider:** JaidedAI (open-source)
- **Model Used:** `CRAFT + ResNet (en)`
- **Technology:** CRAFT text detection + ResNet recognition (PyTorch)
- **Runtime:** Python 3.12 via subprocess
- **Pricing:** Free
- **Strengths:**
  - Simple API, easy to extend
  - Good accuracy on natural scene text (signs, photos)
  - 80+ language support with community-contributed models
  - Built on well-supported PyTorch ecosystem
- **Weaknesses:**
  - Slower than PaddleOCR on CPU
  - Higher memory usage due to PyTorch
  - Less accurate on dense document text compared to PaddleOCR
  - First-run model download (~100 MB)
- **Speed:** ~20–30 seconds/page on CPU
- **Best For:** Scene text recognition (photos, signage), quick prototyping

---

### 5. DocTR — Document Text Recognition (Local Python)

- **Provider:** Mindee (open-source)
- **Model Used:** `fast_base` (detection) + `crnn_vgg16_bn` (recognition)
- **Technology:** Deep learning with PyTorch backend
- **Runtime:** Python 3.12 via subprocess
- **Pricing:** Free
- **Strengths:**
  - Excellent document layout understanding
  - High accuracy on structured documents (invoices, receipts, forms)
  - Native PDF support (no pypdfium2 needed)
  - Word-level and line-level confidence scores
  - Active development by Mindee
  - Clean, well-documented Python API
- **Weaknesses:**
  - Fewer supported languages compared to PaddleOCR/EasyOCR
  - Higher memory usage (~1–2 GB)
  - Slower cold start (model loading)
  - First-run model download (~200 MB)
- **Speed:** ~15–25 seconds/page on CPU
- **Best For:** Document-centric OCR (invoices, receipts, forms), high-accuracy requirements without cloud

---

### 6. Surya OCR (Local Python)

- **Provider:** VikParuchuri (open-source)
- **Model Used:** `Surya det + rec (v0.17)`
- **Technology:** Custom Transformer models (detection + recognition)
- **Runtime:** Python 3.12 via subprocess
- **Pricing:** Free (GPL 3.0 license — note copyleft requirement)
- **Strengths:**
  - State-of-the-art accuracy on benchmarks
  - Excellent multilingual support (90+ languages)
  - Strong handwriting recognition
  - Advanced layout analysis and reading order detection
  - Line-level detection with polygon boundaries
  - Active, fast-moving development
- **Weaknesses:**
  - Heavier models — larger download (~500 MB+)
  - Higher memory usage (~2–3 GB)
  - GPL 3.0 license (copyleft — commercial use may require compliance)
  - Requires `transformers<5` due to API compatibility
  - Slower initial inference due to model loading
- **Speed:** ~20–40 seconds/page on CPU (first run slower due to model download)
- **Best For:** Multilingual documents, handwriting, research/academic use, when highest accuracy is needed locally

---

## Performance Summary (CPU-only, approximate)

| Engine | Cold Start | Per-Page Speed | Memory Usage | Model Size |
|---|---|---|---|---|
| Azure Doc Intel | N/A | 2–5s (network) | Minimal | Cloud |
| Tesseract OCR | < 1s | 1–3s | ~100 MB | ~15 MB |
| PaddleOCR (v4) | ~5s | ~16s | ~500 MB | ~150 MB |
| EasyOCR | ~5s | ~20–30s | ~800 MB | ~100 MB |
| DocTR | ~8s | ~15–25s | ~1.2 GB | ~200 MB |
| Surya OCR | ~10s | ~20–40s | ~2.5 GB | ~500 MB |

> **Note:** All times are approximate and measured on CPU (no GPU). Performance varies significantly with hardware, document complexity, and page content. GPU acceleration can improve Python-based engines by 5–10x.

---

## Choosing the Right Engine

| Scenario | Recommended Engine |
|---|---|
| **Highest accuracy, budget available** | Azure Document Intelligence |
| **Fast, no Python, simple documents** | Tesseract OCR |
| **Best free accuracy-to-speed ratio** | PaddleOCR (PP-OCRv4) |
| **Scene text / photos** | EasyOCR |
| **Document forms / invoices (local)** | DocTR |
| **Multilingual / handwriting (local)** | Surya OCR |
| **Air-gapped / offline environment** | Tesseract OCR or PaddleOCR |
| **Batch processing at scale** | Azure Doc Intel or PaddleOCR |

---

## Architecture Notes

- **Cloud engine** (Azure) communicates via REST API — requires `Azure:Endpoint` and `Azure:ApiKey` in `appsettings.json`.
- **C# engine** (Tesseract) runs in-process via NuGet package — no subprocess.
- **Python engines** (PaddleOCR, EasyOCR, DocTR, Surya) run as subprocesses via `Process.Start()`:
  - Python path configured in `appsettings.json` → `Python:ExecutablePath`
  - Scripts located in `Scripts/` folder (copied to output on build)
  - JSON output on stdout, warnings/logs on stderr
  - 5-minute timeout with process kill on expiry
  - Shared `ParseCliOutput()` method in `PaddleOcrService` for JSON → `OcrResult` mapping

---

## Installation Requirements

```bash
# Python 3.12 (required for PaddleOCR compatibility)
# All Python packages:
pip install paddlepaddle --extra-index-url https://www.paddlepaddle.org.cn/packages/stable/cpu/
pip install paddleocr opencv-python pypdfium2
pip install easyocr
pip install "python-doctr[torch]"
pip install surya-ocr "transformers<5"
```

| Engine | NuGet / pip Package | Version |
|---|---|---|
| Azure Doc Intel | `Azure.AI.DocumentIntelligence` | Latest |
| Tesseract OCR | `Tesseract` (NuGet) | Latest |
| PaddleOCR | `paddleocr` + `paddlepaddle` | 3.4.0 / 3.3.0 |
| EasyOCR | `easyocr` | 1.7.2 |
| DocTR | `python-doctr[torch]` | 1.0.1 |
| Surya OCR | `surya-ocr` | 0.17.1 |
