You are an AI coding agent working inside the Visual Studio Code workspace for a .NET 8 WinForms
solution called LMROCR_Solution. Your task is to implement a Hybrid OCR engine that combines
Azure Document Intelligence (ADI) with a local open-source vision LLM served by Ollama.

Read every instruction carefully before making any change. Complete all steps in order.
Do not modify any file unless explicitly told to. Do not change any existing method signatures,
class names, or namespaces. All existing engines (Azure, Tesseract, PaddleOCR, EasyOCR) must
continue to work exactly as before after your changes.

---

## UNDERSTAND THE EXISTING STRUCTURE FIRST

Before writing any code, read these files in full so you understand the patterns used:

1. Read  Models/OcrResult.cs
2. Read  Services/IOcrService.cs
3. Read  Services/OcrServiceFactory.cs
4. Read  Services/AzureOcrService.cs
5. Read  Form1.cs  — focus on: btnRunOcr_Click, DisplayResults, SetStatusCompleted,
         GetModelDisplayName, and the cmbOcrEngine usage
6. Read  Form1.Designer.cs — find where cmbOcrEngine.Items are populated
7. Read  appsettings.json — understand the existing config key structure

---

## FILE 1 — CREATE  Services/OllamaVisionService.cs  (new file)

Create a new file at  Services/OllamaVisionService.cs  in namespace LMROCR_Solution.Services.

This class is a lightweight HTTP client for the Ollama local REST API.
It has NO dependency on any new NuGet package — use only System.Net.Http and System.Text.Json
which are already available in .NET 8.

The class must have:

CONSTRUCTOR
  Parameters: string baseUrl, string model, int timeoutSeconds = 120
  Creates a private HttpClient with BaseAddress = baseUrl (trimmed trailing slash + "/")
  and Timeout = TimeSpan.FromSeconds(timeoutSeconds).
  Stores model in a private readonly field _model.

METHOD: Task<bool> IsAvailableAsync()
  Calls GET  api/tags  on the Ollama server.
  Parses the JSON response — the root object has a "models" array.
  Each model object has a "name" string property.
  Returns true if any model name starts with _model (case-insensitive).
  Returns false on any exception or non-success status.

METHOD: Task<string> GenerateAsync(byte[] pageImagePng, string prompt)
  Converts pageImagePng to a base64 string.
  POSTs to  api/generate  with a JSON body containing these fields:
    "model"   → _model
    "prompt"  → prompt
    "images"  → [ base64string ]
    "stream"  → false
    "format"  → "json"
  Parses the JSON response — root object has a "response" string field.
  Returns the value of "response". Returns "" if parsing fails.

Use private sealed record or class types for the Ollama request/response JSON shapes.
Use System.Text.Json.Serialization.JsonPropertyName attributes to map camelCase JSON fields.

---

## FILE 2 — CREATE  Services/HybridOcrService.cs  (new file)

Create a new file at  Services/HybridOcrService.cs  in namespace LMROCR_Solution.Services.
This class implements IOcrService.

FIELDS AND PROPERTIES
  private readonly AzureOcrService     _adiService
  private readonly OllamaVisionService _ollama
  public double LlmConfidenceThreshold  — default value 80.0
    Pages with AverageConfidence below this will be sent to the LLM.

CONSTRUCTOR
  Parameters:
    string adiEndpoint
    string adiApiKey
    string ollamaBaseUrl
    string ollamaModel
    double llmConfidenceThreshold = 80.0
    int    ollamaTimeoutSeconds   = 120
  Creates _adiService = new AzureOcrService(adiEndpoint, adiApiKey)
  Creates _ollama     = new OllamaVisionService(ollamaBaseUrl, ollamaModel, ollamaTimeoutSeconds)
  Assigns LlmConfidenceThreshold

METHOD: Task<OcrResult> ProcessAsync(string filePath)
  This is the main pipeline. Implement it in this exact order:

  STEP A — ADI first pass
    Call await _adiService.ProcessAsync(filePath) to get adiResult.
    Append " [Hybrid]" to adiResult.ModelUsed so the UI shows it came through the hybrid path.

  STEP B — Check Ollama availability
    Call await _ollama.IsAvailableAsync().
    If false: add one HybridCorrection to adiResult.HybridCorrections with
      Stage = "Ollama Unavailable"
      CorrectedText = "Start Ollama: run 'ollama serve' and ensure the model is pulled via 'ollama pull <model>'"
      WasApplied = false
    Append " [Ollama offline — ADI only]" to adiResult.ModelUsed and return adiResult early.

  STEP C — Identify low-confidence pages
    Loop through adiResult.DocumentPages.
    Collect PageNumber for any page where adiResult.AverageConfidence < LlmConfidenceThreshold.
    Note: use AverageConfidence as a proxy for all pages in the POC (per-page confidence
    requires re-parsing the raw ADI response which is out of scope).
    If no pages found but AverageConfidence < LlmConfidenceThreshold, add page 1.
    If the list is empty after this: add one HybridCorrection with
      Stage = "LLM Pass Skipped"
      CorrectedText = "All pages met confidence threshold. No LLM intervention needed."
      WasApplied = false
    Append " [LLM: skipped, confidence OK]" to adiResult.ModelUsed and return adiResult early.

  STEP D — Render page images
    Implement a private helper method List<byte[]> RenderPageImages(string filePath).
    For PDF files (extension .pdf):
      Use PDFtoImage.Conversion.ToImages() with RenderOptions(Dpi: 150).
      Encode each page as PNG at quality 85 using SkiaSharp SKEncodedImageFormat.Png.
      Return as List<byte[]>.
    For image files (all other extensions):
      Decode with SKBitmap.Decode(filePath), encode as PNG at quality 85.
      Return as a single-item List<byte[]>.
    Important: materialise the full list before closing the PDF file stream
    (Conversion.ToImages is lazy — do not iterate it after stream disposal).

  STEP E — Extract per-page text from adiResult
    Implement a private helper method Dictionary<int, string> ExtractPageTexts(OcrResult result).
    Split result.ExtractedText on newline.
    Lines matching the pattern  "─── Page N ───"  (where N is a digit) indicate a new page.
    Group all following lines under that page number key.
    Return the dictionary. If no separators exist, put everything under key 1.

  STEP F — LLM correction pass
    For each page number in the low-confidence list:
      Skip if page index is out of range in the rendered images list.
      Get the page image bytes and the ADI text for that page from ExtractPageTexts output.
      Call a private helper string BuildCorrectionPrompt(string adiText, int pageNumber).
        The prompt must:
        - Identify this as an HMLR legal document (TR1, TP1, or Mortgage Deed)
        - Show the ADI extracted text and ask the LLM to compare it against the image
        - Ask the LLM to return corrections ONLY for words it is confident are wrong
        - Emphasise: names, title numbers (format like AGL123456), amounts in words and
          figures, dates, postcodes, and legal terms
        - Instruct the LLM to return ONLY valid JSON — no markdown, no extra text
        - Specify the exact JSON structure to return:
            { "corrections": [ { "original": "", "corrected": "", "confidence": 0.0,
              "reason": "" } ], "page_summary": "" }
        - State that if no corrections are needed, return { "corrections": [], "page_summary": "..." }
      Call await _ollama.GenerateAsync(pageImageBytes, prompt).
      Wrap the call in try/catch — on exception, add a HybridCorrection with Stage = "LLM Error"
      and WasApplied = false and continue to the next page.

  STEP G — Parse LLM response
    Implement a private static LlmCorrectionResponse? ParseLlmResponse(string rawJson).
    Strip any markdown code fences (lines starting with ``` ).
    Find the first { and last } and extract just that substring.
    Deserialize as LlmCorrectionResponse using JsonSerializer with PropertyNameCaseInsensitive = true.
    Return null on any exception.
    LlmCorrectionResponse is a private sealed class with:
      List<LlmFieldCorrection> Corrections  (json: "corrections")
      string PageSummary                    (json: "page_summary")
    LlmFieldCorrection is a private sealed class with:
      string Original    (json: "original")
      string Corrected   (json: "corrected")
      double Confidence  (json: "confidence")
      string Reason      (json: "reason")

  STEP H — Apply corrections and build HybridCorrection records
    For each correction in the parsed response:
      If Original and Corrected differ (case-insensitive comparison):
        Replace Original with Corrected in adiResult.ExtractedText (case-sensitive Replace).
        For each FieldResult in adiResult.StructuredFields whose Value contains Original:
          Replace Original with Corrected in Value.
          Update Confidence to Max(existing, correction.Confidence * 100).
        Set wasApplied = true.
      Add a HybridCorrection to adiResult.HybridCorrections with all fields populated.
    If PageSummary is not empty, add a HybridCorrection with Stage = "Page Summary"
    and WasApplied = false.

  STEP I — Add hybrid summary rows to StructuredFields
    Append these FieldResult rows to adiResult.StructuredFields:
      Key = "── HYBRID LLM CORRECTIONS ──",  Value = "",  Confidence = 100
      Key = "LLM Model",   Value = "Ollama (see appsettings.json → Hybrid:OllamaModel)",  Confidence = 100
      Key = "Pages Reviewed by LLM",  Value = comma-joined list like "P1, P3",  Confidence = 100
      Key = "Corrections Applied",    Value = count of WasApplied corrections as string,  Confidence = 100
    For each correction where WasApplied = true, add a FieldResult:
      Key   = "  ✏ [P{pageNumber}] {first 40 chars of OriginalText}"
      Value = first 80 chars of CorrectedText
      Confidence = LlmConfidence * 100

  STEP J — Recalculate confidence and finalise
    If any corrections were applied:
      Average adiResult.AverageConfidence with the LlmConfidence * 100 values of applied corrections.
      Assign the result back to adiResult.AverageConfidence.
    Set adiResult.ModelUsed = "ADI prebuilt-layout + Ollama LLM ({N} corrections)"
    where N is the count of applied corrections.
    Rebuild adiResult.RawJson using a private helper BuildHybridJson(adiResult, corrections, reviewedPages).
    The JSON should wrap the existing ADI data plus a HybridCorrections array.
    Return adiResult.

---

## FILE 3 — MODIFY  Models/OcrResult.cs

Open the existing OcrResult.cs. Make these two additions only. Do not change anything else.

ADDITION 1 — Add a new property to the OcrResult class, after the ModelUsed property:

    /// <summary>
    /// Populated only when using HybridOcrService.
    /// Empty list = ADI-only run or all pages met the confidence threshold.
    /// </summary>
    public List<HybridCorrection> HybridCorrections { get; set; } = [];

    /// <summary>True if any LLM corrections were applied to the extracted text.</summary>
    public bool HasLlmCorrections => HybridCorrections.Any(c => c.WasApplied);

ADDITION 2 — Add a new public class at the bottom of the file, outside OcrResult:

    public class HybridCorrection
    {
        /// <summary>1-based page number. 0 = pipeline-level message.</summary>
        public int    PageNumber    { get; set; }

        /// <summary>
        /// Pipeline stage. Values: "LLM Correction", "Page Summary", "LLM Error",
        /// "Parse Error", "LLM Pass Skipped", "Ollama Unavailable".
        /// </summary>
        public string Stage         { get; set; } = "";

        /// <summary>Original text as extracted by ADI.</summary>
        public string OriginalText  { get; set; } = "";

        /// <summary>LLM's corrected version.</summary>
        public string CorrectedText { get; set; } = "";

        /// <summary>LLM self-reported confidence (0.0–1.0).</summary>
        public double LlmConfidence { get; set; }

        /// <summary>One-line reason from the LLM.</summary>
        public string Reason        { get; set; } = "";

        /// <summary>True if this correction was patched into OcrResult.ExtractedText.</summary>
        public bool   WasApplied    { get; set; }
    }

---

## FILE 4 — MODIFY  Services/OcrServiceFactory.cs

Open the existing OcrServiceFactory.cs. Find the switch expression inside the Create method.
It currently has cases for "Azure Document Intelligence", "Tesseract OCR", "PaddleOCR", "EasyOCR".

Add ONE new case immediately before the _ => throw line:

    "Hybrid (ADI + OSS LLM)" => new HybridOcrService(
        adiEndpoint:            configuration["Azure:Endpoint"]              ?? "",
        adiApiKey:              configuration["Azure:ApiKey"]               ?? "",
        ollamaBaseUrl:          configuration["Hybrid:OllamaBaseUrl"]       ?? "http://localhost:11434",
        ollamaModel:            configuration["Hybrid:OllamaModel"]         ?? "qwen2-vl",
        llmConfidenceThreshold: double.TryParse(
                                    configuration["Hybrid:ConfidenceThreshold"],
                                    out var t) ? t : 80.0,
        ollamaTimeoutSeconds:   int.TryParse(
                                    configuration["Hybrid:OllamaTimeoutSeconds"],
                                    out var ts) ? ts : 120),

Do not change any other line in this file.

---

## FILE 5 — MODIFY  Form1.Designer.cs

Open Form1.Designer.cs. Find the line that calls cmbOcrEngine.Items.AddRange.
It adds the existing engine names as an object array.

Add "Hybrid (ADI + OSS LLM)" as the last item in that array, before the closing }):

    "Hybrid (ADI + OSS LLM)"

Do not change anything else in this file.

---

## FILE 6 — MODIFY  Form1.cs

Make exactly 3 targeted changes. Do not change any other code.

CHANGE 1 — Inside SetStatusCompleted(), find the shortEngine switch expression.
It currently has one case: "Azure Document Intelligence" => "Azure Doc Intel".
Add a second case immediately after it:

    "Hybrid (ADI + OSS LLM)" => "Hybrid ADI+LLM",

CHANGE 2 — Inside GetModelDisplayName(), find the return switch expression.
It currently has cases for the 4 existing engines followed by _ => modelUsed ?? "Unknown".
Add a new case immediately before the _ fallthrough:

    "Hybrid (ADI + OSS LLM)" => string.IsNullOrEmpty(modelUsed)
        ? "ADI + Ollama LLM" : modelUsed,

CHANGE 3 — Inside DisplayResults(), at the very end of the method body (after the last
lblPages.Text assignment), add the following block:

    // Highlight LLM-corrected rows in the Structured Fields tab
    if (result.HasLlmCorrections)
    {
        foreach (DataGridViewRow row in dgvStructuredFields.Rows)
        {
            var key = row.Cells["colField"].Value?.ToString() ?? "";
            if (key.StartsWith("  ✏"))
            {
                row.DefaultCellStyle.BackColor = Color.FromArgb(20, 60, 60);
                row.DefaultCellStyle.ForeColor = Color.FromArgb(100, 220, 200);
            }
        }

        var corrCount = result.HybridCorrections.Count(c => c.WasApplied);
        if (corrCount > 0)
            SetStatusReady($"Hybrid complete — {corrCount} LLM correction(s) applied");
    }

---

## FILE 7 — MODIFY  appsettings.json

Open appsettings.json. Add the following section as a new top-level key,
alongside the existing "Azure", "Tesseract", and "Python" sections.
Do not remove or alter any existing keys.

    "Hybrid": {
        "OllamaBaseUrl":          "http://localhost:11434",
        "OllamaModel":            "qwen2-vl",
        "ConfidenceThreshold":    "80",
        "OllamaTimeoutSeconds":   "120"
    }

---

## VERIFICATION CHECKLIST

After making all changes, confirm the following before finishing:

1. Solution builds with zero errors and zero new warnings.
2. No existing service class was modified (AzureOcrService, TesseractOcrService,
   PaddleOcrService, EasyOcrService, IOcrService).
3. OcrResult.cs still has all its original properties — only two additions were made.
4. OcrServiceFactory.cs switch now has exactly 5 cases plus the _ throw.
5. Form1.Designer.cs cmbOcrEngine now has 5 items in its Items array.
6. Form1.cs has no changed method signatures — only the 3 additions described above.
7. appsettings.json is valid JSON and still has all original keys.
8. No new NuGet packages are needed — OllamaVisionService uses only System.Net.Http
   and System.Text.Json which are built into .NET 8.

---

## HOW TO TEST AFTER IMPLEMENTATION

1. Install Ollama from https://ollama.com and run:  ollama serve
2. Pull a vision model:  ollama pull qwen2-vl   (or  ollama pull phi3.5  for CPU-only)
3. Run the application.
4. Select "Hybrid (ADI + OSS LLM)" from the engine dropdown.
5. Upload a scanned PDF document.
6. Click Run OCR.
7. Expected results:
   - If ADI confidence >= 80%: Structured Fields shows "LLM Pass Skipped" — correct.
   - If ADI confidence < 80%:  LLM runs; "── HYBRID LLM CORRECTIONS ──" section appears
     in Structured Fields; any corrected rows show in teal highlight.
   - If Ollama is not running: engine degrades gracefully to ADI-only result with
     "Ollama Unavailable" note — no crash.
   - Full JSON tab shows HybridCorrections array with all correction records.
   - Save JSON and Export Excel both work normally.
