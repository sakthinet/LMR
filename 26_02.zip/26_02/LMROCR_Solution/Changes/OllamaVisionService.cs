using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace LMROCR_Solution.Services;

/// <summary>
/// Thin wrapper around the local Ollama REST API.
/// Requires Ollama to be running: https://ollama.com  (ollama serve)
/// Pull a vision model first, e.g.:  ollama pull qwen2-vl
///                                    ollama pull llava
///                                    ollama pull phi3.5
/// </summary>
public class OllamaVisionService
{
    private readonly HttpClient  _http;
    private readonly string      _model;
    private readonly int         _timeoutSeconds;

    // ── Ollama REST models ────────────────────────────────────────────────

    private sealed class OllamaRequest
    {
        [JsonPropertyName("model")]   public string       Model  { get; init; } = "";
        [JsonPropertyName("prompt")]  public string       Prompt { get; init; } = "";
        [JsonPropertyName("images")]  public List<string> Images { get; init; } = [];
        [JsonPropertyName("stream")]  public bool         Stream { get; init; } = false;
        [JsonPropertyName("format")]  public string       Format { get; init; } = "json";
    }

    private sealed class OllamaResponse
    {
        [JsonPropertyName("response")] public string Response { get; init; } = "";
        [JsonPropertyName("done")]     public bool   Done     { get; init; }
    }

    public OllamaVisionService(string baseUrl, string model, int timeoutSeconds = 120)
    {
        _model          = model;
        _timeoutSeconds = timeoutSeconds;
        _http           = new HttpClient
        {
            BaseAddress = new Uri(baseUrl.TrimEnd('/') + "/"),
            Timeout     = TimeSpan.FromSeconds(timeoutSeconds)
        };
    }

    // ── Health check ──────────────────────────────────────────────────────

    /// <summary>Returns true if Ollama is reachable and the configured model is available.</summary>
    public async Task<bool> IsAvailableAsync()
    {
        try
        {
            var response = await _http.GetAsync("api/tags");
            if (!response.IsSuccessStatusCode) return false;

            var json  = await response.Content.ReadAsStringAsync();
            var doc   = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("models", out var models)) return false;

            foreach (var m in models.EnumerateArray())
            {
                var name = m.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "";
                // Ollama model names may include a tag suffix like "qwen2-vl:latest"
                if (name.StartsWith(_model, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }
        catch
        {
            return false;
        }
    }

    // ── Core generation call ──────────────────────────────────────────────

    /// <summary>
    /// Sends a page image (as a PNG byte array) + a text prompt to Ollama.
    /// Expects the model to return a JSON object — set Format = "json" by default.
    /// </summary>
    public async Task<string> GenerateAsync(byte[] pageImagePng, string prompt)
    {
        var base64Image = Convert.ToBase64String(pageImagePng);

        var request = new OllamaRequest
        {
            Model  = _model,
            Prompt = prompt,
            Images = [base64Image],
            Stream = false,
            Format = "json"
        };

        var json    = JsonSerializer.Serialize(request);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        var http = await _http.PostAsync("api/generate", content);
        http.EnsureSuccessStatusCode();

        var responseJson = await http.Content.ReadAsStringAsync();
        var parsed       = JsonSerializer.Deserialize<OllamaResponse>(responseJson);

        return parsed?.Response ?? "";
    }
}
