// ═══════════════════════════════════════════════════════════════════════════
// FORM1.CS — 3 SMALL CHANGES NEEDED TO WIRE IN THE HYBRID ENGINE
// Do NOT replace Form1.cs — make these targeted edits only.
// ═══════════════════════════════════════════════════════════════════════════

// ────────────────────────────────────────────────────────────────────────────
// CHANGE 1 of 3 — Designer file (Form1_Designer.cs)
//
// Find the cmbOcrEngine.Items.AddRange line and add the new engine name.
// The ComboBox Items collection is set in Form1_Designer.cs (not Form1.cs).
//
// FIND this line in Form1_Designer.cs:
//
//   this.cmbOcrEngine.Items.AddRange(new object[] {
//       "Azure Document Intelligence",
//       "Tesseract OCR",
//       "PaddleOCR",
//       "EasyOCR" });
//
// REPLACE WITH:
//
//   this.cmbOcrEngine.Items.AddRange(new object[] {
//       "Azure Document Intelligence",
//       "Tesseract OCR",
//       "PaddleOCR",
//       "EasyOCR",
//       "Hybrid (ADI + OSS LLM)" });          // ← ADD THIS LINE
//
// ────────────────────────────────────────────────────────────────────────────


// ────────────────────────────────────────────────────────────────────────────
// CHANGE 2 of 3 — Form1.cs : SetStatusCompleted()
//
// FIND the shortEngine switch inside SetStatusCompleted():
//
//   var shortEngine = engine switch
//   {
//       "Azure Document Intelligence" => "Azure Doc Intel",
//       _ => engine
//   };
//
// REPLACE WITH:
//
//   var shortEngine = engine switch
//   {
//       "Azure Document Intelligence" => "Azure Doc Intel",
//       "Hybrid (ADI + OSS LLM)"     => "Hybrid ADI+LLM",   // ← ADD THIS
//       _ => engine
//   };
//
// ────────────────────────────────────────────────────────────────────────────


// ────────────────────────────────────────────────────────────────────────────
// CHANGE 3 of 3 — Form1.cs : GetModelDisplayName()
//
// FIND the return switch inside GetModelDisplayName():
//
//   return engine switch
//   {
//       "Azure Document Intelligence" => string.IsNullOrEmpty(modelUsed)
//           ? "prebuilt-layout" : modelUsed,
//       "Tesseract OCR"               => "LSTM (eng.traineddata)",
//       "PaddleOCR"                   => "PP-OCRv4 (det+rec+cls)",
//       "EasyOCR"                     => "CRAFT + ResNet (en)",
//       _                             => modelUsed ?? "Unknown"
//   };
//
// REPLACE WITH:
//
//   return engine switch
//   {
//       "Azure Document Intelligence" => string.IsNullOrEmpty(modelUsed)
//           ? "prebuilt-layout" : modelUsed,
//       "Tesseract OCR"               => "LSTM (eng.traineddata)",
//       "PaddleOCR"                   => "PP-OCRv4 (det+rec+cls)",
//       "EasyOCR"                     => "CRAFT + ResNet (en)",
//       "Hybrid (ADI + OSS LLM)"     => string.IsNullOrEmpty(modelUsed)  // ← ADD THIS CASE
//           ? "ADI + Ollama LLM" : modelUsed,
//       _                             => modelUsed ?? "Unknown"
//   };
//
// ────────────────────────────────────────────────────────────────────────────


// ════════════════════════════════════════════════════════════════════════════
// OPTIONAL: Highlight corrected fields in Structured Fields grid
//
// To visually flag LLM-corrected rows in the Structured Fields tab,
// add the following block inside DisplayResults() in Form1.cs,
// AFTER the existing foreach loop that populates dgvStructuredFields.
//
// This makes LLM-corrected rows appear with a distinct teal background.
//
//   // Highlight LLM-corrected rows in Structured Fields tab
//   if (result.HasLlmCorrections)
//   {
//       foreach (DataGridViewRow row in dgvStructuredFields.Rows)
//       {
//           var key = row.Cells["colField"].Value?.ToString() ?? "";
//           if (key.StartsWith("  ✏"))   // LLM correction entries added by HybridOcrService
//           {
//               row.DefaultCellStyle.BackColor = Color.FromArgb(20, 60, 60);
//               row.DefaultCellStyle.ForeColor = Color.FromArgb(100, 220, 200);
//           }
//       }
//
//       // Show correction count in status bar
//       var corrCount = result.HybridCorrections.Count(c => c.WasApplied);
//       if (corrCount > 0)
//           SetStatusReady($"Hybrid complete — {corrCount} LLM correction(s) applied");
//   }
//
// ════════════════════════════════════════════════════════════════════════════
