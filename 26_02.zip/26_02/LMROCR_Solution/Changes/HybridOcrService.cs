using LMROCR_Solution.Models;
using PDFtoImage;
using SkiaSharp;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace LMROCR_Solution.Services;

/// <summary>
/// Hybrid OCR service: ADI extracts first, then an OSS vision LLM (via Ollama)
/// re-processes low-confidence pages to correct or confirm extracted text.
///
/// Pipeline:
///   1. Run AzureOcrService  →  full OcrResult (structured fields, KV, tables, etc.)
///   2. Identify pages where word-level confidence &lt; LlmConfidenceThreshold
///   3. For each low-confidence page: render PNG → send to Ollama with ADI text
///   4. Parse LLM corrections → merge back into OcrResult
///   5. Return enriched OcrResult with HybridCorrections populated
/// </summary>
public class HybridOcrService : IOcrService
{
    // ── Config ────────────────────────────────────────────────────────────

    /// <summary>
    /// Pages whose average word confidence (%) falls below this threshold
    /// will be sent to the OSS LLM for a correction pass.
    /// Default: 80.0 — tune this during POC calibration.
    /// </summary>
    public double LlmConfidenceThreshold { get; init; } = 80.0;

    private readonly AzureOcrService     _adiService;
    private readonly OllamaVisionService _ollama;

    // ── LLM response model ────────────────────────────────────────────────

    private sealed class LlmCorrectionResponse
    {
        [JsonPropertyName("corrections")]
        public List<LlmFieldCorrection> Corrections { get; init; } = [];

        [JsonPropertyName("page_summary")]
        public string PageSummary { get; init; } = "";
    }

    private sealed class LlmFieldCorrection
    {
        [JsonPropertyName("original")]   public string Original       { get; init; } = "";
        [JsonPropertyName("corrected")]  public string Corrected      { get; init; } = "";
        [JsonPropertyName("confidence")] public double Confidence     { get; init; }
        [JsonPropertyName("reason")]     public string Reason         { get; init; } = "";
    }

    // ── Constructor ───────────────────────────────────────────────────────

    public HybridOcrService(
        string adiEndpoint,
        string adiApiKey,
        string ollamaBaseUrl,
        string ollamaModel,
        double llmConfidenceThreshold = 80.0,
        int    ollamaTimeoutSeconds   = 120)
    {
        _adiService             = new AzureOcrService(adiEndpoint, adiApiKey);
        _ollama                 = new OllamaVisionService(ollamaBaseUrl, ollamaModel, ollamaTimeoutSeconds);
        LlmConfidenceThreshold  = llmConfidenceThreshold;
    }

    // ── Main entry point ──────────────────────────────────────────────────

    public async Task<OcrResult> ProcessAsync(string filePath)
    {
        // ── Step 1: ADI extraction ────────────────────────────────────────
        var adiResult = await _adiService.ProcessAsync(filePath);

        // Annotate which engine ran
        adiResult.ModelUsed = $"ADI ({adiResult.ModelUsed})";

        // ── Step 2: Check if Ollama is reachable ──────────────────────────
        var ollamaAvailable = await _ollama.IsAvailableAsync();

        if (!ollamaAvailable)
        {
            // Degrade gracefully: return ADI result with a warning note
            adiResult.HybridCorrections.Add(new HybridCorrection
            {
                PageNumber  = 0,
                Stage       = "Ollama Unavailable",
                OriginalText = "Ollama service not reachable. Running ADI-only.",
                CorrectedText = "Start Ollama: run 'ollama serve' and ensure the model is pulled.",
                LlmConfidence = 0,
                WasApplied    = false
            });
            adiResult.ModelUsed += " [Ollama offline — ADI only]";
            return adiResult;
        }

        // ── Step 3: Identify pages that need LLM review ───────────────────
        var lowConfidencePages = IdentifyLowConfidencePages(adiResult);

        if (lowConfidencePages.Count == 0)
        {
            // All pages passed threshold — nothing for the LLM to do
            adiResult.HybridCorrections.Add(new HybridCorrection
            {
                PageNumber   = 0,
                Stage        = "LLM Pass Skipped",
                OriginalText = $"All pages met confidence threshold ({LlmConfidenceThreshold:F0}%). " +
                               $"ADI average: {adiResult.AverageConfidence:F1}%.",
                CorrectedText = "No LLM intervention needed.",
                LlmConfidence = adiResult.AverageConfidence / 100.0,
                WasApplied    = false
            });
            adiResult.ModelUsed += " [LLM: no intervention needed]";
            return adiResult;
        }

        // ── Step 4: Render page images ────────────────────────────────────
        var pageImages = RenderPageImages(filePath);

        // ── Step 5: LLM correction pass on low-confidence pages ───────────
        var allCorrections     = new List<HybridCorrection>();
        var correctedTextPages = ExtractPageTexts(adiResult);

        foreach (var pageNum in lowConfidencePages)
        {
            if (pageNum - 1 >= pageImages.Count) continue;

            var pageImage  = pageImages[pageNum - 1];
            var adiPageText = correctedTextPages.GetValueOrDefault(pageNum, "");

            var prompt = BuildCorrectionPrompt(adiPageText, pageNum);

            string llmRaw;
            try
            {
                llmRaw = await _ollama.GenerateAsync(pageImage, prompt);
            }
            catch (Exception ex)
            {
                allCorrections.Add(new HybridCorrection
                {
                    PageNumber    = pageNum,
                    Stage         = "LLM Error",
                    OriginalText  = adiPageText,
                    CorrectedText = $"LLM call failed: {ex.Message}",
                    LlmConfidence = 0,
                    WasApplied    = false
                });
                continue;
            }

            var parsed = ParseLlmResponse(llmRaw);
            if (parsed == null)
            {
                allCorrections.Add(new HybridCorrection
                {
                    PageNumber    = pageNum,
                    Stage         = "Parse Error",
                    OriginalText  = llmRaw,
                    CorrectedText = "Could not parse LLM JSON response.",
                    LlmConfidence = 0,
                    WasApplied    = false
                });
                continue;
            }

            // Apply each correction: update the extracted text
            foreach (var c in parsed.Corrections)
            {
                var wasApplied = false;
                if (!string.IsNullOrWhiteSpace(c.Corrected) &&
                    !string.Equals(c.Original, c.Corrected, StringComparison.OrdinalIgnoreCase))
                {
                    // Patch extracted text in the result
                    adiResult.ExtractedText = adiResult.ExtractedText
                        .Replace(c.Original, c.Corrected, StringComparison.Ordinal);

                    // Also patch any StructuredFields that contain this text
                    foreach (var field in adiResult.StructuredFields
                        .Where(f => f.Value.Contains(c.Original, StringComparison.Ordinal)))
                    {
                        field.Value      = field.Value.Replace(c.Original, c.Corrected);
                        field.Confidence = Math.Max(field.Confidence, c.Confidence * 100);
                    }

                    wasApplied = true;
                }

                allCorrections.Add(new HybridCorrection
                {
                    PageNumber    = pageNum,
                    Stage         = "LLM Correction",
                    OriginalText  = c.Original,
                    CorrectedText = c.Corrected,
                    LlmConfidence = c.Confidence,
                    Reason        = c.Reason,
                    WasApplied    = wasApplied
                });
            }

            // Page summary note
            if (!string.IsNullOrWhiteSpace(parsed.PageSummary))
            {
                allCorrections.Add(new HybridCorrection
                {
                    PageNumber    = pageNum,
                    Stage         = "Page Summary",
                    OriginalText  = "",
                    CorrectedText = parsed.PageSummary,
                    LlmConfidence = 1.0,
                    WasApplied    = false
                });
            }
        }

        // ── Step 6: Rebuild StructuredFields with hybrid section ──────────
        var correctionCount = allCorrections.Count(c => c.WasApplied);
        adiResult.StructuredFields.Add(new FieldResult
        {
            Key        = "── HYBRID LLM CORRECTIONS ──",
            Value      = "",
            Confidence = 100
        });
        adiResult.StructuredFields.Add(new FieldResult
        {
            Key        = "LLM Model",
            Value      = "Ollama (see appsettings.json → Hybrid:OllamaModel)",
            Confidence = 100
        });
        adiResult.StructuredFields.Add(new FieldResult
        {
            Key        = "Pages Reviewed",
            Value      = string.Join(", ", lowConfidencePages.Select(p => $"P{p}")),
            Confidence = 100
        });
        adiResult.StructuredFields.Add(new FieldResult
        {
            Key        = "Corrections Applied",
            Value      = correctionCount.ToString(),
            Confidence = correctionCount > 0 ? 90 : 100
        });

        foreach (var c in allCorrections.Where(c => c.WasApplied))
        {
            adiResult.StructuredFields.Add(new FieldResult
            {
                Key        = $"  ✏ [P{c.PageNumber}] {TruncateText(c.OriginalText, 40)}",
                Value      = TruncateText(c.CorrectedText, 80),
                Confidence = c.LlmConfidence * 100
            });
        }

        // ── Step 7: Recalculate confidence after corrections ──────────────
        var correctedAvg = adiResult.AverageConfidence;
        if (correctionCount > 0)
        {
            var llmConfs  = allCorrections.Where(c => c.WasApplied).Select(c => c.LlmConfidence * 100).ToList();
            var allConfs  = new List<double> { adiResult.AverageConfidence };
            allConfs.AddRange(llmConfs);
            correctedAvg  = allConfs.Average();
        }

        // ── Step 8: Rebuild RawJson with hybrid data ──────────────────────
        adiResult.AverageConfidence = correctedAvg;
        adiResult.HybridCorrections = allCorrections;
        adiResult.ModelUsed         = $"ADI prebuilt-layout + Ollama LLM ({allCorrections.Count(c => c.WasApplied)} corrections)";
        adiResult.RawJson           = BuildHybridJson(adiResult, allCorrections, lowConfidencePages);

        return adiResult;
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    /// <summary>Returns 1-based page numbers whose average word confidence is below threshold.</summary>
    private List<int> IdentifyLowConfidencePages(OcrResult result)
    {
        var lowPages = new List<int>();

        foreach (var page in result.DocumentPages)
        {
            // DocumentPage doesn't carry per-word confidence — use overall average as proxy.
            // A more precise approach would be to re-analyse per-page confidence from RawJson
            // but that requires re-parsing the ADI response, which is overkill for a POC.
            if (result.AverageConfidence < LlmConfidenceThreshold)
                lowPages.Add(page.PageNumber);
        }

        // If no pages found (e.g., non-ADI fallback) but overall confidence is low, flag page 1
        if (lowPages.Count == 0 && result.AverageConfidence < LlmConfidenceThreshold)
            lowPages.Add(1);

        return lowPages;
    }

    /// <summary>Renders all pages of a PDF (or returns a single image for image files) as PNG bytes.</summary>
    private static List<byte[]> RenderPageImages(string filePath)
    {
        var ext = Path.GetExtension(filePath).ToLowerInvariant();

        if (ext == ".pdf")
        {
            var opts = new RenderOptions(Dpi: 150); // lower DPI = smaller payload for LLM
            using var fs = File.OpenRead(filePath);
            return Conversion.ToImages(fs, options: opts)
                .Select(bmp =>
                {
                    using (bmp)
                    using (var ms = new MemoryStream())
                    {
                        bmp.Encode(ms, SKEncodedImageFormat.Png, 85);
                        return ms.ToArray();
                    }
                })
                .ToList();
        }
        else
        {
            // Image file — read as-is and re-encode as PNG
            using var bmp = SKBitmap.Decode(filePath);
            using var ms  = new MemoryStream();
            bmp.Encode(ms, SKEncodedImageFormat.Png, 85);
            return [ms.ToArray()];
        }
    }

    /// <summary>Splits OcrResult extracted text by page (using the ─── Page N ─── separator).</summary>
    private static Dictionary<int, string> ExtractPageTexts(OcrResult result)
    {
        var pages     = new Dictionary<int, string>();
        var current   = new StringBuilder();
        var currentPg = 1;

        foreach (var line in result.ExtractedText.Split('\n'))
        {
            var match = System.Text.RegularExpressions.Regex.Match(line, @"─── Page (\d+) ───");
            if (match.Success)
            {
                if (current.Length > 0)
                    pages[currentPg] = current.ToString().Trim();

                currentPg = int.Parse(match.Groups[1].Value);
                current.Clear();
            }
            else
            {
                current.AppendLine(line);
            }
        }

        if (current.Length > 0)
            pages[currentPg] = current.ToString().Trim();

        return pages;
    }

    /// <summary>
    /// Builds the structured prompt sent to the vision LLM.
    /// The model MUST return a JSON object matching LlmCorrectionResponse.
    /// </summary>
    private string BuildCorrectionPrompt(string adiExtractedText, int pageNumber)
    {
        return $"""
            You are a precise document verification assistant for HM Land Registry (HMLR) legal documents.
            This is page {pageNumber} of a scanned property deed (TR1, TP1, or Mortgage Deed).

            The OCR system extracted the following text from this page, but some words may have been
            misread (the page had low confidence). Your job is to compare the image carefully against
            the extracted text and return corrections for any clearly wrong words or phrases.

            EXTRACTED TEXT FROM OCR:
            ---
            {TruncateText(adiExtractedText, 1500)}
            ---

            Instructions:
            1. Carefully read the image.
            2. Identify words or short phrases where the OCR extraction is clearly wrong.
            3. Focus on: names, title numbers (e.g. AGL123456), amounts in words or figures,
               dates, postcodes, and legal terms.
            4. Only return corrections where you are confident. Do NOT guess.
            5. Return ONLY a valid JSON object — no extra text, no markdown, no explanation outside JSON.

            Return this exact JSON structure:
            {{
              "corrections": [
                {{
                  "original": "<exact text as it appears in OCR output>",
                  "corrected": "<your corrected version>",
                  "confidence": <0.0 to 1.0>,
                  "reason": "<one-line reason e.g. 'digit 0 misread as letter O'>"
                }}
              ],
              "page_summary": "<one sentence describing what this page contains>"
            }}

            If there are no corrections needed, return: {{"corrections": [], "page_summary": "<description>"}}
            """;
    }

    private static LlmCorrectionResponse? ParseLlmResponse(string rawJson)
    {
        if (string.IsNullOrWhiteSpace(rawJson)) return null;

        // Strip any accidental markdown fences
        var clean = rawJson.Trim();
        if (clean.StartsWith("```")) clean = clean.Split('\n', 2)[1];
        if (clean.EndsWith("```"))  clean = clean[..clean.LastIndexOf("```")];
        clean = clean.Trim();

        // Find JSON boundaries
        var start = clean.IndexOf('{');
        var end   = clean.LastIndexOf('}');
        if (start < 0 || end < 0) return null;
        clean = clean[start..(end + 1)];

        try
        {
            return JsonSerializer.Deserialize<LlmCorrectionResponse>(clean,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
        catch
        {
            return null;
        }
    }

    private string BuildHybridJson(OcrResult result, List<HybridCorrection> corrections, List<int> reviewedPages)
    {
        var summary = new
        {
            Engine      = "Hybrid (Azure Document Intelligence + OSS Vision LLM)",
            AdiModel    = "prebuilt-layout",
            LlmModel    = "Ollama (configured in appsettings.json)",
            ConfidenceThreshold = LlmConfidenceThreshold,
            PagesReviewedByLlm  = reviewedPages,
            CorrectionsApplied  = corrections.Count(c => c.WasApplied),
            FinalConfidence     = result.AverageConfidence,
            HybridCorrections   = corrections.Select(c => new
            {
                c.PageNumber, c.Stage, c.OriginalText, c.CorrectedText,
                LlmConfidencePct = c.LlmConfidence * 100,
                c.Reason, c.WasApplied
            }),
            AdiExtractedText    = result.ExtractedText,
            Pages               = result.DocumentPages,
            FormFields          = result.KeyValuePairs,
            Tables              = result.Tables.Select(t => new
            {
                t.PageNumber, t.RowCount, t.ColumnCount,
                Cells = t.Cells.Select(c => new { c.RowIndex, c.ColumnIndex, c.Kind, c.Content })
            }),
            Checkboxes          = result.SelectionMarks.Select(s => new
            {
                s.PageNumber, s.State, s.Confidence, Label = s.DisplayLabel
            })
        };

        return JsonSerializer.Serialize(summary,
            new JsonSerializerOptions { WriteIndented = true });
    }

    private static string TruncateText(string text, int maxLength) =>
        text.Length <= maxLength ? text : text[..maxLength] + "…";
}
