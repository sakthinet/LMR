using Microsoft.Extensions.Configuration;

namespace LMROCR_Solution.Services;

public static class OcrServiceFactory
{
    public static IOcrService Create(string engineName, IConfiguration configuration)
    {
        return engineName switch
        {
            "Azure Document Intelligence" => new AzureOcrService(
                configuration["Azure:Endpoint"] ?? "",
                configuration["Azure:ApiKey"] ?? ""),

            "Tesseract OCR" => new TesseractOcrService(
                configuration["Tesseract:TessDataPath"] ?? "./tessdata",
                configuration["Tesseract:Language"] ?? "eng"),

            "PaddleOCR" => new PaddleOcrService(
                configuration["Python:ExecutablePath"] ?? "python"),

            "EasyOCR" => new EasyOcrService(
                configuration["Python:ExecutablePath"] ?? "python"),

            // ── NEW: Hybrid — ADI first pass + Ollama OSS LLM correction pass ──
            "Hybrid (ADI + OSS LLM)" => new HybridOcrService(
                adiEndpoint:              configuration["Azure:Endpoint"]              ?? "",
                adiApiKey:                configuration["Azure:ApiKey"]               ?? "",
                ollamaBaseUrl:            configuration["Hybrid:OllamaBaseUrl"]       ?? "http://localhost:11434",
                ollamaModel:              configuration["Hybrid:OllamaModel"]         ?? "qwen2-vl",
                llmConfidenceThreshold:   double.TryParse(
                                              configuration["Hybrid:ConfidenceThreshold"],
                                              out var t) ? t : 80.0,
                ollamaTimeoutSeconds:     int.TryParse(
                                              configuration["Hybrid:OllamaTimeoutSeconds"],
                                              out var ts) ? ts : 120),

            _ => throw new NotSupportedException(
                $"OCR engine '{engineName}' is not supported.")
        };
    }
}
