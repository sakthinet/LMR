namespace LMROCR_Solution.Models;

public class OcrResult
{
    public string ExtractedText { get; set; } = "";
    public List<FieldResult> StructuredFields { get; set; } = [];
    public double AverageConfidence { get; set; }
    public int Pages { get; set; }
    public string RawJson { get; set; } = "";

    // Rich structured data (Azure Document Intelligence)
    public List<DocumentPage> DocumentPages { get; set; } = [];
    public List<DocumentParagraph> Paragraphs { get; set; } = [];
    public List<DocumentTable> Tables { get; set; } = [];
    public List<DocumentKeyValuePair> KeyValuePairs { get; set; } = [];
    public List<DocumentSelectionMark> SelectionMarks { get; set; } = [];
    public string ModelUsed { get; set; } = "";

    /// <summary>
    /// Populated only when using HybridOcrService.
    /// Empty list = ADI-only run or all pages met the confidence threshold.
    /// </summary>
    public List<HybridCorrection> HybridCorrections { get; set; } = [];

    /// <summary>True if any LLM corrections were applied to the extracted text.</summary>
    public bool HasLlmCorrections => HybridCorrections.Any(c => c.WasApplied);
}

public class FieldResult
{
    public string Key { get; set; } = "";
    public string Value { get; set; } = "";
    public double Confidence { get; set; }
}

// ── Azure-specific rich models ──────────────────────────────────────────────

public class DocumentPage
{
    public int PageNumber { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
    public string Unit { get; set; } = "";
    public int WordCount { get; set; }
    public int LineCount { get; set; }
}

public class DocumentParagraph
{
    public int PageNumber { get; set; }
    public string Role { get; set; } = "";   // title, sectionHeading, footnote, pageHeader, pageFooter, pageNumber, body
    public string Content { get; set; } = "";
}

public class DocumentTable
{
    public int PageNumber { get; set; }
    public int RowCount { get; set; }
    public int ColumnCount { get; set; }
    public string[,] DisplayGrid { get; set; } = new string[0, 0]; // pre-built display grid with span markers
    public List<DocumentTableCell> Cells { get; set; } = [];
}

public class DocumentTableCell
{
    public int RowIndex { get; set; }
    public int ColumnIndex { get; set; }
    public int RowSpan { get; set; } = 1;
    public int ColumnSpan { get; set; } = 1;
    public string Kind { get; set; } = "content";   // content, rowHeader, columnHeader
    public string Content { get; set; } = "";
}

public class DocumentKeyValuePair
{
    public string Key { get; set; } = "";
    public string Value { get; set; } = "";         // empty string = blank text box
    public double Confidence { get; set; }
    public int PageNumber { get; set; }
    public bool IsEmpty => string.IsNullOrWhiteSpace(Value);
}

public class DocumentSelectionMark
{
    public int PageNumber { get; set; }
    public string State { get; set; } = "";         // selected / unselected
    public double Confidence { get; set; }
    public string Label { get; set; } = "";         // label from associated KV key (prebuilt-document)
    public string NearbyText { get; set; } = "";    // fallback: nearest word (prebuilt-layout)
    public string DisplayLabel => !string.IsNullOrWhiteSpace(Label) ? Label : NearbyText;
}

public class HybridCorrection
{
    /// <summary>1-based page number. 0 = pipeline-level message.</summary>
    public int    PageNumber    { get; set; }

    /// <summary>
    /// Pipeline stage. Values: "LLM Correction", "Page Summary", "LLM Error",
    /// "Parse Error", "LLM Pass Skipped", "Ollama Unavailable".
    /// </summary>
    public string Stage         { get; set; } = "";

    /// <summary>Original text as extracted by ADI.</summary>
    public string OriginalText  { get; set; } = "";

    /// <summary>LLM's corrected version.</summary>
    public string CorrectedText { get; set; } = "";

    /// <summary>LLM self-reported confidence (0.0–1.0).</summary>
    public double LlmConfidence { get; set; }

    /// <summary>One-line reason from the LLM.</summary>
    public string Reason        { get; set; } = "";

    /// <summary>True if this correction was patched into OcrResult.ExtractedText.</summary>
    public bool   WasApplied    { get; set; }
}
