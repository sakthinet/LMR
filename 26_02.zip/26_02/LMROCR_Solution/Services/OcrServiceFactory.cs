using Microsoft.Extensions.Configuration;

namespace LMROCR_Solution.Services;

public static class OcrServiceFactory
{
    public static IOcrService Create(string engineName, IConfiguration configuration)
    {
        return engineName switch
        {
            "Azure Document Intelligence" => new AzureOcrService(
                configuration["Azure:Endpoint"] ?? "",
                configuration["Azure:ApiKey"] ?? ""),

            "Tesseract OCR" => new TesseractOcrService(
                configuration["Tesseract:TessDataPath"] ?? "./tessdata",
                configuration["Tesseract:Language"] ?? "eng"),

            "PaddleOCR" => new PaddleOcrService(
                configuration["Python:ExecutablePath"] ?? "python"),

            "EasyOCR" => new EasyOcrService(
                configuration["Python:ExecutablePath"] ?? "python"),

            "DocTR" => new DoctrOcrService(
                configuration["Python:ExecutablePath"] ?? "python"),

            "Surya OCR" => new SuryaOcrService(
                configuration["Python:ExecutablePath"] ?? "python"),

            "Hybrid (ADI + OSS LLM)" => new HybridOcrService(
                adiEndpoint:            configuration["Azure:Endpoint"]              ?? "",
                adiApiKey:              configuration["Azure:ApiKey"]               ?? "",
                ollamaBaseUrl:          configuration["Hybrid:OllamaBaseUrl"]       ?? "http://localhost:11434",
                ollamaModel:            configuration["Hybrid:OllamaModel"]         ?? "gemma3:4b",
                llmConfidenceThreshold: double.TryParse(
                                            configuration["Hybrid:ConfidenceThreshold"],
                                            out var t) ? t : 80.0,
                ollamaTimeoutSeconds:   int.TryParse(
                                            configuration["Hybrid:OllamaTimeoutSeconds"],
                                            out var ts) ? ts : 120),

            "Hybrid (Tesseract + OSS LLM)" => new HybridTesseractOcrService(
                tessDataPath:           configuration["Tesseract:TessDataPath"]     ?? "./tessdata",
                tessLanguage:           configuration["Tesseract:Language"]          ?? "eng",
                ollamaBaseUrl:          configuration["Hybrid:OllamaBaseUrl"]       ?? "http://localhost:11434",
                ollamaModel:            configuration["Hybrid:OllamaModel"]         ?? "gemma3:4b",
                llmConfidenceThreshold: double.TryParse(
                                            configuration["Hybrid:ConfidenceThreshold"],
                                            out var t2) ? t2 : 70.0,
                ollamaTimeoutSeconds:   int.TryParse(
                                            configuration["Hybrid:OllamaTimeoutSeconds"],
                                            out var ts2) ? ts2 : 180),

            _ => throw new NotSupportedException(
                $"OCR engine '{engineName}' is not supported.")
        };
    }
}
