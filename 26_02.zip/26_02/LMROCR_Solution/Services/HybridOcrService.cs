using LMROCR_Solution.Models;
using PDFtoImage;
using SkiaSharp;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace LMROCR_Solution.Services;

/// <summary>
/// Hybrid OCR engine: Azure Document Intelligence (ADI) first pass,
/// then a local Ollama vision LLM reviews low-confidence pages.
/// </summary>
public class HybridOcrService : IOcrService
{
    private readonly AzureOcrService _adiService;
    private readonly OllamaVisionService _ollama;
    private readonly string _ollamaModel;

    /// <summary>
    /// Pages with AverageConfidence below this threshold will be sent to the LLM.
    /// </summary>
    public double LlmConfidenceThreshold { get; set; }

    public HybridOcrService(
        string adiEndpoint,
        string adiApiKey,
        string ollamaBaseUrl,
        string ollamaModel,
        double llmConfidenceThreshold = 80.0,
        int ollamaTimeoutSeconds = 120)
    {
        _adiService = new AzureOcrService(adiEndpoint, adiApiKey);
        _ollama = new OllamaVisionService(ollamaBaseUrl, ollamaModel, ollamaTimeoutSeconds);
        LlmConfidenceThreshold = llmConfidenceThreshold;
        _ollamaModel = ollamaModel;
    }

    public async Task<OcrResult> ProcessAsync(string filePath)
    {
        // ── STEP A — ADI first pass ─────────────────────────────────────────
        var adiResult = await _adiService.ProcessAsync(filePath);
        adiResult.ModelUsed += " [Hybrid]";

        // Add Hybrid Pipeline Info header to StructuredFields (always visible)
        adiResult.StructuredFields.Insert(0, new FieldResult
        {
            Key = "── HYBRID PIPELINE STATUS ──",
            Value = "",
            Confidence = 100
        });
        adiResult.StructuredFields.Insert(1, new FieldResult
        {
            Key = "Engine Mode",
            Value = "Hybrid (ADI + OSS LLM)",
            Confidence = 100
        });
        adiResult.StructuredFields.Insert(2, new FieldResult
        {
            Key = "Step 1 — ADI",
            Value = "Azure Document Intelligence prebuilt-layout ✔",
            Confidence = 100
        });
        adiResult.StructuredFields.Insert(3, new FieldResult
        {
            Key = "ADI Confidence",
            Value = $"{adiResult.AverageConfidence:F1}% (threshold: {LlmConfidenceThreshold}%)",
            Confidence = adiResult.AverageConfidence
        });
        adiResult.StructuredFields.Insert(4, new FieldResult
        {
            Key = "LLM Model",
            Value = _ollamaModel,
            Confidence = 100
        });

        // ── STEP B — Check Ollama availability ──────────────────────────────
        var ollamaAvailable = await _ollama.IsAvailableAsync();
        if (!ollamaAvailable)
        {
            adiResult.HybridCorrections.Add(new HybridCorrection
            {
                Stage = "Ollama Unavailable",
                CorrectedText = "Start Ollama: run 'ollama serve' and ensure the model is pulled via 'ollama pull <model>'",
                WasApplied = false
            });
            // Update pipeline status fields
            var ollamaStatusIdx = adiResult.StructuredFields.FindIndex(f => f.Key == "LLM Model");
            if (ollamaStatusIdx >= 0)
                adiResult.StructuredFields[ollamaStatusIdx].Value = $"{_ollamaModel}  ❌ OFFLINE";
            adiResult.StructuredFields.Insert(ollamaStatusIdx + 1, new FieldResult
            {
                Key = "Step 2 — LLM",
                Value = "⚠ Ollama not running — ADI results returned as-is",
                Confidence = 0
            });
            adiResult.StructuredFields.Insert(ollamaStatusIdx + 2, new FieldResult
            {
                Key = "Action Required",
                Value = "Run 'ollama serve' then 'ollama pull " + _ollamaModel + "'",
                Confidence = 0
            });
            adiResult.ModelUsed += " [Ollama offline — ADI only]";
            return adiResult;
        }

        // ── STEP C — Identify low-confidence pages ──────────────────────────
        var lowConfidencePages = new List<int>();
        foreach (var page in adiResult.DocumentPages)
        {
            if (adiResult.AverageConfidence < LlmConfidenceThreshold)
                lowConfidencePages.Add(page.PageNumber);
        }
        // If no pages found but overall confidence is low, add page 1
        if (lowConfidencePages.Count == 0 && adiResult.AverageConfidence < LlmConfidenceThreshold)
            lowConfidencePages.Add(1);

        if (lowConfidencePages.Count == 0)
        {
            adiResult.HybridCorrections.Add(new HybridCorrection
            {
                Stage = "LLM Pass Skipped",
                CorrectedText = "All pages met confidence threshold. No LLM intervention needed.",
                WasApplied = false
            });
            // Update pipeline status
            var skipIdx = adiResult.StructuredFields.FindIndex(f => f.Key == "LLM Model");
            if (skipIdx >= 0)
                adiResult.StructuredFields[skipIdx].Value = $"{_ollamaModel}  ✔ Available";
            adiResult.StructuredFields.Insert(skipIdx + 1, new FieldResult
            {
                Key = "Step 2 — LLM",
                Value = $"✔ Skipped — ADI confidence {adiResult.AverageConfidence:F1}% ≥ {LlmConfidenceThreshold}% threshold",
                Confidence = 100
            });
            adiResult.StructuredFields.Insert(skipIdx + 2, new FieldResult
            {
                Key = "Result",
                Value = "ADI output is high-confidence — no LLM review needed",
                Confidence = 100
            });
            adiResult.ModelUsed += " [LLM: skipped, confidence OK]";
            return adiResult;
        }

        // ── STEP D — Render page images ─────────────────────────────────────
        var pageImages = RenderPageImages(filePath);

        // ── STEP E — Extract per-page text from adiResult ───────────────────
        var pageTexts = ExtractPageTexts(adiResult);

        // ── STEP F & G & H — LLM correction pass ───────────────────────────
        var allCorrections = new List<(int PageNumber, LlmFieldCorrection Correction)>();

        foreach (var pageNumber in lowConfidencePages)
        {
            var pageIndex = pageNumber - 1;
            if (pageIndex < 0 || pageIndex >= pageImages.Count)
                continue;

            var pageImageBytes = pageImages[pageIndex];
            pageTexts.TryGetValue(pageNumber, out var adiText);
            adiText ??= "";

            var prompt = BuildCorrectionPrompt(adiText, pageNumber);

            string rawResponse;
            try
            {
                rawResponse = await _ollama.GenerateAsync(pageImageBytes, prompt);
            }
            catch (Exception ex)
            {
                adiResult.HybridCorrections.Add(new HybridCorrection
                {
                    PageNumber = pageNumber,
                    Stage = "LLM Error",
                    CorrectedText = ex.Message,
                    WasApplied = false
                });
                continue;
            }

            // ── STEP G — Parse LLM response ────────────────────────────────
            var parsed = ParseLlmResponse(rawResponse);
            if (parsed is null)
            {
                adiResult.HybridCorrections.Add(new HybridCorrection
                {
                    PageNumber = pageNumber,
                    Stage = "Parse Error",
                    OriginalText = rawResponse.Length > 200 ? rawResponse[..200] : rawResponse,
                    CorrectedText = "Failed to parse LLM JSON response",
                    WasApplied = false
                });
                continue;
            }

            // ── STEP H — Apply corrections ──────────────────────────────────
            if (parsed.Corrections is not null)
            {
                foreach (var correction in parsed.Corrections)
                {
                    if (string.IsNullOrEmpty(correction.Original) || string.IsNullOrEmpty(correction.Corrected))
                        continue;

                    var wasApplied = false;

                    if (!string.Equals(correction.Original, correction.Corrected, StringComparison.OrdinalIgnoreCase))
                    {
                        // Replace in extracted text (case-sensitive)
                        adiResult.ExtractedText = adiResult.ExtractedText.Replace(
                            correction.Original, correction.Corrected);

                        // Replace in structured fields
                        foreach (var field in adiResult.StructuredFields)
                        {
                            if (field.Value.Contains(correction.Original))
                            {
                                field.Value = field.Value.Replace(correction.Original, correction.Corrected);
                                field.Confidence = Math.Max(field.Confidence, correction.Confidence * 100);
                            }
                        }

                        wasApplied = true;
                    }

                    adiResult.HybridCorrections.Add(new HybridCorrection
                    {
                        PageNumber = pageNumber,
                        Stage = "LLM Correction",
                        OriginalText = correction.Original,
                        CorrectedText = correction.Corrected,
                        LlmConfidence = correction.Confidence,
                        Reason = correction.Reason ?? "",
                        WasApplied = wasApplied
                    });

                    if (wasApplied)
                        allCorrections.Add((pageNumber, correction));
                }
            }

            // Page summary
            if (!string.IsNullOrEmpty(parsed.PageSummary))
            {
                adiResult.HybridCorrections.Add(new HybridCorrection
                {
                    PageNumber = pageNumber,
                    Stage = "Page Summary",
                    CorrectedText = parsed.PageSummary,
                    WasApplied = false
                });
            }
        }

        // ── STEP I — Add hybrid summary rows to StructuredFields ────────────
        // Update pipeline status for LLM-active path
        var activeIdx = adiResult.StructuredFields.FindIndex(f => f.Key == "LLM Model");
        if (activeIdx >= 0)
            adiResult.StructuredFields[activeIdx].Value = $"{_ollamaModel}  ✔ Active";
        adiResult.StructuredFields.Insert(activeIdx + 1, new FieldResult
        {
            Key = "Step 2 — LLM",
            Value = $"✔ Reviewing {lowConfidencePages.Count} page(s) — ADI confidence {adiResult.AverageConfidence:F1}% < {LlmConfidenceThreshold}% threshold",
            Confidence = 100
        });

        adiResult.StructuredFields.Add(new FieldResult
        {
            Key = "── HYBRID LLM CORRECTIONS ──",
            Value = "",
            Confidence = 100
        });
        adiResult.StructuredFields.Add(new FieldResult
        {
            Key = "Pages Reviewed by LLM",
            Value = string.Join(", ", lowConfidencePages.Select(p => $"P{p}")),
            Confidence = 100
        });

        var appliedCount = adiResult.HybridCorrections.Count(c => c.WasApplied);
        adiResult.StructuredFields.Add(new FieldResult
        {
            Key = "Corrections Applied",
            Value = appliedCount.ToString(),
            Confidence = 100
        });

        foreach (var (pageNumber, correction) in allCorrections)
        {
            var keyText = correction.Original.Length > 40
                ? correction.Original[..40] : correction.Original;
            var valText = correction.Corrected.Length > 80
                ? correction.Corrected[..80] : correction.Corrected;

            adiResult.StructuredFields.Add(new FieldResult
            {
                Key = $"  ✏ [P{pageNumber}] {keyText}",
                Value = valText,
                Confidence = correction.Confidence * 100
            });
        }

        // ── STEP J — Recalculate confidence and finalise ────────────────────
        if (allCorrections.Count > 0)
        {
            var llmConfidences = allCorrections.Select(c => c.Correction.Confidence * 100).ToList();
            var allValues = new List<double> { adiResult.AverageConfidence };
            allValues.AddRange(llmConfidences);
            adiResult.AverageConfidence = allValues.Average();
        }

        adiResult.ModelUsed = $"ADI prebuilt-layout + Ollama LLM ({appliedCount} corrections)";
        adiResult.RawJson = BuildHybridJson(adiResult, adiResult.HybridCorrections, lowConfidencePages);

        return adiResult;
    }

    // ── Private helpers ─────────────────────────────────────────────────────

    /// <summary>Renders each page of the document as a PNG byte array.</summary>
    private static List<byte[]> RenderPageImages(string filePath)
    {
        var ext = Path.GetExtension(filePath).ToLowerInvariant();
        var result = new List<byte[]>();

        if (ext == ".pdf")
        {
            var opts = new RenderOptions(Dpi: 150);
            using var fs = File.OpenRead(filePath);
            // Materialise the full list before closing the stream
            var skImages = Conversion.ToImages(fs, options: opts).ToList();
            foreach (var skBitmap in skImages)
            {
                using (skBitmap)
                using (var ms = new MemoryStream())
                {
                    skBitmap.Encode(ms, SKEncodedImageFormat.Png, 85);
                    result.Add(ms.ToArray());
                }
            }
        }
        else
        {
            using var bitmap = SKBitmap.Decode(filePath);
            using var ms = new MemoryStream();
            bitmap.Encode(ms, SKEncodedImageFormat.Png, 85);
            result.Add(ms.ToArray());
        }

        return result;
    }

    /// <summary>
    /// Splits OcrResult.ExtractedText into per-page chunks using "─── Page N ───" separators.
    /// </summary>
    private static Dictionary<int, string> ExtractPageTexts(OcrResult result)
    {
        var pageTexts = new Dictionary<int, string>();
        var lines = result.ExtractedText.Split('\n');
        var currentPage = 1;
        var currentLines = new List<string>();

        foreach (var line in lines)
        {
            var match = Regex.Match(line, @"─── Page (\d+) ───");
            if (match.Success)
            {
                // Save previous page
                if (currentLines.Count > 0)
                    pageTexts[currentPage] = string.Join("\n", currentLines);

                currentPage = int.Parse(match.Groups[1].Value);
                currentLines.Clear();
            }
            else
            {
                currentLines.Add(line);
            }
        }

        // Save last page
        if (currentLines.Count > 0)
            pageTexts[currentPage] = string.Join("\n", currentLines);

        // If no separators existed, put everything under key 1
        if (pageTexts.Count == 0)
            pageTexts[1] = result.ExtractedText;

        return pageTexts;
    }

    /// <summary>Builds the correction prompt for the Ollama vision LLM.</summary>
    private static string BuildCorrectionPrompt(string adiText, int pageNumber)
    {
        return $$"""
            You are an expert document reviewer for HMLR (HM Land Registry) legal documents.
            This is page {{pageNumber}} of a scanned legal document, likely a TR1 (Transfer), TP1 (Transfer of Part), or Mortgage Deed.

            The following text was extracted by Azure Document Intelligence (ADI OCR).
            Compare it carefully against the document image provided.

            === ADI EXTRACTED TEXT (Page {{pageNumber}}) ===
            {{adiText}}
            === END OF ADI TEXT ===

            YOUR TASK:
            - Compare the OCR text above against the actual document image
            - Identify ONLY words or phrases you are CONFIDENT are incorrect in the OCR output
            - Focus especially on:
              * Names of parties (transferors, transferees, borrowers, lenders)
              * Title numbers (format like AGL123456)
              * Property addresses and postcodes
              * Amounts in both words and figures
              * Dates
              * Legal terms and standard Land Registry phrases
            - Do NOT guess — only flag corrections you are highly confident about

            RETURN FORMAT:
            Return ONLY valid JSON — no markdown, no code fences, no extra text.
            Use this exact structure:
            {"corrections": [{"original": "incorrect text from OCR", "corrected": "correct text from image", "confidence": 0.95, "reason": "brief explanation"}], "page_summary": "brief summary of page content"}

            If no corrections are needed, return:
            {"corrections": [], "page_summary": "brief summary of page content"}
            """;
    }

    /// <summary>Parses the raw JSON response from the LLM, stripping code fences if present.</summary>
    private static LlmCorrectionResponse? ParseLlmResponse(string rawJson)
    {
        try
        {
            // Strip markdown code fences
            var lines = rawJson.Split('\n')
                .Where(l => !l.TrimStart().StartsWith("```"))
                .ToList();
            var cleaned = string.Join("\n", lines);

            // Find the first { and last } to extract just the JSON object
            var start = cleaned.IndexOf('{');
            var end = cleaned.LastIndexOf('}');
            if (start < 0 || end < 0 || end <= start)
                return null;

            var jsonSubstring = cleaned[start..(end + 1)];

            return JsonSerializer.Deserialize<LlmCorrectionResponse>(jsonSubstring,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
        catch
        {
            return null;
        }
    }

    /// <summary>Builds the final hybrid JSON output wrapping ADI data and corrections.</summary>
    private static string BuildHybridJson(OcrResult result, List<HybridCorrection> corrections, List<int> reviewedPages)
    {
        var hybrid = new
        {
            ModelUsed = result.ModelUsed,
            AverageConfidence = result.AverageConfidence,
            Pages = result.Pages,
            ExtractedText = result.ExtractedText,
            StructuredFields = result.StructuredFields.Select(f => new
            {
                f.Key,
                f.Value,
                f.Confidence
            }),
            HybridCorrections = corrections.Select(c => new
            {
                c.PageNumber,
                c.Stage,
                c.OriginalText,
                c.CorrectedText,
                c.LlmConfidence,
                c.Reason,
                c.WasApplied
            }),
            ReviewedPages = reviewedPages
        };

        return JsonSerializer.Serialize(hybrid, new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });
    }

    // ── LLM response JSON models ────────────────────────────────────────────

    private sealed class LlmCorrectionResponse
    {
        [JsonPropertyName("corrections")]
        public List<LlmFieldCorrection>? Corrections { get; set; }

        [JsonPropertyName("page_summary")]
        public string? PageSummary { get; set; }
    }

    private sealed class LlmFieldCorrection
    {
        [JsonPropertyName("original")]
        public string Original { get; set; } = "";

        [JsonPropertyName("corrected")]
        public string Corrected { get; set; } = "";

        [JsonPropertyName("confidence")]
        public double Confidence { get; set; }

        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
    }
}
