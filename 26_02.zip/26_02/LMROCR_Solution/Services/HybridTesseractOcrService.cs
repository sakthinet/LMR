using LMROCR_Solution.Models;
using PDFtoImage;
using SkiaSharp;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Tesseract;

namespace LMROCR_Solution.Services;

/// <summary>
/// Hybrid Tesseract + OSS LLM engine.
/// 
/// Unlike the ADI hybrid (which only calls the LLM for low-confidence pages),
/// this engine ALWAYS calls the LLM because Tesseract cannot detect:
///   - Checkboxes / selection marks
///   - Handwritten text
///   - Table structure (rows, columns, spans)
///   - Key-value form field pairs
///
/// Pipeline:
///   1. Tesseract extracts raw text + word-level confidence
///   2. Render every page as high-DPI PNG (200 DPI)
///   3. For each page, run 3 focused LLM passes:
///      a) Checkbox detection (visual squares/boxes on the page)
///      b) Form fields + tables (labelled input areas, grids)
///      c) Handwritten text recognition
///   4. Post-process and validate LLM output (filter garbage)
///   5. Optionally correct Tesseract text if low-confidence
///   6. Merge everything into OcrResult
/// </summary>
public class HybridTesseractOcrService : IOcrService
{
    private readonly TesseractOcrService _tesseractService;
    private readonly OllamaVisionService _ollama;
    private readonly string _ollamaModel;
    private readonly int _ollamaTimeoutSeconds;

    /// <summary>Confidence threshold — pages below this get text corrections from LLM.</summary>
    public double LlmConfidenceThreshold { get; set; }

    public HybridTesseractOcrService(
        string tessDataPath,
        string tessLanguage,
        string ollamaBaseUrl,
        string ollamaModel,
        double llmConfidenceThreshold = 70.0,
        int ollamaTimeoutSeconds = 180)
    {
        _tesseractService = new TesseractOcrService(tessDataPath, tessLanguage);
        _ollama = new OllamaVisionService(ollamaBaseUrl, ollamaModel, ollamaTimeoutSeconds);
        _ollamaModel = ollamaModel;
        _ollamaTimeoutSeconds = ollamaTimeoutSeconds;
        LlmConfidenceThreshold = llmConfidenceThreshold;
    }

    public async Task<OcrResult> ProcessAsync(string filePath)
    {
        // ── STEP 1 — Tesseract first pass ───────────────────────────────────
        var result = await _tesseractService.ProcessAsync(filePath);
        result.ModelUsed = $"Tesseract LSTM + {_ollamaModel} [Hybrid]";

        // Add pipeline status header
        result.StructuredFields.Insert(0, new FieldResult
        {
            Key = "── HYBRID PIPELINE STATUS ──",
            Value = "",
            Confidence = 100
        });
        result.StructuredFields.Insert(1, new FieldResult
        {
            Key = "Engine Mode",
            Value = "Hybrid (Tesseract + OSS LLM)",
            Confidence = 100
        });
        result.StructuredFields.Insert(2, new FieldResult
        {
            Key = "Step 1 — Tesseract",
            Value = $"Text extraction ✔  (confidence: {result.AverageConfidence:F1}%)",
            Confidence = result.AverageConfidence
        });
        result.StructuredFields.Insert(3, new FieldResult
        {
            Key = "Tesseract Limitations",
            Value = "Cannot detect: checkboxes, handwriting, tables, KV pairs",
            Confidence = 0
        });

        // ── STEP 2 — Check Ollama availability ──────────────────────────────
        var ollamaAvailable = await _ollama.IsAvailableAsync();
        if (!ollamaAvailable)
        {
            result.HybridCorrections.Add(new HybridCorrection
            {
                Stage = "Ollama Unavailable",
                CorrectedText = $"Start Ollama: run 'ollama serve' and ensure the model is pulled via 'ollama pull {_ollamaModel}'",
                WasApplied = false
            });
            result.StructuredFields.Insert(4, new FieldResult
            {
                Key = "Step 2 — LLM",
                Value = $"❌ Ollama offline — Tesseract-only results (no checkboxes/tables/KV)",
                Confidence = 0
            });
            result.StructuredFields.Insert(5, new FieldResult
            {
                Key = "Action Required",
                Value = $"Run 'ollama serve' then 'ollama pull {_ollamaModel}'",
                Confidence = 0
            });
            result.ModelUsed += " [Ollama offline — Tesseract only]";
            return result;
        }

        result.StructuredFields.Insert(4, new FieldResult
        {
            Key = "LLM Model",
            Value = $"{_ollamaModel}  ✔ Active",
            Confidence = 100
        });
        result.StructuredFields.Insert(5, new FieldResult
        {
            Key = "Step 2 — LLM",
            Value = "Analysing each page: ① checkboxes ② form fields + tables ③ handwriting",
            Confidence = 100
        });

        // ── STEP 3 — Render page images at high DPI ─────────────────────────
        var pageImages = RenderPageImages(filePath);

        // ── STEP 4 — Extract per-page text from Tesseract output ────────────
        var pageTexts = ExtractPageTexts(result);

        // ── STEP 5 — Three focused LLM passes per page ─────────────────────
        var allTables = new List<DocumentTable>();
        var allKvPairs = new List<DocumentKeyValuePair>();
        var allSelectionMarks = new List<DocumentSelectionMark>();
        var allHandwritten = new List<DocumentParagraph>();
        var textCorrections = new List<(int PageNumber, LlmTextCorrection Correction)>();
        int pagesReviewed = 0;

        for (int pageIdx = 0; pageIdx < pageImages.Count; pageIdx++)
        {
            var pageNumber = pageIdx + 1;
            var pageImageBytes = pageImages[pageIdx];
            pageTexts.TryGetValue(pageNumber, out var tessText);
            tessText ??= "";
            pagesReviewed++;

            // ── Pass 1: CHECKBOX detection ──────────────────────────────────
            await RunCheckboxPass(pageNumber, pageImageBytes, tessText,
                allSelectionMarks, result.HybridCorrections);

            // ── Pass 2: FORM FIELDS + TABLES ────────────────────────────────
            await RunFormFieldsAndTablesPass(pageNumber, pageImageBytes, tessText,
                allKvPairs, allTables, result.HybridCorrections);

            // ── Pass 3: HANDWRITING detection ───────────────────────────────
            await RunHandwritingPass(pageNumber, pageImageBytes, tessText,
                allHandwritten, result.HybridCorrections);

            // ── Pass 4: TEXT CORRECTIONS (only for low-confidence pages) ────
            if (result.AverageConfidence < LlmConfidenceThreshold)
            {
                await RunTextCorrectionPass(pageNumber, pageImageBytes, tessText,
                    textCorrections, result);
            }
        }

        // ── STEP 6 — Merge LLM-extracted structure into OcrResult ───────────
        result.Tables = allTables;
        result.KeyValuePairs = allKvPairs;
        result.SelectionMarks = allSelectionMarks;
        if (allHandwritten.Count > 0)
            result.Paragraphs = allHandwritten;

        // ── STEP 7 — Build structured fields for extracted elements ─────────
        BuildStructuredFieldsSections(result, allKvPairs, allSelectionMarks,
            allTables, allHandwritten, textCorrections, pagesReviewed);

        // ── STEP 8 — Confidence and finalise ────────────────────────────────
        var extractionCount = result.HybridCorrections.Count(c => c.Stage == "LLM Extraction" && c.WasApplied);
        if (textCorrections.Count > 0)
        {
            var llmConfs = textCorrections.Select(c => c.Correction.Confidence * 100).ToList();
            var allVals = new List<double> { result.AverageConfidence };
            allVals.AddRange(llmConfs);
            result.AverageConfidence = allVals.Average();
        }

        var totalChanges = textCorrections.Count + extractionCount;
        result.ModelUsed = $"Tesseract + {_ollamaModel} ({totalChanges} extractions, {textCorrections.Count} corrections)";
        result.RawJson = BuildHybridJson(result);

        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    // FOCUSED LLM PASSES
    // ════════════════════════════════════════════════════════════════════════

    private async Task RunCheckboxPass(int pageNumber, byte[] imageBytes, string tessText,
        List<DocumentSelectionMark> allMarks, List<HybridCorrection> corrections)
    {
        try
        {
            var prompt = BuildCheckboxPrompt(tessText, pageNumber);
            var response = await _ollama.GenerateAsync(imageBytes, prompt);
            var parsed = ParseJsonResponse<CheckboxResponse>(response);

            if (parsed?.Checkboxes is { Count: > 0 })
            {
                // Post-process: filter invalid checkboxes
                var valid = parsed.Checkboxes
                    .Where(cb => IsValidCheckboxLabel(cb.Label))
                    .ToList();

                foreach (var cb in valid)
                {
                    allMarks.Add(new DocumentSelectionMark
                    {
                        PageNumber = pageNumber,
                        State = cb.IsChecked ? "selected" : "unselected",
                        Confidence = Math.Clamp(cb.Confidence * 100, 0, 100),
                        Label = cb.Label?.Trim() ?? "",
                        NearbyText = cb.NearbyText?.Trim() ?? ""
                    });
                }

                if (valid.Count > 0)
                {
                    corrections.Add(new HybridCorrection
                    {
                        PageNumber = pageNumber,
                        Stage = "LLM Extraction",
                        CorrectedText = $"Found {valid.Count} checkbox(es) on page {pageNumber}",
                        WasApplied = true
                    });
                }
            }
        }
        catch (Exception ex)
        {
            corrections.Add(new HybridCorrection
            {
                PageNumber = pageNumber,
                Stage = "LLM Error",
                CorrectedText = $"Checkbox detection failed: {ex.Message}",
                WasApplied = false
            });
        }
    }

    private async Task RunFormFieldsAndTablesPass(int pageNumber, byte[] imageBytes, string tessText,
        List<DocumentKeyValuePair> allKv, List<DocumentTable> allTables, List<HybridCorrection> corrections)
    {
        try
        {
            var prompt = BuildFormFieldsPrompt(tessText, pageNumber);
            var response = await _ollama.GenerateAsync(imageBytes, prompt);
            var parsed = ParseJsonResponse<FormFieldsResponse>(response);

            if (parsed is not null)
            {
                // KV pairs — validate
                if (parsed.FormFields is { Count: > 0 })
                {
                    var valid = parsed.FormFields
                        .Where(kv => IsValidKvPair(kv))
                        .ToList();

                    foreach (var kv in valid)
                    {
                        allKv.Add(new DocumentKeyValuePair
                        {
                            PageNumber = pageNumber,
                            Key = kv.FieldLabel?.Trim() ?? "",
                            Value = kv.FieldValue?.Trim() ?? "",
                            Confidence = Math.Clamp(kv.Confidence * 100, 0, 100)
                        });
                    }

                    if (valid.Count > 0)
                    {
                        corrections.Add(new HybridCorrection
                        {
                            PageNumber = pageNumber,
                            Stage = "LLM Extraction",
                            CorrectedText = $"Found {valid.Count} form field(s) on page {pageNumber}",
                            WasApplied = true
                        });
                    }
                }

                // Tables — validate
                if (parsed.Tables is { Count: > 0 })
                {
                    foreach (var tbl in parsed.Tables)
                    {
                        if (tbl.Rows is not { Count: >= 2 }) continue; // need at least header + 1 row
                        var maxCols = tbl.Rows.Max(r => r?.Count ?? 0);
                        if (maxCols < 2) continue; // need at least 2 columns for a real table

                        var grid = new string[tbl.Rows.Count, maxCols];
                        var cells = new List<DocumentTableCell>();

                        for (int r = 0; r < tbl.Rows.Count; r++)
                        {
                            var row = tbl.Rows[r] ?? [];
                            for (int c = 0; c < maxCols; c++)
                            {
                                var cellText = c < row.Count ? row[c]?.Trim() ?? "" : "";
                                grid[r, c] = cellText;
                                cells.Add(new DocumentTableCell
                                {
                                    RowIndex = r,
                                    ColumnIndex = c,
                                    Content = cellText,
                                    Kind = r == 0 ? "columnHeader" : "content"
                                });
                            }
                        }

                        // Validate: table must have at least some non-empty cells
                        var nonEmptyCells = cells.Count(c => !string.IsNullOrWhiteSpace(c.Content));
                        if (nonEmptyCells < 2) continue;

                        allTables.Add(new DocumentTable
                        {
                            PageNumber = pageNumber,
                            RowCount = tbl.Rows.Count,
                            ColumnCount = maxCols,
                            DisplayGrid = grid,
                            Cells = cells
                        });
                    }

                    if (allTables.Any(t => t.PageNumber == pageNumber))
                    {
                        var count = allTables.Count(t => t.PageNumber == pageNumber);
                        corrections.Add(new HybridCorrection
                        {
                            PageNumber = pageNumber,
                            Stage = "LLM Extraction",
                            CorrectedText = $"Found {count} table(s) on page {pageNumber}",
                            WasApplied = true
                        });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            corrections.Add(new HybridCorrection
            {
                PageNumber = pageNumber,
                Stage = "LLM Error",
                CorrectedText = $"Form/table extraction failed: {ex.Message}",
                WasApplied = false
            });
        }
    }

    private async Task RunHandwritingPass(int pageNumber, byte[] imageBytes, string tessText,
        List<DocumentParagraph> allHandwritten, List<HybridCorrection> corrections)
    {
        try
        {
            var prompt = BuildHandwritingPrompt(tessText, pageNumber);
            var response = await _ollama.GenerateAsync(imageBytes, prompt);
            var parsed = ParseJsonResponse<HandwritingResponse>(response);

            if (parsed?.HandwrittenTexts is { Count: > 0 })
            {
                // Post-process: filter items that are clearly printed text
                var valid = parsed.HandwrittenTexts
                    .Where(hw => IsValidHandwriting(hw, tessText))
                    .ToList();

                foreach (var hw in valid)
                {
                    allHandwritten.Add(new DocumentParagraph
                    {
                        PageNumber = pageNumber,
                        Role = "handwritten",
                        Content = hw.Text?.Trim() ?? ""
                    });
                }

                if (valid.Count > 0)
                {
                    corrections.Add(new HybridCorrection
                    {
                        PageNumber = pageNumber,
                        Stage = "LLM Extraction",
                        CorrectedText = $"Found {valid.Count} handwritten region(s) on page {pageNumber}",
                        WasApplied = true
                    });
                }
            }
        }
        catch (Exception ex)
        {
            corrections.Add(new HybridCorrection
            {
                PageNumber = pageNumber,
                Stage = "LLM Error",
                CorrectedText = $"Handwriting detection failed: {ex.Message}",
                WasApplied = false
            });
        }
    }

    private async Task RunTextCorrectionPass(int pageNumber, byte[] imageBytes, string tessText,
        List<(int PageNumber, LlmTextCorrection Correction)> textCorrections, OcrResult result)
    {
        try
        {
            var prompt = BuildTextCorrectionPrompt(tessText, pageNumber);
            var response = await _ollama.GenerateAsync(imageBytes, prompt);
            var parsed = ParseJsonResponse<TextCorrectionResponse>(response);

            if (parsed?.Corrections is { Count: > 0 })
            {
                foreach (var corr in parsed.Corrections)
                {
                    if (string.IsNullOrEmpty(corr.Original) || string.IsNullOrEmpty(corr.Corrected))
                        continue;

                    var wasApplied = false;
                    if (!string.Equals(corr.Original, corr.Corrected, StringComparison.OrdinalIgnoreCase))
                    {
                        result.ExtractedText = result.ExtractedText.Replace(corr.Original, corr.Corrected);
                        foreach (var field in result.StructuredFields)
                        {
                            if (field.Value.Contains(corr.Original))
                            {
                                field.Value = field.Value.Replace(corr.Original, corr.Corrected);
                                field.Confidence = Math.Max(field.Confidence, corr.Confidence * 100);
                            }
                        }
                        wasApplied = true;
                    }

                    result.HybridCorrections.Add(new HybridCorrection
                    {
                        PageNumber = pageNumber,
                        Stage = "LLM Correction",
                        OriginalText = corr.Original,
                        CorrectedText = corr.Corrected,
                        LlmConfidence = corr.Confidence,
                        Reason = corr.Reason ?? "",
                        WasApplied = wasApplied
                    });

                    if (wasApplied)
                        textCorrections.Add((pageNumber, corr));
                }
            }
        }
        catch (Exception ex)
        {
            result.HybridCorrections.Add(new HybridCorrection
            {
                PageNumber = pageNumber,
                Stage = "LLM Error",
                CorrectedText = $"Text correction failed: {ex.Message}",
                WasApplied = false
            });
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // VALIDATION / POST-PROCESSING
    // ════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Validates a checkbox label is a real form option, not instruction text.
    /// Filters out garbage like "X", "'X'", "none", single characters.
    /// </summary>
    private static bool IsValidCheckboxLabel(string? label)
    {
        if (string.IsNullOrWhiteSpace(label)) return false;
        var trimmed = label.Trim().Trim('\'', '"', '\u2018', '\u2019');

        // Reject single characters, "X", "none"
        if (trimmed.Length <= 2) return false;
        if (trimmed.Equals("none", StringComparison.OrdinalIgnoreCase)) return false;
        if (trimmed.Equals("X", StringComparison.OrdinalIgnoreCase)) return false;

        // Reject if label is just an instruction about placing X
        if (trimmed.StartsWith("Place", StringComparison.OrdinalIgnoreCase) &&
            trimmed.Contains("X", StringComparison.OrdinalIgnoreCase)) return false;

        // Must be at least 3 meaningful characters
        return trimmed.Length >= 3;
    }

    /// <summary>
    /// Validates a KV pair is a real form field, not paragraph text or legal references.
    /// </summary>
    private static bool IsValidKvPair(LlmFormField kv)
    {
        if (string.IsNullOrWhiteSpace(kv.FieldLabel)) return false;
        var key = kv.FieldLabel.Trim();

        // Reject if key is longer than 60 chars (it's a sentence, not a field label)
        if (key.Length > 60) return false;

        // Reject if key starts with common legal/instruction boilerplate
        string[] rejectPrefixes = [
            "If you", "Where ", "Remember ", "Failure to ", "Under section",
            "You may ", "The fee ", "The maximum ", "WARNING",
            "©", "Crown copyright", "HM Land Registry is ",
            "Conveyancer is a term", "For information on",
            "This panel ", "If the ", "Unless otherwise"
        ];
        if (rejectPrefixes.Any(p => key.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
            return false;

        // Reject single words that are clearly not field labels (legal references)
        string[] rejectExact = [
            "Section", "Rule", "Form", "OR", "AND", "Schedule",
            "incorporation", "Act", "must sign", "Note", "Notes",
            "IMPORTANT", "See", "Refer", "Please"
        ];
        if (rejectExact.Any(r => key.Equals(r, StringComparison.OrdinalIgnoreCase)))
            return false;

        // Reject if it looks like a sentence (has many words and ends with period)
        if (key.Count(c => c == ' ') > 8 && key.EndsWith('.'))
            return false;

        return true;
    }

    /// <summary>
    /// Validates handwriting detection — filters out items that match printed text.
    /// </summary>
    private static bool IsValidHandwriting(LlmHandwrittenText hw, string tessText)
    {
        if (string.IsNullOrWhiteSpace(hw.Text)) return false;
        var text = hw.Text.Trim();

        // Reject very short items (likely noise)
        if (text.Length < 3) return false;

        // Reject if the text is an exact substring of Tesseract's printed text output
        // (means it's printed, not handwritten — Tesseract CAN read printed text)
        if (tessText.Contains(text, StringComparison.OrdinalIgnoreCase))
            return false;

        // Reject common form boilerplate labels that are definitely printed
        string[] rejectPatterns = [
            "address(es) for service", "conveyancer", "reference",
            "name, address", "form", "year", "panel", "section",
            "Land Registry", "application", "title number",
            "transfer", "assent", "lease", "certificate"
        ];
        if (rejectPatterns.Any(p => text.Equals(p, StringComparison.OrdinalIgnoreCase)))
            return false;

        // Reject if low confidence
        if (hw.Confidence < 0.5) return false;

        return true;
    }

    // ════════════════════════════════════════════════════════════════════════
    // STRUCTURED FIELDS BUILDER
    // ════════════════════════════════════════════════════════════════════════

    private static void BuildStructuredFieldsSections(OcrResult result,
        List<DocumentKeyValuePair> kvPairs, List<DocumentSelectionMark> marks,
        List<DocumentTable> tables, List<DocumentParagraph> handwritten,
        List<(int PageNumber, LlmTextCorrection Correction)> textCorrections,
        int pagesReviewed)
    {
        // KV Pairs section
        if (kvPairs.Count > 0)
        {
            result.StructuredFields.Add(new FieldResult
            {
                Key = "── LLM-EXTRACTED FORM FIELDS ──",
                Value = "",
                Confidence = 100
            });
            foreach (var kv in kvPairs)
            {
                result.StructuredFields.Add(new FieldResult
                {
                    Key = $"[P{kv.PageNumber}] {kv.Key}",
                    Value = string.IsNullOrEmpty(kv.Value) ? "(empty)" : kv.Value,
                    Confidence = kv.Confidence
                });
            }
        }

        // Checkboxes section
        if (marks.Count > 0)
        {
            result.StructuredFields.Add(new FieldResult
            {
                Key = "── LLM-DETECTED CHECKBOXES ──",
                Value = "",
                Confidence = 100
            });
            foreach (var sm in marks)
            {
                var icon = sm.State == "selected" ? "☑" : "☐";
                result.StructuredFields.Add(new FieldResult
                {
                    Key = $"{icon} [P{sm.PageNumber}] {sm.DisplayLabel}",
                    Value = sm.State,
                    Confidence = sm.Confidence
                });
            }
        }

        // Tables section
        if (tables.Count > 0)
        {
            result.StructuredFields.Add(new FieldResult
            {
                Key = "── LLM-DETECTED TABLES ──",
                Value = "",
                Confidence = 100
            });
            for (int ti = 0; ti < tables.Count; ti++)
            {
                var t = tables[ti];
                result.StructuredFields.Add(new FieldResult
                {
                    Key = $"Table {ti + 1} (Page {t.PageNumber})",
                    Value = $"{t.RowCount} rows × {t.ColumnCount} cols",
                    Confidence = 100
                });
                // Show first few rows as preview
                for (int r = 0; r < Math.Min(t.RowCount, 5); r++)
                {
                    var parts = new List<string>();
                    for (int c = 0; c < t.ColumnCount; c++)
                        parts.Add(t.DisplayGrid[r, c] ?? "");
                    var rowLabel = r == 0 ? "  Header" : $"  Row {r}";
                    result.StructuredFields.Add(new FieldResult
                    {
                        Key = rowLabel,
                        Value = string.Join(" │ ", parts),
                        Confidence = 90
                    });
                }
            }
        }

        // Handwritten text section
        if (handwritten.Count > 0)
        {
            result.StructuredFields.Add(new FieldResult
            {
                Key = "── LLM-DETECTED HANDWRITING ──",
                Value = "",
                Confidence = 100
            });
            foreach (var hw in handwritten)
            {
                var preview = hw.Content.Length > 80 ? hw.Content[..80] + "…" : hw.Content;
                result.StructuredFields.Add(new FieldResult
                {
                    Key = $"[P{hw.PageNumber}] Handwritten",
                    Value = preview,
                    Confidence = 80
                });
            }
        }

        // Text corrections summary
        if (textCorrections.Count > 0)
        {
            result.StructuredFields.Add(new FieldResult
            {
                Key = "── LLM TEXT CORRECTIONS ──",
                Value = "",
                Confidence = 100
            });
            result.StructuredFields.Add(new FieldResult
            {
                Key = "Corrections Applied",
                Value = textCorrections.Count.ToString(),
                Confidence = 100
            });
            foreach (var (pageNum, corr) in textCorrections)
            {
                var keyText = corr.Original.Length > 40 ? corr.Original[..40] : corr.Original;
                var valText = corr.Corrected.Length > 80 ? corr.Corrected[..80] : corr.Corrected;
                result.StructuredFields.Add(new FieldResult
                {
                    Key = $"  ✏ [P{pageNum}] {keyText}",
                    Value = valText,
                    Confidence = corr.Confidence * 100
                });
            }
        }

        // Summary
        result.StructuredFields.Add(new FieldResult
        {
            Key = "── HYBRID SUMMARY ──",
            Value = "",
            Confidence = 100
        });
        result.StructuredFields.Add(new FieldResult
        {
            Key = "Pages Reviewed by LLM",
            Value = $"All {pagesReviewed} page(s)",
            Confidence = 100
        });
        result.StructuredFields.Add(new FieldResult
        {
            Key = "Structure Extractions",
            Value = $"{marks.Count} checkboxes, {tables.Count} tables, {kvPairs.Count} KV pairs, {handwritten.Count} handwritten",
            Confidence = 100
        });
        result.StructuredFields.Add(new FieldResult
        {
            Key = "Text Corrections",
            Value = textCorrections.Count.ToString(),
            Confidence = 100
        });
    }

    // ════════════════════════════════════════════════════════════════════════
    // PAGE RENDERING
    // ════════════════════════════════════════════════════════════════════════

    private static List<byte[]> RenderPageImages(string filePath)
    {
        var ext = Path.GetExtension(filePath).ToLowerInvariant();
        var images = new List<byte[]>();

        if (ext == ".pdf")
        {
            // Higher DPI = sharper image for vision model
            var opts = new RenderOptions(Dpi: 200);
            using var fs = File.OpenRead(filePath);
            var skImages = Conversion.ToImages(fs, options: opts).ToList();
            foreach (var skBitmap in skImages)
            {
                using (skBitmap)
                using (var ms = new MemoryStream())
                {
                    skBitmap.Encode(ms, SKEncodedImageFormat.Png, 90);
                    images.Add(ms.ToArray());
                }
            }
        }
        else
        {
            using var bitmap = SKBitmap.Decode(filePath);
            using var ms = new MemoryStream();
            bitmap.Encode(ms, SKEncodedImageFormat.Png, 90);
            images.Add(ms.ToArray());
        }

        return images;
    }

    // ════════════════════════════════════════════════════════════════════════
    // PER-PAGE TEXT EXTRACTION
    // ════════════════════════════════════════════════════════════════════════

    private static Dictionary<int, string> ExtractPageTexts(OcrResult result)
    {
        var pageTexts = new Dictionary<int, string>();
        var lines = result.ExtractedText.Split('\n');
        var currentPage = 1;
        var currentLines = new List<string>();

        foreach (var line in lines)
        {
            var match = Regex.Match(line, @"─── Page (\d+) ───");
            if (match.Success)
            {
                if (currentLines.Count > 0)
                    pageTexts[currentPage] = string.Join("\n", currentLines);
                currentPage = int.Parse(match.Groups[1].Value);
                currentLines.Clear();
            }
            else
            {
                currentLines.Add(line);
            }
        }

        if (currentLines.Count > 0)
            pageTexts[currentPage] = string.Join("\n", currentLines);

        if (pageTexts.Count == 0)
            pageTexts[1] = result.ExtractedText;

        return pageTexts;
    }

    // ════════════════════════════════════════════════════════════════════════
    // FOCUSED PROMPTS — each prompt is specific to ONE task
    // ════════════════════════════════════════════════════════════════════════

    private static string BuildCheckboxPrompt(string tessText, int pageNumber)
    {
        return $$"""
            You are analysing page {{pageNumber}} of a scanned UK government form (likely an HMLR AP1, TR1, TP1, or similar Land Registry form).

            TASK: Find every CHECKBOX or TICK BOX visible in this page image.

            WHAT A CHECKBOX LOOKS LIKE:
            - A small square box (□) that may be empty, ticked (✓), crossed (✗), or contain an X mark
            - They appear next to option text that describes what the checkbox means
            - They are VISUAL ELEMENTS in the image — small drawn squares with borders

            WHAT IS NOT A CHECKBOX:
            - Text instructions that SAY "Place 'X' in the appropriate box" — these are instructions, NOT checkboxes
            - The word "none" in running text
            - Radio buttons or bullet points
            - Table cell borders that look like boxes
            - Panel numbers in boxes (like panel borders)

            For each checkbox found, determine:
            1. Is it CHECKED (contains a tick ✓, cross ✗, or X mark inside) or UNCHECKED (empty square □)?
            2. What is the LABEL — the actual option text printed next to the checkbox?

            EXAMPLES OF REAL CHECKBOXES ON HMLR FORMS:
            - □ the whole of the title(s)
            - □ part of the title(s) as shown on the attached plan
            - □ cheque made payable to 'Land Registry'
            - □ direct debit, under an agreement with Land Registry
            - □ the address of the property
            - □ the address(es) for service from the transfer/assent
            - □ the current address(es) for service shown in the register
            - □ the following address(es) for service
            - □ I am a conveyancer, and I have completed panel 13
            - □ I am not a conveyancer, and I have completed panel 14

            RETURN ONLY valid JSON — no markdown, no code fences, no explanation:
            {"checkboxes": [{"label": "the whole of the title(s)", "nearby_text": "The application affects", "is_checked": false, "confidence": 0.9}]}

            If NO checkboxes are visible on this page: {"checkboxes": []}
            """;
    }

    private static string BuildFormFieldsPrompt(string tessText, int pageNumber)
    {
        return $$"""
            You are analysing page {{pageNumber}} of a scanned UK government form (likely an HMLR AP1, TR1, TP1, or similar Land Registry form).

            TASK 1 — FORM FIELDS: Find labelled input fields where someone would write or type a value.

            A FORM FIELD has:
            - A printed LABEL that is SHORT (typically 1-6 words, followed by a colon or underline)
            - An INPUT AREA next to or below it (may be blank, filled in, or have dotted lines)

            REAL FORM FIELD EXAMPLES (these are the kind of fields to look for):
            - "Local authority serving the property" → value might be a council name or empty
            - "Full postcode of property" → value might be a postcode or empty
            - "Title number(s) of the property" → value might be like "AGL123456" or empty
            - "Key number" → value might be a number or empty
            - "Name" → value might be a person/company name or empty
            - "Address or UK DX box number" → value might be an address or empty
            - "Email address" → value might be an email or empty
            - "Reference" → value might be a reference number or empty
            - "Phone no" → value
            - "Fax no" → value
            - "Date" → value
            - "Documents lodged with this form" → value
            - "The applicant" → value (name of person/company)
            - "Total fees (£)" → value
            - "Price paid or Value (£)" → value
            - "Signature of conveyancer" → value (possibly signed)

            WHAT IS NOT A FORM FIELD — do NOT extract these:
            - Instructions text (e.g., "If you need more room...", "Remember to sign...")
            - Legal references (e.g., "Section 27 of the Land Registration Act 2002")
            - Warning paragraphs (e.g., "WARNING: ...")
            - Copyright notices (e.g., "© Crown copyright")
            - Explanatory notes or guidance text
            - The word "OR" between sections
            - Rule or section numbers (e.g., "Rule 57", "Section 27")

            TASK 2 — TABLES: Find data tables with clear row/column grid structure.
            A real table has VISIBLE GRID LINES forming rows and columns.
            Include the header row and ALL data rows with actual cell content.

            REAL TABLE EXAMPLES ON HMLR FORMS:
            - "Applications in priority order | Price paid/Value (£) | Fees paid (£)"
            - "Name of transferor/... | Conveyancer's name, address and reference"

            RETURN ONLY valid JSON — no markdown, no code fences, no explanation:
            {
              "form_fields": [{"field_label": "Title number(s) of the property", "field_value": "", "confidence": 0.9}],
              "tables": [{"rows": [["Applications in priority order", "Price paid/Value (£)", "Fees paid (£)"], ["", "", ""]]}]
            }

            If none found: {"form_fields": [], "tables": []}
            """;
    }

    private static string BuildHandwritingPrompt(string tessText, int pageNumber)
    {
        return $$"""
            You are analysing page {{pageNumber}} of a scanned UK government form.

            TASK: Find HANDWRITTEN text — text written by hand with pen or pencil, NOT printed by a machine.

            CRITICAL DISTINCTION:
            - HANDWRITTEN text: Irregular letter shapes, varying stroke width, personal handwriting style, ink that looks visually different from the printed form text. Often appears INSIDE form field boxes.
            - PRINTED text: Uniform font, perfectly aligned, consistent letter spacing, same typeface as the rest of the form. This includes ALL form labels, instructions, section headings, and legal text.

            The Tesseract OCR engine already extracted all PRINTED text from this page:
            === TESSERACT PRINTED TEXT ===
            {{tessText}}
            === END ===

            VERY IMPORTANT RULES:
            1. If text appears in the Tesseract output above, it is PRINTED text — do NOT report it as handwritten.
            2. Only report text that is genuinely handwritten and NOT already in the Tesseract output.
            3. If this is a BLANK form with no hand-filled entries, return an empty array.
            4. Form labels like "Name:", "Address:", "Title number:" are PRINTED, not handwritten.
            5. Signatures count as handwriting.

            RETURN ONLY valid JSON — no markdown, no code fences, no explanation:
            {"handwritten_texts": [{"text": "John Smith", "context": "written in the Name field in panel 2", "confidence": 0.8}]}

            If NO handwriting found: {"handwritten_texts": []}
            """;
    }

    private static string BuildTextCorrectionPrompt(string tessText, int pageNumber)
    {
        return $$"""
            You are reviewing page {{pageNumber}} of a scanned document. The text below was extracted by Tesseract OCR.
            Compare it against the document image. Report only CONFIDENT corrections.

            === TESSERACT TEXT (Page {{pageNumber}}) ===
            {{tessText}}
            === END ===

            Focus on: names, title numbers (like AGL123456), amounts, dates, postcodes, legal terms.
            Only report corrections where you are confident the OCR made an error.

            RETURN ONLY valid JSON — no markdown, no code fences, no explanation:
            {"corrections": [{"original": "wrong text", "corrected": "correct text", "confidence": 0.95, "reason": "brief reason"}]}

            If no corrections needed: {"corrections": []}
            """;
    }

    // ════════════════════════════════════════════════════════════════════════
    // JSON PARSING
    // ════════════════════════════════════════════════════════════════════════

    private static T? ParseJsonResponse<T>(string rawJson) where T : class
    {
        try
        {
            // Strip markdown code fences
            var lines = rawJson.Split('\n')
                .Where(l => !l.TrimStart().StartsWith("```"))
                .ToList();
            var cleaned = string.Join("\n", lines);

            var start = cleaned.IndexOf('{');
            var end = cleaned.LastIndexOf('}');
            if (start < 0 || end <= start) return null;

            var json = cleaned[start..(end + 1)];
            return JsonSerializer.Deserialize<T>(json,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
        catch
        {
            return null;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // JSON OUTPUT BUILDER
    // ════════════════════════════════════════════════════════════════════════

    private static string BuildHybridJson(OcrResult result)
    {
        var data = new
        {
            ModelUsed = result.ModelUsed,
            AverageConfidence = result.AverageConfidence,
            Pages = result.Pages,
            ExtractedText = result.ExtractedText,
            StructuredFields = result.StructuredFields.Select(f => new { f.Key, f.Value, f.Confidence }),
            DocumentPages = result.DocumentPages.Select(p => new { p.PageNumber, p.Width, p.Height, p.Unit, p.WordCount, p.LineCount }),
            Tables = result.Tables.Select(t => new
            {
                t.PageNumber,
                t.RowCount,
                t.ColumnCount,
                Cells = t.Cells.Select(c => new { c.RowIndex, c.ColumnIndex, c.Content, c.Kind })
            }),
            KeyValuePairs = result.KeyValuePairs.Select(kv => new { kv.PageNumber, kv.Key, kv.Value, kv.Confidence }),
            SelectionMarks = result.SelectionMarks.Select(sm => new { sm.PageNumber, sm.State, sm.Confidence, sm.Label, sm.NearbyText }),
            Paragraphs = result.Paragraphs.Select(p => new { p.PageNumber, p.Role, p.Content }),
            HybridCorrections = result.HybridCorrections.Select(c => new
            {
                c.PageNumber, c.Stage, c.OriginalText, c.CorrectedText,
                c.LlmConfidence, c.Reason, c.WasApplied
            })
        };

        return JsonSerializer.Serialize(data, new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });
    }

    // ════════════════════════════════════════════════════════════════════════
    // JSON RESPONSE MODEL CLASSES
    // ════════════════════════════════════════════════════════════════════════

    // ── Checkbox pass ────────────────────────────────────────────────────────

    private sealed class CheckboxResponse
    {
        [JsonPropertyName("checkboxes")]
        public List<LlmCheckbox>? Checkboxes { get; set; }
    }

    private sealed class LlmCheckbox
    {
        [JsonPropertyName("label")]
        public string? Label { get; set; }

        [JsonPropertyName("nearby_text")]
        public string? NearbyText { get; set; }

        [JsonPropertyName("is_checked")]
        public bool IsChecked { get; set; }

        [JsonPropertyName("confidence")]
        public double Confidence { get; set; }
    }

    // ── Form fields + tables pass ────────────────────────────────────────────

    private sealed class FormFieldsResponse
    {
        [JsonPropertyName("form_fields")]
        public List<LlmFormField>? FormFields { get; set; }

        [JsonPropertyName("tables")]
        public List<LlmTable>? Tables { get; set; }
    }

    private sealed class LlmFormField
    {
        [JsonPropertyName("field_label")]
        public string? FieldLabel { get; set; }

        [JsonPropertyName("field_value")]
        public string? FieldValue { get; set; }

        [JsonPropertyName("confidence")]
        public double Confidence { get; set; }
    }

    private sealed class LlmTable
    {
        [JsonPropertyName("rows")]
        public List<List<string>>? Rows { get; set; }
    }

    // ── Handwriting pass ─────────────────────────────────────────────────────

    private sealed class HandwritingResponse
    {
        [JsonPropertyName("handwritten_texts")]
        public List<LlmHandwrittenText>? HandwrittenTexts { get; set; }
    }

    private sealed class LlmHandwrittenText
    {
        [JsonPropertyName("text")]
        public string? Text { get; set; }

        [JsonPropertyName("context")]
        public string? Context { get; set; }

        [JsonPropertyName("confidence")]
        public double Confidence { get; set; }
    }

    // ── Text correction pass ─────────────────────────────────────────────────

    private sealed class TextCorrectionResponse
    {
        [JsonPropertyName("corrections")]
        public List<LlmTextCorrection>? Corrections { get; set; }
    }

    private sealed class LlmTextCorrection
    {
        [JsonPropertyName("original")]
        public string Original { get; set; } = "";

        [JsonPropertyName("corrected")]
        public string Corrected { get; set; } = "";

        [JsonPropertyName("confidence")]
        public double Confidence { get; set; }

        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
    }
}
