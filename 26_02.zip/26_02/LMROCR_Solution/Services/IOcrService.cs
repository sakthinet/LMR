using LMROCR_Solution.Models;

namespace LMROCR_Solution.Services;

public interface IOcrService
{
    Task<OcrResult> ProcessAsync(string filePath);
}
