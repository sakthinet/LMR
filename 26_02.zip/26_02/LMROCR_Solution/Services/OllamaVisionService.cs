using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace LMROCR_Solution.Services;

/// <summary>
/// Lightweight HTTP client for the Ollama local REST API.
/// Uses only System.Net.Http and System.Text.Json — no extra NuGet packages.
/// </summary>
public class OllamaVisionService
{
    private readonly HttpClient _httpClient;
    private readonly string _model;

    public OllamaVisionService(string baseUrl, string model, int timeoutSeconds = 120)
    {
        _model = model;
        var normalised = baseUrl.TrimEnd('/') + "/";
        _httpClient = new HttpClient
        {
            BaseAddress = new Uri(normalised),
            Timeout = TimeSpan.FromSeconds(timeoutSeconds)
        };
    }

    /// <summary>
    /// Returns true if the Ollama server is reachable and the configured model is available.
    /// </summary>
    public async Task<bool> IsAvailableAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync("api/tags");
            if (!response.IsSuccessStatusCode) return false;

            var json = await response.Content.ReadAsStringAsync();
            var tagsResponse = JsonSerializer.Deserialize<OllamaTagsResponse>(json,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (tagsResponse?.Models is null) return false;

            return tagsResponse.Models.Any(m =>
                m.Name?.StartsWith(_model, StringComparison.OrdinalIgnoreCase) == true);
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Sends an image and prompt to the Ollama vision model and returns the response text.
    /// </summary>
    public async Task<string> GenerateAsync(byte[] pageImagePng, string prompt)
    {
        var base64 = Convert.ToBase64String(pageImagePng);

        var request = new OllamaGenerateRequest
        {
            Model = _model,
            Prompt = prompt,
            Images = [base64],
            Stream = false,
            Format = "json"
        };

        var jsonPayload = JsonSerializer.Serialize(request,
            new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });

        var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
        var response = await _httpClient.PostAsync("api/generate", content);
        response.EnsureSuccessStatusCode();

        var responseJson = await response.Content.ReadAsStringAsync();
        var result = JsonSerializer.Deserialize<OllamaGenerateResponse>(responseJson,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        return result?.Response ?? "";
    }

    // ── JSON shape classes ──────────────────────────────────────────────────

    private sealed class OllamaTagsResponse
    {
        [JsonPropertyName("models")]
        public List<OllamaModelInfo>? Models { get; set; }
    }

    private sealed class OllamaModelInfo
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }
    }

    private sealed class OllamaGenerateRequest
    {
        [JsonPropertyName("model")]
        public string Model { get; set; } = "";

        [JsonPropertyName("prompt")]
        public string Prompt { get; set; } = "";

        [JsonPropertyName("images")]
        public List<string> Images { get; set; } = [];

        [JsonPropertyName("stream")]
        public bool Stream { get; set; }

        [JsonPropertyName("format")]
        public string Format { get; set; } = "";
    }

    private sealed class OllamaGenerateResponse
    {
        [JsonPropertyName("response")]
        public string? Response { get; set; }
    }
}
