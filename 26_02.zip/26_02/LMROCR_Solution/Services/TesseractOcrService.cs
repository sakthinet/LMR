using LMROCR_Solution.Models;
using PDFtoImage;
using SkiaSharp;
using System.Text;
using System.Text.Json;
using Tesseract;

namespace LMROCR_Solution.Services;

public class TesseractOcrService : IOcrService
{
    private readonly string _tessDataPath;
    private readonly string _language;

    public TesseractOcrService(string tessDataPath, string language)
    {
        _tessDataPath = tessDataPath;
        _language = language;
    }

    public async Task<OcrResult> ProcessAsync(string filePath)
    {
        if (!Directory.Exists(_tessDataPath))
            throw new DirectoryNotFoundException(
                $"Tesseract data folder not found at '{Path.GetFullPath(_tessDataPath)}'. " +
                "Download eng.traineddata from https://github.com/tesseract-ocr/tessdata " +
                "and place it in a 'tessdata' folder next to the application.");

        var ext = Path.GetExtension(filePath).ToLowerInvariant();

        return ext == ".pdf"
            ? await ProcessPdfAsync(filePath)
            : await ProcessImageAsync(filePath);
    }

    // ── PDF: convert each page to a PNG in memory, then OCR ────────────────
    private async Task<OcrResult> ProcessPdfAsync(string filePath)
    {
        return await Task.Run(() =>
        {
            var allText  = new StringBuilder();
            var allWords = new List<WordConfidence>();
            var docPages = new List<Models.DocumentPage>();
            var pageMeanConfs = new List<double>();

            // Materialise ALL pages as PNG byte arrays while the stream is open.
            // ToImages() is lazy – iterating it after the stream closes causes
            // "Cannot access a closed file" (ObjectDisposedException).
            var renderOptions = new RenderOptions(Dpi: 200);
            List<byte[]> pngPages;
            using (var pdfStream = File.OpenRead(filePath))
            {
                pngPages = Conversion.ToImages(pdfStream, options: renderOptions)
                    .Select(bmp =>
                    {
                        using (bmp)
                        using (var ms2 = new MemoryStream())
                        {
                            bmp.Encode(ms2, SkiaSharp.SKEncodedImageFormat.Png, 100);
                            return ms2.ToArray();
                        }
                    }).ToList();
            }
            int pageCount = pngPages.Count;

            int pageIndex = 0;
            foreach (var pngBytes in pngPages)
            {
                pageIndex++;
                // Decode for dimension info only
                using var bitmap = SkiaSharp.SKBitmap.Decode(pngBytes);

                using var engine = new TesseractEngine(_tessDataPath, _language, EngineMode.Default);
                using var pix    = Pix.LoadFromMemory(pngBytes);
                using var page   = engine.Process(pix);

                var pageText = page.GetText() ?? "";
                var meanConf = page.GetMeanConfidence() * 100;
                pageMeanConfs.Add(meanConf);

                if (pageCount > 1)
                    allText.AppendLine($"─── Page {pageIndex} ───────────────────────────────────");
                allText.AppendLine(pageText.Trim());
                if (pageCount > 1)
                    allText.AppendLine();

                var pageWords = new List<WordConfidence>();
                try
                {
                    using var iter = page.GetIterator();
                    iter.Begin();
                    do
                    {
                        var word = iter.GetText(PageIteratorLevel.Word);
                        if (!string.IsNullOrWhiteSpace(word))
                        {
                            var conf = iter.GetConfidence(PageIteratorLevel.Word);
                            pageWords.Add(new WordConfidence(word.Trim(), conf));
                        }
                    } while (iter.Next(PageIteratorLevel.Word));
                }
                catch { /* word-level may not be available */ }

                allWords.AddRange(pageWords);

                docPages.Add(new Models.DocumentPage
                {
                    PageNumber = pageIndex,
                    Width      = bitmap.Width,
                    Height     = bitmap.Height,
                    Unit       = "pixel",
                    WordCount  = pageWords.Count,
                    LineCount  = pageText.Split('\n', StringSplitOptions.RemoveEmptyEntries).Length
                });
            }

            return BuildResult(allText.ToString(), allWords, docPages, pageCount, pageMeanConfs);
        });
    }

    // ── Single image ────────────────────────────────────────────────────────
    private async Task<OcrResult> ProcessImageAsync(string filePath)
    {
        return await Task.Run(() =>
        {
            using var engine = new TesseractEngine(_tessDataPath, _language, EngineMode.Default);
            using var img    = Pix.LoadFromFile(filePath);
            using var page   = engine.Process(img);

            var text     = page.GetText() ?? "";
            var meanConf = page.GetMeanConfidence() * 100;

            var words = new List<WordConfidence>();
            try
            {
                using var iter = page.GetIterator();
                iter.Begin();
                do
                {
                    var word = iter.GetText(PageIteratorLevel.Word);
                    if (!string.IsNullOrWhiteSpace(word))
                    {
                        var conf = iter.GetConfidence(PageIteratorLevel.Word);
                        words.Add(new WordConfidence(word.Trim(), conf));
                    }
                } while (iter.Next(PageIteratorLevel.Word));
            }
            catch { }

            var docPage = new Models.DocumentPage
            {
                PageNumber = 1,
                Width      = img.Width,
                Height     = img.Height,
                Unit       = "pixel",
                WordCount  = words.Count,
                LineCount  = text.Split('\n', StringSplitOptions.RemoveEmptyEntries).Length
            };

            return BuildResult(text, words, [docPage], 1, [meanConf]);
        });
    }

    // ── Shared result builder ───────────────────────────────────────────────
    private OcrResult BuildResult(string text, List<WordConfidence> words,
        List<Models.DocumentPage> docPages, int pageCount, List<double> pageMeanConfs)
    {
        // Use page-level mean confidence from Tesseract (more reliable than
        // averaging individual word confidences which include noise/artifacts)
        var avgPageConf = pageMeanConfs.Count > 0 ? pageMeanConfs.Average() : 0;

        var fields = new List<FieldResult>
        {
            new() { Key = "── DOCUMENT SUMMARY ──",  Value = "",                          Confidence = 100 },
            new() { Key = "Engine",                   Value = "Tesseract OCR",             Confidence = 100 },
            new() { Key = "Language",                 Value = _language,                   Confidence = 100 },
            new() { Key = "Pages",                    Value = pageCount.ToString(),         Confidence = 100 },
            new() { Key = "Word Count",               Value = words.Count.ToString(),       Confidence = 100 },
            new() { Key = "Avg Page Confidence",      Value = $"{avgPageConf:F1}%",         Confidence = avgPageConf }
        };

        var jsonData = new
        {
            Engine               = "Tesseract OCR",
            Language             = _language,
            Pages                = docPages,
            WordCount            = words.Count,
            AveragePageConfidence = avgPageConf,
            Text                 = text.Trim(),
            Words                = words.Select(w => new { w.Text, w.Confidence })
        };
        var json = JsonSerializer.Serialize(jsonData,
            new JsonSerializerOptions { WriteIndented = true });

        return new OcrResult
        {
            ExtractedText     = text.Trim(),
            StructuredFields  = fields,
            AverageConfidence = avgPageConf,
            Pages             = pageCount,
            RawJson           = json,
            ModelUsed         = "LSTM (eng.traineddata)",
            DocumentPages     = docPages
        };
    }

    private record WordConfidence(string Text, float Confidence);
}
