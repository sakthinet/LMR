using Azure;
using Azure.AI.FormRecognizer.DocumentAnalysis;
using LMROCR_Solution.Models;
using System.Text;
using System.Text.Json;

namespace LMROCR_Solution.Services;

public class AzureOcrService : IOcrService
{
    // prebuilt-document gives KV pairs (including empty text boxes) + selection marks with labels
    // prebuilt-layout gives full paragraph roles + tables but NO KV pairs
    // We run prebuilt-document as primary — it includes everything layout has plus form fields.
    //private const string Model = "prebuilt-document";
    private const string Model = "prebuilt-layout";

    private readonly string _endpoint;
    private readonly string _apiKey;

    public AzureOcrService(string endpoint, string apiKey)
    {
        if (string.IsNullOrWhiteSpace(endpoint) || endpoint.Contains("YOUR-RESOURCE"))
            throw new InvalidOperationException(
                "Azure Document Intelligence endpoint is not configured.\n\n" +
                "Update the Azure:Endpoint value in appsettings.json.\n" +
                "Example: https://YOUR-RESOURCE.cognitiveservices.azure.com/");

        if (string.IsNullOrWhiteSpace(apiKey) || apiKey.Contains("YOUR-API-KEY"))
            throw new InvalidOperationException(
                "Azure Document Intelligence API key is not configured.\n\n" +
                "Update the Azure:ApiKey value in appsettings.json.");

        // Ensure endpoint ends with /
        _endpoint = endpoint.TrimEnd('/') + "/";
        _apiKey = apiKey.Trim();
    }

    public async Task<OcrResult> ProcessAsync(string filePath)
    {
        try
        {
            var client = new DocumentAnalysisClient(
                new Uri(_endpoint), new AzureKeyCredential(_apiKey));

            using var stream = File.OpenRead(filePath);
            var operation = await client.AnalyzeDocumentAsync(
                WaitUntil.Completed, Model, stream);
            var az = operation.Value;

        // ── 1. Pages ────────────────────────────────────────────────────────
        var docPages = az.Pages.Select(p => new Models.DocumentPage
        {
            PageNumber = p.PageNumber,
            Width      = p.Width ?? 0,
            Height     = p.Height ?? 0,
            Unit       = p.Unit?.ToString() ?? "",
            WordCount  = p.Words.Count,
            LineCount  = p.Lines.Count
        }).ToList();

        // ── 2. Paragraphs ───────────────────────────────────────────────────
        var paragraphs = az.Paragraphs.Select(p => new Models.DocumentParagraph
        {
            PageNumber = p.BoundingRegions.Count > 0 ? p.BoundingRegions[0].PageNumber : 0,
            Role       = p.Role?.ToString() ?? "body",
            Content    = p.Content
        }).ToList();

        // ── 3. Tables — handle column/row spans correctly ───────────────────
        var tables = az.Tables.Select(t =>
        {
            // Build a display grid that accounts for spans (mark spanned cells clearly)
            var display = new string[t.RowCount, t.ColumnCount];
            foreach (var c in t.Cells)
            {
                // Primary cell
                display[c.RowIndex, c.ColumnIndex] = c.Content;
                // Mark spanned-over cells so they don't appear blank
                for (int dr = 0; dr < c.RowSpan; dr++)
                    for (int dc = 0; dc < c.ColumnSpan; dc++)
                        if ((dr > 0 || dc > 0) &&
                            c.RowIndex + dr < t.RowCount &&
                            c.ColumnIndex + dc < t.ColumnCount)
                            display[c.RowIndex + dr, c.ColumnIndex + dc] = $"↑ {c.Content}";
            }

            return new Models.DocumentTable
            {
                PageNumber  = t.BoundingRegions.Count > 0 ? t.BoundingRegions[0].PageNumber : 0,
                RowCount    = t.RowCount,
                ColumnCount = t.ColumnCount,
                DisplayGrid = display,
                Cells       = t.Cells.Select(c => new Models.DocumentTableCell
                {
                    RowIndex    = c.RowIndex,
                    ColumnIndex = c.ColumnIndex,
                    RowSpan     = c.RowSpan,
                    ColumnSpan  = c.ColumnSpan,
                    Kind        = c.Kind.ToString(),
                    Content     = c.Content
                }).ToList()
            };
        }).ToList();

        // ── 4. Key-Value Pairs (includes empty text boxes) ──────────────────
        // prebuilt-document returns ALL form fields; empty Value.Content = unfilled box
        var kvPairs = az.KeyValuePairs.Select(kvp => new Models.DocumentKeyValuePair
        {
            Key        = kvp.Key?.Content ?? "",
            Value      = kvp.Value?.Content ?? "",
            Confidence = (double)(kvp.Confidence * 100),
            PageNumber = kvp.Key != null && kvp.Key.BoundingRegions.Count > 0
                         ? kvp.Key.BoundingRegions[0].PageNumber : 0
        }).ToList();

        // ── 5. Selection Marks — label from KV pair key where possible ──────
        // Build a lookup: selection mark position → KV key label
        // prebuilt-document links selection marks to their KV key via content span
        var selectionMarks = new List<Models.DocumentSelectionMark>();

        // First pass: collect KV pairs whose value content is a selection mark token
        // ":selected:" / ":unselected:" are the Azure tokens for checkboxes in KV values
        var checkboxKvLabels = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var kvp in az.KeyValuePairs)
        {
            var valContent = kvp.Value?.Content ?? "";
            if (valContent.Contains(":selected:", StringComparison.OrdinalIgnoreCase) ||
                valContent.Contains(":unselected:", StringComparison.OrdinalIgnoreCase))
            {
                var label = kvp.Key?.Content ?? "";
                // Map by value content token
                if (!checkboxKvLabels.ContainsKey(valContent))
                    checkboxKvLabels[valContent] = label;
            }
        }

        foreach (var page in az.Pages)
        {
            foreach (var mark in page.SelectionMarks)
            {
                // Try to find a KV pair label for this mark using bounding region proximity
                var label = "";
                var markX = mark.BoundingPolygon.Count > 0 ? mark.BoundingPolygon.Average(p => p.X) : 0;
                var markY = mark.BoundingPolygon.Count > 0 ? mark.BoundingPolygon.Average(p => p.Y) : 0;

                // Look for KV pairs on same page whose value bbox is near this mark
                foreach (var kvp in az.KeyValuePairs)
                {
                    if (kvp.Value == null) continue;
                    var valContent = kvp.Value.Content ?? "";
                    if (!valContent.Contains(":selected:", StringComparison.OrdinalIgnoreCase) &&
                        !valContent.Contains(":unselected:", StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (kvp.Value.BoundingRegions.Count == 0) continue;
                    if (kvp.Value.BoundingRegions[0].PageNumber != page.PageNumber) continue;

                    var vr = kvp.Value.BoundingRegions[0];
                    // Use bounding box centre of the KV value region
                    if (vr.BoundingPolygon.Count > 0)
                    {
                        var vx = vr.BoundingPolygon.Average(p => p.X);
                        var vy = vr.BoundingPolygon.Average(p => p.Y);
                        var dist = Math.Sqrt(Math.Pow(vx - markX, 2) + Math.Pow(vy - markY, 2));
                        if (dist < 0.5) // within ~0.5 inch
                        {
                            label = kvp.Key?.Content ?? "";
                            break;
                        }
                    }
                }

                // Fallback: find the nearest LINE to the checkbox for a coherent label
                // (using individual words produced garbled cross-line text)
                var nearbyText = "";
                if (mark.BoundingPolygon.Count > 0)
                {
                    // Find lines on the same vertical level (within ~0.3 inch)
                    var sameLevelLines = page.Lines
                        .Where(l => l.BoundingPolygon.Count > 0)
                        .Select(l =>
                        {
                            var ly = l.BoundingPolygon.Average(p => p.Y);
                            var lx = l.BoundingPolygon.Average(p => p.X);
                            return new { Line = l, CX = lx, CY = ly, YDist = Math.Abs(ly - markY) };
                        })
                        .Where(l => l.YDist < 0.3)
                        .OrderBy(l => l.YDist)
                        .ThenBy(l => Math.Abs(l.CX - markX))
                        .ToList();

                    if (sameLevelLines.Count > 0)
                    {
                        // Prefer a line to the RIGHT of the checkbox; fall back to nearest
                        var rightLine = sameLevelLines.FirstOrDefault(l => l.CX > markX);
                        nearbyText = (rightLine ?? sameLevelLines[0]).Line.Content;
                    }
                    else
                    {
                        // No line at same level — pick absolutely nearest line
                        nearbyText = page.Lines
                            .Where(l => l.BoundingPolygon.Count > 0)
                            .OrderBy(l => Math.Pow(l.BoundingPolygon.Average(p => p.X) - markX, 2)
                                         + Math.Pow(l.BoundingPolygon.Average(p => p.Y) - markY, 2))
                            .Select(l => l.Content)
                            .FirstOrDefault() ?? "";
                    }
                }

                selectionMarks.Add(new Models.DocumentSelectionMark
                {
                    PageNumber  = page.PageNumber,
                    // Override low-confidence "Selected" marks to "Unselected" to reduce false positives
                    State       = mark.State.ToString().Equals("Selected", StringComparison.OrdinalIgnoreCase)
                                  && (mark.Confidence * 100) < 50
                                  ? "Unselected"
                                  : mark.State.ToString(),
                    Confidence  = (double)(mark.Confidence * 100),
                    Label       = label,
                    NearbyText  = nearbyText
                });
            }
        }

        // ── 6. Extracted text (page-by-page) ────────────────────────────────
        var textBuilder = new StringBuilder();
        foreach (var page in az.Pages)
        {
            if (az.Pages.Count > 1)
                textBuilder.AppendLine($"─── Page {page.PageNumber} ───────────────────────────────────");
            foreach (var line in page.Lines)
                textBuilder.AppendLine(line.Content);
            if (az.Pages.Count > 1)
                textBuilder.AppendLine();
        }

        // ── 7. StructuredFields grid ─────────────────────────────────────────
        var fields = new List<FieldResult>();

        // Summary
        fields.Add(new FieldResult { Key = "── DOCUMENT SUMMARY ──",  Value = "",                           Confidence = 100 });
        fields.Add(new FieldResult { Key = "Model",                    Value = Model,                        Confidence = 100 });
        fields.Add(new FieldResult { Key = "Pages",                    Value = az.Pages.Count.ToString(),    Confidence = 100 });
        fields.Add(new FieldResult { Key = "Tables",                   Value = tables.Count.ToString(),      Confidence = 100 });
        fields.Add(new FieldResult { Key = "Paragraphs",               Value = paragraphs.Count.ToString(),  Confidence = 100 });
        fields.Add(new FieldResult { Key = "Form Fields (KV Pairs)",   Value = kvPairs.Count.ToString(),     Confidence = 100 });
        fields.Add(new FieldResult { Key = "Checkboxes",               Value = selectionMarks.Count.ToString(), Confidence = 100 });

        // Form fields — split filled vs empty
        if (kvPairs.Count > 0)
        {
            var filled  = kvPairs.Where(k => !k.IsEmpty).ToList();
            var empty   = kvPairs.Where(k => k.IsEmpty).ToList();

            if (filled.Count > 0)
            {
                fields.Add(new FieldResult { Key = "── FILLED FORM FIELDS ──", Value = "", Confidence = 100 });
                foreach (var kv in filled)
                    fields.Add(new FieldResult
                    {
                        Key        = $"[P{kv.PageNumber}] {kv.Key}",
                        Value      = kv.Value,
                        Confidence = kv.Confidence
                    });
            }
            if (empty.Count > 0)
            {
                fields.Add(new FieldResult { Key = "── EMPTY FORM FIELDS ──", Value = "", Confidence = 100 });
                foreach (var kv in empty)
                    fields.Add(new FieldResult
                    {
                        Key        = $"[P{kv.PageNumber}] {kv.Key}",
                        Value      = "(empty)",
                        Confidence = kv.Confidence
                    });
            }
        }

        // Checkboxes
        if (selectionMarks.Count > 0)
        {
            fields.Add(new FieldResult { Key = "── CHECKBOXES ──", Value = "", Confidence = 100 });
            foreach (var sm in selectionMarks)
            {
                var icon = sm.State.Equals("selected", StringComparison.OrdinalIgnoreCase) ? "☑" : "☐";
                fields.Add(new FieldResult
                {
                    Key        = $"{icon} [P{sm.PageNumber}] {sm.DisplayLabel}",
                    Value      = sm.State,
                    Confidence = sm.Confidence
                });
            }
        }

        // Tables summary
        if (tables.Count > 0)
        {
            fields.Add(new FieldResult { Key = "── TABLES ──", Value = "", Confidence = 100 });
            for (int ti = 0; ti < tables.Count; ti++)
            {
                var t = tables[ti];
                fields.Add(new FieldResult
                {
                    Key        = $"Table {ti + 1} (Page {t.PageNumber})",
                    Value      = $"{t.RowCount} rows × {t.ColumnCount} cols",
                    Confidence = 100
                });
                // Add each row as a sub-entry
                for (int r = 0; r < t.RowCount; r++)
                {
                    var parts = new List<string>();
                    for (int c = 0; c < t.ColumnCount; c++)
                        parts.Add(t.DisplayGrid[r, c] ?? "");
                    var isHeader = t.Cells.Any(cl => cl.RowIndex == r &&
                        cl.Kind.Contains("Header", StringComparison.OrdinalIgnoreCase));
                    fields.Add(new FieldResult
                    {
                        Key        = isHeader ? $"  ┌ Header row {r + 1}" : $"  │ Row {r + 1}",
                        Value      = string.Join(" │ ", parts),
                        Confidence = 100
                    });
                }
            }
        }

        // Paragraph roles
        var roles = paragraphs
            .Where(p => !string.IsNullOrEmpty(p.Role) && p.Role != "body")
            .GroupBy(p => p.Role)
            .ToDictionary(g => g.Key, g => g.Count());
        if (roles.Count > 0)
        {
            fields.Add(new FieldResult { Key = "── PARAGRAPH ROLES ──", Value = "", Confidence = 100 });
            foreach (KeyValuePair<string, int> kvRole in roles)
                fields.Add(new FieldResult { Key = kvRole.Key, Value = $"{kvRole.Value} paragraph(s)", Confidence = 100 });
        }

        // ── 8. Confidence — always word-level OCR accuracy ────────────────────
        // Word confidence is the authoritative signal: it reflects how well the
        // model recognised each character/word, regardless of whether KV pairs
        // were detected. KV pair confidence measures extraction correctness, not
        // OCR quality, and is a different (incomparable) scale.
        var wordConf = az.Pages
            .SelectMany(p => p.Words)
            .Select(w => (double)(w.Confidence * 100))
            .ToList();
        var avgConfidence = wordConf.Count > 0 ? wordConf.Average() : 0;

        // ── 9. Rich JSON ──────────────────────────────────────────────────────
        var summary = new
        {
            Engine     = "Azure Document Intelligence",
            Model,
            Pages      = docPages,
            Paragraphs = paragraphs.Select(p => new { p.PageNumber, p.Role, p.Content }),
            Tables     = tables.Select(t => new
            {
                t.PageNumber, t.RowCount, t.ColumnCount,
                Cells = t.Cells.Select(c => new { c.RowIndex, c.ColumnIndex, c.RowSpan, c.ColumnSpan, c.Kind, c.Content })
            }),
            FilledFormFields = kvPairs.Where(k => !k.IsEmpty)
                .Select(k => new { k.PageNumber, k.Key, k.Value, k.Confidence }),
            EmptyFormFields  = kvPairs.Where(k => k.IsEmpty)
                .Select(k => new { k.PageNumber, k.Key, k.Confidence }),
            Checkboxes = selectionMarks.Select(s => new
            {
                s.PageNumber, s.State, s.Confidence,
                Label = s.DisplayLabel
            }),
            ExtractedText = textBuilder.ToString().TrimEnd()
        };
        var json = JsonSerializer.Serialize(summary,
            new JsonSerializerOptions { WriteIndented = true });

        return new OcrResult
        {
            ExtractedText     = textBuilder.ToString().TrimEnd(),
            StructuredFields  = fields,
            AverageConfidence = avgConfidence,
            Pages             = az.Pages.Count,
            RawJson           = json,
            ModelUsed         = Model,
            DocumentPages     = docPages,
            Paragraphs        = paragraphs,
            Tables            = tables,
            KeyValuePairs     = kvPairs,
            SelectionMarks    = selectionMarks
        };
        }
        catch (RequestFailedException ex) when (ex.Status == 401)
        {
            throw new InvalidOperationException(
                $"Azure authentication failed (HTTP 401).\n\n" +
                $"Endpoint: {_endpoint}\n" +
                $"API Key: {_apiKey[..8]}... (first 8 chars)\n\n" +
                $"Possible causes:\n" +
                $"1. Invalid API key\n" +
                $"2. Wrong endpoint region\n" +
                $"3. Resource not active\n\n" +
                $"Error: {ex.Message}", ex);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"Azure Document Intelligence failed.\n\n" +
                $"Endpoint: {_endpoint}\n" +
                $"Error: {ex.Message}", ex);
        }
    }
}
