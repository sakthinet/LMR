using LMROCR_Solution.Models;
using System.Diagnostics;
using System.Text;

namespace LMROCR_Solution.Services;

public class EasyOcrService : IOcrService
{
    private readonly string _pythonPath;

    public EasyOcrService(string pythonPath)
    {
        _pythonPath = pythonPath;
    }

    public async Task<OcrResult> ProcessAsync(string filePath)
    {
        var scriptPath = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "Scripts", "easy_ocr.py");

        if (!File.Exists(scriptPath))
            throw new FileNotFoundException(
                $"EasyOCR script not found at '{scriptPath}'.");

        var (exitCode, stdout, stderr) = await RunPythonAsync(scriptPath, filePath);

        if (exitCode != 0)
        {
            var errorMsg = !string.IsNullOrWhiteSpace(stderr) ? stderr : stdout;
            throw new InvalidOperationException(
                $"EasyOCR failed (exit code {exitCode}):\n{errorMsg}");
        }

        return PaddleOcrService.ParseCliOutput(stdout, "EasyOCR");
    }

    private async Task<(int ExitCode, string Stdout, string Stderr)> RunPythonAsync(
        string scriptPath, string filePath)
    {
        var psi = new ProcessStartInfo
        {
            FileName = _pythonPath,
            Arguments = $"\"{scriptPath}\" \"{filePath}\"",
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var process = new Process { StartInfo = psi };
        var stdoutBuilder = new StringBuilder();
        var stderrBuilder = new StringBuilder();

        process.OutputDataReceived += (_, e) =>
        {
            if (e.Data != null) stdoutBuilder.AppendLine(e.Data);
        };
        process.ErrorDataReceived += (_, e) =>
        {
            if (e.Data != null) stderrBuilder.AppendLine(e.Data);
        };

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        await process.WaitForExitAsync();

        return (process.ExitCode, stdoutBuilder.ToString(), stderrBuilder.ToString());
    }
}
