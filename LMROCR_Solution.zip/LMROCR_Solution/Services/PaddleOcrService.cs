using LMROCR_Solution.Models;
using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace LMROCR_Solution.Services;

public class PaddleOcrService : IOcrService
{
    private readonly string _pythonPath;

    public PaddleOcrService(string pythonPath)
    {
        _pythonPath = pythonPath;
    }

    public async Task<OcrResult> ProcessAsync(string filePath)
    {
        var scriptPath = Path.Combine(
            AppDomain.CurrentDomain.BaseDirectory, "Scripts", "paddle_ocr.py");

        if (!File.Exists(scriptPath))
            throw new FileNotFoundException(
                $"PaddleOCR script not found at '{scriptPath}'.");

        var (exitCode, stdout, stderr) = await RunPythonAsync(scriptPath, filePath);

        if (exitCode != 0)
        {
            var errorMsg = !string.IsNullOrWhiteSpace(stderr) ? stderr : stdout;
            throw new InvalidOperationException(
                $"PaddleOCR failed (exit code {exitCode}):\n{errorMsg}");
        }

        return ParseCliOutput(stdout, "PaddleOCR");
    }

    private async Task<(int ExitCode, string Stdout, string Stderr)> RunPythonAsync(
        string scriptPath, string filePath)
    {
        var psi = new ProcessStartInfo
        {
            FileName = _pythonPath,
            Arguments = $"\"{scriptPath}\" \"{filePath}\"",
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        using var process = new Process { StartInfo = psi };
        var stdoutBuilder = new StringBuilder();
        var stderrBuilder = new StringBuilder();

        process.OutputDataReceived += (_, e) =>
        {
            if (e.Data != null) stdoutBuilder.AppendLine(e.Data);
        };
        process.ErrorDataReceived += (_, e) =>
        {
            if (e.Data != null) stderrBuilder.AppendLine(e.Data);
        };

        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        await process.WaitForExitAsync();

        return (process.ExitCode, stdoutBuilder.ToString(), stderrBuilder.ToString());
    }

    internal static OcrResult ParseCliOutput(string rawOutput, string engineName)
    {
        // Strip any non-JSON lines (warnings/info printed before redirect kicks in)
        var jsonOutput = rawOutput.Trim();
        var jsonStart  = jsonOutput.IndexOf('{');
        if (jsonStart > 0) jsonOutput = jsonOutput[jsonStart..];

        using var doc = JsonDocument.Parse(jsonOutput);
        var root = doc.RootElement;

        if (root.TryGetProperty("error", out var errorProp))
            throw new InvalidOperationException(
                $"{engineName} error: {errorProp.GetString()}");

        var textBuilder = new StringBuilder();
        var fields = new List<FieldResult>();
        var confidences = new List<double>();

        if (root.TryGetProperty("results", out var results))
        {
            var index = 0;
            foreach (var item in results.EnumerateArray())
            {
                var text = item.GetProperty("text").GetString() ?? "";
                var confidence = item.GetProperty("confidence").GetDouble() * 100;

                textBuilder.AppendLine(text);
                confidences.Add(confidence);

                fields.Add(new FieldResult
                {
                    Key = $"Line {++index}",
                    Value = text,
                    Confidence = confidence
                });
            }
        }

        var avgConfidence = confidences.Count > 0 ? confidences.Average() : 0;

        // Re-format the JSON for display
        var formattedJson = JsonSerializer.Serialize(
            JsonSerializer.Deserialize<JsonElement>(jsonOutput),
            new JsonSerializerOptions { WriteIndented = true });

        // Wrap with engine metadata
        var summary = new
        {
            Engine = engineName,
            AverageConfidence = avgConfidence,
            LineCount = fields.Count,
            Results = JsonSerializer.Deserialize<JsonElement>(jsonOutput)
        };
        var displayJson = JsonSerializer.Serialize(summary,
            new JsonSerializerOptions { WriteIndented = true });

        return new OcrResult
        {
            ExtractedText = textBuilder.ToString().TrimEnd(),
            StructuredFields = fields,
            AverageConfidence = avgConfidence,
            Pages = 1,
            RawJson = displayJson,
            ModelUsed = engineName == "EasyOCR" ? "CRAFT + ResNet (en)" : "PP-OCRv4 (det+rec+cls)"
        };
    }
}
