using Microsoft.Extensions.Configuration;

namespace LMROCR_Solution.Services;

public static class OcrServiceFactory
{
    public static IOcrService Create(string engineName, IConfiguration configuration)
    {
        return engineName switch
        {
            "Azure Document Intelligence" => new AzureOcrService(
                configuration["Azure:Endpoint"] ?? "",
                configuration["Azure:ApiKey"] ?? ""),

            "Tesseract OCR" => new TesseractOcrService(
                configuration["Tesseract:TessDataPath"] ?? "./tessdata",
                configuration["Tesseract:Language"] ?? "eng"),

            "PaddleOCR" => new PaddleOcrService(
                configuration["Python:ExecutablePath"] ?? "python"),

            "EasyOCR" => new EasyOcrService(
                configuration["Python:ExecutablePath"] ?? "python"),

            _ => throw new NotSupportedException(
                $"OCR engine '{engineName}' is not supported.")
        };
    }
}
