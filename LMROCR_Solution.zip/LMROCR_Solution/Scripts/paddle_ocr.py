"""
PaddleOCR wrapper script for LMROCR_Solution.
Usage: python paddle_ocr.py <file_path>
Output: JSON to stdout ONLY. All warnings/info go to stderr.

Prerequisites:
    pip install paddleocr --extra-index-url https://www.paddlepaddle.org.cn/packages/stable/cpu/
"""
import sys
import json
import os

# Must be set BEFORE any paddle imports
os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"] = "True"
os.environ["FLAGS_call_stack_level"] = "0"
os.environ["GLOG_v"] = "0"
os.environ["GLOG_logtostderr"] = "0"

# Redirect stdout temporarily so paddle import noise goes to stderr
import io as _io
_real_stdout = sys.stdout
sys.stdout = sys.stderr  # paddle prints to stdout during import - redirect


def ocr_image_bytes(ocr, img_bytes):
    """Run OCR on raw PNG bytes, return list of {text, confidence}."""
    import numpy as np
    import cv2
    arr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    result = ocr.ocr(img)
    lines = []
    if result:
        for page in result:
            if page is None:
                continue
            for line in page:
                # PaddleOCR 2.x: line[1] = (text, conf)
                # PaddleOCR 3.x: line may be a dict or tuple
                if isinstance(line, (list, tuple)) and len(line) >= 2:
                    rec = line[1]
                    if isinstance(rec, (list, tuple)) and len(rec) >= 2:
                        text, conf = str(rec[0]), float(rec[1])
                    elif isinstance(rec, dict):
                        text = str(rec.get("text", ""))
                        conf = float(rec.get("score", rec.get("confidence", 0)))
                    else:
                        continue
                elif isinstance(line, dict):
                    text = str(line.get("text", ""))
                    conf = float(line.get("score", line.get("confidence", 0)))
                else:
                    continue
                if text.strip():
                    lines.append({"text": text, "confidence": round(conf, 4)})
    return lines


def main():
    if len(sys.argv) < 2:
        sys.stdout = _real_stdout
        print(json.dumps({"error": "No file path provided"}))
        sys.exit(1)

    file_path = sys.argv[1]

    try:
        from paddleocr import PaddleOCR
        ocr = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)
        # Restore real stdout now that noisy imports are done
        sys.stdout = _real_stdout

        ext = os.path.splitext(file_path)[1].lower()
        output = {"results": []}

        if ext == ".pdf":
            try:
                import pypdfium2 as pdfium
            except ImportError:
                sys.stdout = _real_stdout
                print(json.dumps({"error": "pypdfium2 not installed. Run: pip install pypdfium2"}))
                sys.exit(1)

            pdf = pdfium.PdfDocument(file_path)
            for page_idx in range(len(pdf)):
                page = pdf[page_idx]
                bitmap = page.render(scale=200/72)
                pil_img = bitmap.to_pil()
                import io
                buf = io.BytesIO()
                pil_img.save(buf, format="PNG")
                lines = ocr_image_bytes(ocr, buf.getvalue())
                output["results"].extend(lines)
        else:
            import cv2
            result = ocr.ocr(file_path)
            if result:
                for page in result:
                    if page is None:
                        continue
                    for line in page:
                        if isinstance(line, (list, tuple)) and len(line) >= 2:
                            rec = line[1]
                            if isinstance(rec, (list, tuple)) and len(rec) >= 2:
                                text, conf = str(rec[0]), float(rec[1])
                            elif isinstance(rec, dict):
                                text = str(rec.get("text", ""))
                                conf = float(rec.get("score", rec.get("confidence", 0)))
                            else:
                                continue
                        elif isinstance(line, dict):
                            text = str(line.get("text", ""))
                            conf = float(line.get("score", line.get("confidence", 0)))
                        else:
                            continue
                        if text.strip():
                            output["results"].append({"text": text, "confidence": round(conf, 4)})

        print(json.dumps(output))

    except ImportError:
        sys.stdout = _real_stdout
        print(json.dumps({"error": "PaddleOCR is not installed. Run: pip install paddleocr --extra-index-url https://www.paddlepaddle.org.cn/packages/stable/cpu/"}))
        sys.exit(1)
    except Exception as e:
        sys.stdout = _real_stdout
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
