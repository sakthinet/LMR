"""
EasyOCR wrapper script for LMROCR_Solution.
Usage: python easy_ocr.py <file_path>
Output: JSON to stdout ONLY. All warnings/info go to stderr.

Prerequisites:
    pip install easyocr
    pip install pypdfium2   (for PDF support)
"""
import sys
import json
import os

# Redirect stdout to stderr during noisy imports
_real_stdout = sys.stdout
sys.stdout = sys.stderr


def main():
    if len(sys.argv) < 2:
        sys.stdout = _real_stdout
        print(json.dumps({"error": "No file path provided"}))
        sys.exit(1)

    file_path = sys.argv[1]

    try:
        import easyocr
        reader = easyocr.Reader(["en"], gpu=False, verbose=False)
        sys.stdout = _real_stdout  # Restore after noisy import

        ext = os.path.splitext(file_path)[1].lower()
        output = {"results": []}

        if ext == ".pdf":
            try:
                import pypdfium2 as pdfium
                import io
            except ImportError:
                print(json.dumps({"error": "pypdfium2 not installed. Run: pip install pypdfium2"}))
                sys.exit(1)

            pdf = pdfium.PdfDocument(file_path)
            for page_idx in range(len(pdf)):
                page = pdf[page_idx]
                bitmap = page.render(scale=200 / 72)
                pil_img = bitmap.to_pil()
                buf = io.BytesIO()
                pil_img.save(buf, format="PNG")
                results = reader.readtext(buf.getvalue())
                for bbox, text, confidence in results:
                    if text.strip():
                        output["results"].append(
                            {"text": text, "confidence": round(float(confidence), 4)}
                        )
        else:
            results = reader.readtext(file_path)
            for bbox, text, confidence in results:
                if text.strip():
                    output["results"].append(
                        {"text": text, "confidence": round(float(confidence), 4)}
                    )

        print(json.dumps(output))

    except ImportError:
        sys.stdout = _real_stdout
        print(json.dumps({"error": "EasyOCR is not installed. Run: pip install easyocr"}))
        sys.exit(1)
    except Exception as e:
        sys.stdout = _real_stdout
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
