from celery import Celery
import os
import shutil
import uuid
from datetime import datetime
import logging
import mimetypes  # NEW
import requests  # NEW
from kombu import Queue  # NEW
import re  # NEW
import json
import hashlib
from typing import Optional, Any, Dict
import socket
from config import settings

# Optional type-specific metadata libraries
try:
    import PyPDF2
    _have_pypdf2 = True
except Exception:
    _have_pypdf2 = False

try:
    import docx
    _have_docx = True
except Exception:
    _have_docx = False

try:
    from PIL import Image
    _have_pillow = True
except Exception:
    _have_pillow = False


def _parse_pdf_date(dstr: str):
    """Parse PDF date strings like "D:YYYYMMDDHHmmSS" into ISO-8601 if possible.
    Falls back to the original string when parsing fails.
    """
    if not dstr:
        return None
    try:
        # Common PDF date format: D:YYYYMMDDHHmmSSOHH'mm'
        if dstr.startswith("D:"):
            s = dstr[2:]
            # Extract numeric prefix
            digits = ''.join(ch for ch in s if ch.isdigit())
            year = int(digits[0:4])
            month = int(digits[4:6]) if len(digits) >= 6 else 1
            day = int(digits[6:8]) if len(digits) >= 8 else 1
            hour = int(digits[8:10]) if len(digits) >= 10 else 0
            minute = int(digits[10:12]) if len(digits) >= 12 else 0
            second = int(digits[12:14]) if len(digits) >= 14 else 0
            return datetime(year, month, day, hour, minute, second).isoformat()
        else:
            # Try ISO parse fallback
            return datetime.fromisoformat(dstr).isoformat()
    except Exception:
        return dstr

# Read configuration from validated settings (env first, then .env fallback)
BROKER_URL = settings.broker_url
RESULT_BACKEND = settings.result_backend
RAW_DATA_BACKBONE_DIR = settings.data_backbone_dir
PROCESSED_DIR_NAME = settings.processed_dir_name
LOG_LEVEL = settings.log_level.upper()
WORKER_RESULTS_URL = settings.worker_results_url
INGEST_QUEUES = settings.ingest_queues

# Configure logging once  # NEW
logger = logging.getLogger("ingest_worker")  # NEW
if not logger.handlers:  # NEW
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:
    logger.setLevel(logging.INFO)

celery_app = Celery(
    'ingest_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND
)

# Configure queues from env (comma-separated), e.g. "Folder,SharePoint"
queue_names = [q.strip() for q in INGEST_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("INGEST_QUEUES must specify at least one queue name")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
# Optionally set the default queue to the first provided
celery_app.conf.task_default_queue = queue_names[0]


def _compute_file_hash(path: str, *, chunk_size: int = 1024 * 1024) -> Optional[str]:
    """Return the SHA-256 hex digest for *path* using a streaming reader."""
    digest = hashlib.sha256()
    try:
        with open(path, "rb") as handle:
            for chunk in iter(lambda: handle.read(chunk_size), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except Exception as exc:  # noqa: BLE001
        logging.getLogger("ingest_worker").warning("Failed to hash %s: %s", path, exc)
        return None


def _is_truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes", "y", "on"}
    return bool(value)


def _extract_cdc_flag(config: Dict[str, Any]) -> bool:
    if not isinstance(config, dict):
        return False

    for key, value in config.items():
        if isinstance(key, str) and key.lower() == "cdc":
            return _is_truthy(value)
    return False


def _sanitize_backbone_dir(path: str, logger: logging.Logger) -> str:
    """Return a safe, normalized backbone directory or raise ValueError.

    Guards against empty strings, just root UNC ("\\"), or whitespace.
    """
    if not path or path.strip() == "":
        raise ValueError("DATA_BACKBONE_DIR is empty")
    # Normalize backslashes and remove trailing separators (but keep UNC server/share)
    # Reject a path that is exactly \\ (root UNC) which cannot hold files.
    if path in ("\\", "//"):
        raise ValueError("DATA_BACKBONE_DIR points to UNC root only (\\). Provide \\SERVER\\SHARE")
    # If it starts with UNC, ensure it has at least \\server\share
    if path.startswith("\\\\"):
        parts = path.split("\\")
        # After split: ['', '', 'SERVER', 'SHARE', ...]
        if len(parts) < 4 or not parts[2] or not parts[3]:
            raise ValueError(f"DATA_BACKBONE_DIR malformed UNC path: {path}")
    sanitized = path.rstrip("/\\")  # drop trailing slashes
    logger.info(f"Using data backbone directory: {sanitized}")
    return sanitized

# Validate backbone path at startup  # NEW
logger_startup = logger  # reuse configured logger  # NEW
try:
    DATA_BACKBONE_DIR = _sanitize_backbone_dir(RAW_DATA_BACKBONE_DIR, logger_startup)
    # Require the directory to exist and be writable (or at least creatable for subfolders)
    if not os.path.exists(DATA_BACKBONE_DIR):
        raise ValueError(f"DATA_BACKBONE_DIR does not exist: {DATA_BACKBONE_DIR}")
    test_uuid = str(uuid.uuid4())
    probe_path = os.path.join(DATA_BACKBONE_DIR, f"_probe_{test_uuid}")
    try:
        os.makedirs(probe_path)
        os.rmdir(probe_path)
    except Exception as probe_err:  # noqa: BLE001
        raise ValueError(f"DATA_BACKBONE_DIR not writable: {probe_err}") from probe_err
except Exception as _path_err:  # noqa: BLE001
    logger_startup.error(f"Backbone directory validation failed (no fallback will be used): {_path_err}")
    DATA_BACKBONE_DIR = None  # Force tasks to fail fast


@celery_app.task(name="folder_worker.folder_task")  # CHANGED: explicit name & signature
def folder_task(task_id, import_config, dag_id, run_id):  # CHANGED SIGNATURE
    """Ingest files from a shared folder into DATA_BACKBONE_DIR and report results via callback."""
    logger = logging.getLogger("folder_worker")
    status = "failed"
    folders = []  # list of {folder_id, document_name}
    pooled_paths = []
    cdc_enabled = False

    try:
        if DATA_BACKBONE_DIR is None:
            raise RuntimeError("DATA_BACKBONE_DIR invalid or not accessible; ingestion aborted")

        if not isinstance(import_config, dict):
            raise ValueError("import_config must be a JSON object/dict")

        # Extract required values using exact keys per contract
        if "FolderUNCPath" not in import_config:
            raise ValueError("FolderUNCPath is required in import_config")
        raw_path = str(import_config["FolderUNCPath"]).strip()
        # Remove wrapping quotes if present
        if (raw_path.startswith('"') and raw_path.endswith('"')) or (raw_path.startswith("'") and raw_path.endswith("'")):
            raw_path = raw_path[1:-1]

        # Also extract NumFiles here before filesystem checks  # FIX
        num_files_raw = import_config.get("NumFiles")
        if num_files_raw is None or str(num_files_raw).strip() == "":
            num_files = None
        else:
            try:
                num_files = int(num_files_raw)
            except Exception:
                raise ValueError("NumFiles must be an integer if provided")

        cdc_enabled = _extract_cdc_flag(import_config)
        logger.info("CDC flag resolved to %s", cdc_enabled)

        # Normalize incoming UNC path by collapsing extra backslashes and ensuring UNC prefix
        path_tmp = raw_path.replace('/', '\\')
        path_tmp = re.sub(r"\\+", r"\\", path_tmp)
        if path_tmp.startswith("\\"):
            m = re.match(r"^\\+", path_tmp)
            lead = len(m.group(0)) if m else 0
            if lead != 2:
                path_tmp = "\\\\" + path_tmp[lead:]
        # Try standard UNC
        logger.info(f"Resolved UNC path (normalized): {repr(path_tmp)}")

        # Build long-path UNC fallback: \\?\UNC\server\share\rest
        alt_path = None
        if path_tmp.startswith("\\\\"):
            parts = path_tmp.lstrip('\\').split('\\')
            if len(parts) >= 2:
                server, share = parts[0], parts[1]
                rest = '\\'.join(parts[2:])
                alt_path = f"\\\\?\\UNC\\{server}\\{share}"
                if rest:
                    alt_path = alt_path + f"\\{rest}"
                logger.info(f"Long UNC candidate: {repr(alt_path)}")

                # If server looks like a hostname (not dotted IPv4), try to resolve to IP
                try:
                    if server and not re.match(r"^\d+\.\d+\.\d+\.\d+$", server):
                        try:
                            ip = socket.gethostbyname(server)
                            ip_parts = [ip, share]
                            ip_rest = '\\'.join(parts[2:])
                            ip_path = f"\\\\{ip}\\{share}"
                            if ip_rest:
                                ip_path = ip_path + f"\\{ip_rest}"
                            logger.info(f"DNS-resolved UNC candidate: {repr(ip_path)} (from {server})")
                            # Prefer IP-based path if it exists
                            if os.path.isdir(ip_path):
                                shared_folder_path = ip_path
                                logger.info("Using IP-based UNC path after DNS resolution")
                        except Exception:
                            # DNS lookup failed, continue with hostname-based checks
                            pass
                except Exception:
                    pass

        # Validate existence; try normal first, then long UNC
        if os.path.isdir(path_tmp):
            shared_folder_path = path_tmp
        elif alt_path and os.path.isdir(alt_path):
            shared_folder_path = alt_path
            logger.info("Using long UNC path variant after existence check succeeded")
        else:
            raise ValueError(f"Shared folder path does not exist or is not a directory: {path_tmp}")

        logger.info(f"Listing files in shared folder: {shared_folder_path}")
        all_entries = os.listdir(shared_folder_path)
        processed_dir = os.path.join(shared_folder_path, PROCESSED_DIR_NAME)
        # Ensure processed directory exists
        if not os.path.exists(processed_dir):
            os.makedirs(processed_dir, exist_ok=True)

        # Filter only regular files not already the processed directory itself
        candidate_files = [
            f for f in all_entries
            if f != PROCESSED_DIR_NAME and os.path.isfile(os.path.join(shared_folder_path, f))
        ]
        logger.info(f"Found candidate files: {candidate_files}")

        # Determine how many files to pool
        files_to_pool = candidate_files if num_files is None else candidate_files[: max(0, int(num_files))]
        logger.info(f"Files selected for pooling: {files_to_pool}")

        for fname in files_to_pool:
            unique_folder_id = str(uuid.uuid4())
            dst_folder_path = os.path.join(DATA_BACKBONE_DIR, unique_folder_id)
            try:
                os.makedirs(dst_folder_path, exist_ok=True)
            except Exception as mk_err:  # noqa: BLE001
                raise RuntimeError(f"Failed to create destination folder {dst_folder_path}: {mk_err}")

            src_file_path = os.path.join(shared_folder_path, fname)
            dest_file_path = os.path.join(dst_folder_path, fname)
            logger.info(f"Copying {src_file_path} to {dest_file_path}")
            shutil.copy2(src_file_path, dest_file_path)
            file_hash = _compute_file_hash(dest_file_path) if cdc_enabled else None
            # Capture file metadata from the copied file and write as JSON alongside it
            try:
                statv = os.stat(dest_file_path)

                metadata = {
                    "original_filename": fname,
                    "original_path": src_file_path,
                    "stored_path": dest_file_path,
                    "size": statv.st_size,
                    "mode": statv.st_mode,
                    "uid": getattr(statv, "st_uid", None),
                    "gid": getattr(statv, "st_gid", None),
                    "access_time": datetime.fromtimestamp(statv.st_atime).isoformat(),
                    "modification_time": datetime.fromtimestamp(statv.st_mtime).isoformat(),
                    "creation_time": datetime.fromtimestamp(statv.st_ctime).isoformat(),
                    # Source information for downstream workers
                    "source_type": "shared folder",
                    "mime_type": mimetypes.guess_type(dest_file_path)[0],
                    "cdc_enabled": bool(cdc_enabled),
                }
                if file_hash:
                    metadata["sha256_hash"] = file_hash
                # Add type-specific metadata where possible
                lower = fname.lower()
                try:
                    # PDF
                    if lower.endswith('.pdf') and _have_pypdf2:
                        try:
                            reader = PyPDF2.PdfReader(dest_file_path)
                            info = reader.metadata or {}
                            # PdfReader metadata keys commonly like '/Author', '/Title', etc.
                            metadata.update({
                                "author": info.get('/Author') or info.get('Author'),
                                "creator": info.get('/Creator') or info.get('Creator'),
                                "producer": info.get('/Producer') or info.get('Producer'),
                                "subject": info.get('/Subject') or info.get('Subject'),
                                "title": info.get('/Title') or info.get('Title'),
                                "creation_date": _parse_pdf_date(info.get('/CreationDate') or info.get('CreationDate') or info.get('CreationDate')),
                                "modification_date": _parse_pdf_date(info.get('/ModDate') or info.get('ModDate') or info.get('ModDate')),
                                "page_count": len(reader.pages) if hasattr(reader, 'pages') else None,
                            })
                        except Exception:
                            logger.debug(f"Failed to extract PDF metadata for {dest_file_path}")

                    # DOCX
                    elif (lower.endswith('.docx') or lower.endswith('.doc')) and _have_docx:
                        try:
                            doc = docx.Document(dest_file_path)
                            props = doc.core_properties
                            metadata.update({
                                "author": getattr(props, 'author', None),
                                "title": getattr(props, 'title', None),
                                "subject": getattr(props, 'subject', None),
                                "creator": getattr(props, 'creator', None),
                                "keywords": getattr(props, 'keywords', None),
                                "comments": getattr(props, 'comments', None),
                                "last_modified_by": getattr(props, 'last_modified_by', None),
                                "revision": getattr(props, 'revision', None),
                                "category": getattr(props, 'category', None),
                                "creation_date": (props.created.isoformat() if getattr(props, 'created', None) is not None else None),
                                "modification_date": (props.modified.isoformat() if getattr(props, 'modified', None) is not None else None),
                                "paragraph_count": len(doc.paragraphs) if hasattr(doc, 'paragraphs') else None,
                                "table_count": len(doc.tables) if hasattr(doc, 'tables') else None,
                            })
                        except Exception:
                            logger.debug(f"Failed to extract DOCX metadata for {dest_file_path}")

                    # Images (Pillow)
                    elif any(lower.endswith(ext) for ext in ('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff', '.webp')) and _have_pillow:
                        try:
                            with Image.open(dest_file_path) as im:
                                width, height = im.size
                                metadata.update({
                                    "format": getattr(im, 'format', None),
                                    "mode": getattr(im, 'mode', None),
                                    "width": width,
                                    "height": height,
                                    "size_pixels": width * height,
                                })
                        except Exception:
                            logger.debug(f"Failed to extract image metadata for {dest_file_path}")
                except Exception:
                    # Never fail ingestion due to metadata extraction
                    logger.debug(f"Unexpected error while extracting type-specific metadata for {dest_file_path}", exc_info=True)
                meta_filename = f"{fname}.metadata"
                meta_path = os.path.join(dst_folder_path, meta_filename)
                # Write atomically to avoid truncated metadata files
                tmp_path = meta_path + ".tmp"
                with open(tmp_path, "w", encoding="utf-8") as mf:
                    json.dump(metadata, mf, ensure_ascii=False, indent=2)
                    mf.flush()
                    os.fsync(mf.fileno())
                os.replace(tmp_path, meta_path)
                logger.info(f"Wrote metadata for {dest_file_path} -> {meta_path}")
            except Exception as meta_err:  # noqa: BLE001
                logger.warning(f"Failed to write metadata for {dest_file_path}: {meta_err}")

            pooled_paths.append(dest_file_path)
            folder_entry = {
                "folder_id": unique_folder_id,
                "document_name": fname,
            }
            if file_hash:
                folder_entry["file_hash"] = file_hash
            if src_file_path:
                folder_entry["source_path"] = src_file_path
            folder_entry["cdc_enabled"] = bool(cdc_enabled)
            folders.append(folder_entry)

            # Move original to processed
            processed_target = os.path.join(processed_dir, fname)
            logger.info(f"Moving original {src_file_path} to {processed_target}")
            try:
                shutil.move(src_file_path, processed_target)
            except Exception as move_err:  # noqa: BLE001
                # rollback copied file to keep consistency
                try:
                    if os.path.exists(dest_file_path):
                        os.remove(dest_file_path)
                        logger.info(f"Rolled back copied file {dest_file_path} after move failure")
                except Exception as rb_err:  # noqa: BLE001
                    logger.warning(f"Rollback failed for {dest_file_path}: {rb_err}")
                raise RuntimeError(f"Failed to move file {src_file_path} to processed folder: {move_err}")

        status = "success"

    except Exception as e:  # noqa: BLE001
        logger.error(f"Exception in ingest_files_task: {e}", exc_info=True)
        # On failure, folders may be partially filled; that's fine for diagnostics
        status = "failed"
        error_message = str(e)
    else:
        error_message = None

    # POST results to backend callback
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id or "",
        "folders": folders,
        "cdc_enabled": bool(cdc_enabled),
    }
    if error_message:
        payload["error_message"] = error_message

    if WORKER_RESULTS_URL:
        try:
            logger.info(f"Posting worker results to {WORKER_RESULTS_URL}: {payload}")
            resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
            if resp.status_code >= 300:
                logger.error(f"Worker results callback returned HTTP {resp.status_code}: {resp.text}")
        except Exception as cb_err:  # noqa: BLE001
            logger.error(f"Failed to POST worker results: {cb_err}")
    else:
        logger.warning("WORKER_RESULTS_URL is not set; skipping worker results callback")

    return {
        "task_id": task_id,
        "status": status,
        "pooled_files": pooled_paths,
        "folders": folders,
        "cdc_enabled": cdc_enabled,
    }