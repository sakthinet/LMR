"""Configuration for the ingest microservice.

Runtime precedence is:
1) Real environment variables (Kubernetes/App Service/host process)
2) Local `.env` file for development convenience

Critical variables (for example `INGEST_DB_DSN`) are validated on import and
raise early if missing.
"""
from __future__ import annotations
import logging
from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class IngestSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    broker_url: str = Field(
        default="pyamqp://guest@10.73.88.101//",
        validation_alias=AliasChoices("CELERY_BROKER_URL", "RABBITMQ_URL", "INGEST_BROKER_URL"),
    )
    result_backend: str = Field(
        default="rpc://",
        validation_alias=AliasChoices("CELERY_RESULT_BACKEND", "INGEST_RESULT_BACKEND"),
    )
    data_backbone_dir: str = Field(
        default=r"\\10.73.88.101\DataBackBone",
        validation_alias=AliasChoices("DATA_BACKBONE_DIR"),
    )
    db_dsn: str = Field(validation_alias=AliasChoices("INGEST_DB_DSN", "DB_DSN"))
    log_level: str = Field(default="INFO", validation_alias=AliasChoices("INGEST_LOG_LEVEL"))
    processed_dir_name: str = Field(
        default="processed",
        validation_alias=AliasChoices("INGEST_PROCESSED_DIR_NAME"),
    )
    worker_results_url: str = Field(default="", validation_alias=AliasChoices("WORKER_RESULTS_URL"))
    ingest_queues: str = Field(default="folder", validation_alias=AliasChoices("INGEST_QUEUES"))


settings = IngestSettings()

# Backward-compatible module constants
BROKER_URL: str = settings.broker_url
RESULT_BACKEND: str = settings.result_backend
DATA_BACKBONE_DIR: str = settings.data_backbone_dir
DB_DSN: str = settings.db_dsn
LOG_LEVEL: str = settings.log_level.upper()
PROCESSED_DIR_NAME: str = settings.processed_dir_name
WORKER_RESULTS_URL: str = settings.worker_results_url
INGEST_QUEUES: str = settings.ingest_queues


def configure_logging(name: str = "ingest_worker") -> logging.Logger:
    """Create (or retrieve) a configured logger for the ingest service.

    Ensures idempotent configuration so importing this module repeatedly does
    not add duplicate handlers.
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        try:
            logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
        except Exception:
            logger.setLevel(logging.INFO)
    return logger

__all__ = [
    "IngestSettings",
    "settings",
    "BROKER_URL",
    "RESULT_BACKEND",
    "DATA_BACKBONE_DIR",
    "DB_DSN",
    "LOG_LEVEL",
    "PROCESSED_DIR_NAME",
    "WORKER_RESULTS_URL",
    "INGEST_QUEUES",
    "configure_logging",
]
