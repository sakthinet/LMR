import os

DB_DSN = os.getenv("EXPORT_DB_DSN", "postgresql://postgres:postgres@localhost:5432/RND")
DATA_BACKBONE_DIR = r"\\AVDGENAIL18-3\DataBackBone"
QDRANT_URL = os.getenv("EXPORT_QDRANT_URL", "http://10.73.81.24:6333")
