import os
import sys
import uuid
import json
import logging
import importlib
import importlib.util
from pathlib import Path
from types import ModuleType
from typing import List, Optional, Dict

from celery import Celery
from kombu import Queue
import requests

from qdrant_client import QdrantClient
from qdrant_client.http.models import (
    PointStruct,
    VectorParams,
    Distance,
    ScalarQuantization,
    ScalarQuantizationConfig,
    ScalarType,
)

# --------------------------------------------------------------------------------------
# Option B: Make imports work regardless of how/where Celery is launched
# (repo root OR workers/export folder)
# --------------------------------------------------------------------------------------
# qdrant_worker.py path: <repo_root>/workers/export/qdrant_worker.py
REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

# ---------------- Env & Logging -----------------

def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for qdrant_worker")
    return val


# Required configuration
BROKER_URL = os.getenv("EXPORT_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("EXPORT_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")

# QDRANT_URL is now optional; when a connection profile is provided via
# export_profile_name, the worker will prefer the profile's base_url.
QDRANT_URL = os.getenv("QDRANT_URL") or os.getenv("EXPORT_QDRANT_URL")

# Optional default Qdrant connection profile name. If set, this will be
# used when no export_profile_name is supplied in the export_config or
# task arguments.
QDRANT_PROFILE_NAME = os.getenv("QDRANT_PROFILE_NAME")

# Optional default Postgres connection profile name for the chunk store.
# When provided, the worker will prefer this profile over any env-based
# Postgres URL for building the chunk/Postgres connection string.
POSTGRES_PROFILE_NAME = os.getenv("POSTGRES_PROFILE_NAME")

LOG_LEVEL = (os.getenv("EXPORT_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()

# WORKER_RESULTS_URL is used to post task completion status back to API gateway
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")  # e.g. http://localhost:8000/export/worker-results

# Derive API base from the WORKER_RESULTS_URL if API_URL not provided explicitly
API_URL = os.getenv("API_URL")
if not API_URL:
    try:
        from urllib.parse import urlparse, urlunparse

        parsed = urlparse(WORKER_RESULTS_URL)
        API_URL = urlunparse((parsed.scheme, parsed.netloc, "", "", "", ""))
    except Exception:
        API_URL = WORKER_RESULTS_URL

EXPORT_QUEUES = os.getenv("EXPORT_QUEUES") or "qdrant"

logger = logging.getLogger("qdrant_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:
    logger.setLevel(logging.INFO)


# --------------------------------------------------------------------------------------
# Robust module import helpers (works even if packages/__init__.py are missing)
# --------------------------------------------------------------------------------------
def _load_module_from_file(module_name: str, file_path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if not spec or not spec.loader:
        raise ImportError(f"Could not load spec for {module_name} from {file_path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    return mod


def _import_or_load(module_dotted: str, fallback_name: str, candidate_files: List[Path]) -> ModuleType:
    # 1) Try dotted import (package-style)
    try:
        return importlib.import_module(module_dotted)
    except Exception as e1:
        logger.warning(f"Import failed for '{module_dotted}': {e1}")

    # 2) Try simple import (module on sys.path)
    try:
        return importlib.import_module(fallback_name)
    except Exception as e2:
        logger.warning(f"Import failed for '{fallback_name}': {e2}")

    # 3) Try loading by file path
    for p in candidate_files:
        try:
            if p.exists():
                logger.info(f"Loading module '{fallback_name}' from file: {p}")
                return _load_module_from_file(fallback_name, p)
        except Exception as e3:
            logger.warning(f"Failed loading '{fallback_name}' from {p}: {e3}")

    raise ImportError(
        f"Failed to import '{module_dotted}' or '{fallback_name}', and no candidate file worked. "
        f"Tried: {[str(p) for p in candidate_files]}"
    )


# --------------- Celery App ----------------
celery_app = Celery(
    "export_worker",
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

# Configure queues from env (comma-separated)
queue_names = [q.strip() for q in EXPORT_QUEUES.split(",") if q.strip()]
if not queue_names:
    queue_names = ["qdrant"]
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]


# ---------------- Helpers -----------------
def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\") or p.startswith("//"))


def _iter_chunk_files(folder_path: str) -> List[str]:
    files = [f for f in os.listdir(folder_path) if f.startswith("chunk") and f.endswith(".json")]
    files.sort()
    return files


def _get_connection_profile_secret(profile_name: str) -> tuple[Optional[str], Optional[str]]:
    """Fetch a decrypted secret (and optional base URL) for a profile.

    Uses the same /rbac/decryptConnectionProfile endpoint as other workers.
    The full URL must be provided via PROFILE_DECRYPT_URL in this worker's
    environment (for example:
      PROFILE_DECRYPT_URL=http://backend-host:8000/rbac/decryptConnectionProfile
    ).

    The backend returns the plaintext secret (password/api_key) and, for
    API-style profiles, an optional base_url derived from metadata_json.
    """

    url = os.getenv("PROFILE_DECRYPT_URL")
    if url:
        url = url.strip()
    if not url:
        raise RuntimeError(
            "PROFILE_DECRYPT_URL is required for qdrant_worker to decrypt "
            "connection profiles (expected full URL to the "
            "/rbac/decryptConnectionProfile endpoint)."
        )

    payload = {"profile_name": profile_name}

    try:
        resp = requests.post(url, json=payload, timeout=30)
    except Exception as e:
        raise RuntimeError(f"Failed to call decryptConnectionProfile at {url}: {e}") from e

    if resp.status_code != 200:
        try:
            body = resp.json()
        except Exception:
            body = resp.text
        raise RuntimeError(
            f"decryptConnectionProfile returned HTTP {resp.status_code}: {body}"
        )

    data = resp.json() or {}

    # Secret is optional for some connection types (e.g., Qdrant without
    # authentication). If present and a string, we return it; otherwise we
    # treat it as absent and rely only on the base_url.
    secret = data.get("password")
    if not isinstance(secret, str) or not secret:
        secret = None

    base_url = data.get("base_url")
    if base_url is not None and not isinstance(base_url, str):
        base_url = None

    return secret, base_url


def _get_postgres_url_from_profile(profile_name: str) -> str:
    """Build a Postgres DSN from a connection profile.

    Uses the same PROFILE_DECRYPT_URL endpoint, which now returns both
    decrypted password and non-secret metadata (endpoint/auth). Expected
    metadata shape for postgres profiles:

      {
        "endpoint": {"host": "...", "port": 5432, "database": "..."},
        "auth": {"method": "password", "username": "..."}
      }
    """

    url = os.getenv("PROFILE_DECRYPT_URL")
    if url:
        url = url.strip()
    if not url:
        raise RuntimeError(
            "PROFILE_DECRYPT_URL is required for qdrant_worker to decrypt "
            "Postgres connection profiles."
        )

    payload = {"profile_name": profile_name}

    try:
        resp = requests.post(url, json=payload, timeout=30)
    except Exception as e:
        raise RuntimeError(f"Failed to call decryptConnectionProfile at {url}: {e}") from e

    if resp.status_code != 200:
        try:
            body = resp.json()
        except Exception:
            body = resp.text
        raise RuntimeError(
            f"decryptConnectionProfile for Postgres returned HTTP {resp.status_code}: {body}"
        )

    data = resp.json() or {}
    metadata = data.get("metadata") or {}
    endpoint = metadata.get("endpoint") or {}
    auth_meta = metadata.get("auth") or {}

    host = endpoint.get("host")
    port = endpoint.get("port") or 5432
    database = endpoint.get("database")
    username = auth_meta.get("username")
    password = data.get("password") or ""

    missing = [
        name
        for name, val in (
            ("host", host),
            ("database", database),
            ("username", username),
            ("password", password),
        )
        if not val
    ]
    if missing:
        raise RuntimeError(
            f"Postgres connection profile '{profile_name}' is missing required fields: {', '.join(missing)}"
        )

    return f"postgresql://{username}:{password}@{host}:{port}/{database}"


def _distance_from_search_type(search_type: str):
    name = (search_type or "").strip().lower()
    if name in ("cosine", "cos", "angular"):
        return Distance.COSINE
    if name in ("dot", "dotproduct", "ip", "inner_product", "innerproduct"):
        return Distance.DOT
    return Distance.EUCLID


def ensure_optimized_qdrant_collection(
    client: QdrantClient, collection_name: str, vector_size: int, search_type: str
) -> None:
    collections = client.get_collections().collections
    existing_collections = [col.name for col in collections]
    if collection_name in existing_collections:
        logger.info(f"Collection '{collection_name}' exists. Skipping creation.")
        return
    try:
        client.create_collection(
            collection_name=collection_name,
            vectors_config=VectorParams(
                size=vector_size,
                distance=_distance_from_search_type(search_type),
                on_disk=True,
            ),
            quantization_config=ScalarQuantization(
                scalar=ScalarQuantizationConfig(
                    type=ScalarType.INT8,
                    always_ram=True,
                )
            ),
        )
        logger.info(f"Collection '{collection_name}' created.")
    except Exception as e:
        logger.error(f"Failed to create collection '{collection_name}': {e}")
        raise


def export_to_qdrant(
    folder_id: str,
    collection_name: str,
    search_type: str,
    chunk_store_config: Optional[Dict] = None,
    pipeline_name: Optional[str] = None,
    export_profile_name: Optional[str] = None,
    vector_store_config: Optional[Dict] = None,
    export_config: Optional[Dict] = None,
    qdrant_url: Optional[str] = None,
    qdrant_api_key: Optional[str] = None,
    postgres_profile_name: Optional[str] = None,
) -> int:
    # Resolve effective Qdrant URL: prefer the one coming from the
    # connection profile, then fall back to any env-based URL.
    effective_qdrant_url = qdrant_url or QDRANT_URL
    if not effective_qdrant_url:
        raise RuntimeError(
            "No Qdrant URL configured; provide export_profile_name with a "
            "connection profile that has base_url, or set QDRANT_URL/EXPORT_QDRANT_URL."
        )

    # Determine if Postgres chunk store is enabled; if not, we export only to Qdrant (no chunk DB).
    chunk_db_name: Optional[str] = None
    chunk_table_name: Optional[str] = None
    metadata_table_name: Optional[str] = None
    pg_url = None
    schema = None

    # Pull PG URL early (even if chunk_store_config is present but incomplete)
    # so we can decide enablement cleanly. Priority:
    #   1) Explicit postgres_url from chunk_store_config (if provided)
    #   2) Postgres connection profile (if postgres_profile_name given)
    #   3) Legacy env-based URL (EXPORT_PG_URL/PG_URL/POSTGRES_URL)
    if chunk_store_config:
        pg_url = chunk_store_config.get("postgres_url")

    if not pg_url and postgres_profile_name:
        pg_url = _get_postgres_url_from_profile(postgres_profile_name)

    if not pg_url:
        pg_url = os.getenv("EXPORT_PG_URL") or os.getenv("PG_URL") or os.getenv("POSTGRES_URL")

    chunk_db_name = (
        (chunk_store_config or {}).get("chunkdatabase")
        or (chunk_store_config or {}).get("chunkDatabase")
        or (chunk_store_config or {}).get("postgres_table")
        or os.getenv("EXPORT_PG_CHUNK_TABLE")
    )

    chunk_store_enabled = bool(chunk_store_config and chunk_store_config.get("postgres_enabled") and pg_url and chunk_db_name)
    if chunk_store_enabled:
        schema = chunk_store_config.get("postgres_schema") or "public"
        chunk_table_name = f"{chunk_db_name}_chunk"
        metadata_table_name = f"{chunk_db_name}_document_metadata"
    else:
        # Qdrant-only mode: skip Postgres entirely
        pg_url = None
        schema = None
        chunk_table_name = None
        metadata_table_name = None

    # Load postgres_utils early if chunk store is enabled (needed for reprocess deletions)
    postgres_utils = None
    cdc_enabled = bool(
        (export_config or {}).get("cdc")
        or (export_config or {}).get("CDC")
    )

    if chunk_store_enabled:
        postgres_utils = _import_or_load(
            "workers.export.postgres_utils",
            "postgres_utils",
            candidate_files=[
                Path(__file__).resolve().parent / "postgres_utils.py",
                REPO_ROOT / "workers" / "export" / "postgres_utils.py",
                REPO_ROOT / "workers" / "export" / "utils" / "postgres_utils.py",
                REPO_ROOT / "workers" / "common" / "postgres_utils.py",
            ],
        )

        try:
            postgres_utils.validate_identifier(chunk_db_name)  # type: ignore[attr-defined]
        except Exception:
            raise RuntimeError(
                "Invalid chunkdatabase; must start with letter/underscore and contain only letters, numbers, underscores"
            )
    else:
        logger.info("Chunk store disabled or incomplete config; exporting to Qdrant only")

    # Resolve folder path and locate metadata before CDC cleanup so document_name is available
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
    else:
        folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    metadata_file = None
    for f in os.listdir(folder_path):
        if f.endswith(".metadata"):
            metadata_file = os.path.join(folder_path, f)
            break

    # Check reprocess flag via backend (do not hit DB from worker)
    pipeline_name_from_db = None
    try:
        endpoint = API_URL.rstrip("/") + f"/export/reprocess-flag?folder_id={folder_id}"
        resp = requests.get(endpoint, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        reprocess = data.get("reprocess", False)
        pipeline_name_from_db = data.get("pipeline_name")
    except Exception as e:
        logger.warning(f"Failed to fetch reprocess flag: {e}")
        reprocess = False

    if reprocess:
        deletion_folder_id = folder_id
        # Try to fetch previous_folder_id from backend (document_change_log)
        try:
            prev_endpoint = API_URL.rstrip("/") + f"/export/document-change-previous?folder_id={folder_id}"
            prev_resp = requests.get(prev_endpoint, timeout=15)
            prev_resp.raise_for_status()
            prev_data = prev_resp.json()
            prev_fid = prev_data.get("previous_folder_id")
            if prev_fid:
                deletion_folder_id = prev_fid
                logger.info(f"Using previous_folder_id={prev_fid} for reprocess deletions instead of folder_id={folder_id}")
        except Exception as e:
            logger.warning(f"Failed to fetch previous_folder_id; using folder_id={folder_id}: {e}")

        # --- Chunk/vector deletion logic ---
        try:
            conn = None
            chunk_ids: List[str] = []
            if chunk_store_enabled:
                conn = postgres_utils.get_connection(pg_url)
                postgres_utils.check_or_create_chunk_table(conn, schema, chunk_table_name)
                chunk_ids = postgres_utils.fetch_chunk_ids_by_folder(conn, schema, chunk_table_name, deletion_folder_id)
            elif cdc_enabled:
                raise RuntimeError("CDC/Reprocess deletion requires Postgres chunk store to be enabled")

            if chunk_ids:
                if chunk_store_enabled:
                    deleted_pg = postgres_utils.delete_chunks_by_ids(conn, schema, chunk_table_name, chunk_ids)
                    logger.info(f"Deleted {deleted_pg} chunks from Postgres for folder_id={deletion_folder_id} (requested {len(chunk_ids)})")
                client = QdrantClient(url=effective_qdrant_url, api_key=qdrant_api_key)
                client.delete(collection_name=collection_name, points_selector={"points": chunk_ids})
                logger.info(
                    f"Deleted {len(chunk_ids)} vectors from Qdrant collection '{collection_name}' for folder_id={deletion_folder_id}"
                )
            else:
                logger.info(f"No chunks to delete for folder_id={deletion_folder_id}")
        except Exception as e:
            logger.error(f"Failed to delete chunks/vectors for reprocess: {e}")
        finally:
            if chunk_store_enabled:
                try:
                    if conn:
                        conn.close()
                except Exception:
                    pass

        # reset reprocess flag
        try:
            endpoint = API_URL.rstrip("/") + "/export/reprocess-reset"
            resp = requests.post(endpoint, data={"folder_id": folder_id}, timeout=30)
            resp.raise_for_status()
        except Exception as e:
            raise RuntimeError(f"Failed to reset reprocess flag via backend: {e}")

    # CDC cleanup path: delete existing vectors/chunks/metadata by document_name before fresh insert
    if cdc_enabled:
        if chunk_store_enabled:
            postgres_utils = _import_or_load(
                "workers.export.postgres_utils",
                "postgres_utils",
                candidate_files=[
                    Path(__file__).resolve().parent / "postgres_utils.py",
                    REPO_ROOT / "workers" / "export" / "postgres_utils.py",
                    REPO_ROOT / "workers" / "export" / "utils" / "postgres_utils.py",
                    REPO_ROOT / "workers" / "common" / "postgres_utils.py",
                ],
            )
            postgres_utils.validate_identifier(chunk_db_name)  # type: ignore[arg-type]

        document_name = None
        if metadata_file:
            try:
                with open(metadata_file, "r", encoding="utf-8") as mf:
                    meta_obj = json.load(mf)
                if isinstance(meta_obj, dict):
                    document_name = meta_obj.get("document_name")
                    if not document_name:
                        try:
                            base = os.path.basename(metadata_file)
                            name_only = os.path.splitext(base)[0]
                            document_name = name_only
                        except Exception:
                            document_name = None
            except Exception as e:
                logger.warning("CDC: failed to read metadata for cleanup: %s", e)

        if not document_name:
            logger.info("CDC enabled but document_name not found; skipping CDC cleanup")
        elif chunk_store_enabled and pg_url:
            try:
                pg_conn = postgres_utils.get_connection(pg_url)  # type: ignore[name-defined]
                cur = pg_conn.cursor()
                postgres_utils.check_or_create_document_metadata_table(pg_conn, schema, metadata_table_name)
                cur.execute(
                    f"""
                    SELECT folder_id
                    FROM {schema}.{metadata_table_name}
                    WHERE document_name = %s
                    ORDER BY updated_at DESC NULLS LAST, created_at DESC NULLS LAST
                    LIMIT 1
                    """,
                    (document_name,),
                )
                row = cur.fetchone()
                prior_folder = str(row[0]) if row and row[0] else None
                logger.info("CDC: lookup document_name=%s prior_folder=%s in %s.%s", document_name, prior_folder, schema, metadata_table_name)
                cur.close()

                chunk_ids_cleanup = []
                if prior_folder:
                    try:
                        postgres_utils.check_or_create_chunk_table(pg_conn, schema, chunk_table_name)  # type: ignore[name-defined]
                        chunk_ids_cleanup = postgres_utils.fetch_chunk_ids_by_folder(pg_conn, schema, chunk_table_name, prior_folder)
                        logger.info("CDC: fetched %d chunk_ids for prior folder_id=%s from %s.%s", len(chunk_ids_cleanup), prior_folder, schema, chunk_table_name)
                    except Exception as e:
                        logger.warning("CDC: failed to fetch chunk ids for prior folder %s: %s", prior_folder, e)

                # Delete vectors first
                if chunk_ids_cleanup:
                    try:
                        client_cleanup = QdrantClient(url=effective_qdrant_url, api_key=qdrant_api_key)
                        client_cleanup.delete(collection_name=collection_name, points_selector={"points": chunk_ids_cleanup})
                        logger.info("CDC: deleted %d vectors for document_name=%s", len(chunk_ids_cleanup), document_name)
                    except Exception as e:
                        logger.warning("CDC: failed vector delete for document_name=%s: %s", document_name, e)

                # Delete chunk rows
                if chunk_ids_cleanup:
                    try:
                        deleted_pg = postgres_utils.delete_chunks_by_ids(pg_conn, schema, chunk_table_name, chunk_ids_cleanup)
                        logger.info("CDC: deleted %d chunks for prior folder_id=%s", deleted_pg, prior_folder)
                    except Exception as e:
                        logger.warning("CDC: failed chunk delete for prior folder_id=%s: %s", prior_folder, e)

                # Delete document_metadata row
                try:
                    cur2 = pg_conn.cursor()
                    cur2.execute(f"DELETE FROM {schema}.{metadata_table_name} WHERE document_name = %s", (document_name,))
                    pg_conn.commit()
                    cur2.close()
                    logger.info("CDC: removed existing document_metadata for document_name=%s", document_name)
                except Exception as e:
                    try:
                        pg_conn.rollback()
                    except Exception:
                        pass
                    logger.warning("CDC: failed to remove document_metadata for document_name=%s: %s", document_name, e)

                # Reset reprocess_flag on document_details for prior folder
                if prior_folder:
                    try:
                        cur3 = pg_conn.cursor()
                        cur3.execute(f"UPDATE {schema}.document_details SET reprocess_flag = false WHERE folder_id = %s", (prior_folder,))
                        pg_conn.commit()
                        cur3.close()
                        logger.info("CDC: reset reprocess_flag for folder_id=%s", prior_folder)
                    except Exception as e:
                        try:
                            pg_conn.rollback()
                        except Exception:
                            pass
                        logger.warning("CDC: failed to reset reprocess_flag for folder_id=%s: %s", prior_folder, e)
            except Exception as e:
                logger.warning("CDC cleanup skipped due to error: %s", e, exc_info=True)
            finally:
                try:
                    if pg_conn:
                        pg_conn.close()
                except Exception:
                    pass
        else:
            logger.info("CDC enabled but chunk store/Postgres URL not configured; skipping cleanup")

    # If metadata exists, insert document metadata via Postgres (only when chunk store is enabled)
    if metadata_file and chunk_store_enabled:
        try:
            with open(metadata_file, "r", encoding="utf-8") as mf:
                doc_meta = json.load(mf)
        except Exception as e:
            raise RuntimeError(f"Failed to read metadata file {metadata_file}: {e}")

        try:
            if not isinstance(doc_meta, dict):
                doc_meta = {"metadata": doc_meta}

            if not doc_meta.get("document_name"):
                try:
                    base = os.path.basename(metadata_file)
                    name_only = os.path.splitext(base)[0]
                except Exception:
                    name_only = None
                if name_only:
                    doc_meta["document_name"] = name_only
                    logger.info("Falling back to metadata filename as document_name: %s", name_only)

            metadata_json = doc_meta.get("metadata") if isinstance(doc_meta.get("metadata"), dict) else {
                k: v
                for k, v in doc_meta.items()
                if k
                not in (
                    "doc_id",
                    "document_name",
                    "original_path",
                    "source_path",
                    "source_type",
                    "mime_type",
                )
            }

            # Require Postgres for document_metadata; no API fallback (endpoint removed)
            metadata_db_url = pg_url
            if not metadata_db_url:
                raise RuntimeError("No Postgres URL available for document_metadata upsert")

            try:
                conn_meta = postgres_utils.get_connection(metadata_db_url)
                postgres_utils.upsert_document_metadata(
                    conn_meta,
                    schema,
                    metadata_table_name,
                    doc_meta.get("doc_id"),
                    folder_id,
                    doc_meta.get("document_name"),
                    doc_meta.get("original_path") or doc_meta.get("source_path"),
                    doc_meta.get("source_type"),
                    doc_meta.get("mime_type"),
                    metadata_json,
                )
                logger.info("Inserted document_metadata row for folder_id=%s via Postgres", folder_id)
            except Exception as e:
                try:
                    if 'conn_meta' in locals():
                        conn_meta.rollback()
                except Exception:
                    pass
                raise RuntimeError(f"Failed to insert document metadata via Postgres: {e}")
            finally:
                try:
                    if 'conn_meta' in locals():
                        conn_meta.close()
                except Exception:
                    pass
        except Exception as e:
            raise RuntimeError(f"Failed to upsert document metadata: {e}")
    elif metadata_file and not chunk_store_enabled:
        logger.info("Chunk store disabled; skipping document_metadata upsert and CDC for metadata")

    chunk_files = _iter_chunk_files(folder_path)
    if not chunk_files:
        raise ValueError("No chunk files found to export.")


    client = QdrantClient(url=effective_qdrant_url, api_key=qdrant_api_key)
    points: List[PointStruct] = []
    vector_size: Optional[int] = None

    # If chunk store is enabled, ensure table exists once up front
    if chunk_store_enabled:
        _pg_conn_for_ddl = postgres_utils.get_connection(pg_url)
        try:
            postgres_utils.check_or_create_chunk_table(_pg_conn_for_ddl, schema, chunk_table_name)
            postgres_utils.check_or_create_document_metadata_table(_pg_conn_for_ddl, schema, metadata_table_name)
        finally:
            try:
                _pg_conn_for_ddl.close()
            except Exception:
                pass

    for chunk_file in chunk_files:
        chunk_path = os.path.join(folder_path, chunk_file)
        try:
            with open(chunk_path, "r", encoding="utf-8") as cf:
                chunk_data = json.load(cf)
        except Exception as e:
            logger.warning(f"Skipping chunk file {chunk_file}: failed to read: {e}")
            continue

        text = chunk_data.get("text")
        embedding = chunk_data.get("embedding") or chunk_data.get("vector")
        metadata_json = chunk_data.get("metadata") or chunk_data.get("metadata_json")
        chunk_text = chunk_data.get("chunk_text")

        if not text and isinstance(chunk_text, dict):
            elements = chunk_text.get("element")
            if isinstance(elements, list) and elements and isinstance(elements[0], dict):
                text = elements[0].get("text", "")
                metadata_json = {k: v for k, v in elements[0].items() if k != "text"}
        elif not text and isinstance(chunk_text, str):
            text = chunk_text

        if embedding is None:
            embedding = chunk_data.get("embedding") or chunk_data.get("vector")

        if not text:
            text = ""

        if isinstance(metadata_json, str):
            try:
                metadata_json = json.loads(metadata_json)
            except Exception:
                logger.warning(
                    f"Failed to parse metadata_json string for chunk {chunk_file}, using empty dict."
                )
                metadata_json = {}

        # Insert chunk into Postgres if enabled; otherwise just derive chunk_uuid
        conn = None
        if chunk_store_enabled:
            try:
                conn = postgres_utils.get_connection(pg_url)
                chunk_id = chunk_data.get("chunk_id")
                chunk_uuid = postgres_utils.insert_chunk(
                    conn,
                    schema,
                    chunk_table_name,
                    chunk_id,
                    folder_id,
                    text,
                    metadata_json,
                )
                if not chunk_uuid:
                    logger.error(f"Failed to insert chunk for {chunk_file} into Postgres")
                    continue
            except Exception as e:
                logger.error(f"Failed to insert chunk for {chunk_file} into Postgres: {e}")
                continue
            finally:
                try:
                    if conn:
                        conn.close()
                except Exception:
                    pass
        else:
            # Qdrant-only mode: generate/use chunk_id locally
            chunk_uuid = chunk_data.get("chunk_id") or str(uuid.uuid4())

        if embedding:
            if vector_size is None:
                vector_size = len(embedding)
                ensure_optimized_qdrant_collection(client, collection_name, vector_size, search_type)

            payload = {
                "folder_id": folder_id,
                "chunk_id": chunk_uuid,
            }

            # If no external chunk store is used, store text and metadata in Qdrant payload
            if not chunk_store_enabled:
                payload["text"] = text
                payload["metadata"] = metadata_json

            points.append(
                PointStruct(
                    id=chunk_uuid,
                    vector=embedding,
                    payload=payload,
                )
            )
        else:
            logger.warning(f"No embedding found or embedding is empty for chunk file: {chunk_file}")

    if not points:
        raise ValueError("No vectors found to export after processing chunks.")


    # Inline qdrant_utils.insert_vectors
    client.upsert(collection_name=collection_name, points=points)
    logger.info(f"Inserted {len(points)} vectors into Qdrant collection {collection_name}")
    logger.info(f"Export complete: {len(points)} vectors uploaded to '{collection_name}'")
    return len(points)


# --------------- Task ----------------------
@celery_app.task(name="qdrant_worker.qdrant_task")
def qdrant_task(task_id, folder_id, export_config, dag_id, run_id, pipeline_name=None, export_profile_name=None):
    """Export embeddings to Qdrant based on ExportConfig and POST results."""
    status = "failed"
    error_message: Optional[str] = None
    num_exported = 0

    chunk_store_config = None
    chunk_store_name_val = export_config.get("chunkDatabase")
    chunk_store_type_val = export_config.get("ChunkStore")
    if chunk_store_type_val and chunk_store_type_val.lower() == "postgres":
        chunk_store_config = {
            "postgres_enabled": True,
            # Postgres URL will be resolved from a connection profile or env
            # inside export_to_qdrant; we no longer depend on a URL here.
            "postgres_schema": os.getenv("POSTGRES_EXPORT_SCHEMA", "public"),
            "postgres_table": chunk_store_name_val,
        }

    try:
        cfg = export_config if isinstance(export_config, dict) else {}
        vector_store_config = cfg

        # --- Fetch pipeline_name from reprocess-flag endpoint ---
        pipeline_name_from_db = None
        try:
            endpoint_flag = API_URL.rstrip("/") + f"/export/reprocess-flag?folder_id={folder_id}"
            resp_flag = requests.get(endpoint_flag, timeout=30)
            resp_flag.raise_for_status()
            data_flag = resp_flag.json()
            pipeline_name_from_db = data_flag.get("pipeline_name")
        except Exception as e:
            logger.warning(f"Failed to fetch pipeline_name from reprocess-flag: {e}")
            pipeline_name_from_db = pipeline_name or "unknown"

        # Vector store registry check/create (backend)
        try:
            endpoint = API_URL.rstrip("/") + "/export/vector-store-registry"
            vcfg = vector_store_config or {}

            chunk_store_name_val = export_config.get("chunkDatabase")
            chunk_store_type_val = export_config.get("ChunkStore")
            vector_store_type_val = export_config.get("VectorStore")
            collection_name_val = export_config.get("VectorDatabase")
            export_profile_name_val = export_config.get("export_profile_name")

            search_type = export_config.get("SearchType") or export_config.get("search_type") or "cosine"

            # Postgres profile name for the chunk store (if enabled).
            postgres_profile_name = None
            if chunk_store_type_val and chunk_store_type_val.lower() == "postgres":
                postgres_profile_name = (
                    export_config.get("postgres_profile_name")
                    or POSTGRES_PROFILE_NAME
                )

            # Resolve Qdrant connection via connection profile.
            # By design, the Qdrant *connection* profile name comes from
            # environment (QDRANT_PROFILE_NAME). The export profile name in
            # export_config is purely logical metadata and must not override
            # the connection profile.
            resolved_profile_name = QDRANT_PROFILE_NAME
            qdrant_url: Optional[str] = None
            qdrant_api_key: Optional[str] = None
            if resolved_profile_name:
                secret, base_url = _get_connection_profile_secret(resolved_profile_name)
                qdrant_api_key = secret
                qdrant_url = (base_url or QDRANT_URL)
            else:
                qdrant_url = QDRANT_URL

            # Export profile name for registry/metadata: this comes from the
            # export configuration or task args, independent of the Qdrant
            # connection profile name.
            export_profile_name_for_registry = export_profile_name_val or export_profile_name or "unknown"

            params = {
                "folder_id": folder_id,
                "export_profile_name": export_profile_name_for_registry,
                "chunk_store_type": chunk_store_type_val or ("postgres" if chunk_store_config else "qdrant"),
                "chunk_store_name": chunk_store_name_val or collection_name_val,
                "vector_store_type": vector_store_type_val or "qdrant",
                "vector_store_name": collection_name_val,
                "vector_store_namespace": vcfg.get("namespace") or "",
            }
            resp = requests.get(endpoint, params=params, timeout=30)
            resp.raise_for_status()
            rdata = resp.json() if resp.content else {}
            if not isinstance(rdata, dict) or rdata.get("status") != "success":
                raise RuntimeError(str(rdata))
        except Exception as e:
            raise RuntimeError(f"Failed to get/create vector store registry via backend: {e}")

        num_exported = export_to_qdrant(
            folder_id=folder_id,
            collection_name=str(collection_name_val),
            search_type=str(search_type),
            chunk_store_config=chunk_store_config,
            pipeline_name=pipeline_name_from_db,
            export_profile_name=export_profile_name,
            vector_store_config=cfg,
            export_config=export_config,
            qdrant_url=qdrant_url,
            qdrant_api_key=qdrant_api_key,
            postgres_profile_name=postgres_profile_name,
        )
        status = "success"
    except Exception as e:
        error_message = str(e)
        logger.error(f"Exception in qdrant_task: {error_message}", exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting export results to {WORKER_RESULTS_URL}: {payload}")
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error(f"export worker-results callback returned HTTP {resp.status_code}: {resp.text}")
    except Exception as cb_err:
        logger.error(f"Failed to POST export worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "error": error_message,
    }
