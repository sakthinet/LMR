import json
import uuid
import logging
import re
from typing import Any, Optional

logger = logging.getLogger("postgres_utils")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(_h)
logger.setLevel(logging.INFO)

# ---------------- Driver detection ----------------
_psycopg = None
_psycopg_sql = None
_psycopg_Jsonb = None

_psycopg2 = None
_psycopg2_sql = None
_psycopg2_Json = None

try:
    import psycopg  # psycopg v3
    from psycopg import sql as _sql3
    from psycopg.types.json import Jsonb as _Jsonb3
    _psycopg = psycopg
    _psycopg_sql = _sql3
    _psycopg_Jsonb = _Jsonb3
except Exception:
    _psycopg = None

if _psycopg is None:
    try:
        import psycopg2
        from psycopg2 import sql as _sql2
        from psycopg2.extras import Json as _Json2
        _psycopg2 = psycopg2
        _psycopg2_sql = _sql2
        _psycopg2_Json = _Json2
    except Exception:
        _psycopg2 = None


def get_connection(pg_url: str):
    """
    Create a Postgres connection using whichever driver is installed.
    Install one of:
      - psycopg[binary]
      - psycopg2-binary
    """
    if _psycopg is not None:
        conn = _psycopg.connect(pg_url)
        try:
            conn.autocommit = False
        except Exception:
            pass
        return conn

    if _psycopg2 is not None:
        conn = _psycopg2.connect(pg_url)
        conn.autocommit = False
        return conn

    raise RuntimeError(
        "No Postgres driver installed. Install either:\n"
        "  python -m pip install \"psycopg[binary]\"\n"
        "or:\n"
        "  python -m pip install psycopg2-binary"
    )


def _coerce_uuid(val: Optional[str]) -> str:
    """Return a valid UUID string; generate if missing/invalid."""
    if not val:
        return str(uuid.uuid4())
    try:
        return str(uuid.UUID(str(val)))
    except Exception:
        return str(uuid.uuid4())


_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def validate_identifier(name: str) -> None:
    """Raise ValueError if name is not a safe SQL identifier."""
    if not name or not _IDENTIFIER_RE.match(name):
        raise ValueError("Invalid identifier; use letters, numbers, underscore, starting with a letter/underscore")


def insert_chunk(
    conn,
    schema: str,
    table: str,
    chunk_id: Optional[str],
    folder_id: str,
    chunk_text: str,
    metadata_json: Any,
) -> Optional[str]:
    """
    Upsert a chunk row and return the chunk_id (uuid string).
    Table schema expected:
      chunk_id uuid PRIMARY KEY,
      folder_id text,
      chunk_text text,
      metadata_json jsonb,
      created_at timestamp default now()
    """
    cid = _coerce_uuid(chunk_id)
    metadata_json = metadata_json if metadata_json is not None else {}

    # psycopg v3 path
    if _psycopg is not None and _psycopg_sql is not None:
        sqlm = _psycopg_sql
        table_ident = sqlm.Identifier(schema, table)
        insert_sql = sqlm.SQL("""
            INSERT INTO {} (chunk_id, folder_id, chunk_text, metadata_json)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (chunk_id) DO UPDATE SET
                folder_id = EXCLUDED.folder_id,
                chunk_text = EXCLUDED.chunk_text,
                metadata_json = EXCLUDED.metadata_json
            RETURNING chunk_id
        """).format(table_ident)

        cur = conn.cursor()
        try:
            meta_val = _psycopg_Jsonb(metadata_json) if _psycopg_Jsonb else json.dumps(metadata_json)
            cur.execute(insert_sql, (cid, folder_id, chunk_text, meta_val))
            row = cur.fetchone()
            conn.commit()
            return str(row[0]) if row else cid
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error("insert_chunk failed (psycopg v3): %s", e)
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass

    # psycopg2 path
    if _psycopg2 is not None and _psycopg2_sql is not None:
        sqlm = _psycopg2_sql
        table_ident = sqlm.Identifier(schema, table)
        insert_sql = sqlm.SQL("""
            INSERT INTO {} (chunk_id, folder_id, chunk_text, metadata_json)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (chunk_id) DO UPDATE SET
                folder_id = EXCLUDED.folder_id,
                chunk_text = EXCLUDED.chunk_text,
                metadata_json = EXCLUDED.metadata_json
            RETURNING chunk_id
        """).format(table_ident)

        cur = conn.cursor()
        try:
            meta_val = _psycopg2_Json(metadata_json) if _psycopg2_Json else json.dumps(metadata_json)
            cur.execute(insert_sql, (cid, folder_id, chunk_text, meta_val))
            row = cur.fetchone()
            conn.commit()
            return str(row[0]) if row else cid
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error("insert_chunk failed (psycopg2): %s", e)
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass

    raise RuntimeError("No usable Postgres driver/sql module available.")


def check_or_create_chunk_table(conn, schema: str, table: str) -> None:
    validate_identifier(table)
    if _psycopg is not None and _psycopg_sql is not None:
        sqlm = _psycopg_sql
        table_ident = sqlm.Identifier(schema, table)
        create_sql = sqlm.SQL("""
            CREATE TABLE IF NOT EXISTS {} (
                chunk_id uuid PRIMARY KEY,
                folder_id text,
                chunk_text text,
                metadata_json jsonb,
                created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
            )
        """).format(table_ident)
        cur = conn.cursor()
        try:
            cur.execute(create_sql)
            conn.commit()
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error("check_or_create_chunk_table failed: %s", e)
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass
        return
    elif _psycopg2 is not None and _psycopg2_sql is not None:
        sqlm = _psycopg2_sql
        table_ident = sqlm.Identifier(schema, table)
        create_sql = sqlm.SQL("""
            CREATE TABLE IF NOT EXISTS {} (
                chunk_id uuid PRIMARY KEY,
                folder_id text,
                chunk_text text,
                metadata_json jsonb,
                created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
            )
        """).format(table_ident)
        cur = conn.cursor()
        try:
            cur.execute(create_sql)
            conn.commit()
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error("check_or_create_chunk_table failed: %s", e)
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass
        return
    else:
        raise RuntimeError("No usable Postgres driver/sql module available.")


def check_or_create_document_metadata_table(conn, schema: str, table: str) -> None:
    """Create prefixed document_metadata table and index if missing."""
    validate_identifier(table)

    create_sql = f"""
    CREATE TABLE IF NOT EXISTS {schema}.{table} (
        doc_id uuid NOT NULL,
        document_name text COLLATE pg_catalog."default" NOT NULL,
        source_path text COLLATE pg_catalog."default",
        source_type character varying(50) COLLATE pg_catalog."default",
        mime_type character varying(100) COLLATE pg_catalog."default",
        created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
        updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
        metadata_json jsonb,
        folder_id text COLLATE pg_catalog."default",
        CONSTRAINT {table}_pkey PRIMARY KEY (doc_id)
    );

    CREATE INDEX IF NOT EXISTS idx_{table}_doc_metadata_gin
        ON {schema}.{table} USING gin
        (metadata_json);
    """

    cur = conn.cursor()
    try:
        cur.execute(create_sql)
        conn.commit()
    except Exception as e:
        try:
            conn.rollback()
        except Exception:
            pass
        logger.error("check_or_create_document_metadata_table failed: %s", e)
        raise
    finally:
        try:
            cur.close()
        except Exception:
            pass


def fetch_chunk_ids_by_folder(conn, schema: str, table: str, folder_id: str) -> list[str]:
    """Return list of chunk_id for a folder_id from the chunk table."""
    if _psycopg is not None:
        sqlm = _psycopg_sql
        table_ident = sqlm.Identifier(schema, table)
        sel_sql = sqlm.SQL("SELECT chunk_id FROM {} WHERE folder_id = %s").format(table_ident)
        cur = conn.cursor()
        try:
            cur.execute(sel_sql, (folder_id,))
            rows = cur.fetchall()
            return [str(r[0]) for r in rows]
        finally:
            try:
                cur.close()
            except Exception:
                pass

    if _psycopg2 is not None:
        sqlm = _psycopg2_sql
        table_ident = sqlm.Identifier(schema, table)
        sel_sql = sqlm.SQL("SELECT chunk_id FROM {} WHERE folder_id = %s").format(table_ident)
        cur = conn.cursor()
        try:
            cur.execute(sel_sql, (folder_id,))
            rows = cur.fetchall()
            return [str(r[0]) for r in rows]
        finally:
            try:
                cur.close()
            except Exception:
                pass

    raise RuntimeError("No usable Postgres driver/sql module available.")


def delete_chunks_by_ids(conn, schema: str, table: str, chunk_ids: list[str]) -> int:
    """Delete chunks by chunk_id list; returns count deleted."""
    if not chunk_ids:
        return 0

    if _psycopg is not None:
        sqlm = _psycopg_sql
        table_ident = sqlm.Identifier(schema, table)
        del_sql = sqlm.SQL("DELETE FROM {} WHERE chunk_id = ANY(%s)").format(table_ident)
        cur = conn.cursor()
        try:
            cur.execute(del_sql, (chunk_ids,))
            deleted = cur.rowcount or 0
            conn.commit()
            return int(deleted)
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass

    if _psycopg2 is not None:
        sqlm = _psycopg2_sql
        table_ident = sqlm.Identifier(schema, table)
        del_sql = sqlm.SQL("DELETE FROM {} WHERE chunk_id = ANY(%s)").format(table_ident)
        cur = conn.cursor()
        try:
            cur.execute(del_sql, (chunk_ids,))
            deleted = cur.rowcount or 0
            conn.commit()
            return int(deleted)
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass

    raise RuntimeError("No usable Postgres driver/sql module available.")

    cur = conn.cursor()
    try:
        cur.execute(create_sql)
        conn.commit()
    except Exception as e:
        try:
            conn.rollback()
        except Exception:
            pass
        logger.error("check_or_create_chunk_table failed: %s", e)
        raise
    finally:
        try:
            cur.close()
        except Exception:
            pass


def delete_chunk_by_id(conn, schema: str, table: str, chunk_id: str) -> None:
    cid = _coerce_uuid(chunk_id)

    if _psycopg is not None and _psycopg_sql is not None:
        sqlm = _psycopg_sql
        table_ident = sqlm.Identifier(schema, table)
        delete_sql = sqlm.SQL("DELETE FROM {} WHERE chunk_id = %s").format(table_ident)
    elif _psycopg2 is not None and _psycopg2_sql is not None:
        sqlm = _psycopg2_sql
        table_ident = sqlm.Identifier(schema, table)
        delete_sql = sqlm.SQL("DELETE FROM {} WHERE chunk_id = %s").format(table_ident)
    else:
        raise RuntimeError("No usable Postgres driver/sql module available.")

    cur = conn.cursor()
    try:
        cur.execute(delete_sql, (cid,))
        conn.commit()
    except Exception as e:
        try:
            conn.rollback()
        except Exception:
            pass
        logger.error("delete_chunk_by_id failed: %s", e)
        raise
    finally:
        try:
            cur.close()
        except Exception:
            pass


def upsert_document_metadata(
    conn,
    schema: str,
    table: str,
    doc_id: Optional[str],
    folder_id: str,
    document_name: str,
    source_path: Optional[str],
    source_type: Optional[str],
    mime_type: Optional[str],
    metadata_json: Any,
) -> str:
    """Insert or update document_metadata and return doc_id."""
    validate_identifier(table)
    doc_id_val = _coerce_uuid(doc_id)
    meta_val = metadata_json if metadata_json is not None else None

    # psycopg v3 path
    if _psycopg is not None and _psycopg_sql is not None:
        sqlm = _psycopg_sql
        table_ident = sqlm.Identifier(schema, table)
        pk_name = sqlm.Identifier(f"{table}_pkey")
        create_table_sql = sqlm.SQL(
            """
            CREATE TABLE IF NOT EXISTS {tbl} (
                doc_id uuid NOT NULL,
                document_name text COLLATE pg_catalog."default" NOT NULL,
                source_path text COLLATE pg_catalog."default",
                source_type character varying(50) COLLATE pg_catalog."default",
                mime_type character varying(100) COLLATE pg_catalog."default",
                created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
                updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
                metadata_json jsonb,
                folder_id text COLLATE pg_catalog."default",
                CONSTRAINT {pk} PRIMARY KEY (doc_id)
            )
            """
        ).format(tbl=table_ident, pk=pk_name)

        create_index_sql = sqlm.SQL(
            """
            CREATE INDEX IF NOT EXISTS {idx}
                ON {tbl} USING gin
                (metadata_json)
            """
        ).format(tbl=table_ident, idx=sqlm.Identifier(f"idx_{table}_doc_metadata_gin"))

        insert_sql = sqlm.SQL(
            """
            INSERT INTO {tbl} (
                doc_id, folder_id, document_name, source_path, source_type, mime_type, metadata_json
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (doc_id) DO UPDATE SET
                folder_id = EXCLUDED.folder_id,
                document_name = EXCLUDED.document_name,
                source_path = EXCLUDED.source_path,
                source_type = EXCLUDED.source_type,
                mime_type = EXCLUDED.mime_type,
                metadata_json = EXCLUDED.metadata_json,
                updated_at = now()
            RETURNING doc_id
            """
        ).format(tbl=table_ident)
        cur = conn.cursor()
        try:
            meta_jsonb = _psycopg_Jsonb(meta_val) if _psycopg_Jsonb else json.dumps(meta_val) if meta_val is not None else None
            cur.execute(create_table_sql)
            cur.execute(create_index_sql)
            cur.execute(
                insert_sql,
                (
                    doc_id_val,
                    folder_id,
                    document_name,
                    source_path,
                    source_type,
                    mime_type,
                    meta_jsonb,
                ),
            )
            row = cur.fetchone()
            conn.commit()
            return str(row[0]) if row else doc_id_val
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error("upsert_document_metadata failed (psycopg v3): %s", e)
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass

    # psycopg2 path
    if _psycopg2 is not None and _psycopg2_sql is not None:
        sqlm = _psycopg2_sql
        table_ident = sqlm.Identifier(schema, table)
        pk_name = sqlm.Identifier(f"{table}_pkey")
        create_table_sql = sqlm.SQL(
            """
            CREATE TABLE IF NOT EXISTS {tbl} (
                doc_id uuid NOT NULL,
                document_name text COLLATE pg_catalog."default" NOT NULL,
                source_path text COLLATE pg_catalog."default",
                source_type character varying(50) COLLATE pg_catalog."default",
                mime_type character varying(100) COLLATE pg_catalog."default",
                created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
                updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
                metadata_json jsonb,
                folder_id text COLLATE pg_catalog."default",
                CONSTRAINT {pk} PRIMARY KEY (doc_id)
            )
            """
        ).format(tbl=table_ident, pk=pk_name)

        create_index_sql = sqlm.SQL(
            """
            CREATE INDEX IF NOT EXISTS {idx}
                ON {tbl} USING gin
                (metadata_json)
            """
        ).format(tbl=table_ident, idx=sqlm.Identifier(f"idx_{table}_doc_metadata_gin"))

        insert_sql = sqlm.SQL(
            """
            INSERT INTO {tbl} (
                doc_id, folder_id, document_name, source_path, source_type, mime_type, metadata_json
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (doc_id) DO UPDATE SET
                folder_id = EXCLUDED.folder_id,
                document_name = EXCLUDED.document_name,
                source_path = EXCLUDED.source_path,
                source_type = EXCLUDED.source_type,
                mime_type = EXCLUDED.mime_type,
                metadata_json = EXCLUDED.metadata_json,
                updated_at = now()
            RETURNING doc_id
            """
        ).format(tbl=table_ident)
        cur = conn.cursor()
        try:
            meta_json = _psycopg2_Json(meta_val) if _psycopg2_Json else json.dumps(meta_val) if meta_val is not None else None
            cur.execute(create_table_sql)
            cur.execute(create_index_sql)
            cur.execute(
                insert_sql,
                (
                    doc_id_val,
                    folder_id,
                    document_name,
                    source_path,
                    source_type,
                    mime_type,
                    meta_json,
                ),
            )
            row = cur.fetchone()
            conn.commit()
            return str(row[0]) if row else doc_id_val
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            logger.error("upsert_document_metadata failed (psycopg2): %s", e)
            raise
        finally:
            try:
                cur.close()
            except Exception:
                pass

    raise RuntimeError("No usable Postgres driver/sql module available for document_metadata upsert.")
