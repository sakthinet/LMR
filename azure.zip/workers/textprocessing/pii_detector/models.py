"""Data models for PII detection"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import json


@dataclass
class PIIEntity:
    """Detected PII entity"""
    entity_type: str
    value: str
    start: int
    end: int
    confidence: float
    detector: str = "unknown"
    context: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        result = {
            "entity_type": self.entity_type,
            "value": self.value,
            "start": self.start,
            "end": self.end,
            "confidence": self.confidence,
            "detector": self.detector
        }
        if self.context:
            result["context"] = self.context
        return result


@dataclass
class DetectionResult:
    """Complete detection result"""
    text: str
    entities: List[PIIEntity] = field(default_factory=list)
    total_found: int = 0
    
    def __post_init__(self):
        self.total_found = len(self.entities)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text,
            "total_found": self.total_found,
            "entities": [e.to_dict() for e in self.entities]
        }
