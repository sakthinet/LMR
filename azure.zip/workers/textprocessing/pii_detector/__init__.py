"""PII Detector - Configuration-driven PII detection library"""

__version__ = "1.0.0"

from .detector import CustomPIIDetector
from .mask_pii import mask_pii
from .models import PIIEntity, DetectionResult


__all__ = ['CustomPIIDetector', 'mask_pii', 'PIIEntity', 'DetectionResult']
