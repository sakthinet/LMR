"""Output formatters"""

import json
import csv
import io


def format_json(entities, pretty: bool = True) -> str:
    data = [e.to_dict() for e in entities]
    if pretty:
        return json.dumps(data, indent=2, ensure_ascii=False)
    return json.dumps(data, ensure_ascii=False)


def format_csv(entities) -> str:
    if not entities:
        return ""
    output = io.StringIO()
    fieldnames = ['entity_type', 'value', 'start', 'end', 'confidence']
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    for entity in entities:
        row = entity.to_dict()
        row.pop('context', None)
        row.pop('detector', None)
        writer.writerow(row)
    return output.getvalue()


def format_table(entities) -> str:
    if not entities:
        return "No entities found."
    lines = ["Type                | Value              | Confidence"]
    lines.append("-" * 60)
    for entity in entities:
        line = f"{entity.entity_type:<20} | {entity.value:<18} | {entity.confidence:.2f}"
        lines.append(line)
    return '\n'.join(lines)
