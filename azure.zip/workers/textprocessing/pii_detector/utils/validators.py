"""Validation utilities"""

import re


def validate_email(email: str) -> bool:
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_phone(phone: str, country: str = "US") -> bool:
    cleaned = re.sub(r'[\s\-\(\)\.]+', '', phone)
    if country == "US":
        return bool(re.match(r'^\+?1?\d{10}$', cleaned))
    elif country == "IN":
        return bool(re.match(r'^\+?91?\d{10}$', cleaned))
    return len(cleaned) >= 10


def validate_credit_card(card_number: str) -> bool:
    cleaned = re.sub(r'[\s\-]+', '', card_number)
    if not cleaned.isdigit() or len(cleaned) < 13:
        return False
    
    total = 0
    for i, digit in enumerate(cleaned[::-1]):
        n = int(digit)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0
