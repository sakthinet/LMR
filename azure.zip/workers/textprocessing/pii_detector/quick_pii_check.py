#!/usr/bin/env python
"""
Quick PII Detector Check

Fast script to verify if pii_detector is available and working.
Run this before starting the worker to ensure everything is set up correctly.
"""

import sys
import os
from pathlib import Path


def main():
    print("=" * 70)
    print("QUICK PII DETECTOR CHECK")
    print("=" * 70)
    
    # Check 1: Directory structure
    print("\n[1] Checking directory structure...")
    
    current_dir = Path('.')
    pii_dir = current_dir / 'pii_detector'
    mask_pii_file = pii_dir / 'mask_pii.py'
    

    # Check 2: Import
    print("\n[2] Testing import...")
    
    try:
        from mask_pii import mask_pii
        print("  ✓ Successfully imported mask_pii")
    except ImportError as e:
        print(f"  ✗ Failed to import: {e}")
        print("\n  ACTION REQUIRED:")
        print("  1. Ensure pii_detector/__init__.py exists")
        print("  2. Check for missing dependencies")
        print("  3. Try: pip install -r requirements.txt")
        return False
    
    # Check 3: Basic functionality
    print("\n[3] Testing basic functionality...")
    
    try:
        result = mask_pii(
            text="Test email: test@example.com",
            mask_types=["email"]
        )
        
        if result['summary']['total_found'] > 0:
            print(f"  ✓ PII detection working")
            print(f"    Detected: {result['summary']['by_type']}")
        else:
            print("  ⚠ Warning: No PII detected in test")
            print("    This might be normal depending on configuration")
    except Exception as e:
        print(f"  ✗ Functionality test failed: {e}")
        return False
    
    # Check 4: Dependencies
    print("\n[4] Checking dependencies...")
    
    deps = [
        ('presidio_analyzer', 'Presidio Analyzer'),
        ('presidio_anonymizer', 'Presidio Anonymizer'),
        ('spacy', 'spaCy'),
    ]
    
    all_deps_ok = True
    for module, name in deps:
        try:
            __import__(module)
            print(f"  ✓ {name} installed")
        except ImportError:
            print(f"  ✗ {name} NOT installed")
            all_deps_ok = False
    
    if not all_deps_ok:
        print("\n  ACTION REQUIRED:")
        print("  Install missing dependencies:")
        print("    pip install -r requirements.txt")
        return False
    
    # Summary
    print("\n" + "=" * 70)
    print("✓✓✓ PII DETECTOR IS READY ✓✓✓")
    print("=" * 70)
    print("\nYou can now:")
    print("1. Start the worker: celery -A textprocessing_worker worker --loglevel=info")
    print("2. Use PII filter in your configurations")
    print("\nExample configuration:")
    print('  {"Filters": {"PII": "True", "WhitespaceRemove": "True"}}')
    
    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
