from mask_pii import mask_pii_folder
report = mask_pii_folder(
    folder_path="C:\\VCS\\context-craft\\_sandbox",
    mask_types=["all"],
    output_strategy="suffix",
    suffix="_masked",
    include_extensions=[".txt"],
    recursive=False,
    mask_style="replace",
    mask_char="*",
    mask_with=None
)
print(report["total_pii_found"], report["aggregate_by_type"])