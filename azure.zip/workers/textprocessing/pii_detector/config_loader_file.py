"""
PII Detector - Configuration Loader
====================================
File: pii_detector/config_loader.py

Handles loading and managing JSON configurations.
"""

import json
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field, asdict
from copy import deepcopy


@dataclass
class DetectionConfig:
    """Detection configuration"""
    language: str = "en"
    confidence_threshold: float = 0.5
    case_sensitive: bool = False
    enabled_entities: List[str] = field(default_factory=list)
    custom_entities: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class AnonymizationConfig:
    """Anonymization configuration"""
    default_strategy: str = "replace"
    entity_strategies: Dict[str, str] = field(default_factory=dict)
    replacements: Dict[str, str] = field(default_factory=dict)
    masking: Dict[str, Any] = field(default_factory=dict)


@dataclass
class OutputConfig:
    """Output configuration"""
    include_positions: bool = True
    include_confidence: bool = True
    format: str = "json"
    pretty_print: bool = True


@dataclass
class PerformanceConfig:
    """Performance configuration"""
    enable_cache: bool = True
    batch_size: int = 100
    timeout: int = 30


class ConfigLoader:
    """
    Configuration Loader
    ===================
    
    Loads and manages PII detection configuration from JSON files.
    
    Features:
    - Load from file, dict, or string
    - Merge configurations
    - Enable/disable entities dynamically
    - Save configurations
    """
    
    def __init__(self, config_dir: Optional[str] = None):
        """
        Initialize config loader
        
        Args:
            config_dir: Directory containing configuration files
        """
        self.config_dir = Path(config_dir) if config_dir else Path("config")
        self.detection_config: Optional[DetectionConfig] = None
        self.anonymization_config: Optional[AnonymizationConfig] = None
        self.output_config: Optional[OutputConfig] = None
        self.performance_config: Optional[PerformanceConfig] = None
        self.entity_patterns: Dict[str, Any] = {}
        self._config_history: List[Dict[str, Any]] = []
    
    def load_from_file(self, config_path: str) -> Dict[str, Any]:
        """
        Load configuration from JSON file
        
        Args:
            config_path: Path to JSON configuration file
            
        Returns:
            Configuration dictionary
        """
        config_path = Path(config_path)
        
        if not config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        self.load_from_dict(config)
        return config
    
    def load_from_dict(self, config: Dict[str, Any]):
        """
        Load configuration from dictionary
        
        Args:
            config: Configuration dictionary
        """
        # Store in history
        self._config_history.append(deepcopy(config))
        
        # Detection config
        detection = config.get('detection', {})
        self.detection_config = DetectionConfig(
            language=detection.get('language', 'en'),
            confidence_threshold=detection.get('confidence_threshold', 0.5),
            case_sensitive=detection.get('case_sensitive', False),
            enabled_entities=detection.get('enabled_entities', []),
            custom_entities=detection.get('custom_entities', [])
        )
        
        # Anonymization config
        anon = config.get('anonymization', {})
        self.anonymization_config = AnonymizationConfig(
            default_strategy=anon.get('default_strategy', 'replace'),
            entity_strategies=anon.get('entity_strategies', {}),
            replacements=anon.get('replacements', {}),
            masking=anon.get('masking', {})
        )
        
        # Output config
        output = config.get('output', {})
        self.output_config = OutputConfig(
            include_positions=output.get('include_positions', True),
            include_confidence=output.get('include_confidence', True),
            format=output.get('format', 'json'),
            pretty_print=output.get('pretty_print', True)
        )
        
        # Performance config
        perf = config.get('performance', {})
        self.performance_config = PerformanceConfig(
            enable_cache=perf.get('enable_cache', True),
            batch_size=perf.get('batch_size', 100),
            timeout=perf.get('timeout', 30)
        )
    
    def load_from_string(self, json_string: str):
        """
        Load configuration from JSON string
        
        Args:
            json_string: JSON configuration as string
        """
        config = json.loads(json_string)
        self.load_from_dict(config)
    
    def load_entity_patterns(self, patterns_path: str) -> Dict[str, Any]:
        """
        Load entity patterns from JSON file
        
        Args:
            patterns_path: Path to entity patterns JSON file
            
        Returns:
            Entity patterns dictionary
        """
        patterns_path = Path(patterns_path)
        
        with open(patterns_path, 'r', encoding='utf-8') as f:
            patterns = json.load(f)
        
        self.entity_patterns = patterns.get('entities', {})
        return self.entity_patterns
    
    def get_config_dict(self) -> Dict[str, Any]:
        """
        Get complete configuration as dictionary
        
        Returns:
            Complete configuration dictionary
        """
        return {
            'detection': asdict(self.detection_config) if self.detection_config else {},
            'anonymization': asdict(self.anonymization_config) if self.anonymization_config else {},
            'output': asdict(self.output_config) if self.output_config else {},
            'performance': asdict(self.performance_config) if self.performance_config else {}
        }
    
    def save_config(self, output_path: str, pretty: bool = True):
        """
        Save current configuration to JSON file
        
        Args:
            output_path: Path to save configuration
            pretty: Pretty print JSON
        """
        config_dict = self.get_config_dict()
        output_path = Path(output_path)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            if pretty:
                json.dump(config_dict, f, indent=2, ensure_ascii=False)
            else:
                json.dump(config_dict, f, ensure_ascii=False)
    
    def update_entity(self, entity_type: str, enabled: bool):
        """
        Enable/disable specific entity type
        
        Args:
            entity_type: Entity type to update
            enabled: Enable or disable
        """
        if enabled and entity_type not in self.detection_config.enabled_entities:
            self.detection_config.enabled_entities.append(entity_type)
        elif not enabled and entity_type in self.detection_config.enabled_entities:
            self.detection_config.enabled_entities.remove(entity_type)
    
    def get_enabled_entities(self) -> List[str]:
        """Get list of currently enabled entities"""
        return self.detection_config.enabled_entities.copy()
    
    def merge_config(self, additional_config: Dict[str, Any]):
        """
        Merge additional configuration with current config
        
        Args:
            additional_config: Configuration to merge
        """
        current = self.get_config_dict()
        
        # Deep merge
        def deep_merge(base, update):
            for key, value in update.items():
                if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                    deep_merge(base[key], value)
                else:
                    base[key] = value
        
        deep_merge(current, additional_config)
        self.load_from_dict(current)
    
    def get_config_history(self) -> List[Dict[str, Any]]:
        """Get configuration change history"""
        return self._config_history.copy()
    
    def rollback_config(self, steps: int = 1):
        """
        Rollback configuration to previous state
        
        Args:
            steps: Number of steps to rollback
        """
        if len(self._config_history) > steps:
            previous_config = self._config_history[-(steps + 1)]
            self.load_from_dict(previous_config)


# Example usage
if __name__ == "__main__":
    print("Configuration Loader - config_loader.py")
    print("=" * 60)
    
    # Example 1: Create and save config
    config = {
        "detection": {
            "confidence_threshold": 0.7,
            "enabled_entities": ["EMAIL_ADDRESS", "PHONE_NUMBER"]
        }
    }
    
    loader = ConfigLoader()
    loader.load_from_dict(config)
    loader.save_config("test_config.json")
    
    print("✓ Configuration loaded and saved")
    print(f"✓ Enabled entities: {loader.get_enabled_entities()}")
    print("\nFile ready to use!")
