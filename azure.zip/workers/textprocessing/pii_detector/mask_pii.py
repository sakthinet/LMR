r"""
Generic PII masking using Microsoft Presidio (if available).

Install (recommended):
    pip install presidio-analyzer presidio-anonymizer spacy
    python -m spacy download en_core_web_lg

Simple use:
    from workers.textprocessing.pii_detector.mask_pii import mask_pii
    result = mask_pii(text="Email jane.doe@acme.com SSN 123-45-6789", mask_types=["email","ssn"])

Returned structure:
{
  "original_text": ...,
  "masked_text": ...,
  "detected_pii": [ { "type": "email", "start": 6, "end": 21, "value": "jane.doe@acme.com" }, ... ],
  "summary": {
      "total_found": N,
      "by_type": { "email": N1, ... },
      "mask_types_used": [...],
      "mask_style": "...",
      "output_file": "... or None"
  }
}

mask_style options:
  replace (default) -> Uses mask_with mapping or auto “[REDACTED TYPE]”
  mask              -> Replaces each char with mask_char (default '*')
  hash              -> Replaces with "[HASH <8hex> TYPE]"
  redact            -> Removes (zero-length replacement)

Custom patterns:
  custom_patterns = { "EMP_ID": r"EMP-\d{6}" }
  Include "EMP_ID" in mask_types to activate.

If Presidio not available, a fallback regex layer is used.
"""

from __future__ import annotations
import os
import sys
import re
import json
import hashlib
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from presidio_anonymizer.entities import OperatorConfig

# Try to load Presidio
_PRESIDIO_AVAILABLE = True
try:
    from presidio_analyzer import AnalyzerEngine, Pattern, PatternRecognizer
    from presidio_analyzer.nlp_engine import NlpEngineProvider
    from presidio_anonymizer import AnonymizerEngine
    from presidio_anonymizer.entities import OperatorConfig
except ImportError:
    _PRESIDIO_AVAILABLE = False

logger = logging.getLogger("pii.mask_pii")
if not logger.handlers:
    logging.basicConfig(level=logging.INFO)

# ---------------- Default & Aliases ----------------

DEFAULT_TYPES = [
    "email", "phone", "ssn", "credit_card", "ipv4",
    "person", "iban", "ip", "address", "passport",
    "driver_license", "dob", "username"
]

# Map simple internal names -> Presidio entity names
ENTITY_ALIAS_MAP = {
    "email": "EMAIL_ADDRESS",
    "phone": "PHONE_NUMBER",
    "ssn": "US_SSN",
    "credit_card": "CREDIT_CARD",
    "ipv4": "IP_ADDRESS",
    "ip": "IP_ADDRESS",
    "person": "PERSON",
    "iban": "IBAN_CODE",
    "address": "LOCATION",
    "passport": "PASSPORT",
    "driver_license": "DRIVER_LICENSE",
    "dob": "DATE_TIME",
    "username": "USERNAME",
}

# Fallback regex if Presidio missing or misses
FALLBACK_REGEX: Dict[str, str] = {
    "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
    "phone": r"\b(?:\+?\d{1,3}[-.\s]?)?(?:\(?\d{2,4}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}\b",
    "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
    "credit_card": r"\b(?:\d[ -]?){13,19}\b",
    "ipv4": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "iban": r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b",
}

# Extended fallback regex patterns (country/format specific)
EXTENDED_FALLBACK_REGEX: Dict[str, str] = {
    "pan_india": r"\b[A-Z]{5}\d{4}[A-Z]\b",
    "aadhaar_india": r"\bAAD-\d{4}-\d{4}-\d{4}\b",
    "passport_generic": r"\b(?:[A-Z]{2}-PAS-[A-Z0-9]{5,10}|[A-Z]{2}PAS[A-Z0-9]{5,10}|[A-Z]{2}-PAS-\w{5,10})\b",
    "driver_license_generic": r"\b(?:DL-[A-Z]{2}-\d{5,9}|[A-Z]{2}-DL-\d{5,9}|ON-DL-\d{6,8}|NSW-DL-\d{6,8}|UK-DL-\d{5,10}|CA-DL-\d{5,10})\b",
    "nino_uk": r"\b(?!BG|GB|NK|KN|TN|NT|ZZ)[A-CEGHJ-PR-TW-Z]{2}\d{6}[A-D]\b",
    "sin_ca": r"\b\d{3}-\d{3}-\d{3}\b",
    "tfn_au": r"\bTFN-\d{3}-\d{3}-\d{3}\b",
    "gstin_india": r"\b\d{2}[A-Z]{5}\d{4}[A-Z]\d[Zz][A-Z\d]\b",
    "ifsc_india": r"\b[A-Z]{4}0[A-Z0-9]{6}\b",
    "routing_number_us": r"\b\d{9}\b(?=.*\b(?:routing|RT|ABA)\b)?",
    "sort_code_uk": r"\b\d{2}-\d{2}-\d{2}\b",
    "transit_ca": r"\b\d{5}-\d{5}\b",
    "bsb_au": r"\b\d{3}-\d{3}\b",
    "account_number_generic": r"\bACCT-[A-Z]{2}-\d{8,14}\b",
    "upi_id": r"\b[a-zA-Z0-9_.+-]+@[a-zA-Z0-9_.-]+\b",
    "iban": r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b",
    "mac_address": r"\b(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\b",
    "ipv6": r"\b(?:[0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{1,4}\b",
    "medical_record_number": r"\bMRN-[A-Z]{2}-\d{3,6}\b",
    "insurance_number": r"\bINS-[A-Z]{2}-\d{2,6}\b",
    "transaction_id": r"\bTXN-(?:[A-Z]{2}|[A-Z]{2})-\d{4}-\d{3,6}\b",
    "employee_id": r"\bEMP-\d{3,6}\b",
    "badge_id": r"\bBADGE-\d{3,6}\b",
    "order_id": r"\bORD-[A-Z]{2}-\d{4}-\d{3,6}\b",
}

# >>> ADD: your generic patterns (lower-cased keys)
GENERIC_PROMPT_REGEX: Dict[str, str] = {
    "email": r"\b[a-zA-Z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
    "phone_international": r"\+\d{1,3}[-\s]?\d{1,4}[-\s]?\d{3,4}[-\s]?\d{3,4}",
    "phone_generic": r"\b(?:\+?\d{1,3}[-.\s]?)?(?:\(?\d{2,4}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}\b",
    "ssn_us": r"\b\d{3}-\d{2}-\d{4}\b",
    "pan_india": r"\b[A-Z]{5}\d{4}[A-Z]\b",
    "aadhaar_like": r"\b(?:AAD[-\s]?)?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b",
    "ifsc": r"\b[A-Z]{4}0[A-Z0-9]{6}\b",
    "gstin_like": r"\b\d{2}[A-Z]{5}\d{4}[A-Z0-9]\b",
    "credit_card": r"\b(?:\d[ -]*?){13,19}\b",
    "iban_like": r"\b[A-Z]{2}\d{2}[A-Z0-9]{8,30}\b",
    "nino_uk": r"\b[A-Z]{2}\d{6}[A-Z]?\b",
    "sin_canada": r"\b\d{3}-\d{3}-\d{3}\b",
    "tfn_aus": r"\bTFN[-\s]?\d{3}[-\s]?\d{3}[-\s]?\d{3}\b",
    "passport_tagged": r"\b(?:IN-PAS|US-PAS|UK-PAS|CA-PAS|AUS-PAS)[A0-9A-Z-]*\b",
    "drivers_license_tagged": r"\b(?:DL-[A-Z]{2}-\d{4,7}|[A-Z]{2}-DL-\d{4,7}|Driver's licence|Driving licence|driver's licence)\b",
    "mrn": r"\bMRN[-_]?[A-Z0-9-]*\b",
    "policy_insurance": r"\b(?:Policy|INS[-_]?)[:\s]?[A-Z0-9-]+|Insurance[:\s]?[A-Z0-9-]+\b",
    "bank_account_tagged": r"\bACCT[-_]?[A-Z0-9-]*\b",
    "iban_generic": r"\b[A-Z]{2}\d{2}[A-Z0-9]{8,30}\b",
    "ip_v4": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "ip_v6": r"\b(?:[A-F0-9]{1,4}:){2,7}[A-F0-9]{1,4}\b",
    "mac": r"\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b",
    "date_iso": r"\b\d{4}-\d{2}-\d{2}\b",
    "name_maiden": r"(?:maiden name[:\s]+)([A-Z][A-Za-z'`.\- ]{1,80})",
    "alias_tagged": r"(?:alias[:\s]+|alias\s)([A-Z0-9\"'\.\- ]{2,80})",
    "upi_id": r"\b[a-zA-Z0-9.\-_]{2,}@[a-zA-Z0-9]+\b",
    "gstin_token": r"\bGSTIN(?:-like)?[:\s]?[A-Z0-9-]+\b",
    "aad_tag": r"\bAadhaar[-\s]like[:\s]?[A-Z0-9-]+\b",
}

# Merge into combined map at runtime (prompt patterns take precedence)
ALL_FALLBACK_REGEX = {**FALLBACK_REGEX, **EXTENDED_FALLBACK_REGEX, **GENERIC_PROMPT_REGEX}

# Update default types to include extended identifiers + prompt patterns
DEFAULT_TYPES = list(dict.fromkeys(
    DEFAULT_TYPES + list(EXTENDED_FALLBACK_REGEX.keys()) + list(GENERIC_PROMPT_REGEX.keys())
))

# Extend alias map so some new keys reuse Presidio operators
ENTITY_ALIAS_MAP.update({
    "ipv6": "IP_ADDRESS",
    "ip": "IP_ADDRESS",
    "ip_v4": "IP_ADDRESS",
    "ip_v6": "IP_ADDRESS",
    "drivers_license_tagged": "DRIVER_LICENSE",
    "passport_tagged": "PASSPORT",
    "ssn_us": "US_SSN",
    # others remain custom entities
})

# Add ignore_types capability
def _filter_ignored(matches: List[Dict[str, Any]], ignore: List[str]) -> List[Dict[str, Any]]:
    ignore_set = {t.lower() for t in ignore}
    return [m for m in matches if m.get("type","").lower() not in ignore_set]

# ---------------- Helpers ----------------

def _count_by_type(entities: List[Dict[str, Any]]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for e in entities:
        t = e.get("type", "unknown")
        out[t] = out.get(t, 0) + 1
    return out

def _sha256_short(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:8]

def _build_auto_mask_with(types: List[str]) -> Dict[str, str]:
    return {t: f"[REDACTED {t.upper().replace('_',' ')}]" for t in types}

def _normalize_types(mask_types: Optional[List[str]]) -> List[str]:
    if not mask_types or any(t.lower() == "all" for t in mask_types):
        return DEFAULT_TYPES
    return [t.lower() for t in mask_types]

def _alias_to_presidio(name: str) -> str:
    return ENTITY_ALIAS_MAP.get(name.lower(), name.upper())

def _apply_style(value: str, t: str, style: str, mask_char: str, custom: Dict[str, str]) -> str:
    if style == "replace":
        return custom.get(t, f"[REDACTED {t.upper()}]")
    if style == "mask":
        return mask_char * len(value)
    if style == "hash":
        return f"[HASH { _sha256_short(value) } {t.upper()}]"
    if style == "redact":
        return ""
    return custom.get(t, f"[REDACTED {t.upper()}]")

# ---------------- Core Function ----------------

# Helper: create Presidio engines robustly (tries multiple spaCy models)
def _create_presidio_engines(language: str):
    models = ["en_core_web_lg", "en_core_web_md", "en_core_web_sm"]
    last_err = None
    for model in models:
        try:
            cfg = {"nlp_engine_name": "spacy", "models": [{"lang_code": language, "model_name": model}]}
            nlp_engine = NlpEngineProvider(nlp_configuration=cfg).create_engine()
            return AnalyzerEngine(nlp_engine=nlp_engine), AnonymizerEngine()
        except Exception as e:
            last_err = e
    try:
        return AnalyzerEngine(), AnonymizerEngine()
    except Exception as e:
        logger.warning(f"Presidio init failed; fallback to regex. Last error: {last_err or e}")
        return None, None

def mask_pii(
    file_path: Optional[str] = None,
    text: Optional[str] = None,
    mask_types: Optional[List[str]] = None,
    custom_patterns: Optional[Dict[str, str]] = None,
    output_file: Optional[str] = None,
    mask_with: Optional[Dict[str, str]] = None,
    mask_style: str = "replace",
    language: str = "en",
    mask_char: str = "*",
    ignore_types: Optional[List[str]] = None
) -> Dict[str, Any]:
    if file_path is None and text is None:
        raise ValueError("Provide file_path or text")

    if text is None:
        input_text = Path(file_path).read_text(encoding="utf-8", errors="ignore")
    else:
        input_text = text

    # Normalize lists
    mask_types = mask_types or ["all"]
    ignore_types = [t.lower() for t in (ignore_types or [])]

    # Expand “all”
    if any(t.lower() == "all" for t in mask_types):
        types = [t for t in DEFAULT_TYPES if t.lower() not in ignore_types]
    else:
        types = [t.lower() for t in mask_types if t.lower() not in ignore_types]

    # Auto mask_with
    mask_with = mask_with or {t: f"[REDACTED {t.upper().replace('_',' ')}]" for t in types}

    detected: List[Dict[str, Any]] = []
    masked_text = input_text

    # ---- Presidio ----
    if _PRESIDIO_AVAILABLE:
        analyzer, anonymizer = _create_presidio_engines(language)
        if analyzer and anonymizer:
            # Register built-in prompt patterns as custom recognizers
            for name, pattern in GENERIC_PROMPT_REGEX.items():
                presidio_name = _alias_to_presidio(name)
                try:
                    analyzer.registry.add_recognizer(
                        PatternRecognizer(
                            supported_entity=presidio_name,
                            patterns=[Pattern(name=f"{presidio_name}_PROMPT", regex=pattern, score=0.8)]
                        )
                    )
                except Exception:
                    pass

            # Plus any caller-provided patterns
            if custom_patterns:
                for name, pattern in custom_patterns.items():
                    presidio_name = _alias_to_presidio(name)
                    analyzer.registry.add_recognizer(
                        PatternRecognizer(
                            supported_entity=presidio_name,
                            patterns=[Pattern(name=f"{presidio_name}_CUSTOM", regex=pattern, score=0.8)]
                        )
                    )

            presidio_entities = list({ _alias_to_presidio(t) for t in types })
            try:
                analysis_results = analyzer.analyze(text=input_text, entities=presidio_entities, language=language)
            except Exception as e:
                logger.warning(f"Presidio analyze failed: {e}; falling back to regex")
                analysis_results = []
            operators: Dict[str, OperatorConfig] = {}
            placeholder_map: Dict[str, str] = {}
            for t in types:
                presidio_name = _alias_to_presidio(t)
                if mask_style == "redact":
                    operators[presidio_name] = OperatorConfig(operator_name="redact", params={})
                elif mask_style == "hash":
                    operators[presidio_name] = OperatorConfig(operator_name="hash", params={})
                elif mask_style == "mask":
                    ph = f"[MASK {t}]"
                    operators[presidio_name] = OperatorConfig(operator_name="replace", params={"new_value": ph})
                    placeholder_map[presidio_name] = ph
                else:
                    repl = mask_with.get(t, f"[REDACTED {t.upper()}]")
                    operators[presidio_name] = OperatorConfig(operator_name="replace", params={"new_value": repl})
            try:
                pres_anonymized = anonymizer.anonymize(
                    text=input_text,
                    analyzer_results=analysis_results,
                    operators=operators
                )
                masked_text = pres_anonymized.text
                if mask_style == "mask":
                    for r in sorted(analysis_results, key=lambda x: x.start, reverse=True):
                        ph = placeholder_map.get(r.entity_type)
                        if ph:
                            original_val = input_text[r.start:r.end]
                            masked_text = masked_text.replace(ph, mask_char * len(original_val), 1)
                for r in analysis_results:
                    simple = next((k for k, v in ENTITY_ALIAS_MAP.items() if v == r.entity_type), r.entity_type.lower())
                    if simple.lower() in ignore_types:
                        continue
                    detected.append({
                        "type": simple,
                        "value": input_text[r.start:r.end],
                        "start": r.start,
                        "end": r.end,
                        "score": getattr(r, "score", None),
                        "presidio_type": r.entity_type
                    })
            except Exception as e:
                logger.warning(f"Presidio anonymize failed: {e}; will use regex fallback")

    # ---- Fallback Regex (runs if none detected or Presidio failed) ----
    if not detected:
        combined_patterns = dict(ALL_FALLBACK_REGEX)
        active = types if "all" not in mask_types else [t for t in combined_patterns.keys() if t.lower() not in ignore_types]
        matches: List[Dict[str, Any]] = []
        for t in active:
            pattern = combined_patterns.get(t)
            if not pattern:
                continue
            try:
                rx = re.compile(pattern)
            except re.error as e:
                logger.warning(f"Bad regex for {t}: {e}")
                continue
            for m in rx.finditer(input_text):
                matches.append({"type": t, "value": m.group(0), "start": m.start(), "end": m.end()})
        if matches:
            chars = list(masked_text)
            for m in sorted(matches, key=lambda x: x["start"], reverse=True):
                repl = _apply_style(m["value"], m["type"], mask_style, mask_char, mask_with)
                del chars[m["start"]:m["end"]]
                chars[m["start"]:m["start"]] = repl
            masked_text = "".join(chars)
            detected = matches

    summary = {
        "total_found": len(detected),
        "by_type": _count_by_type(detected),
        "mask_types_used": types,
        "mask_style": mask_style,
        "ignore_types": ignore_types,
        "output_file": output_file
    }
    result = {
        "original_text": input_text,
        "masked_text": masked_text,
        "detected_pii": detected,
        "summary": summary
    }

    if output_file:
        Path(output_file).write_text(masked_text, encoding="utf-8")
        result["summary"]["output_file"] = output_file
    elif file_path and output_file is None:
        Path(file_path).write_text(masked_text, encoding="utf-8")
        result["summary"]["output_file"] = file_path

    return result

def mask_pii_file(
    input_path: str,
    mask_types: Optional[List[str]] = None,
    custom_patterns: Optional[Dict[str, str]] = None,
    output_file: Optional[str] = None,
    mask_style: str = "replace",
    language: str = "en",
    mask_char: str = "*",
    mask_with: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Convenience wrapper: load text from file, apply masking, overwrite by default.
    """
    if output_file is None:
        output_file = input_path  # overwrite the source file
    return mask_pii(
        file_path=input_path,
        mask_types=mask_types,
        custom_patterns=custom_patterns,
        output_file=output_file,
        mask_with=mask_with,
        mask_style=mask_style,
        language=language,
        mask_char=mask_char
    )

def mask_pii_folder(
    folder_path: str,
    mask_types: Optional[List[str]] = None,
    custom_patterns: Optional[Dict[str, str]] = None,
    include_extensions: Optional[List[str]] = None,
    recursive: bool = True,
    output_strategy: str = "overwrite",  # overwrite | suffix | subdir
    suffix: str = "_masked",
    subdir_name: str = "masked",
    mask_style: str = "replace",
    language: str = "en",
    mask_char: str = "*",
    mask_with: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Bulk-mask PII in all files under a folder.

    include_extensions: list like ['.txt','.md','.log']; default uses common text types.
    output_strategy:
        overwrite  -> modify file in place
        suffix     -> write <name><suffix><ext> beside original
        subdir     -> write to a sibling subfolder (created if needed)
    Returns:
        {
          "folder": str,
          "total_files": int,
          "processed_files": int,
          "total_pii_found": int,
          "aggregate_by_type": {...},
          "files": [
             {
               "path": str,
               "output_path": str,
               "pii_found": int,
               "by_type": {...}
             }, ...
          ]
        }
    """
    base = Path(folder_path)
    if not base.is_dir():
        raise ValueError(f"Folder not found: {folder_path}")

    if include_extensions is None:
        include_extensions = [".txt", ".md", ".log", ".csv"]

    # Collect candidate files
    iterator = base.rglob("*") if recursive else base.glob("*")
    candidates = [
        p for p in iterator
        if p.is_file() and p.suffix.lower() in {e.lower() for e in include_extensions}
    ]

    results: List[Dict[str, Any]] = []
    aggregate_by_type: Dict[str, int] = {}
    total_pii = 0

    # Prepare subdir if needed
    if output_strategy == "subdir":
        target_dir = base / subdir_name
        target_dir.mkdir(exist_ok=True)
    else:
        target_dir = None

    for p in candidates:
        try:
            if output_strategy == "overwrite":
                out_path = p
            elif output_strategy == "suffix":
                out_path = p.with_name(f"{p.stem}{suffix}{p.suffix}")
            elif output_strategy == "subdir":
                out_path = (target_dir / p.name) if target_dir else p
            else:
                raise ValueError(f"Unknown output_strategy: {output_strategy}")

            res = mask_pii(
                file_path=str(p),
                mask_types=mask_types,
                custom_patterns=custom_patterns,
                output_file=str(out_path),
                mask_with=mask_with,
                mask_style=mask_style,
                language=language,
                mask_char=mask_char
            )
            by_type = res["summary"]["by_type"]
            count = res["summary"]["total_found"]

            # Aggregate
            total_pii += count
            for t, c in by_type.items():
                aggregate_by_type[t] = aggregate_by_type.get(t, 0) + c

            results.append({
                "path": str(p),
                "output_path": str(out_path),
                "pii_found": count,
                "by_type": by_type
            })
        except Exception as e:
            logger.warning(f"Failed masking file {p}: {e}")
            results.append({
                "path": str(p),
                "output_path": None,
                "pii_found": 0,
                "by_type": {},
                "error": str(e)
            })

    return {
        "folder": str(base),
        "total_files": len(candidates),
        "processed_files": len(results),
        "total_pii_found": total_pii,
        "aggregate_by_type": aggregate_by_type,
        "files": results
    }

# ----------------- Demo -----------------

if __name__ == "__main__":
    samples = [
        ("email+phone", "Contact john@example.com or call 555-123-4567", ["email","phone"]),
        ("ssn+card", "SSN 123-45-6789 Card 4111-1111-1111-1111", ["ssn","credit_card"]),
        ("all", "Email a@b.com IP 10.0.0.5 SSN 123-45-6789", ["all"]),
        ("custom", "Employee EMP-123456 contacted support", ["EMP_ID"])
    ]

    print("="*60)
    print("Presidio available:", _PRESIDIO_AVAILABLE)
    print("="*60)

    for label, txt, types in samples:
        print(f"\n[{label}]")
        cp = {"EMP_ID": r"EMP-\d{6}"} if label == "custom" else None
        res = mask_pii(text=txt, mask_types=types, custom_patterns=cp)
        print("Original:", res["original_text"])
        print("Masked:  ", res["masked_text"])
        print("Found:   ", res["summary"]["total_found"])
        print("By type: ", res["summary"]["by_type"])

    # File-based test
    print("\n[file-test]")
    sandbox = Path("_sandbox")
    sandbox.mkdir(exist_ok=True)
    file_sample = sandbox / "pii_sample.txt"
    file_sample.write_text(
        "Email jane.doe@acme.com Phone +1 (212) 555-0199 SSN 123-45-6789\n",
        encoding="utf-8"
    )
    res_file = mask_pii_file(str(file_sample), mask_types=["email","phone","ssn"])
    print("Path:", file_sample)
    print("Masked content:\n", file_sample.read_text(encoding="utf-8"))
    print("Summary:", res_file["summary"])

    # Example bulk usage (uncomment to test manually):
    # bulk = mask_pii_folder(
    #     folder_path="_sandbox",
    #     mask_types=["email","phone","ssn"],
    #     output_strategy="suffix",
    #     suffix="_redacted"
    # )
    # print(json.dumps(bulk, indent=2))
