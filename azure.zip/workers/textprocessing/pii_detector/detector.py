"""
PII Detector - Main Detection Engine
=====================================
File: pii_detector/detector.py

This file contains the CustomPIIDetector class with full detection capabilities.
"""

import re
import json
import hashlib
from typing import List, Dict, Any, Optional
from pathlib import Path

# Import models from same package
try:
    from .models import PIIEntity
except ImportError:
    # For standalone testing
    from dataclasses import dataclass
    
    @dataclass
    class PIIEntity:
        entity_type: str
        value: str
        start: int
        end: int
        confidence: float
        detector: str = "unknown"
        context: Optional[str] = None
        
        def to_dict(self):
            result = {
                "entity_type": self.entity_type,
                "value": self.value,
                "start": self.start,
                "end": self.end,
                "confidence": self.confidence,
                "detector": self.detector
            }
            if self.context:
                result["context"] = self.context
            return result


# Default configuration embedded
DEFAULT_CONFIG = {
    "detection": {
        "confidence_threshold": 0.5,
        "enabled_detectors": ["regex_patterns", "exact_match", "presidio_builtin"],
        "regex_patterns": {
            "EMPLOYEE_ID": {
                "enabled": True,
                "patterns": [{"regex": "EMP-\\d{6}", "score": 0.9}]
            }
        },
        "exact_match": {
            "PERSON_NAMES": {
                "enabled": True,
                "values": ["John Doe", "Jane Smith"],
                "score": 0.95,
                "case_sensitive": False,
                "match_whole_word": True
            }
        },
        "presidio_builtin": {
            "enabled": True,
            "entities": ["EMAIL_ADDRESS", "PHONE_NUMBER", "CREDIT_CARD"]
        }
    },
    "anonymization": {
        "default_strategy": "replace",
        "entity_strategies": {
            "EMAIL_ADDRESS": "mask",
            "CREDIT_CARD": "mask"
        },
        "replacements": {
            "EMPLOYEE_ID": "[EMP_ID]",
            "default": "[REDACTED]"
        },
        "masking": {
            "char": "*",
            "chars_to_mask": 100,
            "from_end": False
        }
    },
    "output": {
        "include_positions": True,
        "include_confidence": True,
        "include_context": False,
        "context_window": 20,
        "format": "json",
        "pretty_print": True
    }
}


class CustomPIIDetector:
    """
    Main PII Detection Engine
    ==========================
    
    Supports:
    - Custom regex patterns
    - Exact word/phrase matching
    - Deny lists
    - Presidio integration (optional)
    - Full JSON configuration
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize PII Detector
        
        Args:
            config_path: Path to JSON configuration file (optional)
        """
        self.config = {}
        self.regex_cache = {}
        self.presidio_analyzer = None
        self.presidio_anonymizer = None
        
        if config_path:
            self.load_config(config_path)
        else:
            self.load_default_config()
    
    def load_config(self, config_path: str):
        """Load configuration from JSON file"""
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        self._initialize()
    
    def load_config_from_dict(self, config: Dict[str, Any]):
        """Load configuration from dictionary"""
        self.config = config
        self._initialize()
    
    def load_config_from_string(self, json_string: str):
        """Load configuration from JSON string"""
        self.config = json.loads(json_string)
        self._initialize()
    
    def load_default_config(self):
        """Load default embedded configuration"""
        self.config = DEFAULT_CONFIG.copy()
        self._initialize()
    
    def _initialize(self):
        """Initialize detectors based on configuration"""
        self._compile_regex_patterns()
        
        if self._is_detector_enabled("presidio_builtin"):
            self._initialize_presidio()
    
    def _is_detector_enabled(self, detector_name: str) -> bool:
        """Check if a detector is enabled"""
        return detector_name in self.config.get('detection', {}).get('enabled_detectors', [])
    
    def _compile_regex_patterns(self):
        """Pre-compile all regex patterns"""
        self.regex_cache = {}
        
        if not self._is_detector_enabled("regex_patterns"):
            return
        
        regex_config = self.config.get('detection', {}).get('regex_patterns', {})
        
        for entity_type, entity_config in regex_config.items():
            if not entity_config.get('enabled', False):
                continue
            
            self.regex_cache[entity_type] = []
            
            for pattern_def in entity_config.get('patterns', []):
                flags = 0
                flag_str = pattern_def.get('flags', '')
                
                if 'IGNORECASE' in flag_str or 'I' in flag_str:
                    flags |= re.IGNORECASE
                
                try:
                    compiled = re.compile(pattern_def['regex'], flags)
                    self.regex_cache[entity_type].append({
                        'pattern': compiled,
                        'score': pattern_def.get('score', 0.7)
                    })
                except re.error as e:
                    print(f"Warning: Invalid regex for {entity_type}: {e}")
    
    def _initialize_presidio(self):
        """Initialize Presidio engines"""
        try:
            from presidio_analyzer import AnalyzerEngine, RecognizerRegistry
            from presidio_anonymizer import AnonymizerEngine
            
            registry = RecognizerRegistry()
            registry.load_predefined_recognizers(nlp_engine=None)
            
            self.presidio_analyzer = AnalyzerEngine(
                registry=registry,
                nlp_engine=None
            )
            self.presidio_anonymizer = AnonymizerEngine()
            
        except ImportError:
            print("Warning: Presidio not installed. Run: pip install presidio-analyzer presidio-anonymizer")
    
    def detect(self, text: str) -> List[PIIEntity]:
        """
        Detect PII in text
        
        Args:
            text: Input text to analyze
            
        Returns:
            List of detected PII entities
        """
        if not text:
            return []
        
        results = []
        
        # Regex pattern detection
        if self._is_detector_enabled("regex_patterns"):
            results.extend(self._detect_regex(text))
        
        # Exact match detection
        if self._is_detector_enabled("exact_match"):
            results.extend(self._detect_exact_match(text))
        
        # Deny list detection
        if self._is_detector_enabled("deny_list"):
            results.extend(self._detect_deny_list(text))
        
        # Presidio detection
        if self._is_detector_enabled("presidio_builtin") and self.presidio_analyzer:
            results.extend(self._detect_presidio(text))
        
        # Remove duplicates and apply threshold
        results = self._deduplicate_results(results)
        results = self._apply_threshold(results)
        results.sort(key=lambda x: x.start)
        
        return results
    
    def _detect_regex(self, text: str) -> List[PIIEntity]:
        """Detect using regex patterns"""
        results = []
        regex_config = self.config.get('detection', {}).get('regex_patterns', {})
        
        for entity_type, patterns_info in self.regex_cache.items():
            entity_config = regex_config.get(entity_type, {})
            
            for pattern_info in patterns_info:
                pattern = pattern_info['pattern']
                base_score = pattern_info['score']
                
                for match in pattern.finditer(text):
                    value = match.group(0)
                    start = match.start()
                    end = match.end()
                    
                    # Context boost
                    score = base_score
                    context_words = entity_config.get('context_words', [])
                    if context_words:
                        context = self._get_context(text, start, end)
                        if self._has_context_words(context, context_words):
                            score += entity_config.get('context_boost', 0.1)
                            score = min(score, 1.0)
                    
                    # Get context if configured
                    context_str = None
                    if self.config.get('output', {}).get('include_context', False):
                        context_str = self._get_context(text, start, end)
                    
                    results.append(PIIEntity(
                        entity_type=entity_type,
                        value=value,
                        start=start,
                        end=end,
                        confidence=score,
                        detector="regex",
                        context=context_str
                    ))
        
        return results
    
    def _detect_exact_match(self, text: str) -> List[PIIEntity]:
        """Detect using exact word/phrase matching"""
        results = []
        exact_config = self.config.get('detection', {}).get('exact_match', {})
        
        for entity_type, match_config in exact_config.items():
            if not match_config.get('enabled', False):
                continue
            
            values = match_config.get('values', [])
            case_sensitive = match_config.get('case_sensitive', False)
            match_whole_word = match_config.get('match_whole_word', True)
            score = match_config.get('score', 0.9)
            
            search_text = text if case_sensitive else text.lower()
            
            for value in values:
                search_value = value if case_sensitive else value.lower()
                
                if match_whole_word:
                    pattern = re.compile(r'\b' + re.escape(search_value) + r'\b',
                                       0 if case_sensitive else re.IGNORECASE)
                    for match in pattern.finditer(text):
                        context_str = None
                        if self.config.get('output', {}).get('include_context', False):
                            context_str = self._get_context(text, match.start(), match.end())
                        
                        results.append(PIIEntity(
                            entity_type=entity_type,
                            value=match.group(0),
                            start=match.start(),
                            end=match.end(),
                            confidence=score,
                            detector="exact_match",
                            context=context_str
                        ))
                else:
                    start_pos = 0
                    while True:
                        pos = search_text.find(search_value, start_pos)
                        if pos == -1:
                            break
                        
                        context_str = None
                        if self.config.get('output', {}).get('include_context', False):
                            context_str = self._get_context(text, pos, pos + len(value))
                        
                        results.append(PIIEntity(
                            entity_type=entity_type,
                            value=text[pos:pos + len(value)],
                            start=pos,
                            end=pos + len(value),
                            confidence=score,
                            detector="exact_match",
                            context=context_str
                        ))
                        start_pos = pos + 1
        
        return results
    
    def _detect_deny_list(self, text: str) -> List[PIIEntity]:
        """Detect using deny list"""
        results = []
        deny_config = self.config.get('detection', {}).get('deny_list', {})
        
        for entity_type, list_config in deny_config.items():
            if not list_config.get('enabled', False):
                continue
            
            words = list_config.get('words', [])
            case_sensitive = list_config.get('case_sensitive', False)
            match_whole_word = list_config.get('match_whole_word', True)
            score = list_config.get('score', 0.8)
            
            search_text = text if case_sensitive else text.lower()
            
            for word in words:
                search_word = word if case_sensitive else word.lower()
                
                if match_whole_word:
                    pattern = re.compile(r'\b' + re.escape(search_word) + r'\b',
                                       0 if case_sensitive else re.IGNORECASE)
                    for match in pattern.finditer(text):
                        context_str = None
                        if self.config.get('output', {}).get('include_context', False):
                            context_str = self._get_context(text, match.start(), match.end())
                        
                        results.append(PIIEntity(
                            entity_type=entity_type,
                            value=match.group(0),
                            start=match.start(),
                            end=match.end(),
                            confidence=score,
                            detector="deny_list",
                            context=context_str
                        ))
                else:
                    start_pos = 0
                    while True:
                        pos = search_text.find(search_word, start_pos)
                        if pos == -1:
                            break
                        
                        context_str = None
                        if self.config.get('output', {}).get('include_context', False):
                            context_str = self._get_context(text, pos, pos + len(word))
                        
                        results.append(PIIEntity(
                            entity_type=entity_type,
                            value=text[pos:pos + len(word)],
                            start=pos,
                            end=pos + len(word),
                            confidence=score,
                            detector="deny_list",
                            context=context_str
                        ))
                        start_pos = pos + 1
        
        return results
    
    def _detect_presidio(self, text: str) -> List[PIIEntity]:
        """Detect using Presidio"""
        if not self.presidio_analyzer:
            return []
        
        results = []
        presidio_config = self.config.get('detection', {}).get('presidio_builtin', {})
        entities = presidio_config.get('entities', [])
        
        presidio_results = self.presidio_analyzer.analyze(
            text=text,
            entities=entities,
            language='en'
        )
        
        for result in presidio_results:
            context_str = None
            if self.config.get('output', {}).get('include_context', False):
                context_str = self._get_context(text, result.start, result.end)
            
            results.append(PIIEntity(
                entity_type=result.entity_type,
                value=text[result.start:result.end],
                start=result.start,
                end=result.end,
                confidence=result.score,
                detector="presidio",
                context=context_str
            ))
        
        return results
    
    def _get_context(self, text: str, start: int, end: int) -> str:
        """Get surrounding context"""
        window = self.config.get('output', {}).get('context_window', 20)
        context_start = max(0, start - window)
        context_end = min(len(text), end + window)
        return text[context_start:context_end]
    
    def _has_context_words(self, context: str, words: List[str]) -> bool:
        """Check if context contains any words"""
        context_lower = context.lower()
        return any(word.lower() in context_lower for word in words)
    
    def _deduplicate_results(self, results: List[PIIEntity]) -> List[PIIEntity]:
        """Remove overlapping detections"""
        if not results:
            return []
        
        sorted_results = sorted(results, key=lambda x: (x.start, -x.confidence))
        deduplicated = []
        last_end = -1
        
        for result in sorted_results:
            if result.start >= last_end:
                deduplicated.append(result)
                last_end = result.end
            elif deduplicated and result.confidence > deduplicated[-1].confidence:
                if deduplicated[-1].start == result.start:
                    deduplicated[-1] = result
                    last_end = result.end
        
        return deduplicated
    
    def _apply_threshold(self, results: List[PIIEntity]) -> List[PIIEntity]:
        """Filter by confidence threshold"""
        threshold = self.config.get('detection', {}).get('confidence_threshold', 0.5)
        return [r for r in results if r.confidence >= threshold]
    
    def anonymize(self, text: str) -> Dict[str, Any]:
        """
        Detect and anonymize PII
        
        Args:
            text: Input text
            
        Returns:
            Dictionary with anonymized text and detected entities
        """
        entities = self.detect(text)
        entities_sorted = sorted(entities, key=lambda x: x.start, reverse=True)
        
        anonymized_text = text
        for entity in entities_sorted:
            strategy = self._get_strategy(entity.entity_type)
            replacement = self._get_replacement(entity, strategy)
            
            anonymized_text = (
                anonymized_text[:entity.start] + 
                replacement + 
                anonymized_text[entity.end:]
            )
        
        return {
            "original_text": text,
            "anonymized_text": anonymized_text,
            "detected_entities": [e.to_dict() for e in entities]
        }
    
    def _get_strategy(self, entity_type: str) -> str:
        """Get anonymization strategy"""
        strategies = self.config.get('anonymization', {}).get('entity_strategies', {})
        return strategies.get(entity_type, 
                            self.config.get('anonymization', {}).get('default_strategy', 'replace'))
    
    def _get_replacement(self, entity: PIIEntity, strategy: str) -> str:
        """Get replacement value"""
        if strategy == "redact":
            return ""
        
        elif strategy == "mask":
            masking = self.config.get('anonymization', {}).get('masking', {})
            char = masking.get('char', '*')
            return char * len(entity.value)
        
        elif strategy == "hash":
            return hashlib.sha256(entity.value.encode()).hexdigest()[:16]
        
        elif strategy == "replace":
            replacements = self.config.get('anonymization', {}).get('replacements', {})
            return replacements.get(entity.entity_type, 
                                  replacements.get('default', '[REDACTED]'))
        
        else:
            return '[REDACTED]'
    
    def format_output(self, entities: List[PIIEntity]) -> str:
        """Format output based on configuration"""
        output_format = self.config.get('output', {}).get('format', 'json')
        pretty = self.config.get('output', {}).get('pretty_print', True)
        
        data = [e.to_dict() for e in entities]
        
        if output_format == "json":
            if pretty:
                return json.dumps(data, indent=2, ensure_ascii=False)
            return json.dumps(data, ensure_ascii=False)
        
        return str(data)
    
    def save_config(self, output_path: str):
        """Save current configuration"""
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)


# Example usage
if __name__ == "__main__":
    print("PII Detector - detector.py")
    print("=" * 60)
    
    detector = CustomPIIDetector()
    
    text = "Contact John at john@example.com or call 555-1234"
    results = detector.detect(text)
    
    print(f"\nDetected {len(results)} PII entities:")
    for entity in results:
        print(f"  {entity.entity_type}: {entity.value}")
    
    print("\nFile ready to use!")