from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class TextProcessingConfig(BaseSettings):
	model_config = SettingsConfigDict(
		env_file=".env",
		env_file_encoding="utf-8",
		extra="ignore",
	)

	data_backbone_dir: str = Field(validation_alias=AliasChoices("DATA_BACKBONE_DIR"))
	db_dsn: str = Field(validation_alias=AliasChoices("DB_DSN", "DATABASE_URL", "TEXTPROCESSING_DB_DSN"))


settings = TextProcessingConfig()

DATA_BACKBONE_DIR = settings.data_backbone_dir
DB_DSN = settings.db_dsn


__all__ = [
	"TextProcessingConfig",
	"settings",
	"DATA_BACKBONE_DIR",
	"DB_DSN",
]
