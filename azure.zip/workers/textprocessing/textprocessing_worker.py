"""
Text Processing Worker

This Celery worker handles text processing tasks including:
- Text normalization (whitespace, page numbers, case conversion)
- PII detection and redaction using mask_pii utility

Environment Variables Required:
- CELERY_BROKER_URL: Celery broker connection string
- CELERY_RESULT_BACKEND: Celery result backend connection string
- DATA_BACKBONE_DIR: Base directory for data storage
- DB_DSN: Database DSN (validated at startup)
- TEXTPROCESSING_LOG_LEVEL: Logging level (DEBUG, INFO, WARNING, ERROR)
- WORKER_RESULTS_URL: Callback URL for posting results
- TEXTPROCESSING_QUEUES: Comma-separated queue names
- PII_MASK_TYPES: Default PII types to mask (default: 'all')
- PII_MASK_STYLE: Default masking style (default: 'replace')
"""

import os
import re
import sys
import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path

import requests
from celery import Celery
from kombu import Queue
from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
# Try to import the PII utilities from our package
try:
    from .pii_detector.mask_pii import (
        mask_pii,
        mask_pii_file,
        mask_pii_folder,
    )
    _PII_IMPORT_ERR: Optional[Exception] = None
except Exception as _e:  # fallback if relative import path differs
    try:
        from workers.textprocessing.pii_detector.mask_pii import (
            mask_pii,
            mask_pii_file,
            mask_pii_folder,
        )
        _PII_IMPORT_ERR = None
    except Exception as _e2:
        mask_pii = None  # type: ignore
        mask_pii_file = None  # type: ignore
        mask_pii_folder = None  # type: ignore
        _PII_IMPORT_ERR = _e2

logger = logging.getLogger("workers.textprocessing")

def initialize_pii_detector() -> bool:
    """
    Ensure PII detector is importable.
    Returns True if ready, False otherwise.
    """
    if mask_pii is None:
        logger.warning(f"PII detector not available: {_PII_IMPORT_ERR!r}")
        return False
    return True


# Simple helper to run PII masking on text (non-Celery usage)
def filter_pii(
    text: Optional[str] = None,
    file_path: Optional[str] = None,
    *,
    mask_types: Optional[List[str]] = None,
    custom_patterns: Optional[Dict[str, str]] = None,
    mask_style: str = "replace",
    language: str = "en",
    mask_char: str = "*",
    ignore_types: Optional[List[str]] = None,
    output_file: Optional[str] = None,
    mask_with: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Pass-through to mask_pii with sane defaults.
    """
    if not initialize_pii_detector():
        raise RuntimeError("PII detector not initialized")

    if text is None and file_path is None:
        raise ValueError("Provide text or file_path")

    # mask_pii already auto-generates replacements and supports 'all'
    return mask_pii(  # type: ignore[misc]
        text=text,
        file_path=file_path,
        mask_types=mask_types or ["all"],
        custom_patterns=custom_patterns,
        output_file=output_file,
        mask_with=mask_with,
        mask_style=mask_style,
        language=language,
        mask_char=mask_char,
        ignore_types=ignore_types,
    )


# Convenience wrappers for files/folders (non-Celery)
def filter_pii_file(
    input_path: str,
    *,
    output_file: Optional[str] = None,
    mask_types: Optional[List[str]] = None,
    custom_patterns: Optional[Dict[str, str]] = None,
    mask_style: str = "replace",
    language: str = "en",
    mask_char: str = "*",
    ignore_types: Optional[List[str]] = None,
    mask_with: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    if not initialize_pii_detector():
        raise RuntimeError("PII detector not initialized")
    # mask_pii_file overwrites by default if output_file None
    return mask_pii_file(  # type: ignore[misc]
        input_path=input_path,
        mask_types=mask_types or ["all"],
        custom_patterns=custom_patterns,
        output_file=output_file,
        mask_style=mask_style,
        language=language,
        mask_char=mask_char,
        mask_with=mask_with,
    )


def filter_pii_folder(
    folder_path: str,
    *,
    include_extensions: Optional[List[str]] = None,
    recursive: bool = True,
    output_strategy: str = "suffix",  # overwrite | suffix | subdir
    suffix: str = "_masked",
    subdir_name: str = "masked",
    mask_types: Optional[List[str]] = None,
    custom_patterns: Optional[Dict[str, str]] = None,
    mask_style: str = "replace",
    language: str = "en",
    mask_char: str = "*",
    mask_with: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    if not initialize_pii_detector():
        raise RuntimeError("PII detector not initialized")
    return mask_pii_folder(  # type: ignore[misc]
        folder_path=folder_path,
        mask_types=mask_types or ["all"],
        custom_patterns=custom_patterns,
        include_extensions=include_extensions,
        recursive=recursive,
        output_strategy=output_strategy,
        suffix=suffix,
        subdir_name=subdir_name,
        mask_style=mask_style,
        language=language,
        mask_char=mask_char,
        mask_with=mask_with,
    )


# ============================================================================
# CONFIGURATION
# ============================================================================

class TextProcessingSettings(BaseSettings):
    """Env-first settings with .env fallback for local development."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    celery_broker_url: str = Field(
        validation_alias=AliasChoices("CELERY_BROKER_URL", "RABBITMQ_URL", "TEXTPROCESSING_BROKER_URL")
    )
    celery_result_backend: str = Field(
        validation_alias=AliasChoices("CELERY_RESULT_BACKEND", "TEXTPROCESSING_RESULT_BACKEND")
    )
    data_backbone_dir: str = Field(validation_alias=AliasChoices("DATA_BACKBONE_DIR"))
    db_dsn: str = Field(validation_alias=AliasChoices("DB_DSN", "DATABASE_URL", "TEXTPROCESSING_DB_DSN"))
    textprocessing_log_level: str = Field(
        default="INFO",
        validation_alias=AliasChoices("TEXTPROCESSING_LOG_LEVEL", "LOG_LEVEL"),
    )
    worker_results_url: str = Field(validation_alias=AliasChoices("WORKER_RESULTS_URL"))
    textprocessing_queues: str = Field(
        default="textprocessing",
        validation_alias=AliasChoices("TEXTPROCESSING_QUEUES", "CELERY_QUEUE"),
    )
    pii_mask_types: str = Field(default="all", validation_alias=AliasChoices("PII_MASK_TYPES"))
    pii_mask_style: str = Field(default="replace", validation_alias=AliasChoices("PII_MASK_STYLE"))


settings = TextProcessingSettings()

# Backward-compatible module constants
CELERY_BROKER_URL = settings.celery_broker_url
CELERY_RESULT_BACKEND = settings.celery_result_backend
DATA_BACKBONE_DIR = settings.data_backbone_dir
DB_DSN = settings.db_dsn
TEXTPROCESSING_LOG_LEVEL = settings.textprocessing_log_level.upper()
WORKER_RESULTS_URL = settings.worker_results_url
TEXTPROCESSING_QUEUES = settings.textprocessing_queues
PII_MASK_TYPES = settings.pii_mask_types
PII_MASK_STYLE = settings.pii_mask_style

# ============================================================================
# LOGGING SETUP
# ============================================================================

logger = logging.getLogger("textprocessing_worker")

if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# Set log level from environment variable
try:
    logger.setLevel(getattr(logging, TEXTPROCESSING_LOG_LEVEL, logging.INFO))
except (AttributeError, ValueError):
    logger.setLevel(logging.INFO)
    logger.warning(f"Invalid log level '{TEXTPROCESSING_LOG_LEVEL}', defaulting to INFO")

# ============================================================================
# CELERY CONFIGURATION
# ============================================================================

celery_app = Celery(
    "textprocessing_worker",
    broker=CELERY_BROKER_URL,
    backend=CELERY_RESULT_BACKEND,
)

# Configure task queues from environment variable
queue_names = [q.strip() for q in TEXTPROCESSING_QUEUES.split(",") if q.strip()]
if not queue_names:
    raise RuntimeError(
        "TEXTPROCESSING_QUEUES must specify at least one queue name (e.g. 'textprocessing')"
    )

celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]

logger.info(f"Configured queues: {queue_names}")

# ============================================================================
# PII DETECTION INITIALIZATION
# ============================================================================

_mask_pii_function = None
_PII_AVAILABLE = False


def initialize_pii_detector() -> bool:
    """
    Initialize PII detector by importing mask_pii function.
    
    Tries to import from:
    1. Installed pii_detector package
    2. Local pii_detector directory (sibling to this file)
    3. Parent directory's pii_detector
    
    Returns:
        True if initialization successful, False otherwise
    """
    global _mask_pii_function, _PII_AVAILABLE
    
    # Try 1: Import from installed package
    try:
        from pii_detector.mask_pii import mask_pii
        _mask_pii_function = mask_pii
        _PII_AVAILABLE = True
        logger.info("PII detector loaded from installed package")
        return True
    except ImportError:
        pass
    
    # Try 2: Import from local pii_detector directory (same level as worker)
    try:
        worker_dir = Path(__file__).parent
        pii_detector_path = worker_dir / "pii_detector"
        if pii_detector_path.exists() and pii_detector_path.is_dir():
            sys.path.insert(0, str(worker_dir))
            from pii_detector.mask_pii import mask_pii
            _mask_pii_function = mask_pii
            _PII_AVAILABLE = True
            logger.info(f"PII detector loaded from local directory: {pii_detector_path}")
            return True
    except ImportError:
        pass
    # Note: we intentionally do NOT attempt to import from parent directories.
    # The worker should be self-contained; either the package is installed
    # in the environment or a local `pii_detector/` sibling directory is present.
    
    logger.warning(
        "PII detector (mask_pii) not available. "
        "Place pii_detector directory next to textprocessing_worker.py or install as package."
    )
    return False


# Initialize PII detection at module load time
initialize_pii_detector()

# ============================================================================
# TEXT PROCESSING FILTERS
# ============================================================================


def filter_remove_page_numbers(text: str) -> str:
    """
    Remove page numbers and page markers from text.
    
    Removes lines matching patterns like:
    - Standalone numbers: "5"
    - Page markers: "--- Page 5 ---" or "Page 5"
    
    Args:
        text: Input text
        
    Returns:
        Text with page numbers removed
    """
    lines = text.splitlines()
    cleaned_lines = []
    
    for line in lines:
        # Skip standalone numbers
        if re.fullmatch(r"\s*\d+\s*", line):
            continue
        # Skip page markers
        if re.fullmatch(r"---\s*Page\s+\d+\s*---", line.strip(), re.IGNORECASE):
            continue
        if re.fullmatch(r"Page\s+\d+", line.strip(), re.IGNORECASE):
            continue
        cleaned_lines.append(line)
    
    return "\n".join(cleaned_lines)


def filter_whitespace_normalize(text: str) -> str:
    """
    Normalize whitespace in text.
    
    Operations:
    - Remove trailing spaces from lines
    - Remove empty lines (whitespace-only)
    - Collapse 3+ consecutive newlines to 2
    - Collapse multiple spaces to single space
    
    Args:
        text: Input text
        
    Returns:
        Text with normalized whitespace
    """
    # Remove trailing whitespace from each line
    lines = [re.sub(r"\s+$", "", line) for line in text.splitlines()]
    
    # Remove lines that are only whitespace
    lines = [line for line in lines if line.strip()]
    
    # Join and collapse multiple newlines
    normalized = "\n".join(lines)
    normalized = re.sub(r"\n{3,}", "\n\n", normalized)
    
    # Collapse multiple spaces to single space
    normalized = re.sub(r"[ \t]{2,}", " ", normalized)
    
    return normalized


def filter_convert_to_lowercase(text: str) -> str:
    """
    Convert text to lowercase.
    
    Args:
        text: Input text
        
    Returns:
        Lowercase text
    """
    return text.lower()


def filter_pii(
    file_path: str,
    pii_config: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Detect and redact PII using mask_pii utility.
    """
    if not _PII_AVAILABLE or _mask_pii_function is None:
        raise RuntimeError(
            "PII detector (mask_pii) not available. "
            "Place pii_detector directory next to textprocessing_worker.py"
        )
    
    # Use config from parameter or defaults from environment
    config = pii_config or {}
    
    # Get mask_types
    mask_types_value = config.get("mask_types", PII_MASK_TYPES)
    if isinstance(mask_types_value, str):
        mask_types = [t.strip() for t in mask_types_value.split(",") if t.strip()]
    elif isinstance(mask_types_value, list):
        mask_types = mask_types_value
    else:
        mask_types = ["all"]
    
    # Get other parameters
    custom_patterns = config.get("custom_patterns")
    mask_with = config.get("mask_with")
    mask_style = config.get("mask_style", PII_MASK_STYLE)
    
    logger.info(f"Processing PII with mask_types={mask_types}, mask_style={mask_style}")
    
    # Call mask_pii function
    result = _mask_pii_function(
        file_path=file_path,
        mask_types=mask_types,
        custom_patterns=custom_patterns,
        mask_with=mask_with,
        mask_style=mask_style,
        output_file=file_path
    )
    
    # Build detection info - handle missing 'detected_pii' key
    detection_info = {
        "method": "mask_pii",
        "total_found": result.get('summary', {}).get('total_found', 0),
        "by_type": result.get('summary', {}).get('by_type', {}),
        "mask_types_used": mask_types,
        "mask_style": mask_style
    }
    
    # Add detected_pii if available
    if 'detected_pii' in result:
        detection_info['detected_pii'] = result['detected_pii']
    
    logger.info(
        f"PII detection complete: found {detection_info['total_found']} entities - "
        f"{detection_info['by_type']}"
    )
    
    return detection_info


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================


def is_absolute_or_unc_path(path: str) -> bool:
    """
    Check if path is absolute or UNC path.
    
    Args:
        path: Path string to check
        
    Returns:
        True if path is absolute or UNC, False otherwise
    """
    return bool(path) and (
        os.path.isabs(path) or path.startswith("\\\\") or path.startswith("//")
    )

def is_filter_enabled(value: Any) -> bool:
    """Return True if the provided filter config value indicates the filter should run.

    Accepts booleans, strings like "true", "1", "yes", and treats dicts as enabled.
    """
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    if isinstance(value, dict):
        return True
    return str(value).strip().lower() in ("true", "1", "yes", "y")


# Convenience aliases and small utility helpers expected elsewhere in the file
def _is_abs_or_unc(p: str) -> bool:
    return is_absolute_or_unc_path(p)


# Backward-compatibility alias: some code calls filter_whitespace_remove
def filter_whitespace_remove(text: str) -> str:
    return filter_whitespace_normalize(text)


def resolve_folder_path(folder_id: str) -> str:
    """Resolve a folder identifier to an absolute path.

    If folder_id is an absolute path or UNC path, return it unchanged; otherwise
    join it with DATA_BACKBONE_DIR.
    """
    # Helper to extract UNC host (\\HOST\Share -> HOST)
    def _unc_host(p: str) -> str:
        if not p:
            return ""
        s = p.strip()
        if s.startswith('\\\\'):
            trimmed = s.lstrip('\\')
            parts = trimmed.split('\\', 1)
            return parts[0] if parts else ""
        return ""

    # Build base path for relative ids
    if not _is_abs_or_unc(folder_id):
        # Relative folder case: join with DATA_BACKBONE_DIR
        joined = os.path.join(DATA_BACKBONE_DIR, folder_id)
        if os.path.exists(joined):
            return joined
        # If DATA_BACKBONE_DIR uses localhost and path missing, attempt fallback host substitution
        host_bb = _unc_host(DATA_BACKBONE_DIR)
        if host_bb.lower() in ("localhost", "127.0.0.1"):
            fb_host = os.getenv("DATA_BACKBONE_FALLBACK_HOST") or os.getenv("GENERIC_FALLBACK_HOST") or ""
            if fb_host:
                try:
                    remainder = joined.lstrip('\\')
                    parts = remainder.split('\\', 1)
                    if len(parts) >= 2:
                        _old_host, rest = parts
                        candidate = f"\\\\{fb_host}\\{rest}"
                        if os.path.exists(candidate):
                            logger.info(f"Auto-swapped relative join host '{host_bb}' to fallback '{fb_host}' -> {candidate}")
                            return candidate
                except Exception:
                    pass
        return joined

    # Absolute / UNC path branch
    abs_path = folder_id
    if os.path.exists(abs_path):
        return abs_path

    # Attempt host swap if UNC and missing
    host_bb = _unc_host(DATA_BACKBONE_DIR)
    host_incoming = _unc_host(abs_path)
    if host_bb and host_incoming and host_incoming.lower() in ("localhost", "127.0.0.1"):
        try:
            # Replace leading \\localhost with \\host_bb
            remainder = abs_path.lstrip('\\')
            parts = remainder.split('\\', 1)
            if len(parts) == 2:
                _old_host, rest = parts
                candidate = f"\\\\{host_bb}\\{rest}"
                if os.path.exists(candidate):
                    logger.info(f"Auto-swapped UNC host '{host_incoming}' to '{host_bb}' -> {candidate}")
                    return candidate
        except Exception:
            pass

    # Fallback host substitution via env DATA_BACKBONE_FALLBACK_HOST
    fb_host = os.getenv("DATA_BACKBONE_FALLBACK_HOST") or os.getenv("GENERIC_FALLBACK_HOST") or ""
    if fb_host and host_incoming and host_incoming.lower() in ("localhost", "127.0.0.1"):
        try:
            remainder = abs_path.lstrip('\\')
            parts = remainder.split('\\', 1)
            if len(parts) == 2:
                _old_host, rest = parts
                candidate = f"\\\\{fb_host}\\{rest}"
                if os.path.exists(candidate):
                    logger.info(f"Auto-swapped UNC host '{host_incoming}' to fallback '{fb_host}' -> {candidate}")
                    return candidate
        except Exception:
            pass

    # Return original even if missing so caller can error explicitly
    return abs_path


def find_text_file(folder_path: str) -> str:
    """Return the first .txt file path in folder_path, or raise ValueError.
    """
    if not os.path.isdir(folder_path):
        raise ValueError(f"Folder not found: {folder_path}")
    txt_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.txt')]
    if not txt_files:
        raise ValueError(f"No .txt file found in folder: {folder_path}")
    return os.path.join(folder_path, txt_files[0])


def find_layout_json_file(folder_path: str) -> Optional[str]:
    """Return the first *.layout.json path if present; else None.
    """
    try:
        if not os.path.isdir(folder_path):
            return None
        cand = sorted(
            [f for f in os.listdir(folder_path) if f.lower().endswith('.layout.json')]
        )
        if cand:
            return os.path.join(folder_path, cand[0])
        return None
    except Exception:
        return None


def find_any_json_file(folder_path: str) -> Optional[str]:
    """Return the first *.json path in the folder if present; else None.

    Used primarily for runtime textprocessing, where any JSON payload is acceptable.
    """
    try:
        if not os.path.isdir(folder_path):
            return None
        cand = sorted(
            [f for f in os.listdir(folder_path) if f.lower().endswith('.json')]
        )
        if cand:
            return os.path.join(folder_path, cand[0])
        return None
    except Exception:
        return None


def find_parser_output_json_file(folder_path: str) -> Optional[str]:
    """Return the first *.parser_output.json path if present; else None."""
    try:
        if not os.path.isdir(folder_path):
            return None
        cand = sorted(
            [f for f in os.listdir(folder_path) if f.lower().endswith('.parser_output.json')]
        )
        if cand:
            return os.path.join(folder_path, cand[0])
        return None
    except Exception:
        return None


def _split_outer_tag(tag_text: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Split a single tagged block like <heading ...>inner</heading>.

    Returns (open_tag_with_attrs, inner_text, closing_tag) or (None,None,None) if not matched.
    """
    try:
        m = re.match(r"^(<\s*(heading|paragraph|table)\b[^>]*>)([\s\S]*?)(</\s*\2\s*>)$", tag_text.strip(), flags=re.IGNORECASE)
        if not m:
            return None, None, None
        return m.group(1), m.group(3), m.group(4)
    except Exception:
        return None, None, None


def _apply_filters_to_tag_text(open_tag: str, inner: str, close_tag: str, filters_config: Dict[str, Any]) -> str:
    """Apply non-PII filters to inner text for heading/paragraph only; preserve table HTML.

    We preserve the original open/close tags and attributes; only mutate the inner text.
    """
    # Determine tag type from open_tag
    tag_lower = open_tag.lower()
    is_table = tag_lower.startswith("<table")
    is_heading = tag_lower.startswith("<heading")
    is_paragraph = tag_lower.startswith("<paragraph")

    # Skip altering table inner HTML to avoid breaking structure
    if is_table:
        return open_tag + inner + close_tag

    text = inner or ""
    # 1. Whitespace normalization
    if is_filter_enabled(filters_config.get("WhitespaceRemove")):
        try:
            text = filter_whitespace_normalize(text)
        except Exception:
            pass
    # 2. Remove page numbers
    if is_filter_enabled(filters_config.get("RemovePageNumbers")):
        try:
            text = filter_remove_page_numbers(text)
        except Exception:
            pass
    # 3. Convert to lowercase
    if is_filter_enabled(filters_config.get("ConvertToLowercase")):
        try:
            text = filter_convert_to_lowercase(text)
        except Exception:
            pass
    return open_tag + text + close_tag


def process_layout_json(folder_path: str, json_path: str, filters_config: Dict[str, Any]) -> Tuple[str, Optional[str], List[str]]:
    """Process a layout-style JSON in place.

    Applies configured non-PII filters and optional per-segment PII masking to each segment's
    text_tag while keeping seg['text'] synchronized. The original JSON file is updated in place; no
    additional cleaned JSON or TXT artifacts are produced.

    Returns:
        (updated_json_path, None, applied_filters)
    """
    applied_filters: List[str] = []
    try:
        with open(json_path, 'r', encoding='utf-8', errors='ignore') as fh:
            data = json.load(fh)

        # Flexible extraction: allow several schema variants.
        def _extract_layout(obj: Any) -> Optional[List[Any]]:
            # Direct list root
            if isinstance(obj, list):
                return obj
            if isinstance(obj, dict):
                # Primary expected key
                if isinstance(obj.get('layout'), list):
                    return obj['layout']
                # Alternate conventional keys
                for alt_key in ('segments', 'items', 'elements', 'data', 'pages', 'blocks'):
                    if isinstance(obj.get(alt_key), list):
                        return obj[alt_key]
                # Heuristic: first list-valued key whose list has dict or str entries
                for k, v in obj.items():
                    if isinstance(v, list) and v and any(isinstance(x, (dict, str)) for x in v):
                        return v
            return None

        def _synthesize_layout_from_any(obj: Any) -> List[Dict[str, Any]]:
            """Recursively collect string leaves into paragraph segments if no structured layout present."""
            segments: List[Dict[str, Any]] = []
            def _recurse(node: Any):
                if isinstance(node, str):
                    text = node.strip()
                    if text:
                        segments.append({
                            'type': 'paragraph',
                            'text': text,
                            'text_tag': f"<paragraph>{text}</paragraph>",
                        })
                elif isinstance(node, list):
                    for item in node:
                        _recurse(item)
                elif isinstance(node, dict):
                    # Prefer explicit 'text' field if present in dict
                    if isinstance(node.get('text'), str):
                        t = node.get('text').strip()
                        if t:
                            segments.append({
                                'type': node.get('type', 'paragraph'),
                                'text': t,
                                'text_tag': f"<paragraph>{t}</paragraph>",
                            })
                    # Recurse other values
                    for v in node.values():
                        _recurse(v)
            _recurse(obj)
            return segments

        layout = _extract_layout(data)
        if layout is None:
            # Attempt synthesis from text blob keys first
            synthesized: List[Dict[str, Any]] = []
            text_blob = None
            if isinstance(data, dict):
                for candidate in ('text', 'content', 'raw', 'body', 'value'):  # added 'value'
                    if isinstance(data.get(candidate), str) and data.get(candidate).strip():
                        text_blob = data.get(candidate)
                        break
            if text_blob:
                for line in text_blob.splitlines():
                    line_stripped = line.strip()
                    if not line_stripped:
                        continue
                    synthesized.append({
                        'type': 'paragraph',
                        'text': line_stripped,
                        'text_tag': f"<paragraph>{line_stripped}</paragraph>",
                    })
                layout = synthesized
            else:
                # Ultimate fallback: recurse entire JSON collecting string leaves.
                layout = _synthesize_layout_from_any(data)
            if isinstance(data, dict) and 'layout' not in data:
                data['layout'] = layout
            if not layout:
                raise ValueError("layout.json missing 'layout' array and no extractable textual content found")

        cleaned_lines: List[str] = []  # retained for potential future metrics; no file output
        changed_any = False

        # Determine if PII masking is enabled for per-segment processing
        pii_value = filters_config.get("PII")
        pii_enabled = is_filter_enabled(pii_value)
        pii_cfg = pii_value if isinstance(pii_value, dict) else {}
        # Compute mask_types
        mask_types_value = pii_cfg.get("mask_types") if isinstance(pii_cfg, dict) else None
        if isinstance(mask_types_value, str):
            mask_types_list = [t.strip() for t in mask_types_value.split(",") if t.strip()]
        elif isinstance(mask_types_value, list):
            mask_types_list = mask_types_value
        else:
            env_mt = os.getenv("PII_MASK_TYPES", "all")
            mask_types_list = [t.strip() for t in env_mt.split(",") if t.strip()] or ["all"]
        custom_patterns = pii_cfg.get("custom_patterns") if isinstance(pii_cfg, dict) else None
        mask_with = pii_cfg.get("mask_with") if isinstance(pii_cfg, dict) else None
        mask_style = pii_cfg.get("mask_style", os.getenv("PII_MASK_STYLE", "replace")) if isinstance(pii_cfg, dict) else os.getenv("PII_MASK_STYLE", "replace")

        for seg in layout:
            ttag = seg.get('text_tag')
            if not isinstance(ttag, str) or not ttag.strip():
                # Try to synthesize a minimal tag wrapper from type + text
                s_type = str(seg.get('type', 'paragraph')).lower()
                raw = seg.get('text') or ''
                if s_type == 'table':
                    inner = str(raw)
                    ttag = f"<table>{inner}</table>"
                elif s_type == 'heading':
                    ttag = f"<heading>{str(raw)}</heading>"
                else:
                    ttag = f"<paragraph>{str(raw)}</paragraph>"

            o, inner, c = _split_outer_tag(ttag)
            if o is None:
                # Not a recognized tag; treat the whole as text and apply generic filters
                new_tag_text = ttag
                if is_filter_enabled(filters_config.get("WhitespaceRemove")):
                    try:
                        new_tag_text = filter_whitespace_normalize(new_tag_text)
                    except Exception:
                        pass
                if is_filter_enabled(filters_config.get("RemovePageNumbers")):
                    try:
                        new_tag_text = filter_remove_page_numbers(new_tag_text)
                    except Exception:
                        pass
                if is_filter_enabled(filters_config.get("ConvertToLowercase")):
                    try:
                        new_tag_text = filter_convert_to_lowercase(new_tag_text)
                    except Exception:
                        pass
                # Apply PII to the entire text if enabled (no structured tag)
                if pii_enabled and _mask_pii_function is not None:
                    try:
                        pii_res = _mask_pii_function(
                            text=new_tag_text,
                            mask_types=mask_types_list,
                            custom_patterns=custom_patterns,
                            mask_with=mask_with,
                            mask_style=mask_style,
                        )
                        new_tag_text = pii_res.get("masked_text", new_tag_text)
                    except Exception as pe:
                        logger.warning(f"Per-segment PII masking (unstructured) failed: {pe}")
                if new_tag_text != ttag:
                    changed_any = True
                seg['text_tag'] = new_tag_text
                # Keep plain text in sync (strip outer tag if it exists)
                o2, inner2, c2 = _split_outer_tag(new_tag_text)
                seg['text'] = (inner2 if inner2 is not None else new_tag_text)
                cleaned_lines.append(new_tag_text.strip())
            else:
                updated = _apply_filters_to_tag_text(o, inner or "", c, filters_config)
                # If PII is enabled, and not a table, apply PII to inner text only
                if pii_enabled and not o.lower().startswith("<table") and _mask_pii_function is not None:
                    try:
                        pii_res = _mask_pii_function(
                            text=(inner or ""),
                            mask_types=mask_types_list,
                            custom_patterns=custom_patterns,
                            mask_with=mask_with,
                            mask_style=mask_style,
                        )
                        masked_inner = pii_res.get("masked_text", inner or "")
                        if masked_inner != (inner or ""):
                            # Rebuild with same open/close tags
                            updated = o + masked_inner + c
                    except Exception as pe:
                        logger.warning(f"Per-segment PII masking failed: {pe}")
                if updated != ttag:
                    changed_any = True
                seg['text_tag'] = updated
                # Sync plain text field (for table keep original inner to avoid losing structure; else use masked/filtered inner)
                o3, inner3, c3 = _split_outer_tag(updated)
                if o3 and o3.lower().startswith('<table'):
                    # For tables: prefer original seg['text'] if non-empty else inner3 (raw HTML). Do not lowercase table inner text further.
                    if not seg.get('text'):
                        seg['text'] = inner3 or ''
                else:
                    seg['text'] = inner3 if inner3 is not None else updated
                cleaned_lines.append(updated.strip())

        # Record which filters were actually configured as enabled
        for fname in ("WhitespaceRemove", "RemovePageNumbers", "ConvertToLowercase"):
            if is_filter_enabled(filters_config.get(fname)):
                applied_filters.append(fname)
        if pii_enabled:
            applied_filters.append("PII")

        # In-place update: write back to the same JSON file only
        with open(json_path, 'w', encoding='utf-8') as jh:
            json.dump(data, jh, ensure_ascii=False, indent=2)
        return json_path, None, applied_filters
    except Exception as e:
        # Surface the original exception upstream; retaining stack in Celery logs.
        raise


def process_parser_output_json(json_path: str, filters_config: Dict[str, Any]) -> Tuple[str, List[str]]:
    """Process a canonical *.parser_output.json file in place.

    Expected schema:
      {"parser_output": [{"type": "paragraph|heading|table", "text": "..." , ...}, ...]}

    Behavior:
    - Applies WhitespaceRemove / RemovePageNumbers / ConvertToLowercase to element['text'].
    - Preserves table HTML: if element['type'] == 'table' or text looks like <table...>, do not mutate.
    - If PII is enabled, masks non-table element['text'].
    """
    applied_filters: List[str] = []
    with open(json_path, 'r', encoding='utf-8', errors='ignore') as fh:
        data = json.load(fh)

    items = None
    if isinstance(data, dict) and isinstance(data.get('parser_output'), list):
        items = data.get('parser_output')
    if items is None:
        raise ValueError("parser_output.json missing 'parser_output' list")

    pii_value = filters_config.get("PII")
    pii_enabled = is_filter_enabled(pii_value)
    pii_cfg = pii_value if isinstance(pii_value, dict) else {}

    mask_types_value = pii_cfg.get("mask_types") if isinstance(pii_cfg, dict) else None
    if isinstance(mask_types_value, str):
        mask_types_list = [t.strip() for t in mask_types_value.split(",") if t.strip()]
    elif isinstance(mask_types_value, list):
        mask_types_list = mask_types_value
    else:
        env_mt = os.getenv("PII_MASK_TYPES", "all")
        mask_types_list = [t.strip() for t in env_mt.split(",") if t.strip()] or ["all"]
    custom_patterns = pii_cfg.get("custom_patterns") if isinstance(pii_cfg, dict) else None
    mask_with = pii_cfg.get("mask_with") if isinstance(pii_cfg, dict) else None
    mask_style = pii_cfg.get("mask_style", os.getenv("PII_MASK_STYLE", "replace")) if isinstance(pii_cfg, dict) else os.getenv("PII_MASK_STYLE", "replace")

    changed_any = False
    for el in items:
        if not isinstance(el, dict):
            continue
        raw_text = el.get('text')
        if not isinstance(raw_text, str) or not raw_text.strip():
            continue

        el_type = str(el.get('type') or '').strip().lower()
        looks_like_table = raw_text.lstrip().lower().startswith('<table')
        is_table = el_type == 'table' or looks_like_table
        if is_table:
            continue

        text_val = raw_text
        if is_filter_enabled(filters_config.get("WhitespaceRemove")):
            try:
                text_val = filter_whitespace_normalize(text_val)
            except Exception:
                pass
        if is_filter_enabled(filters_config.get("RemovePageNumbers")):
            try:
                text_val = filter_remove_page_numbers(text_val)
            except Exception:
                pass
        if is_filter_enabled(filters_config.get("ConvertToLowercase")):
            try:
                text_val = filter_convert_to_lowercase(text_val)
            except Exception:
                pass

        if pii_enabled and _mask_pii_function is not None:
            try:
                pii_res = _mask_pii_function(
                    text=text_val,
                    mask_types=mask_types_list,
                    custom_patterns=custom_patterns,
                    mask_with=mask_with,
                    mask_style=mask_style,
                )
                text_val = pii_res.get('masked_text', text_val)
            except Exception as pe:
                logger.warning(f"PII masking failed for element_id={el.get('element_id')}: {pe}")

        if text_val != raw_text:
            el['text'] = text_val
            changed_any = True

    for fname in ("WhitespaceRemove", "RemovePageNumbers", "ConvertToLowercase"):
        if is_filter_enabled(filters_config.get(fname)):
            applied_filters.append(fname)
    if pii_enabled:
        applied_filters.append("PII")

    if changed_any:
        with open(json_path, 'w', encoding='utf-8') as jh:
            json.dump(data, jh, ensure_ascii=False, indent=2)
    return json_path, applied_filters


def post_task_results(
    task_id: str,
    status: str,
    dag_id: str,
    run_id: str,
    folder_id: str,
    applied_filters: Optional[List[str]] = None,
    pii_info: Optional[Dict[str, Any]] = None,
    error_message: Optional[str] = None,
):
    """Post the worker results JSON back to the API gateway WORKER_RESULTS_URL.
    This is a small helper to centralize the callback logic used by workers.
    """
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id,
        "job_id": run_id,
        "folder_id": folder_id,
    }
    if applied_filters:
        payload["applied_filters"] = applied_filters
    if pii_info:
        payload["pii_detection"] = {
            "method": pii_info.get("method"),
            "total_found": pii_info.get("total_found", 0),
            "by_type": pii_info.get("by_type", {}),
            "mask_types_used": pii_info.get("mask_types_used", []),
        }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting results to {WORKER_RESULTS_URL}")
        logger.debug(f"Payload: {payload}")
        response = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if response.status_code >= 300:
            logger.error(
                f"Results callback returned HTTP {response.status_code}: {response.text}"
            )
        else:
            logger.info("Results posted successfully")
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to POST worker results: {e}")


# ============================================================================
# CELERY TASK
# ============================================================================


@celery_app.task(name="textprocessing_worker.textprocessing_task")
def textprocessing_task(
    task_id: str,
    folder_id: str,
    dag_id: str,
    run_id: str,
    text_processing_config: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Apply text processing filters to text file and post results.
    
    This task:
    1. Locates the first .txt file in the specified folder
    2. Applies configured text processing filters in order
    3. Writes the processed text back to the file (for non-PII filters)
    4. For PII filter, mask_pii handles file read/write
    5. Posts results to the callback URL
    
    Configuration Examples:
    
    Example 1 - Simple (use defaults):
    {
        "Filters": {
            "PII": "True",
            "WhitespaceRemove": "True",
            "RemovePageNumbers": "True",
            "ConvertToLowercase": "True"
        }
    }
    
    Example 2 - Advanced PII config:
    {
        "Filters": {
            "WhitespaceRemove": "True",
            "RemovePageNumbers": "True",
            "PII": {
                "mask_types": ["email", "phone", "ssn"],
                "custom_patterns": {
                    "EMPLOYEE_ID": "EMP-\\d{6}",
                    "CASE_NUMBER": "CASE-\\d{8}"
                },
                "mask_with": {
                    "email": "[EMAIL_REDACTED]",
                    "phone": "[PHONE_REDACTED]"
                },
                "mask_style": "replace"
            }
        }
    }
    
    Example 3 - All PII types with custom style:
    {
        "Filters": {
            "WhitespaceRemove": "True",
            "PII": {
                "mask_types": ["all"],
                "mask_style": "hash"
            }
        }
    }
    
    Args:
        task_id: Unique task identifier
        folder_id: Folder UUID or absolute/UNC path
        dag_id: DAG/process name from upstream
        run_id: Run/job identifier from upstream
        text_processing_config: Configuration dict with 'Filters' key
        
    Returns:
        Dict with task execution details
    """
    status = "failed"
    error_message = None
    applied_filters = []
    pii_info = None
    
    logger.info(f"Starting text processing task {task_id}")
    logger.info(f"DATA_BACKBONE_DIR={DATA_BACKBONE_DIR}, folder_id={folder_id}")
    
    try:
        # Resolve folder path
        folder_path = resolve_folder_path(folder_id)
        logger.debug(f"Resolved folder path: {folder_path}")

        # Extract filter configuration
        config = text_processing_config if isinstance(text_processing_config, dict) else {}
        filters_config = config.get("Filters") or config.get("filters") or {}
        
        if not isinstance(filters_config, dict):
            logger.warning("Invalid filters configuration, skipping all filters")
            filters_config = {}
        dag_lower = (dag_id or "").strip().lower()
        run_lower = (run_id or "").strip().lower()
        is_runtime = dag_lower in ("runtimetextprocessing", "runtimetesting") or run_lower in ("runtimetextprocessing", "runtimetesting")

        if is_runtime:
            # Runtime textprocessing: accept any JSON file (not only *.parser_output.json)
            json_path = find_any_json_file(folder_path)
            if not json_path:
                raise ValueError(f"No .json file found in folder for runtime textprocessing: {folder_path}")

            logger.info(f"Runtime textprocessing: using JSON file {json_path} for in-place filtering")
            updated_json_path, _, applied_filters = process_layout_json(folder_path, json_path, filters_config)
            logger.info(f"Updated runtime JSON in place: {updated_json_path}")

            status = "success"
            post_task_results(
                task_id=task_id,
                status=status,
                dag_id=dag_id,
                run_id=run_id,
                folder_id=folder_id,
                applied_filters=applied_filters,
                pii_info=None,
                error_message=None,
            )
            return {
                "task_id": task_id,
                "status": status,
                "folder_id": folder_id,
                "job_id": run_id,
                "applied_filters": applied_filters,
                "pii_detection": None,
                "error": None,
                "updated_json": updated_json_path,
            }

        # Non-runtime: only process canonical parser output JSON (no layout/txt fallback)
        parser_json_path = find_parser_output_json_file(folder_path)
        if not parser_json_path:
            raise ValueError(f"No .parser_output.json file found in folder: {folder_path}")

        logger.info(f"Found parser output JSON: {parser_json_path}; applying filters to parser_output[].text (in-place)")
        updated_json_path, applied_filters = process_parser_output_json(parser_json_path, filters_config)
        logger.info(f"Updated parser output JSON in place: {updated_json_path}")

        status = "success"
        post_task_results(
            task_id=task_id,
            status=status,
            dag_id=dag_id,
            run_id=run_id,
            folder_id=folder_id,
            applied_filters=applied_filters,
            pii_info=None,
            error_message=None,
        )
        return {
            "task_id": task_id,
            "status": status,
            "folder_id": folder_id,
            "job_id": run_id,
            "applied_filters": applied_filters,
            "pii_detection": None,
            "error": None,
            "updated_parser_output_json": updated_json_path,
        }

        # Check if PII filter will be applied
        pii_config_value = filters_config.get("PII")
        will_apply_pii = is_filter_enabled(pii_config_value)
        
        # Apply non-PII filters first (read, process, write)
        # Only if we have non-PII filters to apply OR if PII is disabled
        if (is_filter_enabled(filters_config.get("WhitespaceRemove")) or
            is_filter_enabled(filters_config.get("RemovePageNumbers")) or
            is_filter_enabled(filters_config.get("ConvertToLowercase")) or
            not will_apply_pii):
            
            # Read text file
            with open(txt_path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
            
            original_length = len(text)
            logger.debug(f"Original text length: {original_length} characters")
            
            # 1. Whitespace normalization
            if is_filter_enabled(filters_config.get("WhitespaceRemove")):
                try:
                    text = filter_whitespace_normalize(text)
                    applied_filters.append("WhitespaceRemove")
                    logger.debug("Applied WhitespaceRemove filter")
                except Exception as e:
                    logger.warning(f"WhitespaceRemove filter failed: {e}")
            
            # 2. Remove page numbers
            if is_filter_enabled(filters_config.get("RemovePageNumbers")):
                try:
                    text = filter_remove_page_numbers(text)
                    applied_filters.append("RemovePageNumbers")
                    logger.debug("Applied RemovePageNumbers filter")
                except Exception as e:
                    logger.warning(f"RemovePageNumbers filter failed: {e}")
            
            # 3. Convert to lowercase
            if is_filter_enabled(filters_config.get("ConvertToLowercase")):
                try:
                    text = filter_convert_to_lowercase(text)
                    applied_filters.append("ConvertToLowercase")
                    logger.debug("Applied ConvertToLowercase filter")
                except Exception as e:
                    logger.warning(f"ConvertToLowercase filter failed: {e}")
            
            # Write processed text back to file (only if we made changes)
            if applied_filters:
                with open(txt_path, "w", encoding="utf-8") as f:
                    f.write(text)
                processed_length = len(text)
                logger.info(
                    f"Text filters applied: {applied_filters}. "
                    f"Length: {original_length} -> {processed_length}"
                )
        
        # 4. PII redaction (applied last, handles its own file I/O)
        if will_apply_pii:
            # Extract PII-specific configuration if provided as dict
            pii_config = {}
            if isinstance(pii_config_value, dict):
                pii_config = pii_config_value
            
            pii_info = filter_pii(txt_path, pii_config)
            applied_filters.append("PII")
            logger.debug("Applied PII redaction filter")
        
        # Finalize success if no exception occurred
        logger.info(f"Text processing complete. Applied filters: {applied_filters}")
        status = "success"
    except Exception as e:
        error_message = str(e)
        logger.error(f"Text processing task failed: {error_message}", exc_info=True)
    
    # Post results to callback URL
    post_task_results(
        task_id=task_id,
        status=status,
        dag_id=dag_id,
        run_id=run_id,
        folder_id=folder_id,
        applied_filters=applied_filters,
        pii_info=pii_info,
        error_message=error_message,
    )
    
    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "applied_filters": applied_filters,
        "pii_detection": pii_info,
        "error": error_message,
    }
