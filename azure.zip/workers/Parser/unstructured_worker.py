import os
import requests
import json
import re
from pathlib import Path
from html import escape as _html_escape
from datetime import datetime
from celery import Celery
from kombu import Queue, Exchange
import logging
from typing import Optional, Any, Dict, List, Tuple
from config import settings

import fitz
try:
    from PIL import Image
except Exception:
    Image = None  # type: ignore

logger = logging.getLogger("unstructured_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(fmt)
    logger.addHandler(handler)

# Shared validated configuration (env first, then .env fallback)
BROKER_URL = settings.broker_url
RESULT_BACKEND = settings.result_backend
DATA_BACKBONE_DIR = settings.data_backbone_dir
LOG_LEVEL = settings.parser_log_level.upper()
WORKER_RESULTS_URL = settings.worker_results_url
PARSER_QUEUES = settings.parser_queues
UNSTRUCTURED_API_URL = settings.unstructured_api_url

try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:
    logger.setLevel(logging.INFO)

# Celery app
celery_app = Celery(
    'unstructured_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

queue_names = [q.strip() for q in PARSER_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("PARSER_QUEUES must specify at least one queue name (e.g. 'unstructured')")
celery_app.conf.task_queues = tuple(
    Queue(name, Exchange(name, type="direct"), routing_key=name) for name in queue_names
)
celery_app.conf.task_default_queue = queue_names[0]
celery_app.conf.broker_connection_retry_on_startup = True


def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\\\") or p.startswith("//"))


_TIFF_PAGE_RE = re.compile(r"_page_(\d{1,6})\.tiff$", flags=re.IGNORECASE)


def _page_num_from_tiff_name(name: str) -> Optional[int]:
    if not isinstance(name, str):
        return None
    m = _TIFF_PAGE_RE.search(name)
    if not m:
        return None
    try:
        n = int(m.group(1))
        return n if n > 0 else None
    except Exception:
        return None


def _render_page_to_tiff(page, dpi: int = 300):
    if Image is None:
        raise RuntimeError("PDF->TIFF conversion requires Pillow (PIL). Install: pip install pillow")
    scale = dpi / 72.0
    mat = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    mode = "RGB" if pix.n >= 3 else "L"
    return Image.frombytes(mode, [pix.width, pix.height], pix.samples)


def _pdf_to_tiffs(pdf_path: str, out_dir: str, dpi: int = 300, compression: str = "tiff_lzw") -> List[str]:
    os.makedirs(out_dir, exist_ok=True)
    tiff_paths: List[str] = []
    stem = Path(pdf_path).stem
    with fitz.open(pdf_path) as doc:
        for i, page in enumerate(doc, start=1):
            img = _render_page_to_tiff(page, dpi=dpi)
            out_path = os.path.join(out_dir, f"{stem}_page_{i:03d}.tiff")
            try:
                img.save(out_path, format="TIFF", compression=compression)
            except Exception:
                img.save(out_path, format="TIFF")
            tiff_paths.append(out_path)
    return tiff_paths


def _normalize_bbox(b: Any) -> Optional[Tuple[float, float, float, float]]:
    if not b:
        return None
    try:
        if isinstance(b, (list, tuple)) and len(b) == 4:
            return (float(b[0]), float(b[1]), float(b[2]), float(b[3]))
        if isinstance(b, dict):
            # Common forms: {"x1":..,"y1":..,"x2":..,"y2":..} or {"x":..,"y":..,"w":..,"h":..}
            if all(k in b for k in ("x1", "y1", "x2", "y2")):
                return (float(b["x1"]), float(b["y1"]), float(b["x2"]), float(b["y2"]))
            if all(k in b for k in ("x", "y", "w", "h")):
                x1 = float(b["x"])
                y1 = float(b["y"])
                return (x1, y1, x1 + float(b["w"]), y1 + float(b["h"]))
    except Exception:
        return None
    return None


def _collapse_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def _score_table_html(html: str) -> Tuple[int, int, int]:
    """Heuristic score for table HTML: prefer more non-empty td cells, then total td count, then length."""
    h = html or ""
    td_contents = re.findall(r"<td\b[^>]*>(.*?)</td>", h, flags=re.IGNORECASE | re.DOTALL)
    non_empty = 0
    for c in td_contents:
        txt = re.sub(r"<[^>]+>", " ", c)
        if _collapse_ws(txt):
            non_empty += 1
    return (non_empty, len(td_contents), len(h))


def _best_table_html(meta: Dict[str, Any]) -> Optional[str]:
    candidates: List[str] = []
    for k in ("text_as_html", "table_as_html", "table_html", "html", "text_as_table"):
        v = meta.get(k)
        if isinstance(v, str) and v.strip() and "<table" in v.lower():
            candidates.append(v.strip())
    if not candidates:
        return None
    candidates.sort(key=_score_table_html, reverse=True)
    return candidates[0]


def _maybe_rebuild_table_from_text(text: str) -> str:
    """Build a simple td/tr table from whitespace-separated columns (fallback when HTML is too sparse)."""
    raw = (text or "").strip()
    if not raw:
        return "<table></table>"

    tokens = raw.split()
    if len(tokens) < 6:
        return f"<table><tbody><tr><td>{_html_escape(raw)}</td></tr></tbody></table>"

    # Heuristic: first token run until we see a known header marker; then treat remaining as rows.
    # We keep it conservative: just make a single header row if we can spot it.
    header_markers = {"monthly", "annual", "usd"}
    header_start = None
    for i, t in enumerate(tokens):
        if t.lower().strip("()") in header_markers:
            header_start = max(0, i - 1)
            break

    if header_start is None or header_start == 0:
        # No obvious header; single column rows split by two+ spaces is not possible here.
        return f"<table><tbody><tr><td>{_html_escape(raw)}</td></tr></tbody></table>"

    # Build a 3-col table: Description | Monthly | Annual, and keep any trailing words in Description.
    html = ["<table><thead><tr><th>Description</th><th>Monthly</th><th>Annual</th></tr></thead><tbody>"]

    # Very rough row parsing: look for number-like tokens as column separators.
    row: List[str] = []
    rows: List[List[str]] = []
    for t in tokens:
        row.append(t)
        # Use 'Remarks' as a hard stop if present; everything after becomes a trailing note row.
        if t.lower() == "remarks":
            break
    # After header, parse chunks into rows by recognizing two numeric fields.
    remaining = tokens[len(row):]
    cur_desc: List[str] = []
    nums: List[str] = []
    for t in remaining:
        if re.fullmatch(r"[0-9][0-9,]*", t):
            nums.append(t)
            if len(nums) == 2:
                rows.append([" ".join(cur_desc).strip(), nums[0], nums[1]])
                cur_desc = []
                nums = []
            continue
        cur_desc.append(t)

    for r in rows:
        html.append(
            "<tr>"
            + f"<td>{_html_escape(r[0])}</td>"
            + f"<td>{_html_escape(r[1])}</td>"
            + f"<td>{_html_escape(r[2])}</td>"
            + "</tr>"
        )
    html.append("</tbody></table>")
    return "".join(html)


def _element_to_segment(el: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Map Unstructured element JSON into a MinerU-like segment dict."""
    if not isinstance(el, dict):
        return None
    txt = el.get("text")
    if not isinstance(txt, str):
        txt = "" if txt is None else str(txt)
    txt = txt.strip()

    el_type = str(el.get("type") or "").strip().lower()
    meta = el.get("metadata") if isinstance(el.get("metadata"), dict) else {}
    page = meta.get("page_number") or meta.get("page")
    try:
        page = int(page) if page is not None else 1
    except Exception:
        page = 1

    bbox = _normalize_bbox(meta.get("bbox") or meta.get("coordinates") or meta.get("points"))

    seg_type = "paragraph"
    if el_type in {"title", "header", "heading"}:
        seg_type = "heading"
    elif el_type in {"narrativetext", "text", "paragraph", "listitem", "figurecaption"}:
        seg_type = "paragraph"
    elif el_type in {"table"}:
        seg_type = "table"
    elif el_type in {"image", "figure"}:
        # ignore images for now (no table HTML to preserve)
        return None

    # Prefer Unstructured-provided HTML for tables so td/tr structure is preserved.
    # Different deployments use different keys; we try a few common ones.
    if seg_type == "table":
        html_candidate = _best_table_html(meta)
        if html_candidate:
            # If the best candidate is still too sparse, rebuild a basic td/tr table from plain text.
            non_empty, total, _ln = _score_table_html(html_candidate)
            if total > 0 and non_empty == 0 and txt:
                txt = _maybe_rebuild_table_from_text(txt)
            else:
                txt = html_candidate

    # For non-table elements (or table fallback), require some text.
    if not isinstance(txt, str):
        txt = "" if txt is None else str(txt)
    txt = txt.strip()
    if not txt:
        return None

    return {
        "type": seg_type,
        "page": page,
        "bbox": bbox,
        "text": txt,
    }


def _segment_to_tag(seg: Dict[str, Any]) -> str:
    """Render a segment into <heading>/<paragraph>/<table> tagged line with page/bbox attrs."""
    s_type = seg.get("type") or "paragraph"
    page = seg.get("page")
    bbox = seg.get("bbox")
    attrs: List[str] = []
    if page is not None:
        attrs.append(f'page="{page}"')
    if bbox:
        try:
            bb = tuple(bbox)
            attrs.append(f'bbox="{bb[0]},{bb[1]},{bb[2]},{bb[3]}"')
        except Exception:
            pass
    attr_str = (" " + " ".join(attrs)) if attrs else ""

    raw = seg.get("text") or ""
    if s_type == "table":
        raw_s = str(raw)
        if "<table" in raw_s.lower():
            # inject attrs into the first <table ...>
            def _repl(m: re.Match) -> str:
                open_tag = m.group(0)
                if attr_str.strip() and open_tag.endswith(">"):
                    return open_tag[:-1] + " " + attr_str.strip() + ">"
                return open_tag
            injected = re.sub(r"<table\b[^>]*>", _repl, raw_s, count=1, flags=re.IGNORECASE)
            return injected
        inner = raw_s if ("<" in raw_s and ">" in raw_s) else _html_escape(raw_s)
        return f"<table{attr_str}>" + inner + "</table>"
    if s_type == "heading":
        return f"<heading{attr_str}>" + _html_escape(raw) + "</heading>"
    return f"<paragraph{attr_str}>" + _html_escape(raw) + "</paragraph>"


def _save_layout_json_only(segments: List[Dict[str, Any]], input_pdf_path: str) -> str:
    base = Path(input_pdf_path).stem
    out_dir = Path(input_pdf_path).parent
    json_path = out_dir / f"{base}.layout.json"

    pages: Dict[int, List[Dict[str, Any]]] = {}
    for seg in segments:
        try:
            pn = int(seg.get("page") or 1)
        except Exception:
            pn = 1
        pages.setdefault(pn, []).append(seg)

    payload = {
        "pages": [
            {"page_number": pn, "layout": pages[pn]}
            for pn in sorted(pages.keys())
        ]
    }

    with open(json_path, "w", encoding="utf-8") as jf:
        json.dump(payload, jf, ensure_ascii=False, indent=2)

    return str(json_path)


@celery_app.task(name="unstructured_worker.unstructured_task")
def unstructured_task(task_id, folder_id, parser_config, dag_id, run_id):
    """Process first PDF in folder using Unstructured API and report results.

    Signature: (task_id, folder_id, parser_config, dag_id, run_id)
    Returns similar structure to paddle_worker (output_file path, folders list, error)
    """
    status = "failed"
    error_message = None
    folders = []
    text_path = None
    legacy_jsonl_paths: List[str] = []
    legacy_layout_json_paths: List[str] = []
    normalized_expected_paths: List[str] = []

    try:
        if not isinstance(parser_config, dict):
            raise ValueError("parser_config must be a JSON object/dict")
        parser_name = str(parser_config.get("ParserName", "")).strip().lower()
        if parser_name not in {"unstructured", "unstructured_api"}:
            raise ValueError("ParserName must be 'unstructured' or 'unstructured_api'")

        # Resolve folder path
        if _is_abs_or_unc(folder_id):
            folder_path = folder_id
        else:
            folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
        if not os.path.isdir(folder_path):
            raise ValueError(f"Folder not found: {folder_path}")

        files = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
        if not files:
            raise ValueError(f"No PDF found in folder: {folder_path}")

        file_path = os.path.join(folder_path, files[0])

        # Convert PDF -> TIFF pages in-place (match MinerU defaults: dpi=300, compression=tiff_lzw)
        tiff_dpi = 300
        tiff_compression = "tiff_lzw"
        logger.info("Converting PDF to TIFFs in-place: %s (dpi=%s)", file_path, tiff_dpi)
        tiff_paths = _pdf_to_tiffs(file_path, folder_path, dpi=tiff_dpi, compression=tiff_compression)
        if not tiff_paths:
            raise RuntimeError(f"No TIFFs produced for PDF: {file_path}")

        elements: List[Dict[str, Any]] = []
        try:
            # form fields: strategy, default (auto), output_format
            # Normalize strategy to values expected by the Unstructured API.
            # Allowed: 'fast', 'hi_res', 'auto', 'ocr_only'
            raw_strategy = parser_config.get('strategy', 'hi_res')
            try:
                raw_strategy = str(raw_strategy)
            except Exception:
                raw_strategy = ''
            rs = raw_strategy.strip().lower()
            allowed = {'fast', 'hi_res', 'auto', 'ocr_only'}
            synonyms = {
                'text': 'auto',
                'plain': 'auto',
                'ocr': 'ocr_only',
                'hires': 'hi_res',
                'high_res': 'hi_res',
            }
            strategy = rs if rs in allowed else synonyms.get(rs)
            if not strategy:
                logger.warning("Unrecognized strategy '%s' — falling back to 'hi_res'", raw_strategy)
                strategy = 'hi_res'

            data = {
                'strategy': strategy,
                'default': parser_config.get('default', 'auto'),
                'output_format': parser_config.get('output_format', 'application/json'),
            }
            headers = {'accept': 'application/json'}

            for page_idx, tiff_path in enumerate(tiff_paths, start=1):
                filename = os.path.basename(tiff_path)
                # MinerU-style: derive page number from TIFF filename
                page_num = _page_num_from_tiff_name(filename) or page_idx
                with open(tiff_path, 'rb') as fh:
                    files_payload = {'files': (filename, fh, 'image/tiff')}
                    logger.info(
                        "Posting file '%s' to Unstructured API %s with data=%s",
                        filename,
                        UNSTRUCTURED_API_URL,
                        {k: data[k] for k in data},
                    )
                    resp = requests.post(UNSTRUCTURED_API_URL, headers=headers, files=files_payload, data=data, timeout=120)

                # If the API returned an error, log the body (json or text) to make 422s actionable
                if resp.status_code >= 400:
                    try:
                        err_body = resp.json()
                    except Exception:
                        err_body = resp.text
                    logger.error("Unstructured API returned HTTP %s: %s", resp.status_code, err_body)
                    # Raise to be handled by the outer exception handler and included in worker result
                    resp.raise_for_status()

                j = resp.json()

                # Expected: Unstructured returns a list of element dicts
                if isinstance(j, list):
                    for item in j:
                        if isinstance(item, dict):
                            el = dict(item)
                            meta = el.get("metadata") if isinstance(el.get("metadata"), dict) else {}
                            # Always override page_number from TIFF filename/order (MinerU-style)
                            meta["page_number"] = page_num
                            meta.setdefault("filename", os.path.basename(file_path))
                            el["metadata"] = meta
                            elements.append(el)
                        else:
                            elements.append({"type": "NarrativeText", "text": str(item), "metadata": {"page_number": page_num, "filename": os.path.basename(file_path)}})
                elif isinstance(j, dict) and "elements" in j and isinstance(j["elements"], list):
                    for item in j["elements"]:
                        if isinstance(item, dict):
                            el = dict(item)
                            meta = el.get("metadata") if isinstance(el.get("metadata"), dict) else {}
                            # Always override page_number from TIFF filename/order (MinerU-style)
                            meta["page_number"] = page_num
                            meta.setdefault("filename", os.path.basename(file_path))
                            el["metadata"] = meta
                            elements.append(el)
                elif isinstance(j, dict) and 'text' in j:
                    elements.append({"type": "NarrativeText", "text": j.get("text") or "", "metadata": {"page_number": page_num, "filename": os.path.basename(file_path)}})
                else:
                    elements.append({"type": "NarrativeText", "text": json.dumps(j), "metadata": {"page_number": page_num, "filename": os.path.basename(file_path)}})
        except Exception as e:  # noqa: BLE001
            # If this was an HTTP-level error, try to capture the response body for diagnostics
            try:
                if isinstance(e, requests.HTTPError) and hasattr(e, 'response') and e.response is not None:
                    r = e.response
                    try:
                        body = r.json()
                    except Exception:
                        body = r.text
                    logger.error("Unstructured API HTTPError: status=%s body=%s", getattr(r, 'status_code', None), body)
            except Exception:
                # Best-effort only; don't hide original exception
                pass
            logger.error("Unstructured API call failed: %s", e, exc_info=True)
            raise

        # Track legacy raw elements JSONL path (we no longer write it)
        base_stem = os.path.splitext(files[0])[0]
        legacy_jsonl_paths.append(os.path.join(folder_path, base_stem + "_unstructured.jsonl"))

        segments: List[Dict[str, Any]] = []
        for el in elements:
            seg = _element_to_segment(el)
            if seg:
                segments.append(seg)

        # Write MinerU-like layout.json for backend normalization (do not write layout.txt)
        text_path = _save_layout_json_only(segments, file_path)
        # Track legacy layout.txt from older runs for cleanup
        legacy_layout_json_paths.append(os.path.join(folder_path, f"{Path(file_path).stem}.layout.txt"))
        normalized_expected_paths.append(os.path.join(folder_path, f"{Path(file_path).stem}.parser_output.json"))

        folders.append({'folder_id': folder_id, 'document_name': files[0]})
        status = 'success'

    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error('Exception in unstructured_task: %s', error_message, exc_info=True)

    # Report results back to API gateway
    payload = {
        'task_id': task_id,
        'status': status,
        'process_name': dag_id or '',
        'job_id': run_id,
        'folder_id': folder_id,
        'folders': folders,
    }
    if error_message:
        payload['error_message'] = error_message

    try:
        logger.info('Posting parser results to %s: %s', WORKER_RESULTS_URL, payload)
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error('parser worker-results callback returned HTTP %s: %s', resp.status_code, resp.text)
        else:
            # Best-effort cleanup: keep only normalized JSON from backend.
            # Remove legacy *_unstructured.jsonl if present from older runs.
            for p in legacy_jsonl_paths:
                try:
                    if os.path.exists(p):
                        os.remove(p)
                        logger.info("Deleted legacy artifact: %s", p)
                except Exception as rm_err:  # noqa: BLE001
                    logger.warning("Failed to delete legacy artifact %s: %s", p, rm_err)

            # Remove legacy layout.txt if present from older runs
            for p in legacy_layout_json_paths:
                try:
                    if os.path.exists(p):
                        os.remove(p)
                        logger.info("Deleted legacy artifact: %s", p)
                except Exception as rm_err:  # noqa: BLE001
                    logger.warning("Failed to delete legacy artifact %s: %s", p, rm_err)

            # Delete newly created layout.json only after normalized output exists
            wait_seconds = int(parser_config.get("wait_for_normalized_seconds", 60) or 60)
            poll_interval = float(parser_config.get("normalized_poll_interval", 1.0) or 1.0)
            deadline = datetime.now().timestamp() + max(0, wait_seconds)
            remaining = set(p for p in normalized_expected_paths if p)
            while remaining and datetime.now().timestamp() < deadline:
                remaining = set(p for p in remaining if not os.path.exists(p))
                if remaining:
                    import time as _time
                    _time.sleep(poll_interval)

            if remaining:
                logger.warning("Timed out waiting for normalized output; keeping layout.json")
            else:
                try:
                    if text_path and os.path.exists(text_path):
                        os.remove(text_path)
                        logger.info("Deleted layout.json after normalization: %s", text_path)
                except Exception as rm_err:  # noqa: BLE001
                    logger.warning("Failed to delete layout.json %s: %s", text_path, rm_err)
    except Exception as cb_err:  # noqa: BLE001
        logger.error('Failed to POST parser worker results: %s', cb_err, exc_info=True)

    return {
        'task_id': task_id,
        'status': status,
        'output_file': text_path if status == 'success' else None,
        'folders': folders,
        'error': error_message,
    }
