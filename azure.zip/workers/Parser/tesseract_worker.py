import os
import fitz
import requests
from tempfile import mkdtemp
from celery import Celery
from datetime import datetime
from kombu import Queue, Exchange  # NEW
import logging  # NEW
import uuid  # NEW
import json  # NEW
import time
import re
from pathlib import Path
from typing import Optional, List, Dict, Any
from config import settings

try:
    from PIL import Image
except Exception:
    Image = None  # type: ignore

# ---------------- Env & Logging -----------------
# Shared validated configuration (env first, then .env fallback)
BROKER_URL = settings.broker_url
RESULT_BACKEND = settings.result_backend
DATA_BACKBONE_DIR = settings.data_backbone_dir
LOG_LEVEL = settings.parser_log_level.upper()
WORKER_RESULTS_URL = settings.worker_results_url
PARSER_QUEUES = settings.parser_queues
OCR_API_URL = settings.ocr_api_url

logger = logging.getLogger("tesseract_worker")  # NEW
if not logger.handlers:  # NEW
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:  # noqa: BLE001
    logger.setLevel(logging.INFO)

# --------------- Celery App ----------------
celery_app = Celery(
    'parser_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

# Configure queues from env (comma-separated)  # NEW
queue_names = [q.strip() for q in PARSER_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("PARSER_QUEUES must specify at least one queue name (e.g. 'tesseract')")
celery_app.conf.task_queues = tuple(
    Queue(name, Exchange(name, type="direct"), routing_key=name) for name in queue_names
)
celery_app.conf.task_default_queue = queue_names[0]
celery_app.conf.broker_connection_retry_on_startup = True

# ---------------- Path helpers -----------------
def _is_abs_or_unc(p: str) -> bool:  # NEW
    return bool(p) and (os.path.isabs(p) or p.startswith("\\\\") or p.startswith("//"))


_TIFF_PAGE_RE = re.compile(r"_page_(\d{1,6})\.tiff$", flags=re.IGNORECASE)


def _page_num_from_tiff_name(name: str) -> Optional[int]:
    if not isinstance(name, str):
        return None
    m = _TIFF_PAGE_RE.search(name)
    if not m:
        return None
    try:
        n = int(m.group(1))
        return n if n > 0 else None
    except Exception:
        return None


def _save_layout_json_only(pages: List[Dict[str, Any]], input_pdf_path: str) -> str:
    base = Path(input_pdf_path).stem
    out_dir = Path(input_pdf_path).parent
    json_path = out_dir / f"{base}.layout.json"
    payload = {"pages": pages}
    with open(json_path, "w", encoding="utf-8") as jf:
        json.dump(payload, jf, ensure_ascii=False, indent=2)
    return str(json_path)


def _wait_for_normalized_output(folder_path: str, stem: str, timeout_s: int = 120, poll_s: float = 1.0) -> bool:
    target = os.path.join(folder_path, f"{stem}.parser_output.json")
    deadline = time.time() + max(1, int(timeout_s))
    while time.time() < deadline:
        if os.path.exists(target):
            return True
        time.sleep(poll_s)
    return os.path.exists(target)

# --------------- Task ----------------------
@celery_app.task(name="tesseract_worker.tesseract_task")  # CHANGED signature and behavior
def tesseract_task(task_id, folder_id, parser_config, dag_id, run_id):  # NEW signature
    """Run OCR using Tesseract for the first PDF in the folder and report results back.

    Args:
        task_id: UUID string of the task
        folder_id: either a UUID folder under DATA_BACKBONE_DIR or an absolute/UNC folder path
        parser_config: dict expected to contain ParserName == 'tesseract' (case-insensitive)
        dag_id: producer process name
        run_id: producer job id
    """
    status = "failed"
    error_message = None
    folders = []  # [{ folder_id, document_name }]
    layout_json_path = None
    legacy_txt_path = None
    legacy_json_path = None
    normalized_expected_path = None

    try:
        if not isinstance(parser_config, dict):
            raise ValueError("parser_config must be a JSON object/dict")
        parser_name = str(parser_config.get("ParserName", "")).strip().lower()
        if parser_name != "tesseract":
            raise ValueError("ParserName must be 'Tesseract'")

        # Resolve folder path
        if _is_abs_or_unc(folder_id):
            folder_path = folder_id
        else:
            folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
        if not os.path.isdir(folder_path):
            raise ValueError(f"Folder not found: {folder_path}")

        # Find PDF files
        files = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
        if not files:
            raise ValueError(f"No PDF found in folder: {folder_path}")

        file_path = os.path.join(folder_path, files[0])

        base_stem = os.path.splitext(files[0])[0]
        normalized_expected_path = os.path.join(folder_path, base_stem + ".parser_output.json")

        # OCR (PDF -> TIFF pages -> OCR) and write MinerU-like layout.json (no layout.txt)
        ocr_result = run_tesseract_parser(file_path, out_dir=folder_path)
        pages_out = ocr_result.get("pages") if isinstance(ocr_result, dict) else None
        if not isinstance(pages_out, list) or not pages_out:
            raise RuntimeError("Tesseract OCR returned no pages")

        # Convert OCR pages to MinerU-like layout segments
        # Backend normalization should prefer <stem>.layout.json when present.
        layout_pages: List[Dict[str, Any]] = []
        for idx, p in enumerate(pages_out, start=1):
            if not isinstance(p, dict):
                continue
            tiff_file = p.get("tiff_file")
            page_number = p.get("page_number")
            filename = str(tiff_file) if tiff_file is not None else ""
            # MinerU-style: derive page number from TIFF name if possible
            derived = _page_num_from_tiff_name(filename) or idx
            try:
                pn = int(derived if derived is not None else page_number)
            except Exception:
                pn = 1
            text = p.get("text")
            if not isinstance(text, str):
                text = "" if text is None else str(text)
            text = text.strip()
            if not text:
                continue
            layout_pages.append(
                {
                    "page_number": pn,
                    "layout": [
                        {
                            "type": "paragraph",
                            "page": pn,
                            "bbox": None,
                            "text": text,
                        }
                    ],
                }
            )

        if not layout_pages:
            raise RuntimeError("No non-empty OCR text found to write layout.json")

        layout_json_path = _save_layout_json_only(layout_pages, file_path)
        logger.info("Tesseract layout JSON saved to %s", layout_json_path)

        # Track legacy artifacts for cleanup (older runs)
        legacy_txt_path = os.path.join(folder_path, base_stem + ".txt")
        legacy_json_path = os.path.join(folder_path, base_stem + "_tesseract.json")

        # Prepare folders array (echo back the provided folder_id)
        folders.append({"folder_id": folder_id, "document_name": files[0]})
        status = "success"

    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error(f"Exception in tesseract_task: {error_message}", exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "folders": folders,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting parser results to {WORKER_RESULTS_URL}: {payload}")
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error(f"parser worker-results callback returned HTTP {resp.status_code}: {resp.text}")
        else:
            # Best-effort cleanup: delete intermediate artifacts after normalization exists.
            # Keep TIFFs (MinerU-like); delete layout.json and any legacy txt/json if present.
            try:
                if status == "success" and folders and os.path.isdir(folder_path):
                    stem = Path(files[0]).stem if files else (Path(file_path).stem if file_path else None)
                    if stem and _wait_for_normalized_output(folder_path, stem, timeout_s=120, poll_s=1.0):
                        if layout_json_path and os.path.exists(layout_json_path):
                            try:
                                os.remove(layout_json_path)
                                logger.info("Deleted intermediate layout.json after normalization: %s", layout_json_path)
                            except Exception as del_err:  # noqa: BLE001
                                logger.warning("Failed to delete layout.json '%s': %s", layout_json_path, del_err)

                        for legacy in (legacy_txt_path, legacy_json_path):
                            if legacy and os.path.exists(legacy):
                                try:
                                    os.remove(legacy)
                                    logger.info("Deleted legacy artifact after normalization: %s", legacy)
                                except Exception as del_err:  # noqa: BLE001
                                    logger.warning("Failed to delete legacy artifact '%s': %s", legacy, del_err)
            except Exception as cleanup_err:  # noqa: BLE001
                logger.warning("Post-normalization cleanup skipped due to error: %s", cleanup_err)
    except Exception as cb_err:  # noqa: BLE001
        logger.error(f"Failed to POST parser worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "output_file": layout_json_path,
        "output_json": layout_json_path,
        "folders": folders,
        "error": error_message,
    }


# --------------- OCR Logic -----------------
def _pixmap_to_tiff(pix: "fitz.Pixmap", out_path: str) -> None:
    """Save a PyMuPDF pixmap to TIFF. Prefers Pillow if available."""
    if Image is None:
        # Fallback: save as PNG but keep .tiff extension isn't correct; force requirement.
        raise RuntimeError("TIFF conversion requires Pillow. Install: pip install pillow")
    mode = "RGB" if pix.n >= 3 else "L"
    img = Image.frombytes(mode, [pix.width, pix.height], pix.samples)
    try:
        img.save(out_path, format="TIFF", compression="tiff_lzw")
    except Exception:
        img.save(out_path, format="TIFF")


def run_tesseract_parser(file_path: str, out_dir: Optional[str] = None) -> dict:
    extracted_text: list = []
    pages_out: list = []
    tiff_paths: list = []

    doc = fitz.open(file_path)
    # Write TIFFs into the runtime folder (MinerU-style) unless overridden.
    # This keeps artifacts visible for troubleshooting and allows filename-based page numbering.
    if out_dir is None:
        out_dir = str(Path(file_path).parent)
    os.makedirs(out_dir, exist_ok=True)

    # Match other workers (MinerU-like default). No user DPI knobs.
    dpi = 300
    scale = dpi / 72.0
    mat = fitz.Matrix(scale, scale)

    for page_num in range(len(doc)):
        page = doc[page_num]
        pix = page.get_pixmap(matrix=mat, alpha=False)
        # MinerU-style TIFF naming so page number can be derived reliably
        stem = Path(file_path).stem
        image_path = os.path.join(out_dir, f"{stem}_page_{page_num + 1:03d}.tiff")
        _pixmap_to_tiff(pix, image_path)
        tiff_paths.append(image_path)

    for i, image_path in enumerate(tiff_paths):
        page_no = i + 1
        logger.info(f"OCR on Page {page_no}: {image_path}")
        with open(image_path, "rb") as img_file:
            files = {"file": img_file}
            data = {"options": '{"languages":["eng"]}'}
            try:
                response = requests.post(OCR_API_URL, data=data, files=files, timeout=120)
                response.raise_for_status()
                ocr_text = response.json().get("data", {}).get("stdout", "").strip()
            except Exception as e:  # noqa: BLE001
                ocr_text = f"[ERROR] OCR failed for Page {page_no}: {e}"

        pages_out.append({"page_number": page_no, "tiff_file": os.path.basename(image_path), "text": ocr_text})
        if ocr_text:
            preview = ocr_text[:300].replace("\n", " ") + ("..." if len(ocr_text) > 300 else "")
            logger.info(f"Page {page_no} OCR Preview: {preview}")
            extracted_text.append(f"--- Page {page_no} ---\n{ocr_text}")
        else:
            logger.info(f"No text found on Page {page_no}")

    full_text = "\n\n".join(extracted_text)
    logger.info("OCR Complete. Combined Output (truncated):")
    logger.info(full_text[:1000] + ("..." if len(full_text) > 1000 else ""))

    return {
        "file": os.path.basename(file_path),
        "model": "tesseract_ocr_api",
        "page_count": len(pages_out),
        "pages": pages_out,
        "text": full_text,
    }
