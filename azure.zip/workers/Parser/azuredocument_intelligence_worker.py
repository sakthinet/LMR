import os
import json
import logging
from pathlib import Path
from html import escape as _html_escape

import requests
from celery import Celery
from kombu import Queue
from config import settings
try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None  # type: ignore
try:
    from PIL import Image  # Pillow
except Exception:
    Image = None  # type: ignore

try:
    from azure.core.credentials import AzureKeyCredential
    from azure.ai.documentintelligence import DocumentIntelligenceClient
    from azure.ai.documentintelligence.models import AnalyzeResult
except Exception:  # noqa: BLE001
    # The worker will surface a clear error if Azure SDK is missing at runtime
    AzureKeyCredential = None  # type: ignore
    DocumentIntelligenceClient = None  # type: ignore
    AnalyzeResult = None  # type: ignore


logger = logging.getLogger("azuredocument_intelligence_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(fmt)
    logger.addHandler(handler)
log_level = settings.parser_log_level.upper()
try:
    logger.setLevel(getattr(logging, log_level, logging.INFO))
except Exception:  # noqa: BLE001
    logger.setLevel(logging.INFO)

# Shared validated configuration (env first, then .env fallback)
BROKER_URL = settings.broker_url
RESULT_BACKEND = settings.result_backend
DATA_BACKBONE_DIR = settings.data_backbone_dir
WORKER_RESULTS_URL = settings.worker_results_url
PARSER_QUEUES = settings.parser_queues

# Azure DI specific settings
AZURE_DI_ENDPOINT = settings.azure_di_endpoint
AZURE_DI_KEY = settings.azure_di_key
AZURE_DI_MODEL = settings.azure_di_model

if not AZURE_DI_ENDPOINT:
    raise RuntimeError("AZURE_DI_ENDPOINT is required for azuredocument_intelligence_worker")
if not AZURE_DI_KEY:
    raise RuntimeError("AZURE_DI_KEY is required for azuredocument_intelligence_worker")


# Celery app
celery_app = Celery(
    "azuredocument_intelligence_worker",
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

queue_names = [q.strip() for q in PARSER_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("PARSER_QUEUES must specify at least one queue name (e.g. 'azuredocument_intelligence')")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]


def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\\\") or p.startswith("//"))


def _normalize_unc_using_backbone(folder_path: str) -> str:
    r"""Normalize UNC hostname to the host from DATA_BACKBONE_DIR when share matches.

    Example: \\AVDGENAIL18-3\DataBackBone\... -> \\10.73.88.101\DataBackBone\...
    """
    try:
        if not folder_path:
            return folder_path
        if not (folder_path.startswith('\\\\') or folder_path.startswith('//')):
            return folder_path

        # Extract remainder after host
        stripped = folder_path.lstrip('\\/')
        parts = stripped.split('\\', 1) if '\\' in stripped else stripped.split('/', 1)
        if not parts:
            return folder_path
        path_rest = parts[1] if len(parts) > 1 else ''

        # Extract host/share from DATA_BACKBONE_DIR
        bb = DATA_BACKBONE_DIR or ''
        bb_stripped = bb.lstrip('\\/')
        bb_parts = bb_stripped.split('\\', 1) if '\\' in bb_stripped else bb_stripped.split('/', 1)
        if not bb_parts:
            return folder_path
        bb_host = bb_parts[0]
        bb_rest = bb_parts[1] if len(bb_parts) > 1 else ''
        share_name = bb_rest.split('\\')[0].split('/')[0] if bb_rest else ''
        incoming_share = path_rest.split('\\')[0].split('/')[0] if path_rest else ''

        if share_name and incoming_share and incoming_share.lower() == share_name.lower():
            new_rest = path_rest
            return f"\\\\{bb_host}\\{new_rest}" if new_rest else f"\\\\{bb_host}"
    except Exception:
        return folder_path
    return folder_path


def _bboxes_intersect(bbox1, bbox2):
    if not bbox1 or not bbox2:
        return False
    x0_1, y0_1, x1_1, y1_1 = bbox1
    x0_2, y0_2, x1_2, y1_2 = bbox2
    return not (x1_1 < x0_2 or x1_2 < x0_1 or y1_1 < y0_2 or y1_2 < y0_1)


def _save_layout_files(segments, input_path: str):
    """Deprecated: Workers no longer write files; backend handles persistence."""
    return "", ""


def _inject_attrs_into_first_table(html: str, attr_str: str) -> str:
    try:
        def _repl(m):
            open_tag = m.group(0)
            if attr_str.strip():
                if open_tag.endswith('>'):
                    return open_tag[:-1] + ' ' + attr_str.strip() + '>'
            return open_tag
        import re
        return re.sub(r"<table\b[^>]*>", _repl, html, count=1, flags=re.IGNORECASE)
    except Exception:
        return html


def _segment_to_tag(seg: dict) -> str:
    s_type = seg.get('type') or 'paragraph'
    page = seg.get('page')
    bbox = seg.get('bbox')
    attrs = []
    if page is not None:
        attrs.append(f'page="{page}"')
    if bbox:
        try:
            bb = tuple(bbox)
            attrs.append(f'bbox="{bb[0]},{bb[1]},{bb[2]},{bb[3]}"')
        except Exception:
            pass
    attr_str = (" " + " ".join(attrs)) if attrs else ""

    raw = seg.get('text') or ""
    if s_type == 'table':
        raw_s = str(raw)
        if '<table' in raw_s.lower():
            injected = _inject_attrs_into_first_table(raw_s, attr_str.strip()) if attr_str else raw_s
            return injected + "\n"
        inner = raw_s if ('<' in raw_s and '>' in raw_s) else _html_escape(raw_s)
        return f"<table{attr_str}>" + inner + "</table>\n"
    elif s_type == 'heading':
        return f"<heading{attr_str}>" + _html_escape(str(raw)) + "</heading>\n"
    else:
        return f"<paragraph{attr_str}>" + _html_escape(str(raw)) + "</paragraph>\n"


def _analyze_with_azure_di_file(file_path: str, *, default_page_no: int = 1):
    if DocumentIntelligenceClient is None or AzureKeyCredential is None:
        raise RuntimeError(
            "Missing dependency 'azure-ai-documentintelligence'. Install it via: pip install azure-ai-documentintelligence"
        )

    client = DocumentIntelligenceClient(endpoint=AZURE_DI_ENDPOINT, credential=AzureKeyCredential(AZURE_DI_KEY))
    with open(file_path, 'rb') as f:
        poller = client.begin_analyze_document(AZURE_DI_MODEL, body=f)
    result = poller.result()

    segments = []
    table_bboxes = []

    # Tables to HTML segments with bbox
    if getattr(result, 'tables', None):
        for table in result.tables:
            bbox = None
            try:
                if table.bounding_regions:
                    region = table.bounding_regions[0]
                    polygon = getattr(region, 'polygon', None)
                    if polygon:
                        x_coords = [polygon[i] for i in range(0, len(polygon), 2)]
                        y_coords = [polygon[i] for i in range(1, len(polygon), 2)]
                        bbox = [min(x_coords), min(y_coords), max(x_coords), max(y_coords)]
            except Exception:
                bbox = None

            table_bboxes.append(bbox)
            # Build simple HTML table from cells
            html = '<table>'
            cells_by_row = {}
            for cell in getattr(table, 'cells', []) or []:
                r = cell.row_index
                c = cell.column_index
                cells_by_row.setdefault(r, {})[c] = cell.content or ''
            for r in sorted(cells_by_row.keys()):
                html += '<tr>'
                for c in sorted(cells_by_row[r].keys()):
                    html += f'<td>{cells_by_row[r][c]}</td>'
                html += '</tr>'
            html += '</table>'

            if table.bounding_regions:
                page_no = table.bounding_regions[0].page_number or default_page_no
            else:
                page_no = default_page_no

            segments.append({'type': 'table', 'page': page_no, 'bbox': bbox, 'text': html})

    # Paragraphs (exclude those intersecting table boxes); try to preserve heading titles
    if getattr(result, 'paragraphs', None):
        try:
            result.paragraphs.sort(key=lambda p: p.spans[0].offset if getattr(p, 'spans', None) else 0)
        except Exception:
            pass
        for p in result.paragraphs:
            bbox = None
            page_no = default_page_no
            try:
                if p.bounding_regions:
                    region = p.bounding_regions[0]
                    page_no = getattr(region, 'page_number', 1)
                    polygon = getattr(region, 'polygon', None)
                    if polygon:
                        x_coords = [polygon[i] for i in range(0, len(polygon), 2)]
                        y_coords = [polygon[i] for i in range(1, len(polygon), 2)]
                        bbox = [min(x_coords), min(y_coords), max(x_coords), max(y_coords)]
            except Exception:
                bbox = None

            if any(_bboxes_intersect(bbox, tb) for tb in table_bboxes):
                continue

            seg_type = 'heading' if getattr(p, 'role', None) == 'title' else 'paragraph'
            segments.append({'type': seg_type, 'page': page_no, 'bbox': bbox, 'text': getattr(p, 'content', '')})

    # Merge adjacent paragraphs with small vertical gaps
    merged = []
    current = None
    for seg in segments:
        if (
            seg.get('type') == 'paragraph'
            and current and current.get('type') == 'paragraph'
            and seg.get('page') == current.get('page')
            and seg.get('bbox') and current.get('bbox')
        ):
            _, y0_c, _, y1_c = current['bbox']
            x0_n, y0_n, x1_n, y1_n = seg['bbox']
            if y0_n - y1_c < 0.05:
                current['text'] = (current.get('text') or '') + ' ' + (seg.get('text') or '')
                current['bbox'] = [min(current['bbox'][0], x0_n), min(current['bbox'][1], y0_n), max(current['bbox'][2], x1_n), max(current['bbox'][3], y1_n)]
                continue
        if current:
            merged.append(current)
        current = seg
    if current:
        merged.append(current)

    return merged


def _render_page_to_tiff(page, dpi: int = 300):
    if fitz is None or Image is None:
        raise RuntimeError("PDF->TIFF conversion requires PyMuPDF (fitz) and Pillow (PIL). Please install both.")
    scale = dpi / 72.0
    mat = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    mode = "RGB" if pix.n >= 3 else "L"
    img = Image.frombytes(mode, [pix.width, pix.height], pix.samples)
    return img


def _pdf_to_tiffs(pdf_path: Path, out_dir: Path, dpi: int = 300, compression: str = "tiff_lzw"):
    out_dir.mkdir(parents=True, exist_ok=True)
    tiff_paths = []
    try:
        if fitz is None or Image is None:
            raise RuntimeError("PDF->TIFF conversion requires PyMuPDF (fitz) and Pillow (PIL). Please install both.")
        with fitz.open(str(pdf_path)) as doc:
            for i, page in enumerate(doc, start=1):
                img = _render_page_to_tiff(page, dpi=dpi)
                out_path = out_dir / f"page_{i:03d}.tiff"
                try:
                    img.save(out_path, format="TIFF", compression=compression)
                except Exception:
                    img.save(out_path, format="TIFF")
                tiff_paths.append(out_path)
    except Exception as e:
        logger.warning(f"PDF to TIFF conversion issue for {pdf_path}: {e}")
    return tiff_paths


@celery_app.task(name="azuredocument_intelligence_worker.azuredocument_intelligence_task")
def azuredocument_intelligence_task(task_id, folder_id, parser_config, dag_id, run_id):
    """Process first PDF in folder using Azure Document Intelligence and save layout files.

    Signature: (task_id, folder_id, parser_config, dag_id, run_id)
    ParserName accepted: 'azuredocument_intelligence', 'azure_document_intelligence', 'document_intelligence'
    """
    status = "failed"
    error_message = None
    folders = []
    output_files = []

    try:
        if not isinstance(parser_config, dict):
            raise ValueError("parser_config must be a JSON object/dict")
        parser_name = str(parser_config.get("ParserName", "")).strip().lower()
        if parser_name not in {"azuredocument_intelligence", "azure_document_intelligence", "document_intelligence"}:
            raise ValueError("ParserName must be 'azuredocument_intelligence' (or 'azure_document_intelligence', 'document_intelligence')")

        # Resolve folder path (normalize UNC host to IP using DATA_BACKBONE_DIR host if share matches)
        eff_folder_id = folder_id  # what we will report back
        if _is_abs_or_unc(folder_id):
            folder_path = _normalize_unc_using_backbone(folder_id)
            eff_folder_id = folder_path
        else:
            folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
        if not os.path.isdir(folder_path):
            raise ValueError(f"Folder not found: {folder_path}")

        # Prefer TIFFs; else convert PDF to per-page TIFFs, then analyze per image
        tiffs = [f for f in os.listdir(folder_path) if f.lower().endswith(('.tif', '.tiff'))]
        if not tiffs:
            pdfs = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
            if not pdfs:
                raise ValueError(f"No PDF or TIFF found in folder: {folder_path}")
            pdf_name = pdfs[0]
            pdf_path = Path(folder_path) / pdf_name
            tiff_paths = _pdf_to_tiffs(pdf_path, Path(folder_path))
            if not tiff_paths:
                raise RuntimeError("PDF to TIFF conversion produced no pages; ensure PyMuPDF and Pillow are installed and the PDF is readable.")
            tiffs = [p.name for p in tiff_paths]

        # Analyze each TIFF as one page; build combined tagged text
        tiffs.sort()
        segments = []
        tagged_text_parts = []
        page_counter = 1
        for tif_name in tiffs:
            img_path = os.path.join(folder_path, tif_name)
            segs = _analyze_with_azure_di_file(img_path, default_page_no=page_counter)
            segments.extend(segs)
            tagged_text_parts.append("".join(_segment_to_tag(s) for s in segs))
            page_counter += 1
        tagged_text = "".join(tagged_text_parts)
        output_files = []

        # Prefer reporting original PDF name if present; else first TIFF
        pdfs_in_folder = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
        doc_name = pdfs_in_folder[0] if pdfs_in_folder else tiffs[0]
        folders.append({"folder_id": eff_folder_id if _is_abs_or_unc(folder_id) else folder_id, "document_name": doc_name})
        status = "success"

    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error("Exception in azuredocument_intelligence_task: %s", error_message, exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": eff_folder_id if _is_abs_or_unc(folder_id) else folder_id,
        "folders": folders,
    }
    # Include results for backend-only file creation
    if 'segments' not in payload:
        payload["segments"] = segments if isinstance(locals().get('segments'), list) else []
    if 'tagged_text' not in payload:
        payload["tagged_text"] = locals().get('tagged_text', "")
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info("Posting parser results to %s: %s", WORKER_RESULTS_URL, payload)
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error("parser worker-results callback returned HTTP %s: %s", resp.status_code, resp.text)
    except Exception as cb_err:  # noqa: BLE001
        logger.error("Failed to POST parser worker results: %s", cb_err, exc_info=True)

    return {
        "task_id": task_id,
        "status": status,
        "output_files": output_files,
        "folders": folders,
        "error": error_message,
    }

