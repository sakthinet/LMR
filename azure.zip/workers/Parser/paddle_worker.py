# paddle_worker.py  (ready to run)
import os
from pathlib import Path
import fitz
import requests
from datetime import datetime
from celery import Celery
from kombu import Queue
import logging
import json
import time
import re
from typing import Optional, Any, Dict, List
from config import settings

try:
    from PIL import Image  # Pillow
except Exception:
    Image = None  # type: ignore

logger = logging.getLogger("paddle_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(fmt)
    logger.addHandler(handler)

# Shared validated configuration (env first, then .env fallback)
BROKER_URL = settings.broker_url
RESULT_BACKEND = settings.result_backend
DATA_BACKBONE_DIR = settings.data_backbone_dir
LOG_LEVEL = settings.parser_log_level.upper()
WORKER_RESULTS_URL = settings.worker_results_url
PARSER_QUEUES = settings.parser_queues
PADDLE_OCR_API_URL = settings.paddle_ocr_api_url

try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:
    logger.setLevel(logging.INFO)

# Celery app
celery_app = Celery("parser_worker", broker=BROKER_URL, backend=RESULT_BACKEND)

queue_names = [q.strip() for q in PARSER_QUEUES.split(",") if q.strip()]
if not queue_names:
    raise RuntimeError("PARSER_QUEUES must specify at least one queue name (e.g. 'paddle')")

celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]


def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\\\") or p.startswith("//"))


_TIFF_PAGE_RE = re.compile(r"_page_(\d{1,6})\.tiff$", flags=re.IGNORECASE)


def _page_num_from_tiff_name(name: str) -> Optional[int]:
    if not isinstance(name, str):
        return None
    m = _TIFF_PAGE_RE.search(name)
    if not m:
        return None
    try:
        n = int(m.group(1))
        return n if n > 0 else None
    except Exception:
        return None


def _save_layout_json_only(pages: List[Dict[str, Any]], input_pdf_path: str) -> str:
    base = Path(input_pdf_path).stem
    out_dir = Path(input_pdf_path).parent
    json_path = out_dir / f"{base}.layout.json"
    payload = {"pages": pages}
    with open(json_path, "w", encoding="utf-8") as jf:
        json.dump(payload, jf, ensure_ascii=False, indent=2)
    return str(json_path)


def _wait_for_normalized_output(folder_path: str, stem: str, timeout_s: int = 120, poll_s: float = 1.0) -> bool:
    target = os.path.join(folder_path, f"{stem}.parser_output.json")
    deadline = time.time() + max(1, int(timeout_s))
    while time.time() < deadline:
        if os.path.exists(target):
            return True
        time.sleep(poll_s)
    return os.path.exists(target)


def _render_page_to_tiff(page, dpi: int = 300):
    if Image is None:
        raise RuntimeError("PDF->TIFF conversion requires Pillow (PIL). Install: pip install pillow")
    scale = dpi / 72.0
    mat = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    mode = "RGB" if pix.n >= 3 else "L"
    img = Image.frombytes(mode, [pix.width, pix.height], pix.samples)
    return img


def _pdf_to_tiffs(pdf_path: Path, out_dir: Path, dpi: int = 300, compression: str = "tiff_lzw"):
    out_dir.mkdir(parents=True, exist_ok=True)
    tiff_paths = []
    with fitz.open(str(pdf_path)) as doc:
        for i, page in enumerate(doc, start=1):
            img = _render_page_to_tiff(page, dpi=dpi)
            # MinerU-style naming so page number can be derived reliably
            out_path = out_dir / f"{pdf_path.stem}_page_{i:03d}.tiff"
            try:
                img.save(out_path, format="TIFF", compression=compression)
            except Exception:
                img.save(out_path, format="TIFF")
            tiff_paths.append(out_path)
    return tiff_paths


def _extract_layout_from_any(payload: Any) -> Optional[list]:
    """
    Return a layout list if present anywhere in the OCR response,
    including cases where JSON is stuffed inside text/stdout as a string.
    """
    # direct: {"layout":[...]}
    if isinstance(payload, dict) and isinstance(payload.get("layout"), list):
        return payload["layout"]

    candidate = None

    # common: {"pages":[{"layout":[...]}]} or {"pages":[{"text":"{...}"}]}
    if isinstance(payload, dict) and payload.get("pages"):
        pages = payload.get("pages")
        if isinstance(pages, list) and pages:
            p0 = pages[0]
            if isinstance(p0, dict):
                if isinstance(p0.get("layout"), list):
                    return p0["layout"]
                candidate = p0.get("text")

    # common: {"data":{"stdout":"{...}"}}
    if candidate is None and isinstance(payload, dict):
        data = payload.get("data")
        if isinstance(data, dict):
            candidate = data.get("stdout")

    # sometimes the "candidate" itself is already the layout list
    if isinstance(candidate, list):
        return candidate

    # candidate might be a JSON string containing {"layout":[...]}
    if isinstance(candidate, str):
        s = candidate.lstrip("\ufeff").strip()  # handle BOM
        if s.startswith("{") or s.startswith("["):
            try:
                parsed = json.loads(s)
                if isinstance(parsed, dict) and isinstance(parsed.get("layout"), list):
                    return parsed["layout"]
            except Exception:
                return None

    return None


def _best_effort_text(payload: Any, fallback_text: str) -> str:
    """Fallback plain-text extraction if no layout is present."""
    if isinstance(payload, dict):
        if isinstance(payload.get("text"), str) and payload["text"].strip():
            return payload["text"]
        pages = payload.get("pages")
        if isinstance(pages, list) and pages:
            p0 = pages[0]
            if isinstance(p0, dict) and isinstance(p0.get("text"), str):
                return p0.get("text", "") or fallback_text
        data = payload.get("data")
        if isinstance(data, dict) and isinstance(data.get("stdout"), str):
            return data.get("stdout", "") or fallback_text
    return fallback_text


@celery_app.task(name="paddle_worker.paddle_task")
def paddle_task(task_id, folder_id, parser_config, dag_id, run_id):
    """
    Process first PDF in folder using external Paddle OCR service and report results.

    Signature: (task_id, folder_id, parser_config, dag_id, run_id)
    """
    status = "failed"
    error_message = None
    folders = []
    layout_json_path = None
    legacy_layout_txt_path = None

    try:
        if not isinstance(parser_config, dict):
            raise ValueError("parser_config must be a JSON object/dict")

        parser_name = str(parser_config.get("ParserName", "")).strip().lower()
        if parser_name not in {"paddle", "paddleocr"}:
            raise ValueError("ParserName must be 'paddle' or 'paddleocr'")

        # Resolve folder path
        if _is_abs_or_unc(folder_id):
            folder_path = folder_id
        else:
            folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)

        if not os.path.isdir(folder_path):
            raise ValueError(f"Folder not found: {folder_path}")

        # Prefer TIFFs; else convert first PDF to per-page TIFFs
        tiffs = [f for f in os.listdir(folder_path) if f.lower().endswith((".tif", ".tiff"))]
        if not tiffs:
            pdfs = [f for f in os.listdir(folder_path) if f.lower().endswith(".pdf")]
            if not pdfs:
                raise ValueError(f"No PDF or TIFF found in folder: {folder_path}")

            pdf_name = sorted(pdfs)[0]
            pdf_path = Path(folder_path) / pdf_name
            tiff_paths = _pdf_to_tiffs(pdf_path, Path(folder_path))
            if not tiff_paths:
                raise RuntimeError(
                    "PDF->TIFF produced no pages; ensure PyMuPDF + Pillow are installed and PDF is readable."
                )
            tiffs = [p.name for p in tiff_paths]

        pages: List[Dict[str, Any]] = []

        for idx, tif_name in enumerate(sorted(tiffs), start=1):
            img_path = os.path.join(folder_path, tif_name)
            # MinerU-style: derive page number from TIFF filename; fallback to sorted index
            page_num = _page_num_from_tiff_name(tif_name) or idx
            try:
                with open(img_path, "rb") as fh:
                    files_payload = {"file": fh}
                    data = {"options": json.dumps(parser_config.get("Options", {}))}
                    resp = requests.post(
                        PADDLE_OCR_API_URL, data=data, files=files_payload, timeout=120
                    )
                    resp.raise_for_status()

                    # Parse service response
                    try:
                        j = resp.json()
                    except Exception:
                        j = {"text": resp.text or ""}

                    # ✅ FIX: always extract "layout" even if it is inside pages[0].text as JSON string
                    layout = _extract_layout_from_any(j)
                    if layout is not None:
                        pages.append({"page_number": page_num, "layout": layout})
                    else:
                        text = _best_effort_text(j, resp.text or "")
                        pages.append({"page_number": page_num, "text": text})

            except Exception as e:  # noqa: BLE001
                logger.error("OCR service page %s failed: %s", page_num, e, exc_info=True)
                pages.append({"page_number": page_num, "text": f"[ERROR] OCR failed for Page {page_num}: {e}"})

        # Determine document name
        pdfs_in_folder = [f for f in os.listdir(folder_path) if f.lower().endswith(".pdf")]
        doc_name = sorted(pdfs_in_folder)[0] if pdfs_in_folder else (sorted(tiffs)[0] if tiffs else "")

        # Write MinerU-like layout.json for backend normalization (do not write layout.txt)
        pdfs_in_folder = [f for f in os.listdir(folder_path) if f.lower().endswith(".pdf")]
        pdf_for_stem = sorted(pdfs_in_folder)[0] if pdfs_in_folder else None
        if not pdf_for_stem:
            raise RuntimeError("Paddle worker requires a PDF in folder to determine stem for layout.json")

        pdf_path_for_json = os.path.join(folder_path, pdf_for_stem)

        # Convert pages to MinerU-like layout segments; if OCR returned layout we keep it,
        # else fall back to a simple paragraph segment with the page text.
        layout_pages: List[Dict[str, Any]] = []
        for p in pages:
            try:
                pn = int(p.get("page_number") or 1)
            except Exception:
                pn = 1
            if isinstance(p.get("layout"), list):
                # If service layout items don't include page, we don't mutate them here;
                # backend normalization can still infer page from page_number wrapper.
                layout_pages.append({"page_number": pn, "layout": p.get("layout")})
            else:
                txt = p.get("text")
                if not isinstance(txt, str):
                    txt = "" if txt is None else str(txt)
                txt = txt.strip()
                if not txt:
                    continue
                layout_pages.append(
                    {
                        "page_number": pn,
                        "layout": [{"type": "paragraph", "page": pn, "bbox": None, "text": txt}],
                    }
                )

        if not layout_pages:
            raise RuntimeError("No OCR output to write layout.json")

        layout_json_path = _save_layout_json_only(layout_pages, pdf_path_for_json)
        legacy_layout_txt_path = os.path.join(folder_path, f"{Path(pdf_path_for_json).stem}.layout.txt")

        folders.append({"folder_id": folder_id, "document_name": doc_name})
        status = "success"

    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error("Exception in paddle_task: %s", error_message, exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "folders": folders,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info("Posting parser results to %s", WORKER_RESULTS_URL)
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error("worker-results callback returned HTTP %s: %s", resp.status_code, resp.text)
        else:
            # NOTE: keep <stem>.layout.json for debugging/side-by-side comparison.
            # We still optionally cleanup any legacy layout.txt after normalization exists.
            try:
                if status == "success" and os.path.isdir(folder_path) and legacy_layout_txt_path:
                    # Determine stem from any PDF in folder
                    pdfs_in_folder = [f for f in os.listdir(folder_path) if f.lower().endswith(".pdf")]
                    if pdfs_in_folder:
                        stem = Path(sorted(pdfs_in_folder)[0]).stem
                        if _wait_for_normalized_output(folder_path, stem, timeout_s=120, poll_s=1.0):
                            if os.path.exists(legacy_layout_txt_path):
                                try:
                                    os.remove(legacy_layout_txt_path)
                                    logger.info("Deleted legacy layout.txt after normalization: %s", legacy_layout_txt_path)
                                except Exception as del_err:  # noqa: BLE001
                                    logger.warning("Failed to delete legacy layout.txt '%s': %s", legacy_layout_txt_path, del_err)
            except Exception as cleanup_err:  # noqa: BLE001
                logger.warning("Post-normalization cleanup skipped due to error: %s", cleanup_err)
    except Exception as cb_err:  # noqa: BLE001
        logger.error("Failed to POST parser worker results: %s", cb_err, exc_info=True)

    return {"task_id": task_id, "status": status, "folders": folders, "error": error_message}
