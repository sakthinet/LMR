import os
import json
from datetime import datetime
from celery import Celery
from kombu import Queue
import logging
from typing import Optional, List, Any, Dict
import requests
import fitz
from urllib.parse import urlparse
try:
    from PIL import Image
except Exception:
    Image = None  # type: ignore
import re
import time
from config import settings

# LlamaParse client
try:
    from llama_cloud_services import LlamaParse
    _have_llamaparser = True
except Exception:
    LlamaParse = None
    _have_llamaparser = False

logger = logging.getLogger("llamaparser_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(fmt)
    logger.addHandler(handler)

# Shared validated configuration (env first, then .env fallback)
BROKER_URL = settings.broker_url
RESULT_BACKEND = settings.result_backend
DATA_BACKBONE_DIR = settings.data_backbone_dir
LOG_LEVEL = settings.parser_log_level.upper()
WORKER_RESULTS_URL = settings.worker_results_url
PARSER_QUEUES = settings.parser_queues

try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:
    logger.setLevel(logging.INFO)

# Celery app
celery_app = Celery(
    'llamaparser_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

queue_names = [q.strip() for q in PARSER_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("PARSER_QUEUES must specify at least one queue name (e.g. 'llamaparser')")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]


def _get_connection_profile_secret(profile_name: str) -> tuple[str, Optional[str]]:
    """Fetch a decrypted secret (and optional base URL) for a profile.

    Calls the backend decrypt endpoint for connection profiles. This
    URL must be provided explicitly via the PROFILE_DECRYPT_URL
    environment variable.

    The backend in turn uses decrypt_password_for_profile on the server
    side. The plaintext secret is only kept in-memory in this worker.
    For API-style profiles (e.g., llama_cloud), the backend may also
    return a "base_url" value derived from metadata_json.
    """

    # Require an explicit, logically named URL for the decrypt
    # endpoint. This should be the full URL, e.g.:
    #   PROFILE_DECRYPT_URL=http://10.73.88.101:8000/rbac/decryptConnectionProfile
    url = settings.profile_decrypt_url
    if url:
        url = url.strip()
    if not url:
        raise RuntimeError(
            "PROFILE_DECRYPT_URL is required for llamaparser_worker to "
            "decrypt connection profiles (expected full URL to the "
            "/rbac/decryptConnectionProfile endpoint)."
        )
    payload = {"profile_name": profile_name}

    try:
        resp = requests.post(url, json=payload, timeout=30)
    except Exception as e:
        raise RuntimeError(f"Failed to call decryptConnectionProfile at {url}: {e}") from e

    if resp.status_code != 200:
        try:
            body = resp.json()
        except Exception:
            body = resp.text
        raise RuntimeError(
            f"decryptConnectionProfile returned HTTP {resp.status_code}: {body}"
        )

    data = resp.json() or {}
    secret = data.get("password")
    if not secret or not isinstance(secret, str):
        raise RuntimeError("decryptConnectionProfile response missing 'password' field")

    base_url = data.get("base_url")
    if base_url is not None and not isinstance(base_url, str):
        base_url = None

    return secret, base_url


def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\\\") or p.startswith("//"))


def _render_page_to_tiff(page, dpi: int = 300):
    if Image is None:
        raise RuntimeError("PDF->TIFF conversion requires Pillow (PIL). Install: pip install pillow")
    scale = dpi / 72.0
    mat = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    mode = "RGB" if pix.n >= 3 else "L"
    img = Image.frombytes(mode, [pix.width, pix.height], pix.samples)
    return img


def _pdf_to_tiffs(pdf_path: str, out_dir: str, dpi: int = 300, compression: str = "tiff_lzw") -> List[str]:
    os.makedirs(out_dir, exist_ok=True)
    tiff_paths: List[str] = []
    with fitz.open(pdf_path) as doc:
        for i, page in enumerate(doc, start=1):
            img = _render_page_to_tiff(page, dpi=dpi)
            stem = os.path.splitext(os.path.basename(pdf_path))[0]
            out_path = os.path.join(out_dir, f"{stem}_page_{i:03d}.tiff")
            # Overwrite if exists to ensure page images match current DPI/config.
            try:
                img.save(out_path, format="TIFF", compression=compression)
            except Exception:
                img.save(out_path, format="TIFF")
            tiff_paths.append(out_path)
    return tiff_paths


def _chunked(items: List[str], size: int) -> List[List[str]]:
    if size <= 0:
        return [items]
    return [items[i : i + size] for i in range(0, len(items), size)]


_TIFF_PAGE_RE = re.compile(r"_page_(\d{1,6})\.tiff$", flags=re.IGNORECASE)


def _page_num_from_tiff_path(p: str) -> Optional[int]:
    if not isinstance(p, str):
        return None
    m = _TIFF_PAGE_RE.search(p.replace("/", "\\"))
    if not m:
        return None
    try:
        n = int(m.group(1))
        return n if n > 0 else None
    except Exception:
        return None


def _render_llama_md_to_layout_lines(md: str, page_num: int) -> List[str]:
    """Convert Llama markdown/HTML mix into MinerU-style tagged lines.

    - Preserves <table>...</table> blocks as a single line with page attribute.
    - Treats remaining non-empty lines as <paragraph>.
    """
    if not isinstance(md, str):
        return []
    s = md.strip()
    if not s:
        return []

    lines: List[str] = []
    table_re = re.compile(r"<table\b[^>]*>.*?</table>", flags=re.IGNORECASE | re.DOTALL)
    idx = 0
    for m in table_re.finditer(s):
        before = s[idx : m.start()]
        for raw_line in before.splitlines():
            t = raw_line.strip()
            if t:
                lines.append(f'<paragraph page="{page_num}">{t}</paragraph>')
        table_html = m.group(0).strip()
        # ensure page attr exists
        if re.search(r"\bpage=", table_html, flags=re.IGNORECASE):
            lines.append(table_html)
        else:
            lines.append(re.sub(r"<table\b", f'<table page="{page_num}"', table_html, count=1, flags=re.IGNORECASE))
        idx = m.end()

    tail = s[idx:]
    for raw_line in tail.splitlines():
        t = raw_line.strip()
        if t:
            lines.append(f'<paragraph page="{page_num}">{t}</paragraph>')

    return lines


def _extract_layout_from_llama_page(page_obj: Any) -> Optional[list]:
    try:
        layout = getattr(page_obj, "layout", None)
        if isinstance(layout, list):
            return layout
        text_val = getattr(page_obj, "text", None) or getattr(page_obj, "md", None)
        if isinstance(text_val, str) and text_val.strip():
            return [{"type": "text", "bbox": None, "text": text_val.strip()}]
    except Exception:
        return None
    return None


@celery_app.task(name="llamaparser_worker.llamaparser_task")
def llamaparser_task(task_id, folder_id, parser_config, dag_id, run_id):
    """Parse PDF pages via TIFF using LlamaParse, and post raw_json to backend.

    Signature: (task_id, folder_id, parser_config, dag_id, run_id)
    """
    status = "failed"
    error_message = None
    folders = []
    output_text_path = None
    created_llama_json_paths: List[str] = []
    created_llama_text_paths: List[str] = []
    normalized_expected_paths: List[str] = []
    expected_layout_txt_paths: List[str] = []
    created_tiff_paths: List[str] = []
    # Default so cleanup logic is safe even if we fail before parsing config
    delete_tiffs_after_normalized: bool = False

    try:
        if not _have_llamaparser:
            raise RuntimeError("llama_cloud_services.LlamaParse is not available in this environment")

        if not isinstance(parser_config, dict):
            raise ValueError("parser_config must be a JSON object/dict")
        parser_name = str(parser_config.get("ParserName", "")).strip().lower()
        if parser_name not in {"llamaparser", "llama", "llamaparser_worker"}:
            # allow flexible naming
            if parser_name == "":
                # allow empty and proceed (caller may elect to run llamaparser)
                logger.debug("ParserName not provided; proceeding assuming LlamaParse")
            else:
                raise ValueError("ParserName must be 'LlamaParser' (case-insensitive)")

        # Resolve folder path
        # Always prefer the shared DATA_BACKBONE_DIR (IP-based UNC) so that
        # host-specific UNC paths like \\AVDHOST\DataBackBone\Runtime_xxx
        # are normalized to the central share.
        if _is_abs_or_unc(folder_id):
            # Strip to the last path component (e.g. Runtime_xxx) and join
            # with DATA_BACKBONE_DIR instead of trusting the incoming UNC.
            folder_basename = os.path.basename(str(folder_id).rstrip("/\\"))
            folder_path = os.path.join(DATA_BACKBONE_DIR, folder_basename)
        else:
            folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
        if not os.path.isdir(folder_path):
            raise ValueError(f"Folder not found: {folder_path}")

        # Collect files to parse
        candidates = [f for f in os.listdir(folder_path) if f.lower().endswith((".pdf", ".docx", ".txt"))]
        if not candidates:
            raise ValueError(f"No supported files found in folder: {folder_path}")

        # Resolve API key / secret: prefer a connection profile (from
        # parser_config or env), then explicit parser_config.api_key,
        # and only lastly the legacy env variable.
        env_profile_name = settings.llama_cloud_profile_name
        if env_profile_name:
            # Be tolerant of .env styles like: LLAMA_CLOUD_PROFILE_NAME = "Llama API"
            env_profile_name = env_profile_name.strip().strip('"').strip("'")

        api_key_profile_name = (
            parser_config.get("connection_profile_name")
            or parser_config.get("api_profile_name")
            or env_profile_name
        )

        if not api_key_profile_name:
            raise RuntimeError(
                "No Llama connection profile name configured: set "
                "parser_config.connection_profile_name or LLAMA_CLOUD_PROFILE_NAME."
            )

        api_key: Optional[str] = None
        api_url_from_profile: Optional[str] = None

        try:
            api_key, api_url_from_profile = _get_connection_profile_secret(str(api_key_profile_name))
            logger.info(
                "Resolved Llama API key from connection profile '%s' via backend decrypt endpoint.",
                api_key_profile_name,
            )
        except Exception as e:
            logger.error(
                "Failed to resolve API key from connection profile '%s': %s",
                api_key_profile_name,
                e,
            )
            raise

        if not api_key:
            raise RuntimeError(
                "Llama API key could not be obtained from connection profile '%s'."
                % api_key_profile_name
            )

        # Explicitly check and log the API URL override. Prefer the
        # base_url returned from the connection profile (if any), then a
        # parser_config override, then the legacy env var.
        api_url_from_env = settings.llama_cloud_api_url
        api_url_from_config = parser_config.get("api_url")
        api_url = api_url_from_profile or api_url_from_config or api_url_from_env
        logger.info(
            "API URL Override Check: from_profile=%s, from_parser_config=%s, from_env=%s, final_url=%s",
            api_url_from_profile,
            api_url_from_config,
            api_url_from_env,
            api_url,
        )

        # Build parser client. Allow passing config options from parser_config
        num_workers = int(parser_config.get("num_workers", 1) or 1)
        parse_mode = parser_config.get("parse_mode", "parse_page_with_agent")
        high_res_ocr = bool(parser_config.get("high_res_ocr", True))
        adaptive_long_table = bool(parser_config.get("adaptive_long_table", True))
        outlined_table_extraction = bool(parser_config.get("outlined_table_extraction", True))
        output_tables_as_HTML = bool(parser_config.get("output_tables_as_HTML", True))
        verbose = bool(parser_config.get("verbose", False))
        language = parser_config.get("language", "en")

        def _mask_key(k: str) -> str:
            if not k:
                return "<none>"
            if len(k) <= 8:
                return k[:2] + "..."
            return k[:4] + "..." + k[-4:]

        logger.info("Initializing LlamaParse client (key=%s, mode=%s)", _mask_key(api_key), parse_mode)

        # Build kwargs for the client so we can optionally inject an explicit API URL
        client_kwargs = {
            "api_key": api_key,
            "num_workers": num_workers,
            "verbose": verbose,
            "language": language,
            "parse_mode": parse_mode,
            "high_res_ocr": high_res_ocr,
            "adaptive_long_table": adaptive_long_table,
            "outlined_table_extraction": outlined_table_extraction,
            "output_tables_as_HTML": output_tables_as_HTML,
        }

        # Allow explicit override of the API endpoint via parser_config or env
        if api_url:
            client_kwargs["base_url"] = api_url
            logger.info("Attempting to construct client with explicit base_url: %s", api_url)
        else:
            logger.info("No API URL override found. Relying on default SDK endpoint.")

        # Try constructing the client
        try:
            parser = LlamaParse(**client_kwargs)
        except TypeError as te:
            # If base_url caused an unexpected kwarg, try removing it and retrying with api_url.
            err_text = str(te)
            if api_url and "base_url" in err_text:
                logger.warning("LlamaParse constructor rejected 'base_url' kwarg. Retrying with 'api_url'.")
                client_kwargs.pop("base_url", None)
                client_kwargs["api_url"] = api_url
                try:
                    parser = LlamaParse(**client_kwargs)
                except Exception:
                    logger.error("LlamaParse constructor failed with both 'base_url' and 'api_url' kwargs.")
                    raise
            else:
                # Not a url issue — re-raise
                raise

        use_tiff_input = bool(parser_config.get("use_tiff_input", True))
        tiff_dpi = int(parser_config.get("tiff_dpi", 300) or 300)
        tiff_compression = str(parser_config.get("tiff_compression", "tiff_lzw") or "tiff_lzw")
        tiff_batch_size = int(parser_config.get("tiff_batch_size", 0) or 0)
        # Keep TIFFs by default (user requirement). These are useful for auditing/debugging.
        delete_tiffs_after_normalized = bool(parser_config.get("delete_tiffs_after_normalized", False))

        # Parse each source file; for PDFs convert to per-page TIFF images and parse those (TIFF-only like MinerU).
        results_list = []
        results_source_names: List[str] = []
        tiff_paths_by_source: Dict[str, List[str]] = {}
        for fname in candidates:
            src_path = os.path.join(folder_path, fname)
            lower = src_path.lower()

            if use_tiff_input and lower.endswith(".pdf"):
                tiff_out_dir = folder_path
                logger.info("Converting PDF to TIFFs in-place: %s -> %s (dpi=%s)", src_path, tiff_out_dir, tiff_dpi)
                tiff_paths = _pdf_to_tiffs(src_path, tiff_out_dir, dpi=tiff_dpi, compression=tiff_compression)
                tiff_paths = sorted(tiff_paths)
                if not tiff_paths:
                    raise RuntimeError(f"No TIFFs produced for PDF: {src_path}")
                tiff_paths_by_source[fname] = tiff_paths
                created_tiff_paths.extend(tiff_paths)

                logger.info("TIFF pages generated: %s", [os.path.basename(p) for p in tiff_paths[:5]])

                logger.info("Invoking LlamaParse on %s TIFF pages for %s", len(tiff_paths), fname)
                if tiff_batch_size and len(tiff_paths) > tiff_batch_size:
                    batch_results = []
                    for batch in _chunked(tiff_paths, tiff_batch_size):
                        r = parser.parse(batch)
                        if isinstance(r, list):
                            batch_results.extend(r)
                        else:
                            batch_results.append(r)
                    results_list.append(batch_results)
                else:
                    r = parser.parse(tiff_paths)
                    results_list.append(r)
                results_source_names.append(fname)
                continue

            if use_tiff_input and lower.endswith(".pdf") is False:
                # In TIFF-only mode we should never send PDFs directly.
                # Non-PDF inputs (already images) are allowed.
                pass

            # Default: parse the original file directly.
            # If use_tiff_input is enabled and the input is a PDF, we must not fall back to PDF parsing.
            if use_tiff_input and lower.endswith(".pdf"):
                raise RuntimeError(f"TIFF-only mode enabled but PDF was not converted: {src_path}")

            logger.info("Invoking LlamaParse on file: %s", src_path)
            r = parser.parse(src_path)
            results_list.append(r)
            results_source_names.append(fname)

        # Normalize each per-file result to a single object (or list-of-objects)
        normalized_results = []
        for r in results_list:
            # parser.parse() may return a list or a single result
            normalized_results.append(r)

        # Custom JSON encoder to handle non-serializable LlamaParse objects
        class LlamaParseEncoder(json.JSONEncoder):
            def default(self, o):
                # For ImageItem or other complex objects from the SDK,
                # convert them to a dictionary of their attributes.
                if hasattr(o, '__dict__'):
                    return o.__dict__
                # Fallback for objects without __dict__
                return str(o)

        # For each source file result:
        # - write raw <stem>_llamaparser.json for backend normalization
        # - write MinerU-style <stem>.layout.txt (preferred input for normalization; preserves table HTML)
        # Normalized JSON is produced by the backend as <stem>.parser_output.json.
        all_structured: List[dict] = []
        for res, fname in zip(normalized_results, results_source_names):
            base = os.path.splitext(fname)[0]

            # If the source PDF was converted to per-page TIFFs, use their order
            # to force stable 1-based page numbering.
            forced_page_numbers: Optional[List[int]] = None
            tiffs_for_file = tiff_paths_by_source.get(fname) or []
            if tiffs_for_file:
                # MinerU-style: derive page numbers from the TIFF filenames
                nums = []
                for tp in tiffs_for_file:
                    pn = _page_num_from_tiff_path(tp)
                    if pn is not None:
                        nums.append(pn)
                if nums and len(nums) == len(tiffs_for_file):
                    forced_page_numbers = nums
                else:
                    # Fallback to sequential if filenames are unexpected
                    forced_page_numbers = list(range(1, len(tiffs_for_file) + 1))

            json_filename = f"{base}_llamaparser.json"
            json_path = os.path.join(folder_path, json_filename)
            # Raw JSON output: best-effort extract md/text per page
            structured = {
                "file": fname,
                "pages": [],
            }
            try:
                res_items = res if isinstance(res, list) else [res]
                page_counter = 0
                for res_item in res_items:
                    for page in getattr(res_item, "pages", []) or []:
                        page_counter += 1

                        # Derive page number with multiple fallbacks:
                        # 1) explicit forced_page_numbers from TIFF filenames
                        # 2) page/page_number attribute on the Llama page object
                        # 3) sequential counter per document
                        page_num: Optional[int] = None
                        if forced_page_numbers and page_counter <= len(forced_page_numbers):
                            page_num = forced_page_numbers[page_counter - 1]

                        if page_num is None:
                            candidate = getattr(page, "page_number", None)
                            if candidate is None:
                                candidate = getattr(page, "page", None)
                            if isinstance(candidate, int) and candidate > 0:
                                page_num = candidate

                        if page_num is None:
                            page_num = page_counter

                        structured_page = {
                            "page": page_num,
                            "text": getattr(page, "text", None),
                            "md": getattr(page, "md", None),
                            "images": getattr(page, "images", None),
                            "layout": getattr(page, "layout", None),
                            "structuredData": getattr(page, "structuredData", None),
                        }
                        structured["pages"].append(structured_page)
            except Exception:
                try:
                    res_items = res if isinstance(res, list) else [res]
                    for res_item in res_items:
                        text_docs = res_item.get_text_documents(split_by_page=True)
                        for idx, td in enumerate(text_docs, start=1):
                            page_num: Optional[int] = None
                            if forced_page_numbers and idx <= len(forced_page_numbers):
                                page_num = forced_page_numbers[idx - 1]
                            if page_num is None:
                                page_num = idx
                            structured["pages"].append({"page": page_num, "text": getattr(td, "text", str(td))})
                except Exception:
                    structured["pages"].append({"page": None, "text": None})

            with open(json_path, "w", encoding="utf-8") as jf:
                json.dump(structured, jf, ensure_ascii=False, indent=2, cls=LlamaParseEncoder)
            created_llama_json_paths.append(json_path)
            all_structured.append(structured)

            folders.append({"folder_id": folder_id, "document_name": fname})
            # Do not keep <stem>.layout.txt artifacts for Llama; track legacy path for cleanup.
            expected_layout_txt_paths.append(os.path.join(folder_path, f"{base}.layout.txt"))
            normalized_expected_paths.append(os.path.join(folder_path, f"{base}.parser_output.json"))

        status = "success"

    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error("Exception in llamaparser_task: %s", error_message, exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "folders": folders,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info("Posting parser results to %s: %s", WORKER_RESULTS_URL, payload)
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=60)
        if resp.status_code >= 300:
            logger.error("llamaparser worker-results callback returned HTTP %s: %s", resp.status_code, resp.text)
        else:
            # Wait for backend normalization to complete, then delete raw *_llamaparser.json
            wait_seconds = int(parser_config.get("wait_for_normalized_seconds", 60) or 60)
            poll_interval = float(parser_config.get("normalized_poll_interval", 1.0) or 1.0)

            deadline = time.time() + max(0, wait_seconds)
            remaining = set(p for p in normalized_expected_paths if p)
            while remaining and time.time() < deadline:
                remaining = set(p for p in remaining if not os.path.exists(p))
                if remaining:
                    time.sleep(poll_interval)

            if remaining:
                logger.warning(
                    "Timed out waiting for normalized outputs (%ss). Keeping raw json: %s",
                    wait_seconds,
                    sorted(remaining),
                )
            else:
                for json_path in created_llama_json_paths:
                    try:
                        if os.path.exists(json_path):
                            os.remove(json_path)
                            logger.info("Deleted raw artifact after normalization: %s", json_path)
                    except Exception as rm_err:  # noqa: BLE001
                        logger.warning("Failed to delete raw artifact %s: %s", json_path, rm_err)

                # Delete rendered TIFF inputs after normalization
                if delete_tiffs_after_normalized:
                    for tp in created_tiff_paths:
                        try:
                            if os.path.exists(tp):
                                os.remove(tp)
                                logger.info("Deleted TIFF artifact after normalization: %s", tp)
                        except Exception as rm_err:  # noqa: BLE001
                            logger.warning("Failed to delete TIFF artifact %s: %s", tp, rm_err)
                logger.info("Keeping TIFF artifacts")

                # Delete any legacy <stem>.layout.txt if present
                for layout_path in expected_layout_txt_paths:
                    try:
                        if os.path.exists(layout_path):
                            os.remove(layout_path)
                            logger.info("Deleted legacy layout artifact after normalization: %s", layout_path)
                    except Exception as rm_err:  # noqa: BLE001
                        logger.warning("Failed to delete legacy layout artifact %s: %s", layout_path, rm_err)

            # No text/layout artifacts are produced for Llama.
    except Exception as cb_err:  # noqa: BLE001
        logger.error("Failed to POST llamaparser worker results: %s", cb_err, exc_info=True)

    return {
        "task_id": task_id,
        "status": status,
        "output_file": output_text_path,
        "folders": folders,
        "error": error_message,
    }
