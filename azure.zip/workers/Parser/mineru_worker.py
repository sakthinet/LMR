import json
import logging
import os
import subprocess
import tempfile
from pathlib import Path
from html import escape as _html_escape
import re
import time

import requests
from celery import Celery
from kombu import Queue
from config import settings
try:
    import fitz  # PyMuPDF for PDF rendering
except Exception:
    fitz = None  # type: ignore
try:
    from PIL import Image  # Pillow for image writing
except Exception:
    Image = None  # type: ignore

logger = logging.getLogger(__name__)

# Shared validated configuration (env first, then .env fallback)
BROKER_URL = settings.broker_url
RESULT_BACKEND = settings.result_backend
DATA_BACKBONE_DIR = settings.data_backbone_dir
LOG_LEVEL = settings.parser_log_level.upper()
WORKER_RESULTS_URL = settings.worker_results_url
PARSER_QUEUES = settings.parser_queues

celery_app = Celery(
    "mineru_worker",
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

queue_names = [q.strip() for q in PARSER_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("PARSER_QUEUES must specify at least one queue name (e.g. 'mineru')")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]


def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\\\") or p.startswith("//"))


def _wait_for_normalized_outputs(layout_paths: list, *, wait_seconds: int = 60, poll_interval: float = 1.0) -> bool:
    """Wait until corresponding <stem>.parser_output.json exists for each <stem>.layout.json path."""
    try:
        deadline = time.time() + max(0, int(wait_seconds))
    except Exception:
        deadline = time.time() + 60

    expected = []
    for lp in layout_paths or []:
        if not isinstance(lp, str):
            continue
        if lp.lower().endswith('.layout.json'):
            expected.append(lp[:-len('.layout.json')] + '.parser_output.json')

    remaining = set(p for p in expected if p)
    while remaining and time.time() < deadline:
        remaining = set(p for p in remaining if not os.path.exists(p))
        if remaining:
            time.sleep(max(0.1, float(poll_interval) if poll_interval else 1.0))
    return not remaining


def parse_pdf_with_mineru(pdf_path: str):
    """Parse PDF using MinerU CLI and return segments.

    Enhanced error handling:
    - Detect specific missing modules (doclayout_yolo, ultralytics).
    - Generic ModuleNotFoundError guidance for other modules.
    - If pipeline fails (non-zero exit) without producing *_middle.json, raise detailed stderr.
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        # Prepare a sitecustomize shim to relax PyTorch weights_only restrictions for trusted checkpoints
        # and allowlist the DocLayout YOLO class used in MinerU.
        shim_dir = tempfile.mkdtemp()
        try:
            sitecustomize_path = os.path.join(shim_dir, 'sitecustomize.py')
            with open(sitecustomize_path, 'w', encoding='utf-8') as sc:
                sc.write(
                    """
import os
try:
    import torch
    from torch.serialization import add_safe_globals
    try:
        # Allowlist YOLOv10DetectionModel used by doclayout_yolo checkpoints
        from doclayout_yolo.nn.tasks import YOLOv10DetectionModel
        add_safe_globals([YOLOv10DetectionModel])
    except Exception:
        # If doclayout_yolo isn't available yet, skip allowlisting here
        pass

    # Optionally force weights_only=False if explicitly allowed
    if settings.mineru_allow_unsafe_torch_load:
        _orig_load = torch.load
        def _patched_load(*args, **kwargs):
            kwargs.setdefault('weights_only', False)
            return _orig_load(*args, **kwargs)
        torch.load = _patched_load
except Exception:
    # Best-effort shim; never break the interpreter startup
    pass
"""
                )

            # Run MinerU CLI with adjusted PYTHONPATH so sitecustomize.py is auto-imported
            cmd = ['mineru', '-p', pdf_path, '-o', temp_dir]
            env = os.environ.copy()
            env['PYTHONPATH'] = shim_dir + (os.pathsep + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
            # Ensure UTF-8 stdout/stderr to avoid Windows cp1252 decode errors
            env.setdefault('PYTHONIOENCODING', 'utf-8')
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                env=env,
            )
        finally:
            # Clean up shim directory
            try:
                # On Windows, ensure file handles are closed before cleanup; tolerate failures
                for fname in ['sitecustomize.py', 'sitecustomize.pyc', '__pycache__']:
                    fpath = os.path.join(shim_dir, fname)
                    if os.path.isdir(fpath):
                        try:
                            import shutil
                            shutil.rmtree(fpath, ignore_errors=True)
                        except Exception:
                            pass
                    elif os.path.exists(fpath):
                        try:
                            os.remove(fpath)
                        except Exception:
                            pass
                # Do not rmdir shim_dir aggressively to avoid race on Windows; it's temporary anyway
                pass
            except Exception:
                pass
        stderr_lower = (result.stderr or '').lower()
        if "no module named 'doclayout_yolo'" in stderr_lower or "no module named \"doclayout_yolo\"" in stderr_lower:
            raise RuntimeError(
                "Missing dependency 'doclayout_yolo' required by MinerU. Install it via: "
                "pip install doclayout-yolo (or doclayout_yolo if hyphenated name not found) and add it to requirements.txt."
            )
        if "no module named 'ultralytics'" in stderr_lower or "no module named \"ultralytics\"" in stderr_lower:
            raise RuntimeError(
                "Missing dependency 'ultralytics' required by MinerU (YOLOv8). Install it via: "
                "pip install ultralytics and add it to workers/Parser/requirements.txt."
            )
        # Detect PyTorch weights_only related failure and explain the shim we applied
        if "weights only load failed" in stderr_lower or "weights_unpickler error" in stderr_lower:
            logger.warning(
                "MinerU encountered a PyTorch weights_only/safe_globals error; applied sitecustomize shim to allowlist YOLOv10DetectionModel and set weights_only=False."
            )
        # Generic catch for other missing modules
        if "module not found" in stderr_lower or "no module named" in stderr_lower:
            # Attempt to extract the module name
            import re
            match = re.search(r"no module named ['\"]([^'\"]+)['\"]", stderr_lower)
            if match:
                missing = match.group(1)
                raise RuntimeError(
                    f"Missing dependency '{missing}' required during MinerU run. Install via: pip install {missing} (verify exact package name) and add to requirements.txt."
                )
        if result.returncode != 0:
            raise RuntimeError(f"MinerU failed (exit {result.returncode}): {result.stderr}")
        # Locate the *_middle.json produced by MinerU (structure can vary)
        pdf_stem = Path(pdf_path).stem
        temp_root = Path(temp_dir)
        candidates = list(temp_root.rglob("*_middle.json"))

        # Heuristics: prefer match with same stem and/or under an 'auto' directory
        def _score(p: Path) -> tuple:
            name_match = int(p.name.lower().startswith(pdf_stem.lower()))
            in_auto = int(p.parent.name.lower() == 'auto' or 'auto' in [x.name.lower() for x in p.parents])
            size = p.stat().st_size if p.exists() else 0
            return (name_match, in_auto, size)

        if not candidates:
            # Provide a helpful error with a snapshot of directory contents
            snapshot = []
            try:
                for d in temp_root.glob('**/*'):
                    if len(snapshot) >= 50:
                        break
                    snapshot.append(str(d))
            except Exception:
                pass
            raise RuntimeError(
                "MinerU parsing produced no *_middle.json files. This typically means a pipeline failure before middle JSON generation. "
                f"Temp dir: {temp_root}. Files (truncated): {snapshot}. Original stderr: {result.stderr}"
            )

        candidates.sort(key=_score, reverse=True)
        middle_json = candidates[0]
        output_dir = middle_json.parent

        with open(middle_json, 'r', encoding='utf-8') as f:
            data = json.load(f)

        segments = []
        for page_idx, page in enumerate(data['pdf_info']):
            for block in page['preproc_blocks']:
                seg_type = block['type']
                bbox = block['bbox']
                if seg_type in ['text', 'title']:
                    text = ''
                    for line in block.get('lines', []):
                        for span in line.get('spans', []):
                            text += span.get('content', '')
                    seg = {
                        'type': 'paragraph' if seg_type == 'text' else 'heading',
                        'page': page_idx + 1,
                        'bbox': bbox,
                        'text': text.strip()
                    }
                elif seg_type == 'table':
                    # Build explicit <table><tr><td> HTML from MinerU line/span structure
                    rows_html = []
                    table_body = block.get('blocks', [{}])[0]
                    for line in table_body.get('lines', []):
                        cells = []
                        for span in line.get('spans', []):
                            # Prefer plain content; fallback to html; always wrap in <td>
                            cell_txt = span.get('content')
                            if cell_txt is None:
                                cell_txt = span.get('html', '')
                            # If html contains tags, keep as-is inside td; else escape
                            val = str(cell_txt)
                            if '<' in val and '>' in val:
                                cells.append(f"<td>{val}</td>")
                            else:
                                cells.append(f"<td>{_html_escape(val)}</td>")
                        rows_html.append('<tr>' + ''.join(cells) + '</tr>')
                    html = '<table>' + ''.join(rows_html) + '</table>'
                    seg = {
                        'type': 'table',
                        'page': page_idx + 1,
                        'bbox': bbox,
                        'text': html
                    }
                else:
                    # Skip other types like image, etc.
                    continue
                segments.append(seg)

        return segments


def _inject_attrs_into_first_table(html: str, attr_str: str) -> str:
    """Inject attributes into the first <table ...> opening tag.

    If injection fails, return original html.
    """
    try:
        # Match the first <table ...> opening tag
        def _repl(m: re.Match) -> str:
            open_tag = m.group(0)
            # If attrs already present, append our attrs before closing '>'
            if attr_str.strip():
                if open_tag.endswith('>'):
                    return open_tag[:-1] + ' ' + attr_str.strip() + '>'
            return open_tag

        return re.sub(r"<table\b[^>]*>", _repl, html, count=1, flags=re.IGNORECASE)
    except Exception:
        return html


def _segment_to_tag(seg: dict) -> str:
    """Render a segment into a simple HTML-like tagged string.
    Types: heading -> <heading>, paragraph -> <paragraph>, table -> <table> (inner HTML if present).
    Includes page and bbox attributes when available.
    """
    s_type = seg.get('type') or 'paragraph'
    page = seg.get('page')
    bbox = seg.get('bbox')
    attrs = []
    if page is not None:
        attrs.append(f'page="{page}"')
    if bbox:
        try:
            bb = tuple(bbox)
            attrs.append(f'bbox="{bb[0]},{bb[1]},{bb[2]},{bb[3]}"')
        except Exception:
            pass
    attr_str = (" " + " ".join(attrs)) if attrs else ""

    raw = seg.get('text') or ""
    if s_type == 'table':
        # If raw already contains a <table>, avoid double wrapping and inject attributes
        raw_s = str(raw)
        if '<table' in raw_s.lower():
            injected = _inject_attrs_into_first_table(raw_s, attr_str.strip()) if attr_str else raw_s
            return injected + "\n"
        # If no HTML, escape and wrap
        inner = raw_s if ('<' in raw_s and '>' in raw_s) else _html_escape(raw_s)
        return f"<table{attr_str}>" + inner + "</table>\n"
    elif s_type == 'heading':
        return f"<heading{attr_str}>" + _html_escape(raw) + "</heading>\n"
    else:
        # paragraph or other text types
        return f"<paragraph{attr_str}>" + _html_escape(raw) + "</paragraph>\n"


def save_layout_files(segments, input_path):
    """Write MinerU segments to <base>.layout.json next to the input.

    - JSON contains the original segments plus a text_tag per segment.
    - Does NOT create any .layout.txt artifacts.
    Returns json_path as string.
    """
    base = Path(input_path).stem
    out_dir = Path(input_path).parent
    json_path = out_dir / f"{base}.layout.json"

    # Enrich JSON with a text_tag field per segment
    enriched = []
    for seg in segments:
        seg_copy = dict(seg)
        tag_line = _segment_to_tag(seg).strip()
        seg_copy['text_tag'] = tag_line
        enriched.append(seg_copy)

    with open(json_path, 'w', encoding='utf-8') as fjson:
        json.dump({'source_file': Path(input_path).name, 'layout': enriched}, fjson, ensure_ascii=False, indent=2)

    return str(json_path)

def parse_image_with_mineru(image_path: str):
    """Process a single-page image by converting it to a temporary single-page PDF
    and running the existing MinerU PDF pipeline. Returns MinerU segments list.
    """
    from PIL import Image
    with tempfile.TemporaryDirectory() as td:
        pdf_path = os.path.join(td, 'page.pdf')
        try:
            im = Image.open(image_path)
            # Ensure RGB or L mode for PDF export
            if im.mode not in ("RGB", "L"):
                im = im.convert("RGB")
            im.save(pdf_path, "PDF")
        except Exception as e:
            raise RuntimeError(f"Failed to convert image to PDF for MinerU: {e}")
        return parse_pdf_with_mineru(pdf_path)


def _render_page_to_tiff(page, dpi: int = 300):
    """Render a single PyMuPDF page to a Pillow Image at given DPI."""
    if fitz is None or Image is None:
        raise RuntimeError("PDF->TIFF conversion requires PyMuPDF (fitz) and Pillow (PIL). Please install both.")
    scale = dpi / 72.0
    mat = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    mode = "RGB" if pix.n >= 3 else "L"
    img = Image.frombytes(mode, [pix.width, pix.height], pix.samples)
    return img


from typing import List
def _pdf_to_tiffs(pdf_path: Path, out_dir: Path, dpi: int = 300, compression: str = "tiff_lzw") -> List[Path]:
    """Split a PDF into per-page TIFFs written into out_dir; returns list of paths."""
    out_dir.mkdir(parents=True, exist_ok=True)
    tiff_paths: List[Path] = []
    try:
        if fitz is None or Image is None:
            raise RuntimeError("PDF->TIFF conversion requires PyMuPDF (fitz) and Pillow (PIL). Please install both.")
        with fitz.open(str(pdf_path)) as doc:
            for i, page in enumerate(doc, start=1):
                img = _render_page_to_tiff(page, dpi=dpi)
                out_path = out_dir / f"page_{i:03d}.tiff"
                try:
                    img.save(out_path, format="TIFF", compression=compression)
                except Exception:
                    img.save(out_path, format="TIFF")
                tiff_paths.append(out_path)
    except Exception as e:
        logger.warning(f"PDF to TIFF conversion issue for {pdf_path}: {e}")
    return tiff_paths


def _normalize_unc_using_backbone(folder_path: str) -> str:
    r"""Normalize UNC hostname to the host from DATA_BACKBONE_DIR when share matches.

    Example: \\AVDGENAIL18-3\DataBackBone\... -> \\10.73.88.101\DataBackBone\...
    """
    try:
        if not folder_path:
            return folder_path
        if not (folder_path.startswith('\\\\') or folder_path.startswith('//')):
            return folder_path

        # Extract remainder after host
        stripped = folder_path.lstrip('\\/')
        parts = stripped.split('\\', 1) if '\\' in stripped else stripped.split('/', 1)
        if not parts:
            return folder_path
        path_rest = parts[1] if len(parts) > 1 else ''

        # Extract host/share from DATA_BACKBONE_DIR
        bb = DATA_BACKBONE_DIR or ''
        bb_stripped = bb.lstrip('\\/')
        bb_parts = bb_stripped.split('\\', 1) if '\\' in bb_stripped else bb_stripped.split('/', 1)
        if not bb_parts:
            return folder_path
        bb_host = bb_parts[0]
        bb_rest = bb_parts[1] if len(bb_parts) > 1 else ''
        share_name = bb_rest.split('\\')[0].split('/')[0] if bb_rest else ''
        incoming_share = path_rest.split('\\')[0].split('/')[0] if path_rest else ''

        if share_name and incoming_share and incoming_share.lower() == share_name.lower():
            new_rest = path_rest
            return f"\\\\{bb_host}\\{new_rest}" if new_rest else f"\\\\{bb_host}"
    except Exception:
        return folder_path
    return folder_path


@celery_app.task(name="mineru_worker.mineru_task")
def mineru_task(task_id, folder_id, parser_config, dag_id, run_id):
    """Process first PDF in folder using MinerU and save layout files.

    Signature matches other parser workers: (task_id, folder_id, parser_config, dag_id, run_id)
    """
    status = "failed"
    error_message = None
    folders = []
    output_files = []

    try:
        if not isinstance(parser_config, dict):
            raise ValueError("parser_config must be a JSON object/dict")
        parser_name = str(parser_config.get("ParserName", "")).strip().lower()
        if parser_name not in {"mineru", "mineru_worker"}:
            raise ValueError("ParserName must be 'mineru' or 'mineru_worker'")

        # Resolve folder path
        eff_folder_id = folder_id  # what we will report back in payload
        if _is_abs_or_unc(folder_id):
            # If backend sent a UNC like \\AVDGENAIL18-3\DataBackBone..., rewrite host to the
            # DATA_BACKBONE_DIR host (e.g., \\10.73.88.101\DataBackBone...).
            folder_path = _normalize_unc_using_backbone(folder_id)
            eff_folder_id = folder_path
        else:
            folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
            # keep eff_folder_id as the relative ID for DB integrity
        if not os.path.isdir(folder_path):
            raise ValueError(f"Folder not found: {folder_path}")

        # Prefer single-page TIFF processing if present; otherwise, convert PDF -> per-page TIFFs here
        tiffs = [f for f in os.listdir(folder_path) if f.lower().endswith(('.tif', '.tiff'))]
        if tiffs:
            # Stream TIFFs: build ONE combined.layout.json (no .txt artifacts).
            # Ensure page numbering increments globally across TIFF sequence instead of each page being 1.
            tiffs.sort()
            pdfs_in_folder = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
            if pdfs_in_folder:
                base_stem = Path(pdfs_in_folder[0]).stem
            else:
                base_stem = "combined"

            combined_json_path = os.path.join(folder_path, f"{base_stem}.layout.json")
            combined_layout = []
            global_page_counter = 1
            for tif_name in tiffs:
                img_path = os.path.join(folder_path, tif_name)
                segs = parse_image_with_mineru(img_path)
                for seg in segs:
                    seg = dict(seg)
                    seg['page'] = global_page_counter
                    seg['text_tag'] = _segment_to_tag(seg).strip()
                    combined_layout.append(seg)
                global_page_counter += 1

            with open(combined_json_path, 'w', encoding='utf-8') as fjson:
                json.dump({'source_file': pdfs_in_folder[0] if pdfs_in_folder else tiffs[0], 'layout': combined_layout}, fjson, ensure_ascii=False, indent=2)

            output_files.append(combined_json_path)
            # Report the original PDF name if present; otherwise the first TIFF as document_name
            if pdfs_in_folder:
                folders.append({"folder_id": eff_folder_id, "document_name": pdfs_in_folder[0]})
            else:
                folders.append({"folder_id": eff_folder_id, "document_name": tiffs[0]})
            status = "success"
        else:
            pdfs = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
            if not pdfs:
                raise ValueError(f"No PDF or TIFF found in folder: {folder_path}")
            pdf_name = pdfs[0]
            pdf_path = Path(folder_path) / pdf_name
            # Convert PDF to per-page TIFFs, then process TIFFs as above and produce a combined .layout.json
            tiff_paths = _pdf_to_tiffs(pdf_path, Path(folder_path))
            if not tiff_paths:
                # Strict behavior: require PDF->TIFF conversion to succeed; do not fall back to direct PDF parsing
                raise RuntimeError("PDF to TIFF conversion produced no pages; ensure PyMuPDF (fitz) and Pillow are installed and the PDF is readable.")
            else:
                base_stem = Path(pdf_name).stem
                combined_json_path = os.path.join(folder_path, f"{base_stem}.layout.json")
                combined_layout = []
                global_page_counter = 1
                for tif_path in sorted(tiff_paths):
                    segs = parse_image_with_mineru(str(tif_path))
                    for seg in segs:
                        seg = dict(seg)
                        seg['page'] = global_page_counter
                        seg['text_tag'] = _segment_to_tag(seg).strip()
                        combined_layout.append(seg)
                    global_page_counter += 1

                with open(combined_json_path, 'w', encoding='utf-8') as fjson:
                    json.dump({'source_file': pdf_name, 'layout': combined_layout}, fjson, ensure_ascii=False, indent=2)

                output_files.append(combined_json_path)
                folders.append({"folder_id": eff_folder_id, "document_name": pdf_name})
                status = "success"

    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error("Exception in mineru_task: %s", error_message, exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": eff_folder_id if _is_abs_or_unc(folder_id) else folder_id,
        "folders": folders,
    }
    # payload minimal; files are written next to inputs for backend normalization
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info("Posting parser results to %s: %s", WORKER_RESULTS_URL, payload)
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error("parser worker-results callback returned HTTP %s: %s", resp.status_code, resp.text)
        else:
            cfg = parser_config if isinstance(parser_config, dict) else {}
            wait_seconds = int(cfg.get("wait_for_normalized_seconds", 60) or 60)
            poll_interval = float(cfg.get("normalized_poll_interval", 1.0) or 1.0)
            if _wait_for_normalized_outputs(output_files, wait_seconds=wait_seconds, poll_interval=poll_interval):
                for p in list(output_files):
                    try:
                        if isinstance(p, str) and p.lower().endswith('.layout.json') and os.path.exists(p):
                            os.remove(p)
                            logger.info("Deleted MinerU layout artifact after normalization: %s", p)
                    except Exception as rm_err:  # noqa: BLE001
                        logger.warning("Failed to delete MinerU layout artifact %s: %s", p, rm_err)
    except Exception as cb_err:  # noqa: BLE001
        logger.error("Failed to POST parser worker results: %s", cb_err, exc_info=True)

    return {
        "task_id": task_id,
        "status": status,
        "output_files": output_files,
        "folders": folders,
        "error": error_message,
    }