from __future__ import annotations

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ParserSettings(BaseSettings):
	model_config = SettingsConfigDict(
		env_file=".env",
		env_file_encoding="utf-8",
		extra="ignore",
	)

	broker_url: str = Field(
		default="pyamqp://guest@localhost//",
		validation_alias=AliasChoices("CELERY_BROKER_URL", "RABBITMQ_URL", "PARSER_BROKER_URL"),
	)
	result_backend: str = Field(
		default="rpc://",
		validation_alias=AliasChoices("CELERY_RESULT_BACKEND", "CELERY_BACKEND_URL", "PARSER_RESULT_BACKEND"),
	)
	data_backbone_dir: str = Field(
		default=r"\\AVDGENAIL18-3\DataBackBone",
		validation_alias=AliasChoices("DATA_BACKBONE_DIR"),
	)
	parser_log_level: str = Field(
		default="INFO",
		validation_alias=AliasChoices("PARSER_LOG_LEVEL", "PARSERLOG_LEVEL", "LOG_LEVEL"),
	)
	worker_results_url: str = Field(
		default="http://localhost:8000/parser/worker-results",
		validation_alias=AliasChoices("WORKER_RESULTS_URL"),
	)
	parser_queues: str = Field(default="parser", validation_alias=AliasChoices("PARSER_QUEUES", "CELERY_QUEUE"))

	db_dsn: str = Field(validation_alias=AliasChoices("DB_DSN", "PARSER_DB_DSN", "DATABASE_URL"))

	ocr_api_url: str = Field(
		default="http://localhost:8884/tesseract",
		validation_alias=AliasChoices("OCR_API_URL"),
	)
	paddle_ocr_api_url: str = Field(
		default="http://localhost:8081/analyze/",
		validation_alias=AliasChoices("PADDLE_OCR_API_URL"),
	)
	unstructured_api_url: str = Field(
		default="http://localhost:7888/general/v0/general",
		validation_alias=AliasChoices("UNSTRUCTURED_API_URL"),
	)

	azure_di_endpoint: str = Field(default="", validation_alias=AliasChoices("AZURE_DI_ENDPOINT"))
	azure_di_key: str = Field(default="", validation_alias=AliasChoices("AZURE_DI_KEY"))
	azure_di_model: str = Field(default="prebuilt-layout", validation_alias=AliasChoices("AZURE_DI_MODEL"))

	profile_decrypt_url: str = Field(default="", validation_alias=AliasChoices("PROFILE_DECRYPT_URL"))
	llama_cloud_profile_name: str = Field(default="", validation_alias=AliasChoices("LLAMA_CLOUD_PROFILE_NAME"))
	llama_cloud_api_url: str = Field(default="", validation_alias=AliasChoices("LLAMA_CLOUD_API_URL"))

	mineru_allow_unsafe_torch_load: bool = Field(
		default=True,
		validation_alias=AliasChoices("MINERU_ALLOW_UNSAFE_TORCH_LOAD"),
	)


settings = ParserSettings()

# Backward-compatible module constants
BROKER_URL = settings.broker_url
RESULT_BACKEND = settings.result_backend
DATA_BACKBONE_DIR = settings.data_backbone_dir
LOG_LEVEL = settings.parser_log_level.upper()
WORKER_RESULTS_URL = settings.worker_results_url
PARSER_QUEUES = settings.parser_queues
DB_DSN = settings.db_dsn
OCR_API_URL = settings.ocr_api_url
PADDLE_OCR_API_URL = settings.paddle_ocr_api_url
UNSTRUCTURED_API_URL = settings.unstructured_api_url
AZURE_DI_ENDPOINT = settings.azure_di_endpoint
AZURE_DI_KEY = settings.azure_di_key
AZURE_DI_MODEL = settings.azure_di_model
PROFILE_DECRYPT_URL = settings.profile_decrypt_url
LLAMA_CLOUD_PROFILE_NAME = settings.llama_cloud_profile_name
LLAMA_CLOUD_API_URL = settings.llama_cloud_api_url
MINERU_ALLOW_UNSAFE_TORCH_LOAD = settings.mineru_allow_unsafe_torch_load


__all__ = [
	"ParserSettings",
	"settings",
	"BROKER_URL",
	"RESULT_BACKEND",
	"DATA_BACKBONE_DIR",
	"LOG_LEVEL",
	"WORKER_RESULTS_URL",
	"PARSER_QUEUES",
	"DB_DSN",
	"OCR_API_URL",
	"PADDLE_OCR_API_URL",
	"UNSTRUCTURED_API_URL",
	"AZURE_DI_ENDPOINT",
	"AZURE_DI_KEY",
	"AZURE_DI_MODEL",
	"PROFILE_DECRYPT_URL",
	"LLAMA_CLOUD_PROFILE_NAME",
	"LLAMA_CLOUD_API_URL",
	"MINERU_ALLOW_UNSAFE_TORCH_LOAD",
]
