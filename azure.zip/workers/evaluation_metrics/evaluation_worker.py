"""Evaluation Metrics Worker

Processes evaluation runs in the background by consuming RabbitMQ tasks.
"""

import logging
import os
import json
import sys
import math
from datetime import datetime
from urllib.parse import quote
from typing import Any, Dict, List, Optional

import requests
from celery import Celery
from config import settings, configure_logging

# Add backend directory to path for local debugging if needed
BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

logger = configure_logging("workers.evaluation_metrics")

celery_app = Celery(
    "evaluation_worker",
    broker=settings.broker_url,
    backend=settings.result_backend,
)

celery_app.conf.task_default_queue = settings.evaluation_queues.split(",")[0].strip()

_deprecated_poll_warned = False


@celery_app.task(name="evaluation_worker.poll_for_runs", bind=True, ignore_result=True)
def poll_for_runs_compat(self) -> Dict[str, str]:
    global _deprecated_poll_warned
    if not _deprecated_poll_warned:
        _deprecated_poll_warned = True
        logger.warning(
            "Received deprecated task 'evaluation_worker.poll_for_runs'; "
            "acknowledging silently after this warning. "
            "Please stop legacy publisher and keep only 'evaluate_api_task'."
        )
    return {"status": "ignored", "reason": "deprecated_task"}

class EvaluationWorker:
    def __init__(self, backend_url: str):
        self.backend_url = backend_url.rstrip("/")
        self.session = requests.Session()
        self.embeddings_api_url = settings.embeddings_api_url
        self.model_name = settings.model_name
        self.similarity_threshold = float(settings.similarity_threshold)
        self.llm_api_url = settings.llm_api_url
        self.llm_model_name = settings.llm_model_name
        self.llm_api_key = settings.llm_api_key
        self.llm_timeout = int(settings.llm_timeout)
        self.answer_matching_enabled = bool(self.embeddings_api_url and self.model_name)
        if self.answer_matching_enabled:
            logger.info("Answer matching enabled (external embeddings API: %s, model: %s)", self.embeddings_api_url, self.model_name)
        else:
            logger.warning("Answer matching disabled (missing EMBEDDINGS_API_URL or MODEL_NAME)")

    def _get_embedding(self, text: str) -> Optional[List[float]]:
        if not text:
            return None

        base_url = (self.embeddings_api_url or "").rstrip("/")
        endpoint_candidates = [base_url]
        if base_url.endswith("/api/embeddings"):
            endpoint_candidates.append(base_url[: -len("/api/embeddings")] + "/api/embed")

        model_candidates = [self.model_name]
        model_hyphen = self.model_name.replace("_", "-")
        if model_hyphen != self.model_name:
            model_candidates.append(model_hyphen)

        timeout = max(30, settings.evaluation_query_timeout)
        last_error_detail: Optional[str] = None

        for endpoint in endpoint_candidates:
            for model_name in model_candidates:
                try:
                    if endpoint.endswith("/api/embed"):
                        payload = {
                            "model": model_name,
                            "input": text,
                        }
                    else:
                        payload = {
                            "model": model_name,
                            "prompt": text,
                            "options": {"embedding_only": True},
                        }

                    response = self.session.post(endpoint, json=payload, timeout=timeout)
                    if response.status_code >= 400:
                        response_excerpt = (response.text or "")[:240]
                        last_error_detail = (
                            f"HTTP {response.status_code} at {endpoint} using model '{model_name}'"
                            f" response={response_excerpt}"
                        )
                        continue

                    data = response.json()
                    embedding: Optional[List[float]] = None

                    if isinstance(data, dict):
                        if isinstance(data.get("embedding"), list):
                            embedding = data.get("embedding")
                        elif isinstance(data.get("embeddings"), list) and data.get("embeddings"):
                            first = data["embeddings"][0]
                            if isinstance(first, list):
                                embedding = first

                    if not isinstance(embedding, list) or not embedding:
                        last_error_detail = (
                            f"No embedding vector in response from {endpoint} using model '{model_name}'"
                        )
                        continue

                    return [float(v) for v in embedding]
                except Exception as exc:
                    last_error_detail = f"{type(exc).__name__} calling {endpoint} model '{model_name}': {exc}"
                    continue

        logger.warning("Embedding API call failed: %s", last_error_detail or "unknown error")
        return None

    @staticmethod
    def _cosine_similarity(vec_a: List[float], vec_b: List[float]) -> Optional[float]:
        if not vec_a or not vec_b:
            return None
        size = min(len(vec_a), len(vec_b))
        if size <= 0:
            return None
        a = vec_a[:size]
        b = vec_b[:size]
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(y * y for y in b))
        if norm_a == 0.0 or norm_b == 0.0:
            return None
        return dot / (norm_a * norm_b)

    def _post(self, path: str, json_body: Optional[Dict[str, Any]] = None, **kwargs) -> Optional[Dict[str, Any]]:
        try:
            url = f"{self.backend_url}{path}"
            resp = self.session.post(url, json=json_body, timeout=kwargs.pop("timeout", 30), **kwargs)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.error("POST %s failed: %s", path, e)
            return None

    @staticmethod
    def _normalize_mode(evaluation_type: Optional[str]) -> str:
        value = (evaluation_type or "").strip().lower()
        if "judge" in value or "llm" in value:
            return "llm_judge"
        return "vector_similarity"

    @staticmethod
    def _normalize_str_list(value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            text = value.strip()
            return [text] if text else []
        if isinstance(value, list):
            result: List[str] = []
            for item in value:
                if item is None:
                    continue
                text = str(item).strip()
                if text:
                    result.append(text)
            return result
        text = str(value).strip()
        return [text] if text else []

    def _compute_vector_similarity_metrics(
        self,
        retrieved_results: List[Dict[str, Any]],
        expected_docs: List[str],
        expected_chunks: Optional[List[str]] = None,
        reference_answer: Optional[str] = None,
    ) -> Dict[str, Any]:
        def _docname_fallback_metrics() -> Dict[str, Any]:
            expected_set = set(expected_docs or [])
            relevant = [doc for doc in doc_ids if doc in expected_set]
            unique_relevant = len(set(relevant))
            precision = float(len(relevant)) / float(len(doc_ids)) if doc_ids else 0.0
            recall = float(unique_relevant) / float(len(expected_set)) if expected_set else 0.0

            mrr = 0.0
            first_pos: Optional[int] = None
            for idx, doc in enumerate(doc_ids, start=1):
                if doc in expected_set:
                    mrr = 1.0 / float(idx)
                    first_pos = idx
                    break

            return {
                "precision": round(precision, 4),
                "recall": round(recall, 4),
                "mrr": round(mrr, 4),
                "coverage": round(recall, 4),
                "first_relevant_position": first_pos,
                "found_expected_doc": bool(relevant),
            }

        doc_ids = [
            (r.get("document_metadata", {}) or {}).get("document_name") or ""
            for r in retrieved_results
        ]
        retrieved_texts = [
            (
                r.get("chunk_text")
                or r.get("text_preview")
                or r.get("text")
                or r.get("content")
                or r.get("page_content")
                or (r.get("document_metadata", {}) or {}).get("chunk_text")
                or (r.get("document_metadata", {}) or {}).get("text")
                or ""
            )
            for r in retrieved_results
        ]

        expected_targets = [str(v) for v in (expected_chunks or []) if str(v).strip()]
        if reference_answer and str(reference_answer).strip():
            expected_targets.append(str(reference_answer).strip())

        metrics: Dict[str, Any] = {
            "mode": "vector_similarity",
            "retrieved_count": len(retrieved_results),
            "expected_chunk_count": len(set(expected_targets)),
            "expected_doc_count": len(set(expected_docs or [])),
            "similarity_threshold": self.similarity_threshold,
        }

        if not retrieved_results:
            metrics.update({
                "precision": 0.0,
                "recall": 0.0,
                "mrr": 0.0,
                "coverage": 0.0,
                "first_relevant_position": None,
                "found_expected_doc": False,
            })
            return metrics

        # Fallback to doc-name exact matching when semantic targets are unavailable
        if not expected_targets:
            metrics.update(_docname_fallback_metrics())
            return metrics

        expected_embeddings: List[List[float]] = []
        for target in expected_targets:
            emb = self._get_embedding(target)
            if emb:
                expected_embeddings.append(emb)

        if not expected_embeddings:
            # If semantic embeddings are unavailable, fallback to doc-name matching when possible.
            if expected_docs:
                metrics.update(_docname_fallback_metrics())
            else:
                metrics.update({
                    "precision": 0.0,
                    "recall": 0.0,
                    "mrr": 0.0,
                    "coverage": 0.0,
                    "first_relevant_position": None,
                    "found_expected_doc": False,
                })
            return metrics

        retrieved_relevant_flags: List[bool] = []
        first_relevant_pos: Optional[int] = None
        matched_expected_idx: set[int] = set()
        successful_retrieved_embeddings = 0

        for idx, text in enumerate(retrieved_texts, start=1):
            emb = self._get_embedding(text) if text else None
            if not emb:
                retrieved_relevant_flags.append(False)
                continue
            successful_retrieved_embeddings += 1

            is_relevant = False
            for e_idx, e_emb in enumerate(expected_embeddings):
                score = self._cosine_similarity(emb, e_emb)
                if score is None:
                    continue
                if score >= self.similarity_threshold:
                    is_relevant = True
                    matched_expected_idx.add(e_idx)

            retrieved_relevant_flags.append(is_relevant)
            if is_relevant and first_relevant_pos is None:
                first_relevant_pos = idx

        relevant_count = sum(1 for flag in retrieved_relevant_flags if flag)

        # If no retrieved chunk could be embedded, fallback to doc-name matching when expected docs exist.
        if successful_retrieved_embeddings == 0 and expected_docs:
            metrics.update(_docname_fallback_metrics())
            return metrics

        precision = float(len(matched_expected_idx)) / float(len(retrieved_results)) if retrieved_results else 0.0
        recall = (
            float(len(matched_expected_idx)) / float(len(expected_embeddings))
            if expected_embeddings
            else 0.0
        )
        mrr = (1.0 / float(first_relevant_pos)) if first_relevant_pos else 0.0

        metrics.update({
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "mrr": round(mrr, 4),
            "coverage": round(recall, 4),
            "first_relevant_position": first_relevant_pos,
            "found_expected_doc": bool(first_relevant_pos),
        })
        return metrics

    def _compute_llm_judge_metrics(
        self,
        *,
        question: str,
        reference_answer: Optional[str],
        expected_chunks: Optional[List[str]],
        expected_documents: List[str],
        retrieved_results: List[Dict[str, Any]],
        generated_answer: str,
    ) -> Dict[str, Any]:
        if not self.llm_api_url or not self.llm_model_name:
            raise RuntimeError("LLM judge mode requires LLM_API_URL and LLM_MODEL_NAME")

        chunks = [
            {
                "position": idx,
                "document_name": (item.get("document_metadata", {}) or {}).get("document_name"),
                "chunk_text": item.get("chunk_text"),
            }
            for idx, item in enumerate(retrieved_results, start=1)
        ]

        prompt = (
            "You are evaluating retrieval quality for a single query. "
            "Return ONLY strict JSON with numeric fields in [0,1]: "
            "precision, recall, mrr, coverage, and optional rationale string.\n\n"
            f"Question: {question}\n"
            f"Reference Answer: {reference_answer or ''}\n"
            f"Expected Chunks: {json.dumps(expected_chunks or [])}\n"
            f"Expected Documents: {json.dumps(expected_documents or [])}\n"
            f"Generated Answer: {generated_answer or ''}\n"
            f"Retrieved Chunks: {json.dumps(chunks, ensure_ascii=False)}\n"
        )

        headers = {}
        if self.llm_api_key:
            headers["Authorization"] = f"Bearer {self.llm_api_key}"

        timeout = max(30, self.llm_timeout)
        response_data: Dict[str, Any]
        llm_url = self.llm_api_url.rstrip("/")

        if llm_url.endswith("/v1/chat/completions"):
            payload = {
                "model": self.llm_model_name,
                "response_format": {"type": "json_object"},
                "messages": [
                    {"role": "system", "content": "Return only valid JSON."},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0,
            }
            resp = self.session.post(llm_url, json=payload, headers=headers or None, timeout=timeout)
            resp.raise_for_status()
            body = resp.json()
            content = (
                (((body.get("choices") or [{}])[0].get("message") or {}).get("content"))
                if isinstance(body, dict)
                else ""
            )
            response_data = json.loads(content) if isinstance(content, str) and content.strip() else {}
        else:
            # Ollama /api/generate style
            payload = {
                "model": self.llm_model_name,
                "prompt": prompt,
                "stream": False,
                "format": "json",
            }
            resp = self.session.post(llm_url, json=payload, headers=headers or None, timeout=timeout)
            resp.raise_for_status()
            body = resp.json()
            raw_response = body.get("response") if isinstance(body, dict) else ""
            response_data = json.loads(raw_response) if isinstance(raw_response, str) and raw_response.strip() else {}

        def _as_score(value: Any) -> float:
            try:
                score = float(value)
            except Exception:
                return 0.0
            return max(0.0, min(1.0, score))

        precision = _as_score(response_data.get("precision"))
        recall = _as_score(response_data.get("recall"))
        mrr = _as_score(response_data.get("mrr"))
        coverage = _as_score(response_data.get("coverage"))

        return {
            "mode": "llm_judge",
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "mrr": round(mrr, 4),
            "coverage": round(coverage, 4),
            "found_expected_doc": precision > 0.0,
            "first_relevant_position": None,
            "judge_model": self.llm_model_name,
            "judge_rationale": response_data.get("rationale"),
        }

    def mark_run_running(self, run_id: str) -> bool:
        data = self._post(f"/search-api/evaluation/worker/run/{run_id}/start")
        return bool(data and data.get("status") == "success")

    def save_query_result(
        self,
        run_id: str,
        query_id: str,
        question: str,
        reference_answer: Optional[str],
        expected_documents: Optional[List[str]],
        retrieved_results: List[Dict[str, Any]],
        query_metrics: Dict[str, Any],
        started_at: Optional[str] = None,
        completed_at: Optional[str] = None,
    ) -> bool:
        payload = {
            "question": question,
            "reference_answer": reference_answer,
            "expected_documents": expected_documents,
            "retrieved_results": retrieved_results,
            "query_metrics": query_metrics,
            "started_at": started_at,
            "completed_at": completed_at,
        }
        data = self._post(
            f"/search-api/evaluation/worker/run/{run_id}/query/{query_id}/complete",
            json_body=payload,
        )
        return bool(data and data.get("status") == "success")

    def mark_query_failed(
        self, 
        run_id: str, 
        query_id: str, 
        question: str,
        reference_answer: Optional[str],
        expected_documents: Optional[List[str]],
        error_message: str,
        started_at: Optional[str] = None,
        completed_at: Optional[str] = None,
    ) -> bool:
        payload = {
            "question": question,
            "reference_answer": reference_answer,
            "expected_documents": expected_documents,
            "error_message": error_message,
            "started_at": started_at,
            "completed_at": completed_at,
        }
        data = self._post(
            f"/search-api/evaluation/worker/run/{run_id}/query/{query_id}/fail",
            json_body=payload,
        )
        return bool(data and data.get("status") == "success")

    def finalize_run(self, run_id: str) -> bool:
        data = self._post(f"/search-api/evaluation/worker/run/{run_id}/finalize")
        return bool(data and data.get("status") == "success")

    def call_search_api(self, api_name: str, question: str, top_k: int = 10) -> Optional[Dict[str, Any]]:
        # Prefer exact mounted route first (URL-encoded), then fallback forms.
        encoded_name = quote(api_name, safe="")
        slug_lower = api_name.replace(" ", "_").lower()
        slug_as_is = api_name.replace(" ", "_")
        candidate_paths = [
            f"/api/{encoded_name}/search",
            f"/api/{slug_as_is}/search",
            f"/api/{slug_lower}/search",
        ]

        last_error: Optional[str] = None
        for path in candidate_paths:
            try:
                url = f"{self.backend_url}{path}"
                payload = {
                    "search_term": question,
                    "limit": top_k,
                    "include_metadata": True,
                }
                resp = self.session.post(url, json=payload, timeout=settings.evaluation_query_timeout)
                if resp.status_code == 404:
                    logger.debug("Search route not found for candidate path: %s", path)
                    last_error = f"404 Not Found: {path}"
                    continue
                resp.raise_for_status()
                data = resp.json()
                api_data = data.get("data") if isinstance(data, dict) and "data" in data else data

                generated_answer = (
                    api_data.get("generated_answer")
                    or api_data.get("answer")
                    or api_data.get("response")
                    or ""
                )
                if not generated_answer:
                    results = api_data.get("results", [])
                    if results:
                        chunks = [r.get("chunk_text", "")[:200] for r in results[:3]]
                        generated_answer = " ".join(chunks)

                api_data["generated_answer"] = generated_answer
                return api_data
            except Exception as e:
                last_error = f"{type(e).__name__} on {path}: {e}"
                continue

        logger.error("Error calling search API for %s after trying all candidate paths: %s", api_name, last_error)
        return None

    def _compute_relevance_metrics(
        self,
        retrieved_results: List[Dict[str, Any]],
        expected_docs: List[str],
    ) -> Dict[str, Any]:
        doc_ids = [
            (r.get("document_metadata", {}) or {}).get("document_name") or ""
            for r in retrieved_results
        ]
        expected_set = set(expected_docs or [])

        metrics: Dict[str, Any] = {
            "retrieved_count": len(retrieved_results),
            "expected_doc_count": len(expected_set),
        }

        relevant = [doc for doc in doc_ids if doc in expected_set]
        num_relevant = len(relevant)
        unique_relevant = len(set(relevant))

        precision = float(num_relevant) / float(len(doc_ids)) if doc_ids else 0.0
        recall = float(unique_relevant) / float(len(expected_set)) if expected_set else 0.0

        metrics["precision"] = round(precision, 4)
        metrics["recall"] = round(recall, 4)

        if expected_set:
            coverage = float(unique_relevant) / float(len(expected_set))
        else:
            coverage = 0.0
        metrics["coverage"] = round(coverage, 4)

        found_any = num_relevant > 0

        mrr = 0.0
        first_pos: Optional[int] = None
        for idx, doc in enumerate(doc_ids, start=1):
            if doc in expected_set:
                mrr = 1.0 / float(idx)
                first_pos = idx
                break
        metrics["mrr"] = round(mrr, 4)
        metrics["first_relevant_position"] = first_pos
        metrics["found_expected_doc"] = found_any
        return metrics

    def _compute_deep_metrics(
        self,
        generated_answer: str,
        reference_answer: str,
    ) -> Dict[str, Any]:
        metrics: Dict[str, Any] = {}
        if not self.answer_matching_enabled:
            return metrics

        if generated_answer and reference_answer:
            try:
                emb_gen = self._get_embedding(generated_answer)
                emb_ref = self._get_embedding(reference_answer)
                if emb_gen is None or emb_ref is None:
                    return metrics
                sim = self._cosine_similarity(emb_gen, emb_ref)
                if sim is None:
                    return metrics
                metrics["semantic_similarity"] = round(float(sim), 4)
                metrics["answer_match_score"] = round(float(sim), 4)
            except Exception as e:
                logger.warning("Failed to compute semantic similarity: %s", e)

        return metrics

@celery_app.task(name="evaluate_api_task", bind=True, max_retries=3, acks_late=True)
def evaluate_api_task(
    self,
    run_id: str,
    api_name: str,
    api_version: int,
    eval_config: Dict[str, Any],
    evaluation_type: Optional[str] = None,
    dataset_folder: Optional[str] = None,
    dataset_path: Optional[str] = None,
):
    logger.info(f"Starting evaluation run {run_id} for API {api_name} (v{api_version})")
    worker = EvaluationWorker(settings.backend_url)
    mode = worker._normalize_mode(evaluation_type)
    
    # Mark run as running
    worker.mark_run_running(run_id)

    resolved_dataset_path = dataset_path
    if dataset_folder:
        resolved_dataset_path = os.path.join(dataset_folder, "dataset.json")

    if not resolved_dataset_path:
        logger.error("Missing dataset location for run %s. Expected dataset_folder or dataset_path", run_id)
        worker.finalize_run(run_id)
        return

    try:
        with open(resolved_dataset_path, "r", encoding="utf-8") as f:
            dataset = json.load(f)
    except Exception as e:
        logger.error(f"Failed to read dataset from {resolved_dataset_path}: {e}")
        worker.finalize_run(run_id)
        return

    for item in dataset:
        query_id = item.get("query_id")
        question = item.get("question")
        reference_answer = item.get("reference_answer") or item.get("answer")
        expected_chunks = worker._normalize_str_list(
            item.get("expected_chunks")
            or item.get("expected_chunk_text")
            or item.get("expected_chunk")
            or item.get("expected_chunk_texts")
        )
        if not expected_chunks and "expected_chunk_text" in item:
            expected_chunks = worker._normalize_str_list(item["expected_chunk_text"])
            
        expected_documents = worker._normalize_str_list(
            item.get("expected_documents")
            or item.get("document_names")
            or item.get("document_name")
            or item.get("expected_document")
        )
        if not expected_documents and "document_name" in item:
            expected_documents = worker._normalize_str_list(item["document_name"])

        logger.info(f"Query {query_id}: Found {len(expected_chunks)} expected chunks and {len(expected_documents)} expected documents from dataset.")

        if not query_id or not question:
            continue

        query_started_at = datetime.utcnow()
        query_started_at_iso = query_started_at.isoformat()

        try:
            api_response = worker.call_search_api(api_name, question)
            query_completed_at_iso = datetime.utcnow().isoformat()
            if not api_response:
                worker.mark_query_failed(
                    run_id,
                    query_id,
                    question,
                    reference_answer,
                    expected_documents,
                    "Search API call failed or returned empty",
                    query_started_at_iso,
                    query_completed_at_iso,
                )
                continue

            retrieved_results = api_response.get("results", [])
            generated_answer = api_response.get("generated_answer", "")

            if mode == "llm_judge":
                metrics = worker._compute_llm_judge_metrics(
                    question=question,
                    reference_answer=reference_answer,
                    expected_chunks=expected_chunks,
                    expected_documents=expected_documents,
                    retrieved_results=retrieved_results,
                    generated_answer=generated_answer,
                )
            else:
                metrics = worker._compute_vector_similarity_metrics(
                    retrieved_results,
                    expected_documents,
                    expected_chunks,
                    reference_answer,
                )
                if reference_answer and generated_answer:
                    deep_metrics = worker._compute_deep_metrics(
                        generated_answer,
                        reference_answer,
                    )
                    metrics.update(deep_metrics)

            worker.save_query_result(
                run_id,
                query_id,
                question,
                reference_answer,
                expected_documents,
                retrieved_results,
                metrics,
                query_started_at_iso,
                query_completed_at_iso,
            )
        except Exception as e:
            logger.exception(f"Error processing query {query_id}")
            query_completed_at_iso = datetime.utcnow().isoformat()
            worker.mark_query_failed(
                run_id,
                query_id,
                question,
                reference_answer,
                expected_documents,
                str(e),
                query_started_at_iso,
                query_completed_at_iso,
            )

    # Finalize run
    worker.finalize_run(run_id)
    logger.info(f"Completed evaluation run {run_id}")

