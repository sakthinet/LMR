"""Configuration for the evaluation metrics worker.

Runtime precedence:
1) Real environment variables (Kubernetes/App Service/host process)
2) Local `.env` file for development convenience
"""

from __future__ import annotations

import logging

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict


class EvaluationSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    backend_url: str = Field(
        validation_alias=AliasChoices("BACKEND_URL", "EVALUATION_BACKEND_URL")
    )
    broker_url: str = Field(
        validation_alias=AliasChoices("EVALUATION_BROKER_URL", "CELERY_BROKER_URL", "RABBITMQ_URL")
    )
    result_backend: str = Field(
        default="rpc://",
        validation_alias=AliasChoices("EVALUATION_RESULT_BACKEND", "CELERY_RESULT_BACKEND"),
    )
    evaluation_queues: str = Field(
        default="evaluation",
        validation_alias=AliasChoices("EVALUATION_QUEUES"),
    )
    evaluation_query_timeout: int = Field(
        default=60,
        validation_alias=AliasChoices("EVALUATION_QUERY_TIMEOUT"),
    )
    evaluation_worker_id: str = Field(
        default="default",
        validation_alias=AliasChoices("EVALUATION_WORKER_ID"),
    )
    embeddings_api_url: str = Field(
        validation_alias=AliasChoices("EMBEDDINGS_API_URL", "EVALUATION_EMBEDDINGS_API_URL"),
    )
    model_name: str = Field(
        validation_alias=AliasChoices("MODEL_NAME", "EVALUATION_MODEL_NAME"),
    )
    similarity_threshold: float = Field(
        default=0.75,
        validation_alias=AliasChoices("EVALUATION_SIMILARITY_THRESHOLD", "SIMILARITY_THRESHOLD"),
    )
    llm_api_url: str = Field(
        default="",
        validation_alias=AliasChoices("LLM_API_URL", "EVALUATION_LLM_API_URL"),
    )
    llm_model_name: str = Field(
        default="",
        validation_alias=AliasChoices("LLM_MODEL_NAME", "EVALUATION_LLM_MODEL_NAME"),
    )
    llm_api_key: str = Field(
        default="",
        validation_alias=AliasChoices("LLM_API_KEY", "EVALUATION_LLM_API_KEY"),
    )
    llm_timeout: int = Field(
        default=60,
        validation_alias=AliasChoices("EVALUATION_LLM_TIMEOUT", "LLM_TIMEOUT"),
    )
    log_level: str = Field(default="INFO", validation_alias=AliasChoices("EVALUATION_LOG_LEVEL"))

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return env_settings, dotenv_settings, init_settings, file_secret_settings


settings = EvaluationSettings()

# Backward-compatible constants
BACKEND_URL: str = settings.backend_url
BROKER_URL: str = settings.broker_url
RESULT_BACKEND: str = settings.result_backend
EVALUATION_QUEUES: str = settings.evaluation_queues
EVALUATION_QUERY_TIMEOUT: int = settings.evaluation_query_timeout
EVALUATION_WORKER_ID: str = settings.evaluation_worker_id
EMBEDDINGS_API_URL: str = settings.embeddings_api_url
MODEL_NAME: str = settings.model_name
SIMILARITY_THRESHOLD: float = settings.similarity_threshold
LLM_API_URL: str = settings.llm_api_url
LLM_MODEL_NAME: str = settings.llm_model_name
LLM_API_KEY: str = settings.llm_api_key
LLM_TIMEOUT: int = settings.llm_timeout
LOG_LEVEL: str = settings.log_level.upper()


def configure_logging(name: str = "workers.evaluation_metrics") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    try:
        logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
    except Exception:
        logger.setLevel(logging.INFO)
    return logger


__all__ = [
    "EvaluationSettings",
    "settings",
    "BACKEND_URL",
    "BROKER_URL",
    "RESULT_BACKEND",
    "EVALUATION_QUEUES",
    "EVALUATION_QUERY_TIMEOUT",
    "EVALUATION_WORKER_ID",
    "EMBEDDINGS_API_URL",
    "MODEL_NAME",
    "SIMILARITY_THRESHOLD",
    "LLM_API_URL",
    "LLM_MODEL_NAME",
    "LLM_API_KEY",
    "LLM_TIMEOUT",
    "LOG_LEVEL",
    "configure_logging",
]
