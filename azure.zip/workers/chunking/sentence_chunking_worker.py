import os
import json
import psycopg2
from celery import Celery
from dotenv import load_dotenv
from datetime import datetime
import spacy
import re
from typing import Any, Dict, List, Optional
import logging
import requests

# Load local .env to allow worker config per-folder
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"), override=True)

# Require env vars (no fallbacks)
def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for sentence_chunking_worker")
    return val

DB_DSN = os.getenv("DB_DSN") or os.getenv("DATABASE_URL")
if DB_DSN:
    DB_DSN = DB_DSN.replace("+asyncpg", "")
else:
    raise RuntimeError("Environment variable 'DB_DSN' or 'DATABASE_URL' is required for sentence_chunking_worker")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")
BROKER_URL = os.getenv("CHUNKING_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("CHUNKING_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
LOG_LEVEL = (os.getenv("CHUNKING_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")

logger = logging.getLogger("sentence_chunking_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:
    logger.setLevel(logging.INFO)

celery_app = Celery('sentence_chunking_worker', broker=BROKER_URL, backend=RESULT_BACKEND)

# Ensure spaCy model is available
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    from spacy.cli import download  # type: ignore
    download("en_core_web_sm")
    nlp = spacy.load("en_core_web_sm")


def update_task_status(task_id, status, started_at=None, completed_at=None):
    """Best-effort status update into processing_tasks.

    If the table is missing (e.g. running chunking workers against a
    separate database), log and continue without failing the task.
    """
    try:
        conn = psycopg2.connect(DB_DSN)
        cur = conn.cursor()
        if status == "running":
            cur.execute(
                """
                UPDATE processing_tasks SET status = %s, started_at = %s WHERE id = %s
                """,
                (status, started_at, task_id),
            )
        elif status == "success" or status == "failed":
            cur.execute(
                """
                UPDATE processing_tasks SET status = %s, completed_at = %s WHERE id = %s
                """,
                (status, completed_at, task_id),
            )
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        # Missing table or other DB error should not break the worker.
        try:
            logger.warning(f"update_task_status skipped due to DB error: {e}")
        except Exception:
            pass


def _strip_tags(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s or "")


def _find_layout_segments(data: Any) -> Optional[List[Dict[str, Any]]]:
    """Best-effort detection of layout segments in a JSON structure.

    This is a simplified version of the logic used by the semantic
    chunking worker: it looks for a list of dicts that contain
    keys like "text" / "text_tag" / "type".
    """

    def looks_like_segments(val: Any) -> bool:
        if not isinstance(val, list) or not val or not isinstance(val[0], dict):
            return False
        keys = set(val[0].keys())
        return bool(keys & {"text", "text_tag", "type"})

    if isinstance(data, dict):
        for key in ("layout", "segments", "items", "elements", "data"):
            cand = data.get(key)
            if looks_like_segments(cand):
                return cand  # type: ignore[return-value]
        for v in data.values():
            found = _find_layout_segments(v)
            if found:
                return found
    elif isinstance(data, list):
        if looks_like_segments(data):
            return data  # type: ignore[return-value]
        for it in data:
            found = _find_layout_segments(it)
            if found:
                return found
    return None


def _load_layout_segments(folder_path: str) -> Optional[List[Dict[str, Any]]]:
    """Load the first JSON file that contains layout-like segments, if any."""
    json_files = [f for f in os.listdir(folder_path) if f.lower().endswith(".json")]
    for jf in sorted(json_files):
        path = os.path.join(folder_path, jf)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fp:
                data = json.load(fp)
        except Exception:
            continue
        segments = _find_layout_segments(data)
        if not segments:
            continue
        return segments
    return None


def _read_best_effort_text(folder_path: str) -> str:
    """Read text for chunking, preferring layout-style JSON then plain .txt.

    - If a JSON file with layout-like segments is present, flatten its
      segments' text into a single string.
    - Otherwise fall back to the first .txt file in the folder.
    """

    # Prefer layout-style JSON
    json_files = [f for f in os.listdir(folder_path) if f.lower().endswith(".json")]
    for jf in sorted(json_files):
        path = os.path.join(folder_path, jf)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fp:
                data = json.load(fp)
        except Exception:
            continue
        segments = _find_layout_segments(data)
        if not segments:
            continue
        parts: List[str] = []
        for seg in segments:
            if not isinstance(seg, dict):
                continue
            txt = seg.get("text") or seg.get("text_tag") or ""
            if isinstance(txt, str):
                txt = txt.strip()
            else:
                txt = str(txt).strip()
            if txt:
                parts.append(txt)
        if parts:
            return "\n\n".join(parts)

    # Fallback: first .txt file (previous behaviour)
    txt_files = [f for f in os.listdir(folder_path) if f.lower().endswith(".txt")]
    if not txt_files:
        raise FileNotFoundError("No .json or .txt file found in folder")
    txt_path = os.path.join(folder_path, sorted(txt_files)[0])
    with open(txt_path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def _build_sentence_chunks_from_layout(
    segments: List[Dict[str, Any]],
    sentences_per_chunk: int,
) -> List[Dict[str, Any]]:
    """Build element-aware sentence chunks from layout segments.

    - Non-table segments are split into sentences and grouped into chunks of
      up to ``sentences_per_chunk`` sentences.
    - If all sentences in a chunk come from the same source element, emit a
      single element with ``original_elements`` pointing back to that id.
    - If multiple elements contribute, emit a ``GroupedElement`` with
      ``original_elements`` listing contributing element ids.
    - Table segments are never split and always form their own dedicated
      chunk (using their raw tagged text when available).
    """

    import uuid as _uuid

    # Buffer of sentence units with attached source metadata
    buffer: List[Dict[str, Any]] = []
    chunks: List[Dict[str, Any]] = []

    # Track how many chunks have been emitted per source element id
    per_element_counts: Dict[str, int] = {}

    def flush_all_buffer() -> None:
        nonlocal buffer
        while buffer:
            take = buffer[:sentences_per_chunk]
            buffer = buffer[sentences_per_chunk:]
            if not take:
                break
            chunk_text = " ".join(u["text"] for u in take if u.get("text"))
            if not chunk_text:
                continue

            # Collect distinct contributing element ids in order
            element_ids: List[str] = []
            for u in take:
                eid = str(u.get("element_id") or "")
                if eid and (not element_ids or element_ids[-1] != eid):
                    element_ids.append(eid)
            if not element_ids:
                continue

            if len(element_ids) == 1:
                sid = element_ids[0]
                base = take[0]
                per_element_counts[sid] = per_element_counts.get(sid, 0) + 1
                elem_id = f"{sid}-{per_element_counts[sid]}"
                elem = {
                    "element_id": elem_id,
                    "type": str(base.get("type") or "paragraph").lower(),
                    "text": chunk_text,
                    "original_elements": str(sid),
                    "page": base.get("page"),
                    "bbox": base.get("bbox"),
                    "source": base.get("source"),
                    "kv_pairs": base.get("kv_pairs") if isinstance(base.get("kv_pairs"), list) else [],
                    "table_summary": base.get("table_summary") or {},
                }
            else:
                first = take[0]
                elem = {
                    "element_id": _uuid.uuid4().hex,
                    "type": "GroupedElement",
                    "text": chunk_text,
                    "original_elements": ",".join(element_ids),
                    "page": first.get("page"),
                    "bbox": None,
                    "source": first.get("source"),
                    "kv_pairs": [],
                    "table_summary": {},
                }

            chunks.append({
                "chunk_text": {"element": [elem]},
                "embed_text": chunk_text,
            })

    for seg in segments:
        if not isinstance(seg, dict):
            continue
        seg_type = str(seg.get("type", "paragraph")).lower()
        element_id = seg.get("element_id") or seg.get("id") or seg.get("elementId") or ""
        page = seg.get("page")
        bbox = seg.get("bbox")
        source = seg.get("source")
        kv_pairs = seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else []
        table_summary = seg.get("table_summary")

        if seg_type == "table":
            # Flush any pending sentence-based chunks before emitting table chunk
            flush_all_buffer()
            raw_table = seg.get("text_tag") or seg.get("text") or ""
            if not isinstance(raw_table, str):
                raw_table = str(raw_table)
            plain = _strip_tags(raw_table).strip()
            elem = {
                "element_id": str(element_id),
                "type": "table",
                "text": raw_table,
                "original_elements": str(element_id),
                "page": page,
                "bbox": bbox,
                "source": source,
                "kv_pairs": kv_pairs,
                "table_summary": table_summary or {},
            }
            chunks.append({
                "chunk_text": {"element": [elem]},
                "embed_text": plain,
            })
            continue

        raw_text = seg.get("text")
        if raw_text is None or (isinstance(raw_text, str) and not raw_text.strip()):
            raw_text = seg.get("text_tag") or ""
        if not isinstance(raw_text, str):
            raw_text = str(raw_text)
        plain = raw_text.strip()
        if not plain:
            continue

        doc = nlp(plain)
        for sent in doc.sents:
            s_txt = sent.text.strip()
            if not s_txt:
                continue
            buffer.append({
                "text": s_txt,
                "element_id": str(element_id),
                "type": seg_type,
                "page": page,
                "bbox": bbox,
                "source": source,
                "kv_pairs": kv_pairs,
                "table_summary": table_summary or {},
            })

    # Flush any remaining sentences into one or more chunks
    flush_all_buffer()
    return chunks


def spacy_sentence_chunking(folder_id, sentences_per_chunk):
    folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
    # Ensure a sensible minimum
    try:
        sentences_per_chunk = int(sentences_per_chunk)
    except Exception:
        sentences_per_chunk = 1
    if sentences_per_chunk <= 0:
        sentences_per_chunk = 1

    layout_segments = _load_layout_segments(folder_path)

    # Import lazily to avoid unnecessary overhead when not chunking
    import uuid as _uuid

    if layout_segments:
        # Layout-aware path: emit grouped-element style chunks like semantic/fixed workers,
        # including a per-chunk chunk_id just like semantic_chunking_worker.
        chunk_objs = _build_sentence_chunks_from_layout(layout_segments, sentences_per_chunk)
        for idx, obj in enumerate(chunk_objs):
            payload = {"chunk_id": str(_uuid.uuid4()), **obj}
            chunk_path = os.path.join(folder_path, f"chunk{idx}.json")
            with open(chunk_path, 'w', encoding='utf-8') as cf:
                json.dump(payload, cf, ensure_ascii=False, indent=2)
        return len(chunk_objs)

    # Fallback: plain-text path when no layout metadata is available.
    # To stay consistent with semantic-style chunk layout, we also emit
    # chunk_id + chunk_text/element + embed_text here (with a synthetic element).
    chunks_plain: List[str] = []
    text = _read_best_effort_text(folder_path)
    doc = nlp(text)
    sentences = [sent.text.strip() for sent in doc.sents if sent.text and sent.text.strip()]
    for i in range(0, len(sentences), sentences_per_chunk):
        chunk = " ".join(sentences[i:i + sentences_per_chunk]).strip()
        if not chunk:
            continue
        chunks_plain.append(chunk)

    for idx, chunk in enumerate(chunks_plain):
        element_id = f"{folder_id}-sentence-chunk-{idx}"
        elem = {
            "element_id": element_id,
            "type": "paragraph",
            "text": chunk,
            "original_elements": element_id,
            "page": None,
            "bbox": None,
            "source": None,
            "kv_pairs": [],
            "table_summary": {},
        }
        payload = {
            "chunk_id": str(_uuid.uuid4()),
            "chunk_text": {"element": [elem]},
            "embed_text": chunk,
        }
        chunk_path = os.path.join(folder_path, f"chunk{idx}.json")
        with open(chunk_path, 'w', encoding='utf-8') as cf:
            json.dump(payload, cf, ensure_ascii=False, indent=2)
    return len(chunks_plain)


@celery_app.task(name="sentence_chunking_worker.sentence_chunking_task")
def sentence_task(task_id, folder_id, chunking_config, dag_id, run_id):
    """Sentence-based chunking over layout or plain text.

    Args mirror other chunking workers so this task can be scheduled
    in the same way as semantic/fixedcharacter chunkers:
      - task_id: UUID task id
      - folder_id: data backbone folder
      - chunking_config: dict with SentencePerChunk or similar keys
      - dag_id: upstream process name
      - run_id: upstream job id
    """

    status = "failed"
    error_message: Optional[str] = None
    num_chunks = 0

    try:
        cfg = chunking_config if isinstance(chunking_config, dict) else {}
        # Accept multiple casings/aliases for the sentence batch size
        spc_val = (
            cfg.get("SentencesPerChunk")
            or cfg.get("sentences_per_chunk")
            or cfg.get("Sentences")
            or cfg.get("SentenceBatchSize")
            or cfg.get("sentence_batch_size")
        )
        if spc_val is None:
            sentences_per_chunk = 5
        else:
            try:
                sentences_per_chunk = int(spc_val)
            except Exception:
                sentences_per_chunk = 5

        num_chunks = spacy_sentence_chunking(folder_id, sentences_per_chunk)
        status = "success"
    except Exception as e:
        error_message = str(e)
        logger.error(f"Exception in sentence_chunking_task: {error_message}", exc_info=True)

    # Report results back to API gateway, consistent with other workers
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "num_chunks": num_chunks,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting sentence chunking results to {WORKER_RESULTS_URL}: {payload}")
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error(
                f"sentence_chunking worker-results callback returned HTTP {resp.status_code}: {resp.text}"
            )
    except Exception as cb_err:
        logger.error(f"Failed to POST sentence_chunking worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "num_chunks": num_chunks,
        "error": error_message,
    }
