import os
import json
import logging
import time
from typing import List, Sequence, Tuple, Dict, Any, Optional

from celery import Celery
from kombu import Queue
import requests

# ---------------- Env & Logging -----------------

def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for recursive_chunking_worker")
    return val


# Required configuration
BROKER_URL = os.getenv("CHUNKING_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("CHUNKING_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")
LOG_LEVEL = (os.getenv("CHUNKING_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")  # e.g. http://localhost:8000/chunking/worker-results
WORKER_RESULTS_TOKEN = os.getenv("WORKER_RESULTS_TOKEN")  # optional Bearer token
CHUNKING_QUEUES = _req("CHUNKING_QUEUES")  # e.g. "recursive_chunking"

logger = logging.getLogger("recursive_chunking_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:  # noqa: BLE001
    logger.setLevel(logging.INFO)

# --------------- Celery App ----------------
celery_app = Celery(
    'chunking_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

# Configure queues from env (comma-separated)
queue_names = [q.strip() for q in CHUNKING_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("CHUNKING_QUEUES must specify at least one queue name (e.g. 'recursive_chunking')")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]


# ---------------- Helpers -----------------

def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\") or p.startswith("//"))


def _read_first_text_file(folder_path: str) -> str:
    txt_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.txt')]
    if not txt_files:
        raise FileNotFoundError("No .txt file found in folder")
    txt_path = os.path.join(folder_path, txt_files[0])
    with open(txt_path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()
    if "\uFFFD" in content:
        logger.warning("Input contained undecodable bytes; replacement characters were inserted.")
    return content


def _find_layout_segments(data: Any) -> Optional[List[Dict[str, Any]]]:
    """Best-effort detection of layout segments in a JSON structure.

    Looks for a list of dicts that contain common layout keys like
    "text" / "text_tag" / "type".
    """

    def looks_like_segments(val: Any) -> bool:
        if not isinstance(val, list) or not val or not isinstance(val[0], dict):
            return False
        keys = set(val[0].keys())
        return bool(keys & {"text", "text_tag", "type"})

    if isinstance(data, dict):
        for key in ("layout", "segments", "items", "elements", "data", "parser_output"):
            cand = data.get(key)
            if looks_like_segments(cand):
                return cand  # type: ignore[return-value]
        for v in data.values():
            found = _find_layout_segments(v)
            if found:
                return found
    elif isinstance(data, list):
        if looks_like_segments(data):
            return data  # type: ignore[return-value]
        for it in data:
            found = _find_layout_segments(it)
            if found:
                return found
    return None


def _read_best_effort_text(folder_path: str) -> str:
    """Read text for chunking, preferring layout-style JSON then plain .txt.

    - If a JSON file with layout-like segments is present, flatten its
      segments' text into a single string.
    - Otherwise fall back to the first .txt file in the folder.
    """

    json_files = [f for f in os.listdir(folder_path) if f.lower().endswith(".json")]
    for jf in sorted(json_files):
        path = os.path.join(folder_path, jf)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fp:
                data = json.load(fp)
        except Exception:
            continue
        segments = _find_layout_segments(data)
        if not segments:
            continue
        parts: List[str] = []
        for seg in segments:
            if not isinstance(seg, dict):
                continue
            txt = seg.get("text") or seg.get("text_tag") or ""
            if isinstance(txt, str):
                txt = txt.strip()
            else:
                txt = str(txt).strip()
            if txt:
                parts.append(txt)
        if parts:
            return "\n\n".join(parts)

    # Fallback: original behaviour on plain text
    return _read_first_text_file(folder_path)


def _delete_old_chunk_files(folder_path: str) -> None:
    for f in os.listdir(folder_path):
        if f.startswith("chunk") and f.endswith(".json"):
            try:
                os.remove(os.path.join(folder_path, f))
            except Exception:
                pass


def _write_chunks(folder_path: str, chunks: List[str], doc_id: str) -> None:
    """Write per-chunk files using a semantic-style layout.

    Each chunk file contains:
      - chunk_id: UUID for the chunk
      - chunk_text: {"element": [single synthetic element]}
      - embed_text: plain text for embeddings

    Recursive chunking works over flattened text, so we emit one
    synthetic paragraph element per chunk while keeping the schema
    compatible with semantic_chunking_worker.
    """
    import uuid as _uuid

    _delete_old_chunk_files(folder_path)
    for idx, chunk in enumerate(chunks):
        chunk_path = os.path.join(folder_path, f"chunk{idx}.json")
        element_id = f"{doc_id}-chunk-{idx}"
        elem = {
            "element_id": element_id,
            "type": "paragraph",
            "text": chunk,
            "original_elements": element_id,
            "page": None,
            "bbox": None,
            "source": None,
            "kv_pairs": [],
            "table_summary": {},
        }
        payload = {
            "chunk_id": str(_uuid.uuid4()),
            "chunk_text": {"element": [elem]},
            "embed_text": chunk,
        }
        with open(chunk_path, "w", encoding="utf-8") as cf:
            json.dump(payload, cf, ensure_ascii=False, indent=2)


def _write_chunks_array(
    folder_path: str,
    chunk_items: List[Tuple[int, List[int], str]],
) -> None:
    """Write an aggregated chunks.json array with desired metadata.

    Each item: (chunk_id, sentence_indices, text)
    """
    out = []
    for cid, sent_ids, text in chunk_items:
        out.append({
            "chunk_id": cid,
            "sentences": sent_ids,
            "text": text,
        })
    agg_path = os.path.join(folder_path, "chunks.json")
    with open(agg_path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)


def _parse_separators(val) -> List[str]:
    """Accept list or comma-separated string; provide sensible defaults.

    Default order is coarse-to-fine: paragraphs -> lines -> sentences -> words -> fallback.
    """
    if isinstance(val, list):
        seps = [str(x) for x in val]
    elif isinstance(val, str) and val.strip():
        import codecs
        parts = [p.strip() for p in val.split(',')]
        seps = [codecs.decode(p, 'unicode_escape') for p in parts]
    else:
        seps = ["\n\n", "\n", ". ", " "]
    # Ensure unique order, keep as provided
    out = []
    for s in seps:
        if s not in out:
            out.append(s)
    return out


# ---------------- Text utilities -----------------

def _normalize_sentence_spacing(text: str) -> str:
    """Insert a space after sentence enders when followed by a letter/quote/paren.

    Preserves ellipses ("...") and handles Unicode quotes.
    Example: 'ugly.Explicit' -> 'ugly. Explicit'
    """
    import re
    if not text:
        return ""
    text = text.replace("…", "...")  # normalize ellipsis
    # Add space after ., !, ? optionally followed by a closing quote/paren, if next char is non-space
    pattern = re.compile(r"(?<!\.)"          # not part of an ellipsis
                         r"([.!?])"           # sentence ender
                         r"([\"'’)”\]])?"  # optional closing punctuation
                         r"(?=(\S))")       # followed by non-space
    return pattern.sub(lambda m: (m.group(1) + (m.group(2) or "") + " "), text)

_ABBREVS = set(
    """
    mr mrs ms dr prof sr jr vs e g i e etc fig figs eq eqs no nos al
    jan feb mar apr may jun jul aug sep sept oct nov dec
    """.split()
)


def _split_into_sentences(text: str) -> List[str]:
    """Rule-based sentence splitter with simple abbreviation & decimal guards.

    Keeps end punctuation attached to the sentence.
    """
    import re
    if not text:
        return []
    parts: List[str] = []
    start = 0
    # match an ender (., !, ?) with any closing quotes/parens, followed by whitespace
    pattern = re.compile(r'[.!?](["’”\)\]]+)?\s+')
    for m in pattern.finditer(text):
        end = m.end()
        span = text[start:end].strip()
        if not span:
            start = end
            continue
        tail = span.split()[-1].rstrip('\"’”)')
        low = tail.strip().strip('.').lower()
        # guard abbreviations like e.g., Dr., etc. and decimals like 3.14
        if low in _ABBREVS or re.search(r'\d\.\d$', tail):
            continue
        parts.append(span)
        start = end
    rest = text[start:].strip()
    if rest:
        parts.append(rest)
    return parts


def _units_by_paragraph_then_sentence(text: str) -> List[List[str]]:
    paras = [p.strip() for p in text.split("\n\n") if p.strip()]
    return [_split_into_sentences(p) for p in paras]


# ---------------- Recursive Split (fallback path) -----------------

def _split_once(text: str, sep: str) -> List[str]:
    if not sep:
        return [text]
    return text.split(sep)


def _recursive_partition(text: str, separators: Sequence[str], max_size: int) -> List[str]:
    """Recursively partition text strictly using provided separators.

    Rules:
    - Only split at explicit separator boundaries.
    - If a segment remains larger than max_size after exhausting separators, return it intact (no character slicing).
    """
    if len(text) <= max_size:
        return [text]

    for i, sep in enumerate(separators):
        if not sep:
            continue
        parts = _split_once(text, sep)
        if len(parts) == 1:  # separator not found
            continue
        out: List[str] = []
        for part in parts:
            part = part.strip()
            if not part:
                continue
            if len(part) <= max_size:
                out.append(part)
            else:
                rest = separators[i+1:] if i + 1 < len(separators) else []
                sub = _recursive_partition(part, rest, max_size)
                out.extend(sub)
        if out:
            return out

    # No separator produced smaller segments; return whole text untouched.
    return [text]


def _merge_with_overlap(pieces: List[str], chunk_size: int, overlap: int) -> List[str]:
    if chunk_size <= 0:
        raise ValueError("ChunkSize must be > 0")
    if overlap < 0:
        raise ValueError("ChunkOverlap must be >= 0")
    if overlap >= chunk_size:
        overlap = 0

    def _preferred_cut_point(s: str, size: int) -> int:
        """Pick a cut point at/near size on a natural boundary to avoid mid-word splits."""
        if len(s) <= size:
            return len(s)
        preferred = set(" \t\r\n,.;:!?)]}")
        back_start = max(0, size - 80)
        for idx in range(size, back_start, -1):
            if s[idx - 1] in preferred:
                return idx
        fwd_end = min(len(s), size + 40)
        for idx in range(size, fwd_end):
            if s[idx] in preferred:
                return idx + 1
        return size

    chunks: List[str] = []
    current = ""
    for piece in pieces:
        if not piece:
            # treat empty string as a hard fencepost (paragraph boundary)
            if current:
                chunks.append(current)
                current = ""
            continue
        if not current:
            current = piece
        elif len(current) + 1 + len(piece) <= chunk_size:
            joiner = " " if (current and piece and not current.endswith(" ") and not piece.startswith(" ")) else ""
            current = current + joiner + piece
        else:
            if len(current) > chunk_size:
                while len(current) > chunk_size:
                    cut = _preferred_cut_point(current, chunk_size)
                    chunks.append(current[:cut].rstrip())
                    if overlap > 0:
                        start = max(0, cut - overlap)
                        current = current[start:]
                    else:
                        current = current[cut:]
                if not current:
                    current = piece
                elif len(current) + 1 + len(piece) <= chunk_size:
                    joiner = " " if (current and piece and not current.endswith(" ") and not piece.startswith(" ")) else ""
                    current = current + joiner + piece
                else:
                    chunks.append(current)
                    current = piece
            else:
                chunks.append(current)
                if overlap > 0:
                    prefix = current[-overlap:]
                    current = prefix + piece
                    while len(current) > chunk_size:
                        cut = _preferred_cut_point(current, chunk_size)
                        chunks.append(current[:cut].rstrip())
                        start = max(0, cut - overlap)
                        current = current[start:]
                else:
                    current = piece

    if current:
        while len(current) > chunk_size:
            cut = _preferred_cut_point(current, chunk_size)
            chunks.append(current[:cut].rstrip())
            if overlap > 0:
                start = max(0, cut - overlap)
                current = current[start:]
            else:
                current = current[cut:]
        if current:
            chunks.append(current)

    # Final guard to ensure no outliers remain
    out: List[str] = []
    for c in chunks:
        if len(c) <= chunk_size:
            out.append(c)
        else:
            start = 0
            while start < len(c):
                if (len(c) - start) <= chunk_size:
                    out.append(c[start:])
                    break
                cut = _preferred_cut_point(c[start:], chunk_size)
                out.append(c[start:start + cut].rstrip())
                start = start + cut
    return out


# ---------------- Chunking Logic -----------------

def recursive_chunking(
    folder_id: str,
    chunk_size: int,
    chunk_overlap: int,
    separators_conf,
    *,
    strict_separators: bool = True,
    normalize_sentence_spaces: bool = True,
    write_array_file: bool = False,
    overlap_sentences: int = 0,
) -> int:
    # Resolve folder path
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
        doc_id = os.path.basename(os.path.normpath(folder_path)) or folder_id
    else:
        folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
        doc_id = folder_id
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    text = _read_best_effort_text(folder_path)
    if normalize_sentence_spaces:
        text = _normalize_sentence_spacing(text)

    separators = _parse_separators(separators_conf)

    # Choose units: paragraph → sentences pipeline when sentence separator is requested
    use_sentence_units = any(sep.strip() in (".", ". ") for sep in separators)

    # Unify overlap policy to avoid double-overlap surprises
    if use_sentence_units and strict_separators:
        # sentence-level overlap only
        char_overlap = 0
    else:
        # char-level overlap only
        overlap_sentences = 0
        char_overlap = int(chunk_overlap)

    if use_sentence_units:
        para_sents = _units_by_paragraph_then_sentence(text)
        # Flatten with paragraph fenceposts as empty strings
        units: List[str] = []
        for ps in para_sents:
            units.extend(ps if ps else [])
            units.append("")  # fencepost
        if units and units[-1] == "":
            units.pop()
    else:
        units = _recursive_partition(text, separators, chunk_size)

    chunk_texts: List[str] = []
    sentence_map: List[List[int]] = []

    if use_sentence_units and strict_separators:
        cur_texts: List[str] = []
        cur_ids: List[int] = []
        sid = 0
        for sent in units:
            if sent == "":  # paragraph fencepost → flush
                if cur_texts:
                    final_text = " ".join(cur_texts).strip()
                    if not chunk_texts or final_text != chunk_texts[-1]:
                        chunk_texts.append(final_text)
                        sentence_map.append(cur_ids[:])
                    cur_texts, cur_ids = [], []
                continue

            sid += 1
            candidate = (" ".join(cur_texts + [sent])).strip()
            if cur_texts and len(candidate) > chunk_size:
                final_text = " ".join(cur_texts).strip()
                if not chunk_texts or final_text != chunk_texts[-1]:
                    chunk_texts.append(final_text)
                    sentence_map.append(cur_ids[:])
                # carry sentence overlap
                if overlap_sentences > 0 and len(cur_texts) > 0:
                    keep_ids = cur_ids[-overlap_sentences:]
                    keep_sents = cur_texts[-overlap_sentences:]
                    cur_texts = keep_sents + [sent]
                    cur_ids = keep_ids + [sid]
                else:
                    cur_texts = [sent]
                    cur_ids = [sid]
            else:
                cur_texts.append(sent)
                cur_ids.append(sid)
        if cur_texts:
            final_text = " ".join(cur_texts).strip()
            if not chunk_texts or final_text != chunk_texts[-1]:
                chunk_texts.append(final_text)
                sentence_map.append(cur_ids[:])
    else:
        # Fallback to character-window merging with soft boundaries and paragraph fenceposts
        chunk_texts = _merge_with_overlap(units, chunk_size, char_overlap)
        sentence_map = [[] for _ in chunk_texts]

    # Write per-chunk files using semantic-style schema
    _write_chunks(folder_path, chunk_texts, doc_id)

    return len(chunk_texts)


# --------------- Callback helper -----------------

def _post_with_retry(url: str, payload: dict, token: str | None = None, retries: int = 3, backoff: float = 2.0) -> bool:
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    for attempt in range(1, retries + 1):
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=30)
            if resp.status_code < 300:
                return True
            logger.error(f"worker-results HTTP {resp.status_code}: {resp.text}")
        except Exception as e:  # noqa: BLE001
            logger.error(f"POST attempt {attempt} failed: {e}")
        time.sleep(backoff ** attempt)
    return False


# --------------- Task ----------------------
@celery_app.task(name="recursive_chunking_worker.recursive_chunking_task")
def recursive_chunking_task(task_id, folder_id, chunking_config, dag_id, run_id):
    """Chunk text using recursive separators and POST results to API.

    Args:
        task_id: UUID task id
        folder_id: UUID/absolute folder where input .txt resides
        chunking_config: dict with ChunkingStrategy, ChunkSize, ChunkOverlap, Separators (list or comma-separated string)
        dag_id: upstream process name
        run_id: upstream job id
    """
    status = "failed"
    error_message = None
    num_chunks = 0

    try:
        cfg = chunking_config if isinstance(chunking_config, dict) else {}
        size_val = (
            cfg.get("ChunkSize")
            or cfg.get("chunk_size")
            or cfg.get("size")
            or cfg.get("chunksize")
        )
        overlap_val = (
            cfg.get("ChunkOverlap")
            or cfg.get("chunk_overlap")
            or cfg.get("overlap")
            or 0
        )
        separators_val = (
            cfg.get("Separators")
            or cfg.get("separators")
            or cfg.get("delimiter_list")
        )

        if size_val is None:
            raise ValueError("ChunkSize is required in ChunkingConfig")

        chunk_size = int(size_val)
        chunk_overlap = int(overlap_val)
        if chunk_size <= 0:
            raise ValueError("ChunkSize must be > 0")
        if chunk_overlap < 0:
            raise ValueError("ChunkOverlap must be >= 0")

        num_chunks = recursive_chunking(
            folder_id,
            chunk_size,
            chunk_overlap,
            separators_val,
            strict_separators=bool(cfg.get("StrictSeparatorMode", True)),
            normalize_sentence_spaces=bool(cfg.get("NormalizeSentenceSpaces", True)),
            write_array_file=bool(cfg.get("WriteArrayFile", False)),
            overlap_sentences=int(cfg.get("OverlapSentences", 0)),
        )
        status = "success"
    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error(f"Exception in recursive_task: {error_message}", exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "num_chunks": num_chunks,
    }
    if error_message:
        payload["error_message"] = error_message
    try:
        logger.info(f"Posting chunking results to {WORKER_RESULTS_URL}: {payload}")
        ok = _post_with_retry(WORKER_RESULTS_URL, payload, token=WORKER_RESULTS_TOKEN)
        if not ok:
            logger.error("Failed to POST chunking worker results after retries")
    except Exception as cb_err:  # noqa: BLE001
        logger.error(f"Failed to POST chunking worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "num_chunks": num_chunks,
        "error": error_message,
    }
