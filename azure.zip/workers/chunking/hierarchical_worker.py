import os
import json
import logging
from typing import List, Dict, Any, Optional, Tuple
from celery import Celery
from dotenv import load_dotenv
from kombu import Queue
import requests
import re
from html import unescape as _html_unescape

# ---------------- Env & Logging -----------------
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"), override=True)

def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for hierarchical_worker")
    return val

BROKER_URL = os.getenv("CHUNKING_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("CHUNKING_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")
LOG_LEVEL = (os.getenv("CHUNKING_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")
CHUNKING_QUEUES = _req("CHUNKING_QUEUES")

logger = logging.getLogger("hierarchical_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:
    logger.setLevel(logging.INFO)

# --------------- Celery App ----------------
celery_app = Celery(
    "hierarchical_worker",
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

queue_names = [q.strip() for q in CHUNKING_QUEUES.split(",") if q.strip()]
if not queue_names:
    raise RuntimeError("CHUNKING_QUEUES must specify at least one queue name (e.g. 'hierarchical')")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]

# ---------------- Helpers -----------------

def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\") or p.startswith("//"))

def _strip_tags(s: str) -> str:
    return _html_unescape(re.sub(r"<[^>]+>", "", s or ""))

_H_TAG_RE = re.compile(r"<\s*h([1-6])\b", re.IGNORECASE)

def _detect_heading_level(seg: Dict[str, Any]) -> Optional[int]:
    """
    Return heading level 1-6 if the segment looks like a heading/title, else None.
    Priority:
      1) explicit <h1>..</h1> tags in text_tag
      2) type naming patterns (h1, heading_2, header3, title -> default level 1/2)
    """
    tagged = seg.get("text_tag") or seg.get("text_tagged") or ""
    if isinstance(tagged, str):
        m = _H_TAG_RE.search(tagged)
        if m:
            try:
                return int(m.group(1))
            except Exception:
                pass

    t = str(seg.get("type", "")).strip().lower()

    # direct types like "h1", "h2"
    m2 = re.match(r"^h([1-6])$", t)
    if m2:
        return int(m2.group(1))

    # patterns like "heading_1", "heading1", "header2"
    m3 = re.match(r"^(heading|header)[\s_\-]*([1-6])$", t)
    if m3:
        return int(m3.group(2))

    # common title/heading types without level -> assume level 1 (or 2 if you prefer)
    if t in {"title", "heading", "header"}:
        return 1

    return None


def _find_layout_segments(data: Any) -> Optional[List[Dict[str, Any]]]:
    def looks_like_segments(val: Any) -> bool:
        if not isinstance(val, list) or not val or not isinstance(val[0], dict):
            return False
        keys = set(val[0].keys())
        return bool(keys & {"text", "text_tag", "type", "content", "bbox", "page"})

    if isinstance(data, dict):
        for key in ("layout", "segments", "items", "elements", "data", "parser_output"):
            cand = data.get(key)
            if looks_like_segments(cand):
                return cand  # type: ignore[return-value]
        for v in data.values():
            found = _find_layout_segments(v)
            if found:
                return found
    elif isinstance(data, list):
        if looks_like_segments(data):
            return data  # type: ignore[return-value]
        for it in data:
            found = _find_layout_segments(it)
            if found:
                return found
    return None


def _read_layout_or_parser_output(folder_path: str) -> Tuple[List[Dict[str, Any]], str]:
    json_files = sorted([f for f in os.listdir(folder_path) if f.lower().endswith(".json")])
    if not json_files:
        raise FileNotFoundError("No .json files found in folder")

    priority: List[str] = []
    others: List[str] = []
    for f in json_files:
        lf = f.lower()
        if lf.endswith(".layout.json") or lf.endswith(".parser_output.json"):
            priority.append(f)
        else:
            others.append(f)

    for fname in priority + others:
        path = os.path.join(folder_path, fname)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as fh:
                data = json.load(fh)
            segments = _find_layout_segments(data)
            if segments:
                return segments, fname
        except Exception:
            continue

    raise FileNotFoundError("No valid layout/parser output JSON found in folder")


def _normalize_segments(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Normalize segments for downstream chunking.
    Adds:
      - heading_level: 1..6 if heading else None
      - is_heading: bool
    """
    norm: List[Dict[str, Any]] = []
    for idx, seg in enumerate(items):
        if not isinstance(seg, dict):
            continue

        seg_type = str(seg.get("type", "paragraph")).lower()
        element_id = seg.get("element_id") or seg.get("id") or seg.get("elementId") or idx

        tagged = seg.get("text_tag") or seg.get("text_tagged")
        if tagged is None or tagged == "":
            tagged = seg.get("text") or ""
        if not isinstance(tagged, str):
            tagged = str(tagged)

        plain = seg.get("text")
        if plain is None or (isinstance(plain, str) and plain.strip() == ""):
            plain = _strip_tags(tagged)
        if not isinstance(plain, str):
            plain = str(plain)

        heading_level = _detect_heading_level({"type": seg_type, "text_tag": tagged})
        is_heading = heading_level is not None

        norm.append(
            {
                "type": seg_type,
                "page": seg.get("page"),
                "bbox": seg.get("bbox"),
                "element_id": element_id,
                "source": seg.get("source"),
                "kv_pairs": seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
                "table_summary": seg.get("table_summary") or {},
                "text_tag": tagged,
                "text": plain,
                "heading_level": heading_level,
                "is_heading": is_heading,
            }
        )
    return norm


def _write_chunks(folder_path: str, chunks: List[Dict[str, Any]]) -> None:
    """Write per-chunk files using the same layout as semantic_chunking_worker.

    Each chunk file contains:
      - chunk_id: UUID for the chunk
      - chunk_text: {"element": [...]} (built upstream)
      - embed_text: plain text for embeddings
    """
    import uuid as _uuid

    for idx, chunk_data in enumerate(chunks):
        chunk_path = os.path.join(folder_path, f"chunk{idx}.json")
        payload = {"chunk_id": str(_uuid.uuid4()), **chunk_data}
        with open(chunk_path, "w", encoding="utf-8") as cf:
            json.dump(payload, cf, ensure_ascii=False, indent=2)


def _build_section_tree(
    segments: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """
    Build a hierarchy of sections using heading levels.
    Returns a flat list of section nodes, each node has:
      - title
      - level
      - path_titles
      - elements (non-heading segments)
    """
    sections: List[Dict[str, Any]] = []

    # Stack entries: {"level": int, "title": str, "path_titles": List[str]}
    stack: List[Dict[str, Any]] = []

    def current_path_titles() -> List[str]:
        return [s["title"] for s in stack if s.get("title")]

    # Start with a default root section (level 0)
    stack.append({"level": 0, "title": "ROOT", "path_titles": ["ROOT"]})
    current_section = {
        "title": "ROOT",
        "level": 0,
        "path_titles": ["ROOT"],
        "elements": [],
    }
    sections.append(current_section)

    for seg in segments:
        text = (seg.get("text") or "").strip()
        if not text:
            continue

        if seg.get("is_heading"):
            lvl = int(seg.get("heading_level") or 1)
            title = _strip_tags(seg.get("text_tag") or seg.get("text") or "").strip() or "Untitled"

            # Pop until parent level < this heading level
            while stack and stack[-1]["level"] >= lvl:
                stack.pop()
            stack.append({"level": lvl, "title": title, "path_titles": current_path_titles() + [title]})

            path_titles = current_path_titles()  # includes ROOT + ancestors + this title
            # Create a new section node
            current_section = {
                "title": title,
                "level": lvl,
                "path_titles": path_titles,
                "elements": [],
                "heading": {
                    "text": title,
                    "page": seg.get("page"),
                    "bbox": seg.get("bbox"),
                    "element_id": seg.get("element_id"),
                    "type": seg.get("type"),
                },
            }
            sections.append(current_section)
            continue

        # Non-heading segments go into current section
        current_section["elements"].append(seg)

    return sections


def _build_hierarchical_chunks(
    segments: List[Dict[str, Any]],
    *,
    max_chunk_size: int,
    doc_id: str,
    strategy: str = "hierarchical",
) -> List[Dict[str, Any]]:
    """Hierarchy-aware chunking that matches semantic_chunking_worker output schema.

    - Output chunks contain only: chunk_text.element[] + embed_text
    - If a chunk includes multiple source elements, emit a single GroupedElement with original_elements.
    - Tables are unsplittable and always emitted as a single-element chunk.
    - Tags are kept inside element['text'] (when source provides text_tag).
    """
    if max_chunk_size <= 0:
        raise ValueError("max_chunk_size must be > 0")

    sections = _build_section_tree(segments)

    chunks: List[Dict[str, Any]] = []
    assigned_tables: set = set()

    def _seg_id(seg: Dict[str, Any], fallback: Any) -> str:
        return str(seg.get("element_id") or seg.get("id") or seg.get("elementId") or fallback)

    def _seg_type(seg: Dict[str, Any]) -> str:
        return str(seg.get("type", "paragraph")).lower()

    def _seg_text_tag(seg: Dict[str, Any]) -> str:
        val = seg.get("text_tag") or seg.get("text_tagged") or seg.get("text") or ""
        return val if isinstance(val, str) else str(val)

    def _seg_plain(seg: Dict[str, Any]) -> str:
        raw_tag = seg.get("text_tag") or seg.get("text_tagged")
        raw_text = seg.get("text")
        if isinstance(raw_tag, str) and raw_tag:
            return _strip_tags(raw_tag)
        return (raw_text or "") if isinstance(raw_text, str) else str(raw_text or "")

    def _make_element_for_single(seg: Dict[str, Any], *, element_id: str, seg_type: str, text: str) -> Dict[str, Any]:
        return {
            "element_id": element_id,
            "type": seg_type,
            "text": text,
            "original_elements": str(element_id),
            "page": seg.get("page"),
            "bbox": seg.get("bbox"),
            "source": seg.get("source"),
            "kv_pairs": seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
            "table_summary": seg.get("table_summary") or {},
        }

    def _flush_composite(buf_segs: List[Dict[str, Any]], buf_ids: List[str], *, section_path: Optional[List[str]] = None) -> None:
        if not buf_segs:
            return

        import uuid as _uuid

        # Combine using plain text for embedding; keep tags only inside element text if needed.
        combined_plain = "\n".join([_seg_plain(s) for s in buf_segs if _seg_plain(s)])

        if len(buf_segs) == 1:
            s = buf_segs[0]
            sid = buf_ids[0]
            element = _make_element_for_single(s, element_id=sid, seg_type=_seg_type(s), text=_seg_plain(s))
        else:
            # GroupedElement: put breadcrumb tags into text if requested
            group_text = combined_plain
            if section_path:
                titles = [t for t in section_path if t and t != "ROOT"]
                if titles:
                    breadcrumb = " > ".join(titles)
                    # Tags INSIDE the chunk_text element text (not top-level)
                    group_text = f"<section path=\"{breadcrumb}\">\n" + group_text + "\n</section>"

            first = buf_segs[0]
            element = {
                "element_id": _uuid.uuid4().hex,
                "type": "GroupedElement",
                "text": group_text,
                "original_elements": ",".join(buf_ids),
                "page": first.get("page"),
                "bbox": None,
                "source": first.get("source"),
                "kv_pairs": [],
                "table_summary": {},
            }

        chunks.append({
            "chunk_text": {"element": [element]},
            "embed_text": combined_plain,
        })

    for sec in sections:
        elements = sec.get("elements") or []
        if not elements:
            continue

        buf_segs: List[Dict[str, Any]] = []
        buf_ids: List[str] = []
        buf_words = 0

        def flush_buf() -> None:
            nonlocal buf_segs, buf_ids, buf_words
            _flush_composite(buf_segs, buf_ids, section_path=sec.get("path_titles"))
            buf_segs = []
            buf_ids = []
            buf_words = 0

        for idx, seg in enumerate(elements):
            seg_type = _seg_type(seg)
            sid = _seg_id(seg, idx)

            raw_tag = _seg_text_tag(seg)
            plain = _seg_plain(seg).strip()
            if not plain:
                continue

            if seg_type == "table":
                if sid in assigned_tables:
                    continue
                # Close any open composite and emit table as its own chunk.
                flush_buf()
                assigned_tables.add(sid)

                elem = _make_element_for_single(seg, element_id=sid, seg_type="table", text=raw_tag)
                chunks.append({
                    "chunk_text": {"element": [elem]},
                    "embed_text": _strip_tags(raw_tag),
                })
                continue

            words = len(plain.split())
            would = buf_words + words
            if buf_segs and would > max_chunk_size:
                flush_buf()

            buf_segs.append(seg)
            buf_ids.append(sid)
            buf_words += words

        flush_buf()

    return chunks


# ---------------- Chunking Logic -----------------

def hierarchical_chunking(folder_id: str, max_chunk_size: int) -> int:
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
        doc_id = os.path.basename(os.path.normpath(folder_path)) or folder_id
    else:
        folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
        doc_id = folder_id

    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    raw_segments, _source_file = _read_layout_or_parser_output(folder_path)
    segments = _normalize_segments(raw_segments)

    final_chunks = _build_hierarchical_chunks(
        segments,
        max_chunk_size=max_chunk_size,
        doc_id=doc_id,
        strategy="hierarchical",
    )
    _write_chunks(folder_path, final_chunks)
    return len(final_chunks)


# --------------- Task ----------------------
@celery_app.task(name="hierarchical_worker.hierarchical_task")
def hierarchical_task(task_id, folder_id, chunking_config, dag_id, run_id):
    status = "failed"
    error_message = None
    num_chunks = 0

    try:
        cfg = chunking_config if isinstance(chunking_config, dict) else {}
        max_size_val = cfg.get("MaxChunkSize") or cfg.get("max_chunk_size") or 500
        max_chunk_size = int(max_size_val)
        if max_chunk_size <= 0:
            raise ValueError("MaxChunkSize must be > 0")

        num_chunks = hierarchical_chunking(folder_id, max_chunk_size)
        status = "success"
    except Exception as e:
        error_message = str(e)
        logger.error(f"Exception in hierarchical_task: {error_message}", exc_info=True)

    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "num_chunks": num_chunks,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting chunking results to {WORKER_RESULTS_URL}: {payload}")
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error(f"chunking worker-results callback returned HTTP {resp.status_code}: {resp.text}")
    except Exception as cb_err:
        logger.error(f"Failed to POST chunking worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "num_chunks": num_chunks,
        "error": error_message,
    }
