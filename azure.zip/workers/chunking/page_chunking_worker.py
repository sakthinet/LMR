import os
import json
import logging
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path

from celery import Celery
from kombu import Queue
from dotenv import load_dotenv
import requests

# ---------------- Env & Logging -----------------
# Load .env from this folder (override to prefer local values)
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"), override=True)


def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for page_chunking_worker")
    return val


BROKER_URL = os.getenv("CHUNKING_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("CHUNKING_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")  # e.g. http://localhost:8000/chunking/worker-results
LOG_LEVEL = (os.getenv("CHUNKING_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()
CHUNKING_QUEUES = os.getenv("CHUNKING_QUEUES", "page_chunking,runtime_page_chunking")

logger = logging.getLogger("page_chunking_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:  # noqa: BLE001
    logger.setLevel(logging.INFO)

# --------------- Celery App ----------------
celery_app = Celery(
    'chunking_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

queue_names = [q.strip() for q in CHUNKING_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("CHUNKING_QUEUES must specify at least one queue name (e.g. 'page_chunking')")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]


# ---------------- Helpers -----------------

def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\") or p.startswith("//"))


def _resolve_folder(folder_id: str) -> str:
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
    else:
        folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")
    return folder_path


def _read_layout_or_parser_output(folder_path: str) -> Tuple[List[dict], str, str]:
    """Locate and load a layout-style JSON or parser_output JSON file.

    Preference order:
      1. *.layout.json (expects root dict with 'layout' list or acceptable alternatives)
      2. *.parser_output.json (expects dict with 'parser_output' list or raw list)

    Returns:
        (segments_list, filename, mode) where mode is 'layout' or 'parser_output'.
    """
    # 1. Try layout JSON
    layout_candidates = sorted([
        f for f in os.listdir(folder_path) if f.lower().endswith('.layout.json')
    ])
    if layout_candidates:
        fname = layout_candidates[0]
        path = os.path.join(folder_path, fname)
        with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
            data = json.load(fh)
        segments: Optional[List[dict]] = None
        if isinstance(data, dict):
            # direct 'layout' key
            if isinstance(data.get('layout'), list):
                segments = data['layout']
            else:
                # Alternate keys
                for k in ('segments', 'items', 'elements', 'data', 'pages', 'blocks'):
                    if isinstance(data.get(k), list):
                        segments = data[k]
                        break
        elif isinstance(data, list):
            segments = data  # treat root list as segments
        if segments is None:
            raise ValueError(f"Unrecognized layout JSON structure in {fname}")
        return segments, fname, 'layout'

    # 2. Fallback to parser_output.json
    parser_candidates = sorted([
        f for f in os.listdir(folder_path) if f.lower().endswith('.parser_output.json')
    ])
    if parser_candidates:
        fname = parser_candidates[0]
        path = os.path.join(folder_path, fname)
        with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
            data = json.load(fh)
        if isinstance(data, dict) and isinstance(data.get('parser_output'), list):
            return data['parser_output'], fname, 'parser_output'
        if isinstance(data, list):
            return data, fname, 'parser_output'
        raise ValueError(f"Unexpected parser_output file schema in {fname}")

    raise FileNotFoundError("No *.layout.json or *.parser_output.json found in folder")


def _extract_page(it: dict, default: Optional[int] = None) -> Optional[int]:
    """Extract page number from a segment/item using common keys.

    Accepts keys: 'page', 'page_num', 'pageNumber'. Returns int or default.
    """
    for k in ('page', 'page_num', 'pageNumber'):
        pg = it.get(k)
        if isinstance(pg, int):
            return pg
        if isinstance(pg, str) and pg.isdigit():
            return int(pg)
    return default


def _inner_from_text_tag(tag_val: str) -> str:
    """Extract inner text from a simple <tag>...</tag> structure; fallback to original string.
    Keeps tables untouched (returns full tag block for tables)."""
    if not isinstance(tag_val, str):
        return str(tag_val)
    s = tag_val.strip()
    if s.lower().startswith('<table'):
        return s  # preserve table HTML
    m = None
    try:
        m = __import__('re').match(r"^<([a-zA-Z]+)[^>]*>([\s\S]*?)</\1>$", s)
    except Exception:
        pass
    if m:
        return m.group(2).strip()
    return s


def _group_text_by_page(items: List[dict], prefer_text_tag: bool) -> Dict[int, List[Dict[str, Any]]]:
    """Group segments by page, preserving element metadata.

    Returns a mapping page_num -> list of segment dicts with at least:
      - element_id
      - text (cleaned body)
      - page / bbox / source / kv_pairs / table_summary
    """
    pages: Dict[int, List[Dict[str, Any]]] = {}
    inferred_page = 1
    for idx, it in enumerate(items):
        try:
            pg = _extract_page(it, default=None)
            if pg is None:
                pg = inferred_page
            txt_source: Any
            if prefer_text_tag and isinstance(it.get('text_tag'), str) and it.get('text_tag').strip():
                txt_source = _inner_from_text_tag(it.get('text_tag'))
            else:
                txt_source = it.get('text') or ''
            if not isinstance(txt_source, str):
                txt_source = str(txt_source)
            cleaned = txt_source.strip()
            if not cleaned:
                continue

            seg_id = it.get('element_id') or it.get('id') or it.get('elementId') or f"page-{pg}-seg-{idx}"
            seg: Dict[str, Any] = {
                "element_id": seg_id,
                "text": cleaned,
                "page": pg,
                "bbox": it.get('bbox'),
                "source": it.get('source'),
                "kv_pairs": it.get('kv_pairs') if isinstance(it.get('kv_pairs'), list) else [],
                "table_summary": it.get('table_summary') or {},
            }
            pages.setdefault(pg, []).append(seg)
        except Exception:
            continue
    return pages


def _write_page_chunks(folder_path: str, pages: Dict[int, List[Dict[str, Any]]]) -> int:
    """Write per-page chunks using the semantic-style schema.

    Each chunk file contains:
      - chunk_id: UUID for the chunk
      - chunk_text: {"element": [single GroupedElement]}
      - embed_text: full page text

    original_elements holds the comma-separated ids of all contributing
    layout segments for that page, matching the semantic/fixed workers.
    """
    import uuid as _uuid

    count = 0
    for idx, page_num in enumerate(sorted(pages.keys())):
        segs = pages[page_num]
        texts = [s.get("text") for s in segs if isinstance(s.get("text"), str) and s.get("text").strip()]
        body = "\n\n".join(texts).strip()
        if not body:
            continue

        out_path = os.path.join(folder_path, f"chunk{idx}.json")

        orig_ids = []
        for s in segs:
            eid = s.get("element_id")
            if eid is not None:
                eid_str = str(eid)
                if eid_str not in orig_ids:
                    orig_ids.append(eid_str)

        element = {
            "element_id": _uuid.uuid4().hex,
            "type": "GroupedElement",
            "text": body,
            "original_elements": ",".join(orig_ids),
            "page": page_num,
            "bbox": None,
            "source": None,
            "kv_pairs": [],
            "table_summary": {},
            "num_segments": len(texts),
        }
        payload = {
            "chunk_id": str(_uuid.uuid4()),
            "chunk_text": {"element": [element]},
            "embed_text": body,
        }
        with open(out_path, 'w', encoding='utf-8') as cf:
            json.dump(payload, cf, ensure_ascii=False, indent=2)
        count += 1
    return count


# --------------- Task ----------------------
@celery_app.task(name="page_chunking_worker.page_chunking_task")
def page_chunking_task(task_id, folder_id, chunking_config, dag_id, run_id):
    """Page-level chunking: one chunk per page from parser_output.json.

    Args (from backend):
        task_id: UUID task id
        folder_id: absolute/UNC runtime folder or relative under DATA_BACKBONE_DIR
        chunking_config: dict (unused for now)
        dag_id: upstream process name
        run_id: upstream job id
    """
    status = "failed"
    error_message: Optional[str] = None
    num_chunks = 0

    try:
        folder_path = _resolve_folder(folder_id)
        items, filename, mode = _read_layout_or_parser_output(folder_path)
        logger.info(f"[page_chunking] Using {mode} file '{filename}' with {len(items)} segments/items in '{folder_path}'")
        # Prefer text_tag when available (layout mode or segments containing text_tag)
        prefer_text_tag = any(isinstance(it.get('text_tag'), str) and it.get('text_tag').strip() for it in items)
        page_map = _group_text_by_page(items, prefer_text_tag=prefer_text_tag)
        num_chunks = _write_page_chunks(folder_path, page_map)
        status = "success"
    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error(f"Exception in page_chunking_task: {error_message}", exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "num_chunks": num_chunks,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting chunking results to {WORKER_RESULTS_URL}: {payload}")
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error(f"chunking worker-results callback returned HTTP {resp.status_code}: {resp.text}")
    except Exception as cb_err:  # noqa: BLE001
        logger.error(f"Failed to POST chunking worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "num_chunks": num_chunks,
        "error": error_message,
    }
