import os
import json
import logging
from copy import deepcopy
from typing import List, Dict, Any, Optional
from celery import Celery
from dotenv import load_dotenv
from kombu import Queue
import requests

# ---------------- Env & Logging -----------------
# Load .env from this folder (override to prefer local values)
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"), override=True)

# Strict env helper
def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for byelements_worker")
    return val

# Required configuration
BROKER_URL = os.getenv("CHUNKING_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("CHUNKING_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")
LOG_LEVEL = (os.getenv("CHUNKING_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")
CHUNKING_QUEUES = _req("CHUNKING_QUEUES")

logger = logging.getLogger("byelements_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:  # noqa: BLE001
    logger.setLevel(logging.INFO)

# --------------- Celery App ----------------
celery_app = Celery(
    'byelements_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

# Configure queues from env (comma-separated)
queue_names = [q.strip() for q in CHUNKING_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("CHUNKING_QUEUES must specify at least one queue name (e.g. 'byelements')")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]

# ---------------- Helpers -----------------

def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\") or p.startswith("//"))

def _read_first_layout_file(folder_path: str) -> List[Dict[str, Any]]:
    """Mimic fixedcharacters pattern: pick FIRST suitable layout file and return elements.

    Order of preference:
    1. First .jsonl file (one JSON object per line)
    2. First .json file (either list[dict] or { elements: [...] })
    3. Fallback: input.txt (single Text element) for runtime testing only.
    """
    entries = sorted(os.listdir(folder_path))
    for name in entries:
        lower = name.lower()
        path = os.path.join(folder_path, name)
        if lower.endswith('.jsonl'):
            logger.info(f"Using layout file (jsonl): {name}")
            out: List[Dict[str, Any]] = []
            with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                        if isinstance(obj, dict):
                            obj = dict(obj)
                            obj['raw_json'] = line
                            out.append(obj)
                    except json.JSONDecodeError:
                        logger.warning(f"Skipping invalid JSONL line in {name}")
            return out
        if lower.endswith('.json'):
            logger.info(f"Using layout file (json): {name}")
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
                    data = json.load(fh)
            except json.JSONDecodeError as exc:
                logger.error(f"Failed parsing {name}: {exc}")
                continue
            if isinstance(data, list):
                out: List[Dict[str, Any]] = []
                for d in data:
                    if isinstance(d, dict):
                        obj = dict(d)
                        try:
                            obj['raw_json'] = json.dumps(d, ensure_ascii=False)
                        except Exception:
                            pass
                        out.append(obj)
                return out
            if isinstance(data, dict):
                if isinstance(data.get('elements'), list):
                    out: List[Dict[str, Any]] = []
                    for d in data['elements']:
                        if isinstance(d, dict):
                            obj = dict(d)
                            try:
                                obj['raw_json'] = json.dumps(d, ensure_ascii=False)
                            except Exception:
                                pass
                            out.append(obj)
                    return out
                obj = dict(data)
                try:
                    obj['raw_json'] = json.dumps(data, ensure_ascii=False)
                except Exception:
                    pass
                return [obj]

    # Fallback: try to parse input.txt as JSONL (one element per line); if none parse, treat as plain text
    txt_path = os.path.join(folder_path, 'input.txt')
    if os.path.exists(txt_path):
        logger.info("Falling back to input.txt")
        parsed_lines: List[Dict[str, Any]] = []
        with open(txt_path, 'r', encoding='utf-8', errors='ignore') as fh:
            for line in fh:
                s = line.strip()
                if not s:
                    continue
                try:
                    obj = json.loads(s)
                    if isinstance(obj, dict):
                        tmp = dict(obj)
                        tmp['raw_json'] = s
                        parsed_lines.append(tmp)
                except json.JSONDecodeError:
                    # not JSON line; continue scanning
                    continue
        if parsed_lines:
            return parsed_lines
        # no JSON lines parsed; treat whole file as plain text
        with open(txt_path, 'r', encoding='utf-8', errors='ignore') as fh:
            content = fh.read().strip()
        return [{"type": "Text", "text": content, "metadata": {"source": "input.txt"}}] if content else []
    raise FileNotFoundError("No layout file (.jsonl/.json) or input.txt fallback found in folder")

def _write_chunks(folder_path: str, chunks: List[Dict[str, Any]]) -> None:
    for idx, chunk_data in enumerate(chunks):
        chunk_path = os.path.join(folder_path, f"chunk{idx}.json")
        # Add chunk_index to the data before writing
        output_data = {"chunk_index": idx, **chunk_data}
        with open(chunk_path, "w", encoding="utf-8") as cf:
            json.dump(output_data, cf, ensure_ascii=False, indent=2)


SECTION_BREAK_TYPES = {
    "Title",
    "Heading",
    "Chapter",
    "SectionHeader",
    "Header",
    "Footer",
}
DEFAULT_OVERLAP_WORDS = 40


def _coerce_metadata(metadata: Any) -> Dict[str, Any]:
    if isinstance(metadata, dict):
        return dict(metadata)
    return {}


def _split_large_element(element: Dict[str, Any], max_words: int, overlap_words: int) -> List[Dict[str, Any]]:
    """Split oversized elements while keeping overlap for continuity.

    Adds metadata markers so downstream can see a split occurred.
    """
    text = element.get("text", "").strip()
    words = text.split()
    orig_raw = element.get("raw_json")
    if max_words <= 0 or len(words) <= max_words:
        element_copy = deepcopy(element)
        element_copy["text"] = text
        if orig_raw:
            element_copy["raw_json"] = orig_raw
        return [element_copy]

    overlap = min(overlap_words, max_words // 2)
    if overlap >= max_words:
        overlap = max(1, max_words // 3 or 1)

    fragments: List[Dict[str, Any]] = []
    start = 0
    fragment_index = 0
    total_words = len(words)

    # mark that a split is happening
    was_split = total_words > max_words

    while start < total_words:
        end = min(start + max_words, total_words)
        segment_words = words[start:end]
        segment_text = " ".join(segment_words).strip()
        if not segment_text:
            break

        fragment = deepcopy(element)
        fragment["text"] = segment_text
        metadata = _coerce_metadata(fragment.get("metadata"))
        metadata.update({
            "fragment_index": fragment_index,
            "fragment_of": element.get("element_id") or metadata.get("fragment_of"),
            "overlap_words": overlap,
            "split_due_to_size": was_split,
        })
        fragment["metadata"] = metadata
        fragment["element_id"] = f"{element.get('element_id') or 'element'}-part{fragment_index}"
        # for split fragments we omit original raw_json (no longer matches),
        # finalize step will serialize updated fragment instead
        if "raw_json" in fragment:
            fragment.pop("raw_json", None)
        fragments.append(fragment)

        if end >= total_words:
            break
        start = max(0, end - overlap)
        fragment_index += 1

    fragment_total = len(fragments)
    for frag in fragments:
        frag_meta = _coerce_metadata(frag.get("metadata"))
        frag_meta["fragment_total"] = fragment_total
        frag["metadata"] = frag_meta

    return fragments


def _normalize_elements(raw_elements: List[Dict[str, Any]], max_chunk_size: int) -> List[Dict[str, Any]]:
    """Coerce raw element list; split oversized elements (word-based)."""
    result: List[Dict[str, Any]] = []
    overlap_words = max(10, min(DEFAULT_OVERLAP_WORDS, max_chunk_size // 5 or 10))
    for raw in raw_elements:
        if not isinstance(raw, dict):
            continue
        txt = raw.get('text')
        if not isinstance(txt, str):
            continue
        txt = txt.strip()
        if not txt:
            continue
        elem: Dict[str, Any] = {
            'type': raw.get('type') or raw.get('element_type') or 'Unknown',
            'text': txt,
            'metadata': _coerce_metadata(raw.get('metadata')),
            'element_id': raw.get('element_id') or raw.get('id'),
        }
        # Preserve original raw_json for non-split elements; _split_large_element drops it for fragments
        if 'raw_json' in raw and isinstance(raw.get('raw_json'), str):
            elem['raw_json'] = raw.get('raw_json')
        for frag in _split_large_element(elem, max_chunk_size, overlap_words):
            frag_txt = frag.get('text', '').strip()
            if not frag_txt:
                continue
            frag['word_count'] = len(frag_txt.split())
            result.append(frag)
    return result


def _starts_new_section(element_type: str) -> bool:
    return element_type in SECTION_BREAK_TYPES


def _finalize_chunk(chunk_elements: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not chunk_elements:
        return None

    plain_parts: List[str] = []
    llm_objects: List[Dict[str, Any]] = []

    for element in chunk_elements:
        text = element.get("text", "").strip()
        if not text:
            continue

        plain_parts.append(text)
        metadata = _coerce_metadata(element.get("metadata"))
        element_id = element.get("element_id") or metadata.get("element_id")
        # llm object mirrors input element shape with possible metadata enrichments
        llm_obj: Dict[str, Any] = {
            "type": element.get("type") or element.get("element_type") or "Unknown",
            "element_id": element_id,
            "text": text,
            "metadata": metadata or None,
        }
        # Enhance table objects with HTML/cell info when available
        if (llm_obj["type"] == "Table"):
            html = None
            if isinstance(metadata, dict):
                html = metadata.get("text_as_html") or metadata.get("html") or metadata.get("table_html")
                # If a structured representation exists, keep it too
                if "cells" in metadata:
                    llm_obj["cells"] = metadata.get("cells")
            if html:
                llm_obj["text_as_html"] = html
        llm_objects.append(llm_obj)

    # Join plain text ensuring sentence-like separation between elements
    def _join_for_embedding(parts: List[str]) -> str:
        out: List[str] = []
        for p in parts:
            p = p.strip()
            if not p:
                continue
            if p[-1] in ".!?":
                out.append(p)
            else:
                out.append(p + ".")
        return " ".join(out).strip()

    plain_text = _join_for_embedding(plain_parts)
    if not plain_text:
        return None

    # LLM text as JSONL-style blocks for each included element
    llm_lines: List[str] = []
    for original, obj in zip(chunk_elements, llm_objects):
        raw_line = original.get('raw_json')
        # For tables, prefer the enhanced object if it contains html/cells
        if obj.get("type") == "Table" and ("text_as_html" in obj or "cells" in obj):
            llm_lines.append(json.dumps(obj, ensure_ascii=False))
            continue
        if raw_line and isinstance(raw_line, str):
            llm_lines.append(raw_line)
        else:
            llm_lines.append(json.dumps(obj, ensure_ascii=False))
    llm_text = "\n\n".join(llm_lines)

    return {
        "text": plain_text,            # primary plain text for embeddings & status endpoint
        "llm_text": llm_text,          # JSONL-style element objects
    }

# ---------------- Chunking Logic -----------------

def by_elements_chunking(folder_id: str, max_chunk_size: int) -> int:
    # Resolve folder path
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
    else:
        folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    logger.info(f"Starting chunking for folder: {folder_path}")
    raw_elements = _read_first_layout_file(folder_path)
    logger.info(f"Read {len(raw_elements)} raw element(s) from layout parser output")

    normalized_elements = _normalize_elements(raw_elements, max_chunk_size)
    logger.info(f"Prepared {len(normalized_elements)} normalized element(s) for chunking")

    if not normalized_elements:
        logger.warning("No usable elements found after normalization; skipping chunk generation")
        return 0

    if len(normalized_elements) < 5:
        logger.debug("Sample normalized elements: %s", json.dumps(normalized_elements[:5], indent=2))

    final_chunks: List[Dict[str, Any]] = []
    current: List[Dict[str, Any]] = []
    current_words = 0

    for elem in normalized_elements:
        wc = elem.get('word_count') or len(elem.get('text', '').split())
        # Would adding this element overflow? finalize current first.
        if current and (current_words + wc > max_chunk_size):
            payload = _finalize_chunk(current)
            if payload:
                final_chunks.append(payload)
            current = []
            current_words = 0
        current.append(elem)
        current_words += wc

    # flush remainder
    payload = _finalize_chunk(current)
    if payload:
        final_chunks.append(payload)

    logger.info("Total chunks created: %d", len(final_chunks))
    if final_chunks and len(final_chunks) <= 5:
        logger.debug("Chunk preview: %s", json.dumps(final_chunks[:5], indent=2))

    _write_chunks(folder_path, final_chunks)
    return len(final_chunks)

# --------------- Task ----------------------
@celery_app.task(name="byelements_worker.byelements_task")
def byelements_task(task_id, folder_id, chunking_config, dag_id, run_id):
    """Chunk text by elements based on document layout and max size."""
    status = "failed"
    error_message = None
    num_chunks = 0

    try:
        cfg = chunking_config if isinstance(chunking_config, dict) else {}
        max_size_val = (
            cfg.get("MaxChunkSize")
            or cfg.get("max_chunk_size")
            or 100  # Default value
        )
        
        max_chunk_size = int(max_size_val)
        if max_chunk_size <= 0:
            raise ValueError("MaxChunkSize must be > 0")

        num_chunks = by_elements_chunking(folder_id, max_chunk_size)
        status = "success"
    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error(f"Exception in byelements_task: {error_message}", exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "num_chunks": num_chunks,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting chunking results to {WORKER_RESULTS_URL}: {payload}")
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error(f"chunking worker-results callback returned HTTP {resp.status_code}: {resp.text}")
    except Exception as cb_err:  # noqa: BLE001
        logger.error(f"Failed to POST chunking worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "num_chunks": num_chunks,
        "error": error_message,
    }
