# Config for chunking microservice
# Moved configuration to environment variables via workers/chunking/.env
# Keep this file for documentation/reference only.
# Required env vars:
# - DB_DSN
# - DATA_BACKBONE_DIR
# - CELERY_BROKER_URL
# - CELERY_RESULT_BACKEND
