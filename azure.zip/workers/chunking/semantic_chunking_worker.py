"""Semantic Chunking Worker

This file was corrupted by previous patches (stray lines at top, indentation errors).
Reconstructed clean implementation providing:
 - Flexible layout JSON detection and token-limited chunking (516 default)
 - Table splitting by <tr> row groups with fallback token slicing
 - Per-chunk files chunkN.json plus aggregate chunk.json
 - Metadata retention: element_id (or id/elementId), source, kv_pairs, table_summary
 - token_count, sub_element ("i of N"), chunkid
 - Graceful fallback when SBERT model isn't available (semantic functions return single chunk)
"""

from __future__ import annotations

import os
import json
import logging
import re
from typing import List, Optional, Tuple, Iterable, Dict, Any, Sequence
from dataclasses import dataclass

from celery import Celery
from kombu import Queue
from html import unescape as _html_unescape
import requests

# Optional SBERT import (graceful degrade if missing)
try:  # pragma: no cover - optional dependency
    from sentence_transformers import SentenceTransformer  # type: ignore
    import numpy as np  # type: ignore
except Exception:  # noqa: BLE001
    SentenceTransformer = None  # type: ignore
    np = None  # type: ignore

try:  # tiktoken optional
    import tiktoken  # type: ignore
except Exception:  # noqa: BLE001
    tiktoken = None  # type: ignore

# -------------------------------------------------- Env & Logging

def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for semantic_chunking_worker")
    return val


BROKER_URL = os.getenv("CHUNKING_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("CHUNKING_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")
LOG_LEVEL = (os.getenv("CHUNKING_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()
CHUNKING_QUEUES = os.getenv("CHUNKING_QUEUES", "semantic_chunking,runtime_semantic_chunking")

logger = logging.getLogger("semantic_chunking_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:  # noqa: BLE001
    logger.setLevel(logging.INFO)

# -------------------------------------------------- Celery App
celery_app = Celery("semantic_chunking_worker", broker=BROKER_URL, backend=RESULT_BACKEND)
queue_names = [q.strip() for q in CHUNKING_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("CHUNKING_QUEUES must specify at least one queue name")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]

# -------------------------------------------------- Helpers
def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\") or p.startswith("//"))


def _resolve_folder(folder_id: str) -> str:
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
    else:
        folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")
    return folder_path


def _strip_tags(s: str) -> str:
    return _html_unescape(re.sub(r"<[^>]+>", "", s or ""))


ENCODING_NAME = os.getenv("TOKEN_ENCODING", "cl100k_base")
_TK_ENC = None  # cached tiktoken encoding

def _get_encoding():  # returns encoding or None
    global _TK_ENC
    if _TK_ENC is not None:
        return _TK_ENC
    if tiktoken is None:
        return None
    try:
        _TK_ENC = tiktoken.get_encoding(ENCODING_NAME)
    except Exception:  # noqa: BLE001
        try:
            _TK_ENC = tiktoken.get_encoding("cl100k_base")
        except Exception:  # noqa: BLE001
            _TK_ENC = None
    return _TK_ENC

def _tokenize(s: str) -> List[int]:
    """Return token ids using tiktoken if available else fallback to whitespace words.

    The returned list is a sequence of token identifiers (ints) if tiktoken present,
    otherwise indices of faux tokens (we just reuse list positions of words).
    """
    if not s:
        return []
    enc = _get_encoding()
    if enc is not None:
        try:
            return enc.encode(s)
        except Exception:  # noqa: BLE001
            pass
    # fallback word splitting
    s_norm = re.sub(r"\s+", " ", str(s)).strip()
    if not s_norm:
        return []
    # Represent each word as a dummy token id (we don't need the id itself, just count/segment)
    return list(range(len(s_norm.split(" "))))

def _decode_tokens(tokens: Sequence[int], original_text: str) -> str:
    """Decode token ids back to text when tiktoken available; if fallback mode, rebuild text by slicing words.

    We require the original_text for fallback segmentation so we can respect word boundaries
    even though dummy token ids were used.
    """
    if not tokens:
        return ""
    enc = _get_encoding()
    if enc is not None:
        try:
            return enc.decode(list(tokens))
        except Exception:  # noqa: BLE001
            pass
    # Fallback: map token indices to words
    words = re.sub(r"\s+", " ", original_text).strip().split(" ")
    # tokens are sequential indexes; slice up to len(words)
    return " ".join(words[:len(tokens)])


def _join_tokens(tokens: Iterable[str]) -> str:
    return " ".join(tokens)


def _format_element_from_seg(seg: Dict[str, Any], fallback_id: Any) -> Dict[str, Any]:
    """Normalize a raw layout segment (dict) into the output element structure.

    Ensures keys: element_id, type, page, bbox, source, kv_pairs, table_summary, text.
    Text is plain text (tags stripped when text_tag is present).
    """
    seg_type = str(seg.get("type", "paragraph")).lower()
    element_id = seg.get("element_id") or seg.get("id") or seg.get("elementId") or fallback_id
    raw_tag = seg.get("text_tag")
    raw_text = seg.get("text")
    plain = _strip_tags(raw_tag) if raw_tag else (raw_text or "")
    return {
        "element_id": element_id,
        "type": seg_type,
        "page": seg.get("page"),
        "bbox": seg.get("bbox"),
        "source": seg.get("source"),
        "kv_pairs": seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
        "table_summary": seg.get("table_summary") or {},
        "text": plain,
    }


def _render_tag_for_part(seg_type: str, seg: Dict[str, Any], inner_text: str, *, sub_element: Optional[str] = None) -> str:
    s_type = (seg_type or seg.get("type", "paragraph")).lower()
    page = seg.get("page")
    bbox = seg.get("bbox")
    attrs: List[str] = []
    if page is not None:
        attrs.append(f'page="{page}"')
    if bbox and isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
        attrs.append(f'bbox="{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}"')
    if sub_element:
        attrs.append(f'sub_element="{sub_element}"')
    attr_str = (" " + " ".join(attrs)) if attrs else ""
    if s_type == "table":
        return f"<table{attr_str}>" + str(inner_text) + "</table>"
    if s_type == "heading":
        return f"<heading{attr_str}>" + _html_unescape(str(inner_text)) + "</heading>"
    return f"<paragraph{attr_str}>" + _html_unescape(str(inner_text)) + "</paragraph>"


def _find_layout_segments(data: Any) -> Optional[List[Dict[str, Any]]]:
    def looks_like_segments(val: Any) -> bool:
        if not isinstance(val, list) or not val or not isinstance(val[0], dict):
            return False
        keys = set(val[0].keys())
        return bool(keys & {"text", "text_tag", "type"})

    if isinstance(data, dict):
        for key in ("layout", "segments", "items", "elements", "data"):
            cand = data.get(key)
            if looks_like_segments(cand):
                return cand  # type: ignore[return-value]
        # shallow walk
        for v in data.values():
            found = _find_layout_segments(v)
            if found:
                return found
    elif isinstance(data, list):
        if looks_like_segments(data):
            return data  # type: ignore[return-value]
        for it in data:
            found = _find_layout_segments(it)
            if found:
                return found
    return None


# ---------------------- Semantic-layout helpers (ported from script, adapted) ----------------------

def _count_tokens(text: str) -> int:
    return len(_tokenize(text or ""))


def _is_title_like(text: str) -> bool:
    t = (text or "").strip()
    if not t:
        return False
    if t.endswith(":"):
        return True
    if re.match(r"^(section|chapter|part)\s+\d+(\.\d+)?[\.: -]", t, flags=re.I):
        return True
    if re.match(r"^\d+(\.\d+)*[\)\.]?\s+[A-Za-z].{0,80}$", t):
        return True
    if len(t) <= 80 and t.upper() == t and re.search(r"[A-Z]", t):
        return True
    words = [w for w in re.split(r"\s+", t) if w]
    if 1 <= len(words) <= 12:
        caps = sum(1 for w in words if w[:1].isupper())
        if caps >= max(1, len(words) // 2):
            return True
    return False


@dataclass
class _Block:
    idx: int
    type: str
    element_id: Any
    page: Any
    bbox: Any
    source: Any
    kv_pairs: List[Any]
    table_summary: Any
    text_tag: str
    text_plain: str
    tokens_plain: int
    embedding: Optional[Any] = None  # numpy array or None


def _element_meta(block: _Block, sub_element: Optional[str] = None) -> Dict[str, Any]:
    m: Dict[str, Any] = {
        "element_id": block.element_id,
        "type": block.type,
        "page": block.page,
        "bbox": block.bbox,
        "source": block.source,
        "kv_pairs": block.kv_pairs,
        "table_summary": block.table_summary,
    }
    if sub_element:
        m["sub_element"] = sub_element
    return m


def _normalize_blocks(segments: List[Dict[str, Any]], *, promote_title_tokens: int = 20) -> List[_Block]:
    out: List[_Block] = []
    for i, seg in enumerate(segments):
        if not isinstance(seg, dict):
            continue
        seg_type = str(seg.get("type", "paragraph")).lower()
        element_id = seg.get("element_id") or seg.get("id") or seg.get("elementId") or i
        text_tag = seg.get("text_tag") or seg.get("text") or ""
        if not isinstance(text_tag, str):
            text_tag = str(text_tag)
        text_plain = seg.get("text")
        if not isinstance(text_plain, str) or not text_plain.strip():
            text_plain = _strip_tags(text_tag)
        tok = _count_tokens(text_plain)
        if seg_type != "table" and tok <= promote_title_tokens and _is_title_like(text_plain):
            seg_type = "heading"
        out.append(_Block(
            idx=i,
            type=seg_type,
            element_id=element_id,
            page=seg.get("page"),
            bbox=seg.get("bbox"),
            source=seg.get("source"),
            kv_pairs=seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
            table_summary=seg.get("table_summary"),
            text_tag=text_tag,
            text_plain=text_plain,
            tokens_plain=tok,
        ))
    return out


def _make_chunk_from_blocks(blocks: List[_Block], note: Optional[str] = None) -> Dict[str, Any]:
    """Create a chunk payload matching requested schema from semantic _Block objects.

    Rules:
      - If a chunk contains a single source block, emit that original element (retain type/id and metadata).
      - If a chunk merges multiple source blocks, emit a single GroupedElement with original_elements as comma-separated ids.
    """
    import uuid as _uuid
    texts = [b.text_plain for b in blocks if b.text_plain]
    combined = "\n".join(texts)
    if len(blocks) == 1:
        b = blocks[0]
        element = {
            "element_id": b.element_id,
            "type": b.type,
            "text": b.text_plain,
            "original_elements": str(b.element_id),
            "page": b.page,
            "bbox": b.bbox,
            "source": b.source,
            "kv_pairs": b.kv_pairs if isinstance(b.kv_pairs, list) else [],
            "table_summary": b.table_summary or {},
        }
    else:
        # Use the first block's page/source for provenance for a grouped element
        first_page = blocks[0].page if blocks else None
        first_source = blocks[0].source if blocks else None
        element = {
            "element_id": _uuid.uuid4().hex,
            "type": "GroupedElement",
            "text": combined,
            "original_elements": ",".join(str(b.element_id) for b in blocks),
            "page": first_page,
            "bbox": None,
            "source": first_source,
            "kv_pairs": [],
            "table_summary": {},
        }
    return {
        "chunk_text": {"element": [element]},
        "embed_text": combined,
    }


def _semantic_chunk_layout(
    blocks: List[_Block],
    *,
    model: Optional[Any],
    max_tokens: int,
    threshold: float,
    heading_starts_new: bool = True,
    short_merge_tokens: int = 20,
) -> List[Dict[str, Any]]:
    # Special case: a single non-table block should be eligible for semantic sentence-level splitting
    if len(blocks) == 1 and blocks[0].type != "table":
        b = blocks[0]
        # Use sentence-based semantic chunking to produce smaller coherent parts
        parts = semantic_chunk_text(b.text_plain, threshold=threshold, max_chunk_chars=None, max_parts=None, overlap_sentences=0)
        if parts and len(parts) > 1:
            chunks: List[Dict[str, Any]] = []
            total = len(parts)
            for i, part in enumerate(parts, start=1):
                elem = {
                    "element_id": f"{b.element_id}-{i}",
                    "type": b.type,
                    "sub_element": f"{i} of {total}",
                    "text": part,
                    "original_elements": str(b.element_id),
                    "page": b.page,
                    "bbox": b.bbox,
                    "source": b.source,
                    "kv_pairs": b.kv_pairs if isinstance(b.kv_pairs, list) else [],
                    "table_summary": b.table_summary or {},
                }
                chunks.append({
                    "chunk_text": {"element": [elem]},
                    "embed_text": part,
                })
            return chunks

    def _is_section_heading(text: str) -> bool:
        t = (text or "").strip()
        return bool(re.match(r"^section\s+\d+(\.\d+)?\s*:", t, flags=re.I))

    # Precompute embeddings if model available
    if model is not None and np is not None:
        idxs: List[int] = []
        texts: List[str] = []
        for i, b in enumerate(blocks):
            if b.type != "table" and (b.text_plain or "").strip():
                idxs.append(i)
                texts.append(b.text_plain)
        if texts:
            try:
                embs = model.encode(texts, normalize_embeddings=True)
                for j, bi in enumerate(idxs):
                    blocks[bi].embedding = embs[j]
            except Exception:
                pass

    chunks: List[Dict[str, Any]] = []
    cur_blocks: List[_Block] = []
    cur_tokens = 0
    cur_emb = None
    in_section = False

    def flush(note: Optional[str] = None):
        nonlocal cur_blocks, cur_tokens, cur_emb, in_section
        if not cur_blocks:
            return
        chunks.append(_make_chunk_from_blocks(cur_blocks, note=note))
        cur_blocks = []
        cur_tokens = 0
        cur_emb = None
        in_section = False

    def _start_new_chunk_with_block(b: _Block, note: str):
        nonlocal cur_blocks, cur_tokens, cur_emb, in_section
        flush(note=note)
        cur_blocks = [b]
        cur_tokens = b.tokens_plain
        cur_emb = b.embedding
        in_section = (b.type == "heading" and _is_section_heading(b.text_plain))

    for b in blocks:
        if b.type == "table":
            # Always standalone; do not split tables. Emit single-element chunk with full metadata.
            flush(note="before_table")
            # Preserve original table HTML (td/tr) from parser; do not convert to plain text
            raw_html = b.text_tag or b.text_plain or ""
            elem = {
                "element_id": b.element_id,
                "type": "table",
                "page": b.page,
                "bbox": b.bbox,
                "source": b.source,
                "kv_pairs": b.kv_pairs if isinstance(b.kv_pairs, list) else [],
                "table_summary": b.table_summary or {},
                "text": raw_html,
            }
            chunks.append({
                "chunk_text": {"element": [elem]},
                "embed_text": _strip_tags(raw_html),
            })
            continue

        b_tok = b.tokens_plain
        if not cur_blocks:
            # If the very first block itself exceeds budget and is non-table, split it into sub-element chunks
            if max_tokens > 0 and b_tok > max_tokens and b.type != "table":
                toks = _tokenize(b.text_plain)
                parts: List[str] = []
                if toks:
                    # Slice tokens into windows of max_tokens and reconstruct text by word fallback
                    for i in range(0, len(toks), max_tokens):
                        window = toks[i:i+max_tokens]
                        part_text = _decode_tokens(window, b.text_plain) if _get_encoding() is not None else " ".join(re.sub(r"\s+", " ", b.text_plain).strip().split(" ")[i//max_tokens*max_tokens:(i//max_tokens+1)*max_tokens])
                        parts.append(part_text)
                else:
                    parts = _split_text_by_chars(b.text_plain, max_chars=max_tokens, overlap=0)
                total = len(parts)
                for i, part in enumerate(parts, start=1):
                    elem = {
                        "element_id": f"{b.element_id}-{i}",
                        "type": b.type,
                        "sub_element": f"{i} of {total}",
                        "text": part,
                        "original_elements": str(b.element_id),
                        "page": b.page,
                        "bbox": b.bbox,
                        "source": b.source,
                        "kv_pairs": b.kv_pairs if isinstance(b.kv_pairs, list) else [],
                        "table_summary": b.table_summary or {},
                    }
                    chunks.append({
                        "chunk_text": {"element": [elem]},
                        "embed_text": part,
                    })
                # After splitting, reset and move to next block
                cur_blocks = []
                cur_tokens = 0
                cur_emb = None
                in_section = False
                continue
            # Otherwise start a new chunk with this block
            cur_blocks = [b]
            cur_tokens = b_tok
            cur_emb = b.embedding
            in_section = (b.type == "heading" and _is_section_heading(b.text_plain))
            continue

        last = cur_blocks[-1]

        if b.type == "heading" and _is_section_heading(b.text_plain):
            if last.type == "heading" and not _is_section_heading(last.text_plain) and len(cur_blocks) == 1:
                would = cur_tokens + b_tok
                if max_tokens <= 0 or would <= max_tokens:
                    cur_blocks.append(b)
                    cur_tokens = would
                    # blend embeddings
                    if cur_emb is None:
                        cur_emb = b.embedding
                    elif cur_emb is not None and b.embedding is not None and np is not None:
                        cur_emb = (cur_emb + b.embedding) / 2.0
                        n = float(np.linalg.norm(cur_emb))
                        if n > 0:
                            cur_emb = cur_emb / n
                    in_section = True
                    continue
            _start_new_chunk_with_block(b, note="new_section_heading")
            continue

        if b.type == "heading" and last.type == "heading":
            # Prevent merging section headings together
            is_last_sec = _is_section_heading(last.text_plain)
            is_cur_sec = _is_section_heading(b.text_plain)
            if is_last_sec and is_cur_sec:
                _start_new_chunk_with_block(b, note="section_heading_boundary")
                continue
            would = cur_tokens + b_tok
            if max_tokens <= 0 or would <= max_tokens:
                cur_blocks.append(b)
                cur_tokens = would
                if cur_emb is None:
                    cur_emb = b.embedding
                elif cur_emb is not None and b.embedding is not None and np is not None:
                    cur_emb = (cur_emb + b.embedding) / 2.0
                    n = float(np.linalg.norm(cur_emb))
                    if n > 0:
                        cur_emb = cur_emb / n
                if b.type == "heading" and _is_section_heading(b.text_plain):
                    in_section = True
                continue
            else:
                _start_new_chunk_with_block(b, note="boundary_budget_between_headings")
                continue

        if heading_starts_new and b.type == "heading":
            _start_new_chunk_with_block(b, note="before_heading")
            continue

        would_tokens = cur_tokens + b_tok
        token_ok = (max_tokens <= 0) or (would_tokens <= max_tokens)

        sim_ok = True
        if cur_emb is not None and b.embedding is not None and np is not None:
            sim = float(np.dot(cur_emb, b.embedding))
            sim_ok = sim >= threshold

        force_merge = False
        if token_ok:
            if last.tokens_plain <= short_merge_tokens or _is_title_like(last.text_plain):
                force_merge = True
            if in_section and last.type == "paragraph" and b.type == "paragraph":
                force_merge = True

        if token_ok and (sim_ok or force_merge):
            cur_blocks.append(b)
            cur_tokens = would_tokens
            if cur_emb is None:
                cur_emb = b.embedding
            elif cur_emb is not None and b.embedding is not None and np is not None:
                cur_emb = (cur_emb + b.embedding) / 2.0
                n = float(np.linalg.norm(cur_emb))
                if n > 0:
                    cur_emb = cur_emb / n
        else:
            flush(note="boundary_similarity_or_budget")
            cur_blocks = [b]
            cur_tokens = b_tok
            cur_emb = b.embedding
            in_section = (b.type == "heading" and _is_section_heading(b.text_plain))

    flush(note="end")
    return chunks


# ---------------------- Basic (character-based) chunking ----------------------

def _split_text_by_chars(text: str, *, max_chars: int, overlap: int) -> List[str]:
    if max_chars <= 0:
        return [text]
    if overlap < 0:
        overlap = 0
    step = max(1, max_chars - overlap)
    out: List[str] = []
    i = 0
    n = len(text)
    while i < n:
        out.append(text[i:i + max_chars])
        i += step
    return out


def _basic_chunk_layout(
    segments: List[Dict[str, Any]],
    *,
    max_characters: int,
    new_after_n_chars: Optional[int] = None,
    overlap: int = 0,
    overlap_all: bool = False,
) -> List[Dict[str, Any]]:
    """Basic strategy emitting the requested schema with preserved elements.

    - Combine sequential elements until adding the next would exceed max_characters (hard-max) based on plain text length.
    - Prefer starting a new chunk after new_after_n_chars (soft-max) if provided.
    - Tables are never split and form their own single-element chunk.
    - Does NOT split oversized text elements; if one element exceeds max_characters, it becomes a single-element chunk.
    """
    import uuid as _uuid
    chunks: List[Dict[str, Any]] = []
    buf_text_parts: List[str] = []
    buf_ids: List[str] = []
    buf_segs: List[Dict[str, Any]] = []
    buf_len = 0
    buf_first_page: Any = None
    buf_first_source: Any = None

    def seg_plain(s: Dict[str, Any]) -> str:
        raw_tag = s.get("text_tag")
        raw_text = s.get("text")
        return _strip_tags(raw_tag) if raw_tag else (raw_text or "")

    def seg_type(s: Dict[str, Any]) -> str:
        return str(s.get("type", "paragraph")).lower()

    def seg_id(s: Dict[str, Any], fallback: Any) -> str:
        val = s.get("element_id") or s.get("id") or s.get("elementId") or fallback
        return str(val)

    def flush_composite():
        nonlocal buf_text_parts, buf_ids, buf_segs, buf_len
        if not buf_text_parts:
            return
        text = "\n".join([p for p in buf_text_parts if p])
        if len(buf_ids) == 1 and len(buf_segs) == 1:
            # Emit original element (no grouping)
            seg = buf_segs[0]
            sid = buf_ids[0]
            elem = {
                "element_id": sid,
                "type": seg_type(seg),
                "text": seg_plain(seg),
                "original_elements": str(sid),
                "page": seg.get("page"),
                "bbox": seg.get("bbox"),
                "source": seg.get("source"),
                "kv_pairs": seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
                "table_summary": seg.get("table_summary") or {},
            }
        else:
            elem = {
                "element_id": _uuid.uuid4().hex,
                "type": "GroupedElement",
                "text": text,
                "original_elements": ",".join(buf_ids),
                "page": buf_first_page,
                "bbox": None,
                "source": buf_first_source,
                "kv_pairs": [],
                "table_summary": {},
            }
        chunks.append({
            "chunk_text": {"element": [elem]},
            "embed_text": text,
        })
        buf_text_parts = []
        buf_ids = []
        buf_segs = []
        buf_len = 0
        buf_first_page = None
        buf_first_source = None

    for idx, seg in enumerate(segments):
        t = seg_type(seg)
        plain = seg_plain(seg)
        sid = seg_id(seg, idx)
        if t == "table":
            # Close any open composite
            flush_composite()
            if max_characters and max_characters > 0 and len(plain) > max_characters:
                parts = _split_text_by_chars(plain, max_chars=max_characters, overlap=0)
                total = len(parts)
                for i, part in enumerate(parts, start=1):
                    elem = {
                        "element_id": f"{sid}-{i}",
                        "type": "table",
                        "sub_element": f"{i} of {total}",
                        "text": part,
                        "original_elements": str(sid),
                        "page": seg.get("page"),
                        "bbox": seg.get("bbox"),
                        "source": seg.get("source"),
                        "kv_pairs": seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
                        "table_summary": seg.get("table_summary") or {},
                    }
                    chunks.append({
                        "chunk_text": {"element": [elem]},
                        "embed_text": part,
                    })
            else:
                elem = {
                    "element_id": sid,
                    "type": "table",
                    "text": plain,
                    "original_elements": str(sid),
                    "page": seg.get("page"),
                    "bbox": seg.get("bbox"),
                    "source": seg.get("source"),
                    "kv_pairs": seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
                    "table_summary": seg.get("table_summary") or {},
                }
                chunks.append({
                    "chunk_text": {"element": [elem]},
                    "embed_text": plain,
                })
            continue

        # Text-like element
        if max_characters and max_characters > 0 and len(plain) > max_characters:
            # Oversized single element -> split into multiple sub-elements, retaining original type
            flush_composite()
            parts = _split_text_by_chars(plain, max_chars=max_characters, overlap=0)
            total = len(parts)
            for i, part in enumerate(parts, start=1):
                elem = {
                    "element_id": f"{sid}-{i}",
                    "type": t,
                    "sub_element": f"{i} of {total}",
                    "text": part,
                    "original_elements": str(sid),
                    "page": seg.get("page"),
                    "bbox": seg.get("bbox"),
                    "source": seg.get("source"),
                    "kv_pairs": seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
                    "table_summary": {},
                }
                chunks.append({
                    "chunk_text": {"element": [elem]},
                    "embed_text": part,
                })
            continue

        # Try to add to current composite
        add_len = len(plain) + (1 if buf_len > 0 and len(plain) > 0 else 0)
        would_len = buf_len + add_len
        if max_characters and max_characters > 0 and would_len > max_characters and buf_text_parts:
            flush_composite()
            # Start new composite with this element
            buf_text_parts = [plain]
            buf_ids = [sid]
            buf_segs = [seg]
            buf_len = len(plain)
            buf_first_page = seg.get("page")
            buf_first_source = seg.get("source")
        else:
            # Soft threshold
            if new_after_n_chars and new_after_n_chars > 0 and buf_len >= new_after_n_chars and buf_text_parts:
                flush_composite()
            if not buf_text_parts:
                buf_first_page = seg.get("page")
                buf_first_source = seg.get("source")
            buf_text_parts.append(plain)
            buf_ids.append(sid)
            buf_segs.append(seg)
            buf_len += len(plain) + (1 if buf_len > 0 and len(plain) > 0 else 0)

    flush_composite()
    return chunks


def _chunk_layout_segments(layout: List[Dict[str, Any]], max_tokens: int = 516) -> List[Dict[str, Any]]:
    """Composite-style chunking across adjacent text segments with a token budget.

    Rules:
      - Accumulate consecutive non-table segments while total tokens <= max_tokens.
      - Tables are never merged into text chunks; each table becomes its own chunk.
      - Do not create multiple element_id fields in the chunk payload. Instead, emit a single
        composite element object with:
          type: "composite", element_id: first child's id, element_ids: [all child ids],
          children: [{element_id, type, page, bbox}] (metadata only, no per-child text here).
      - For vectorization, place concatenated plain text in top-level 'embed_text'.
    """
    if max_tokens is None or max_tokens <= 0:
        max_tokens = 516

    def _seg_base_text(seg: Dict[str, Any]) -> str:
        raw_tag = seg.get("text_tag")
        raw_text = seg.get("text")
        return _strip_tags(raw_tag) if raw_tag else (raw_text or "")

    def _seg_id(seg: Dict[str, Any], fallback: Any) -> Any:
        return seg.get("element_id") or seg.get("id") or seg.get("elementId") or fallback

    chunks: List[Dict[str, Any]] = []

    cur_children: List[Dict[str, Any]] = []
    cur_ids: List[Any] = []
    cur_tokens: int = 0
    cur_embed_parts: List[str] = []

    def _flush_current():
        nonlocal cur_children, cur_ids, cur_tokens, cur_embed_parts
        if not cur_children:
            return
        first_id = cur_ids[0] if cur_ids else None
        chunk_obj = {
            "type": "composite",
            "element_id": first_id,
            "element_ids": cur_ids[:],
            "token_count": cur_tokens,
            "embed_text": "\n".join([p for p in cur_embed_parts if p]).strip(),
            "chunk_text": {
                "element": {
                    "type": "composite",
                    "element_id": first_id,
                    "element_ids": cur_ids[:],
                    "children": cur_children[:],
                }
            },
        }
        chunks.append(chunk_obj)
        cur_children = []
        cur_ids = []
        cur_tokens = 0
        cur_embed_parts = []

    for orig_idx, seg in enumerate(layout):
        seg_type = str(seg.get("type", "paragraph")).lower()
        base_text = _seg_base_text(seg)
        element_id = _seg_id(seg, orig_idx)
        if seg_type == "table":
            # Close current composite chunk first
            _flush_current()
            # Table as standalone chunk; do not split
            plain = _strip_tags(seg.get("text_tag") or seg.get("text") or "")
            tbl_tokens = len(_tokenize(plain))
            table_chunk = {
                "type": "table",
                "element_id": element_id,
                "token_count": tbl_tokens,
                "embed_text": plain,
                "text": plain,
                "text_tag": seg.get("text_tag") or seg.get("text") or "",
                "page": seg.get("page"),
                "bbox": seg.get("bbox"),
                "source": seg.get("source"),
                "kv_pairs": seg.get("kv_pairs") if isinstance(seg.get("kv_pairs"), list) else [],
                "table_summary": seg.get("table_summary"),
            }
            chunks.append(table_chunk)
            continue

        # Text-like segment
        toks = _tokenize(base_text)
        tlen = len(toks)
        if tlen == 0:
            # Still include as empty child to preserve ordering/metadata
            child_meta = {
                "element_id": element_id,
                "type": seg_type,
                "page": seg.get("page"),
                "bbox": seg.get("bbox"),
                "source": seg.get("source"),
            }
            # Don't change token count or embed text
            cur_children.append(child_meta)
            cur_ids.append(element_id)
            continue

        if cur_tokens + tlen <= max_tokens and cur_children:
            # Append to current composite
            cur_children.append({
                "element_id": element_id,
                "type": seg_type,
                "page": seg.get("page"),
                "bbox": seg.get("bbox"),
                "source": seg.get("source"),
            })
            cur_ids.append(element_id)
            cur_tokens += tlen
            cur_embed_parts.append(base_text)
        else:
            # Start a new composite chunk
            if cur_children:
                _flush_current()
            cur_children = [{
                "element_id": element_id,
                "type": seg_type,
                "page": seg.get("page"),
                "bbox": seg.get("bbox"),
                "source": seg.get("source"),
            }]
            cur_ids = [element_id]
            cur_tokens = tlen
            cur_embed_parts = [base_text]

    # Flush if anything pending
    _flush_current()
    return chunks


def _assign_chunk_ids(chunks: List[Dict[str, Any]]) -> None:  # retained for backward compatibility (no-op)
    return None


def _write_semantic_chunks_per_files(folder_path: str, chunks: List[Dict[str, Any]]) -> None:
    import uuid as _uuid
    for idx, seg in enumerate(chunks):
        payload = {"chunk_id": str(_uuid.uuid4()), **seg}
        out_path = os.path.join(folder_path, f"chunk{idx}.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)


def _write_aggregate_chunk_json(folder_path: str, chunks: List[Dict[str, Any]], *, filename: str = "chunk.json") -> str:
    out_path = os.path.join(folder_path, filename)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"layout": chunks}, f, ensure_ascii=False, indent=2)
    return out_path


def _read_first_text_file(folder_path: str) -> Tuple[str, bool, str]:
    # Prefer any JSON with layout-like segments rendered into tags
    json_files = sorted([f for f in os.listdir(folder_path) if f.lower().endswith(".json")])
    for jf_name in json_files:
        path = os.path.join(folder_path, jf_name)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as jf:
                data = json.load(jf)
        except Exception:
            continue
        layout = _find_layout_segments(data)
        if isinstance(layout, list) and layout:
            rendered: List[str] = []
            for seg in layout:
                seg_type = str(seg.get("type", "paragraph")).lower()
                txt = seg.get("text_tag") or seg.get("text") or ""
                page = seg.get("page")
                bbox = seg.get("bbox")
                attrs: List[str] = []
                if page is not None:
                    attrs.append(f'page="{page}"')
                if bbox and isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
                    attrs.append(f'bbox="{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}"')
                attr_str = (" " + " ".join(attrs)) if attrs else ""
                if seg_type == "table":
                    rendered.append(f"<table{attr_str}>" + str(txt) + "</table>\n")
                elif seg_type == "heading":
                    rendered.append(f"<heading{attr_str}>" + _html_unescape(str(txt)) + "</heading>\n")
                else:
                    rendered.append(f"<paragraph{attr_str}>" + _html_unescape(str(txt)) + "</paragraph>\n")
            return "".join(rendered), True, jf_name
    # Fallback to text / html like files
    supported_exts = {".txt", ".html", ".htm", ".xml", ".xhtml"}
    files = [f for f in os.listdir(folder_path) if any(f.lower().endswith(ext) for ext in supported_exts)]
    if not files:
        raise FileNotFoundError("No supported text file found")
    files.sort()
    for fname in files:
        path = os.path.join(folder_path, fname)
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception:
            continue
        if re.search(r"<(table|heading|paragraph)\b", content, flags=re.IGNORECASE):
            return content, True, fname
        if re.search(r"&lt;(table|heading|paragraph)\b", content, flags=re.IGNORECASE):
            decoded = _html_unescape(content)
            if re.search(r"<(table|heading|paragraph)\b", decoded, flags=re.IGNORECASE):
                return decoded, True, fname
    # plain fallback
    path = os.path.join(folder_path, files[0])
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()
    return content, False, files[0]


# -------------------------------------------------- Semantic (optional)
_MODEL: Optional[Any] = None


def _write_chunks(folder_path: str, chunks: List[str], *, include_text_tag: bool = False) -> None:
    """Legacy per-chunk writer for plain semantic chunking (non-layout JSON path).

    Each chunk written as chunk{idx}.json with fields:
      - chunk_index
      - text
      - optional text_tag (if include_text_tag True)
    """
    for idx, chunk in enumerate(chunks):
        out_path = os.path.join(folder_path, f"chunk{idx}.json")
        payload: Dict[str, Any] = {"chunk_index": idx}
        if include_text_tag:
            payload["text_tag"] = chunk
            payload["text"] = _strip_tags(chunk)
        else:
            payload["text"] = chunk
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)


def _get_model() -> Optional[Any]:  # SentenceTransformer | None
    if SentenceTransformer is None:
        return None
    global _MODEL
    if _MODEL is None:
        name = os.getenv("SBERT_MODEL_NAME", "all-MiniLM-L6-v2")
        try:
            _MODEL = SentenceTransformer(name)
        except Exception:  # noqa: BLE001
            _MODEL = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    return _MODEL


def _split_sentences(text: str) -> List[str]:
    parts = re.split(r"(?<=[\.!\?])\s+(?=[A-Z0-9\"“])", text or "")
    return [p.strip() for p in parts if p.strip()]


def semantic_chunk_text(
    text: str,
    *,
    threshold: float = 0.8,
    max_chunk_chars: Optional[int] = None,
    max_parts: Optional[int] = None,
    overlap_sentences: int = 0,
) -> List[str]:
    model = _get_model()
    if model is None or np is None:  # dependency missing, fallback single chunk
        return [text] if text else []
    sents = _split_sentences(text)
    if not sents:
        return []
    def _cos(a, b) -> float:
        an = float(np.linalg.norm(a))
        bn = float(np.linalg.norm(b))
        if an == 0.0 or bn == 0.0:
            return 0.0
        return float(np.dot(a, b) / (an * bn))

    chunks: List[str] = []
    cur_sents = [sents[0]]
    cur_emb = model.encode([sents[0]])[0]
    cur_len = len(sents[0])
    cur_parts = 1
    for s in sents[1:]:
        e = model.encode([s])[0]
        sim = _cos(cur_emb, e)
        would_len = cur_len + 1 + len(s)
        would_parts = cur_parts + 1
        can_merge = (sim >= threshold) and \
                    (max_chunk_chars is None or would_len <= max_chunk_chars) and \
                    (max_parts is None or would_parts <= max_parts)
        if can_merge:
            cur_sents.append(s)
            cur_emb = (cur_emb + e) / 2.0
            cur_len = would_len
            cur_parts = would_parts
        else:
            chunks.append(" ".join(cur_sents))
            if overlap_sentences > 0:
                keep = cur_sents[-overlap_sentences:]
                cur_sents = keep + [s]
                emb_keep = model.encode(keep) if keep else []
                cur_emb = (np.mean(np.vstack(emb_keep + [e]), axis=0)).astype(np.float32) if emb_keep else e
                cur_len = sum(len(x) for x in keep) + len(s)
                cur_parts = len(keep) + 1
            else:
                cur_sents = [s]
                cur_emb = e
                cur_len = len(s)
                cur_parts = 1
    if cur_sents:
        chunks.append(" ".join(cur_sents))
    return chunks


def semantic_chunk_text_tag_aware(text: str, **kwargs) -> List[str]:
    if not re.search(r"<(table|heading|paragraph)\b", text or "", flags=re.IGNORECASE):
        return semantic_chunk_text(text, **kwargs)
    # Preserve tagged blocks intact; chunk plain text between
    pattern = re.compile(r"(<table\b[^>]*>.*?</table>|<heading\b[^>]*>.*?</heading>|<paragraph\b[^>]*>.*?</paragraph>)", re.IGNORECASE | re.DOTALL)
    pos = 0
    chunks: List[str] = []
    buffer: List[str] = []
    for m in pattern.finditer(text):
        start, end = m.span()
        if start > pos:
            buffer.append(text[pos:start])
        # flush buffer
        if buffer:
            buf = "".join(buffer).strip()
            if buf:
                chunks.extend(semantic_chunk_text(buf, **kwargs))
            buffer = []
        block = text[start:end].strip()
        if block:
            chunks.append(block)
        pos = end
    if pos < len(text):
        buffer.append(text[pos:])
    if buffer:
        buf = "".join(buffer).strip()
        if buf:
            chunks.extend(semantic_chunk_text(buf, **kwargs))
    return chunks


def _split_layout_txt_into_chunks(text: str) -> List[str]:
    if not text:
        return []
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    out: List[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        lower = line.lower()
        if lower.startswith("<heading") or lower.startswith("<paragraph"):
            out.append(line)
            i += 1
            continue
        if lower.startswith("<table"):
            buf = [line]
            open_count = len(re.findall(r"<table\b", lower))
            close_count = len(re.findall(r"</table>", lower))
            j = i + 1
            while j < len(lines) and open_count > close_count:
                tline = lines[j]
                buf.append(tline)
                tl = tline.lower()
                open_count += len(re.findall(r"<table\b", tl))
                close_count += len(re.findall(r"</table>", tl))
                j += 1
            out.append("\n".join(buf))
            i = j
            continue
        out.append(line)
        i += 1
    return out


# -------------------------------------------------- Task
@celery_app.task(name="semantic_chunking_worker.semantic_chunking_task")
def semantic_chunking_task(task_id, folder_id, chunking_config, dag_id, run_id):
    status = "failed"
    error_message: Optional[str] = None
    num_chunks = 0
    try:
        cfg = chunking_config if isinstance(chunking_config, dict) else {}
        threshold = float(cfg.get("SimilarityThreshold") or cfg.get("threshold") or 0.8)
        max_chunk_chars = cfg.get("MaxChunkChars")
        if max_chunk_chars is not None:
            try:
                max_chunk_chars = int(max_chunk_chars)
            except Exception:  # noqa: BLE001
                max_chunk_chars = None
        max_parts = cfg.get("MaxParts")
        if max_parts is not None:
            try:
                max_parts = int(max_parts)
            except Exception:  # noqa: BLE001
                max_parts = None
        overlap_sentences = int(cfg.get("OverlapSentences") or 0)
        folder_path = _resolve_folder(folder_id)
        text, has_tags, filename = _read_first_text_file(folder_path)
        logger.info(f"[semantic_chunking] Using '{filename}' tagged={has_tags} size={len(text)}")
        fname_lower = filename.lower()
        if fname_lower.endswith(".json"):
            try:
                with open(os.path.join(folder_path, filename), "r", encoding="utf-8", errors="ignore") as jf:
                    data = json.load(jf)
            except Exception:
                data = None
            layout = _find_layout_segments(data) if data is not None else None
            if isinstance(layout, list) and layout:
                # Choose strategy: default to 'basic' (character-based) unless explicitly overridden
                strategy = (cfg.get("ChunkingStrategy") or cfg.get("strategy") or "basic").strip().lower()
                if strategy == "basic":
                    # Default hard cap set to 516 characters per chunk
                    max_characters = int(cfg.get("MaxCharacters") or cfg.get("max_characters") or cfg.get("MaxChars") or 516)
                    new_after_n_chars = cfg.get("NewAfterNChars") or cfg.get("new_after_n_chars")
                    try:
                        new_after_n_chars = int(new_after_n_chars) if new_after_n_chars is not None else None
                    except Exception:
                        new_after_n_chars = None
                    overlap_chars = int(cfg.get("Overlap") or cfg.get("overlap") or cfg.get("overlap_chars") or 0)
                    overlap_all = bool(cfg.get("OverlapAll") or cfg.get("overlap_all") or False)
                    chunks_seg = _basic_chunk_layout(
                        layout,
                        max_characters=max_characters,
                        new_after_n_chars=new_after_n_chars,
                        overlap=overlap_chars,
                        overlap_all=overlap_all,
                    )
                else:
                    # Semantic strategy (token-based with headings) as fallback
                    max_tokens = int(cfg.get("MaxTokensPerChunk") or 516)
                    heading_starts_new = bool(cfg.get("HeadingStartsNew") or cfg.get("heading_starts_new") or True)
                    short_merge_tokens = int(cfg.get("ShortMergeTokens") or 20)
                    promote_title_tokens = int(cfg.get("PromoteTitleTokens") or 20)
                    blocks = _normalize_blocks(layout, promote_title_tokens=promote_title_tokens)
                    model = _get_model()
                    chunks_seg = _semantic_chunk_layout(
                        blocks,
                        model=model,
                        max_tokens=max_tokens,
                        threshold=threshold,
                        heading_starts_new=heading_starts_new,
                        short_merge_tokens=short_merge_tokens,
                    )
                # _assign_chunk_ids now no-op; chunks already minimal
                _write_semantic_chunks_per_files(folder_path, chunks_seg)
                num_chunks = len(chunks_seg)
                status = "success"
                payload = {
                    "task_id": task_id,
                    "status": status,
                    "process_name": dag_id or "",
                    "job_id": run_id,
                    "folder_id": folder_id,
                    "num_chunks": num_chunks,
                }
                try:
                    requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
                except Exception as cb_err:  # noqa: BLE001
                    logger.error(f"Callback failed: {cb_err}")
                return payload
        # Non-layout JSON path
        if fname_lower.endswith(".layout.txt"):
            chunks = _split_layout_txt_into_chunks(text)
            if not chunks:
                chunks = semantic_chunk_text_tag_aware(text, threshold=threshold, max_chunk_chars=max_chunk_chars, max_parts=max_parts, overlap_sentences=overlap_sentences)
        else:
            if has_tags:
                chunks = semantic_chunk_text_tag_aware(text, threshold=threshold, max_chunk_chars=max_chunk_chars, max_parts=max_parts, overlap_sentences=overlap_sentences)
            else:
                chunks = semantic_chunk_text(text, threshold=threshold, max_chunk_chars=max_chunk_chars, max_parts=max_parts, overlap_sentences=overlap_sentences)
        _write_chunks(folder_path, chunks, include_text_tag=has_tags)
        num_chunks = len(chunks)
        status = "success"
    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error(f"semantic_chunking_task error: {error_message}", exc_info=True)

    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "num_chunks": num_chunks,
    }
    if error_message:
        payload["error_message"] = error_message
    try:
        requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
    except Exception as cb_err:  # noqa: BLE001
        logger.error(f"Callback failed: {cb_err}")
    return payload

