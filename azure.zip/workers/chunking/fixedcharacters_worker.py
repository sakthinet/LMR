import os
import json
import logging
from typing import List, Tuple, Optional, Any, Dict
from celery import Celery
from kombu import Queue
import requests

# ---------------- Env & Logging -----------------

# Strict env helper

def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for fixed_characters_worker")
    return val

# Required configuration
BROKER_URL = os.getenv("CHUNKING_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("CHUNKING_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")
LOG_LEVEL = (os.getenv("CHUNKING_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")  # e.g. http://localhost:8000/chunking/worker-results
CHUNKING_QUEUES = _req("CHUNKING_QUEUES")  # e.g. "fixed_characters"

logger = logging.getLogger("fixedcharacters_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:  # noqa: BLE001
    logger.setLevel(logging.INFO)

# --------------- Celery App ----------------
celery_app = Celery(
    'chunking_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

# Configure queues from env (comma-separated)
queue_names = [q.strip() for q in CHUNKING_QUEUES.split(',') if q.strip()]
if not queue_names:
    raise RuntimeError("CHUNKING_QUEUES must specify at least one queue name (e.g. 'fixed_characters')")
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]

# ---------------- Helpers -----------------

def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\") or p.startswith("//"))


def _read_first_text_file(folder_path: str) -> str:
    txt_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.txt')]
    if not txt_files:
        raise FileNotFoundError("No .txt file found in folder")
    txt_path = os.path.join(folder_path, txt_files[0])
    with open(txt_path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def _find_layout_segments(data: Any) -> Optional[List[Dict[str, Any]]]:
    """Recursively search for a list of segments/items in a JSON object."""
    def looks_like_segments(val: Any) -> bool:
        if not isinstance(val, list) or not val or not isinstance(val[0], dict):
            return False
        # Heuristic: check for common keys
        keys = set(val[0].keys())
        return bool(keys & {"text", "text_tag", "type", "content"})

    if isinstance(data, dict):
        # Priority keys
        for key in ("layout", "segments", "items", "elements", "data", "parser_output"):
            cand = data.get(key)
            if looks_like_segments(cand):
                return cand  # type: ignore[return-value]
        # Shallow walk
        for v in data.values():
            found = _find_layout_segments(v)
            if found:
                return found
    elif isinstance(data, list):
        if looks_like_segments(data):
            return data  # type: ignore[return-value]
        for it in data:
            found = _find_layout_segments(it)
            if found:
                return found
    return None


def _read_layout_or_parser_output(folder_path: str) -> Tuple[List[dict], str, str]:
    """Locate and load a layout-style JSON or parser_output JSON file using robust detection.

    Returns:
        (segments_list, filename, mode)
    """
    # Prefer .layout.json or .parser_output.json, but check all JSONs
    json_files = sorted([f for f in os.listdir(folder_path) if f.lower().endswith('.json')])
    
    # Prioritize specific suffixes
    priority = []
    others = []
    for f in json_files:
        if f.lower().endswith('.layout.json') or f.lower().endswith('.parser_output.json'):
            priority.append(f)
        else:
            others.append(f)
    
    for fname in priority + others:
        path = os.path.join(folder_path, fname)
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
                data = json.load(fh)
            segments = _find_layout_segments(data)
            if segments:
                return segments, fname, 'json_layout'
        except Exception:
            continue

    raise FileNotFoundError("No valid layout/parser output JSON found in folder")


def _strip_tags(s: str) -> str:
    import re as _re
    return _re.sub(r"<[^>]+>", "", s or "")


def _snap_index_to_boundary(text: str, idx: int, *, direction: str, max_scan: int = 200) -> int:
    """Snap an index to a nearby natural boundary.

    This avoids cutting sentences mid-way for fixed-size chunking.
    We prefer sentence/paragraph boundaries but will fall back to whitespace.
    """
    if not text:
        return 0
    n = len(text)
    idx = max(0, min(int(idx), n))
    if direction not in {"left", "right"}:
        return idx

    boundary_chars = {"\n", "\r"}
    sentence_endings = {".", "!", "?"}

    def is_boundary(i: int) -> bool:
        if i <= 0 or i >= n:
            return True
        ch = text[i - 1]
        if ch in boundary_chars:
            return True
        if ch in sentence_endings:
            # require next char is whitespace/newline/end
            nxt = text[i] if i < n else " "
            return nxt.isspace() or nxt in boundary_chars
        return False

    if direction == "left":
        start = max(0, idx - max_scan)
        for i in range(idx, start, -1):
            if is_boundary(i):
                return i
        # fallback to whitespace
        for i in range(idx, start, -1):
            if text[i - 1].isspace():
                return i
        return idx

    end = min(n, idx + max_scan)
    for i in range(idx, end):
        if is_boundary(i):
            return i
    for i in range(idx, end):
        if i < n and text[i].isspace():
            return i
    return idx


def _normalize_segments(items: List[dict]) -> List[Dict[str, Any]]:
    """Normalize parser/layout segments extracting consistent metadata.

    Fields preserved: type, page, bbox, element_id (from element_id/id/elementId),
    source, kv_pairs, table_summary, text (plain).
    """
    norm: List[Dict[str, Any]] = []
    for idx, seg in enumerate(items):
        if not isinstance(seg, dict):
            continue
        seg_type = str(seg.get('type', 'paragraph')).lower()
        element_id = seg.get('element_id') or seg.get('id') or seg.get('elementId') or idx
        # semantic_chunking_worker outputs plain `text` (tags stripped when necessary)
        raw_text = seg.get('text')
        if raw_text is None or (isinstance(raw_text, str) and raw_text.strip() == ""):
            raw_text = seg.get('text_tag') or seg.get('text_tagged') or ''
            if not isinstance(raw_text, str):
                raw_text = str(raw_text)
            plain = _strip_tags(raw_text)
        else:
            plain = raw_text
        if not isinstance(plain, str):
            plain = str(plain)
        norm.append({
            'type': seg_type,
            'page': seg.get('page'),
            'bbox': seg.get('bbox'),
            'element_id': element_id,
            'source': seg.get('source'),
            'kv_pairs': seg.get('kv_pairs') if isinstance(seg.get('kv_pairs'), list) else [],
            'table_summary': seg.get('table_summary'),
            # Preserve tagged/HTML text if present (used for tables / provenance)
            'text_tag': seg.get('text_tag') or seg.get('text_tagged'),
            'text': plain,
        })
    return norm


def _is_page_marker(seg: Dict[str, Any]) -> bool:
    txt = seg.get('text')
    if not isinstance(txt, str):
        return False
    t = txt.strip()
    return t.startswith('<<<PAGE:') and t.endswith('>>>')


def _build_fixed_character_chunks(
    segments: List[Dict[str, Any]],
    *,
    chunk_size: int,
    chunk_overlap: int,
    doc_id: str,
    strategy: str = "fixedchar",
) -> List[Dict[str, Any]]:
    """Build fixed-size character windows with overlap, matching semantic_chunking_worker chunk schema.

    Output per chunk:
        - chunk_text: {"element": [<single element>]}
        - embed_text: plain text used for embeddings

    Rules:
        - If a window intersects multiple source segments, emit a single GroupedElement with original_elements.
        - Tables are unsplittable: assign the whole table to the first overlapping window only, emitted as its own chunk.
        - Tags stay inside element['text'] when source provides text_tag; never as a top-level field.
    """
    # Linearize segments into a single plain string (for windowing) with separators, tracking boundaries.
    # Note: segments are already normalized to include plain `text`.
    import uuid as _uuid

    parts: List[Tuple[int, int, Dict[str, Any]]] = []  # (start,end,seg)
    cursor = 0
    sep = '\n\n'
    usable_segments = [s for s in segments if not _is_page_marker(s)]
    for seg in usable_segments:
        txt_plain = seg.get('text') or ''
        if not isinstance(txt_plain, str):
            txt_plain = str(txt_plain)
        start = cursor
        end = start + len(txt_plain)
        parts.append((start, end, seg))
        cursor = end + len(sep)
    full_plain = sep.join([(seg.get('text') or '') if isinstance(seg.get('text'), str) else str(seg.get('text') or '') for seg in usable_segments])

    if chunk_size <= 0:
        raise ValueError('chunk_size must be > 0')
    step = chunk_size - chunk_overlap if chunk_overlap < chunk_size else chunk_size
    if step <= 0:
        step = chunk_size

    chunks: List[Dict[str, Any]] = []
    window_start = 0
    full_len = len(full_plain)
    # Track tables already assigned to a chunk to avoid splitting or duplicating
    assigned_tables: set = set()
    while window_start < full_len:
        raw_end = min(window_start + chunk_size, full_len)
        # Prefer extending to the next boundary (avoid mid-sentence cuts).
        # If that fails (no boundary nearby), fall back to snapping left.
        window_end = _snap_index_to_boundary(full_plain, raw_end, direction="right")
        if window_end <= window_start or window_end > min(full_len, raw_end + 250):
            window_end = _snap_index_to_boundary(full_plain, raw_end, direction="left")
        if window_end <= window_start:
            window_end = raw_end

        contributing_ids: List[str] = []
        contributing_segs: List[Dict[str, Any]] = []
        embed_text_parts: List[str] = []

        # If a table overlaps this window, emit it standalone and skip other content.
        table_emitted = False
        for s_start, s_end, seg in parts:
            if s_end < window_start or s_start > window_end:
                continue
            slice_start = max(window_start, s_start)
            slice_end = min(window_end, s_end)
            slice_len = max(0, slice_end - slice_start)
            if slice_len <= 0:
                continue
            elem_id = str(seg.get('element_id') or seg.get('id') or seg.get('elementId') or '')
            seg_type = str(seg.get('type') or 'paragraph').lower()
            if seg_type == 'table':
                if elem_id in assigned_tables:
                    continue
                # Preserve raw table markup when available, like semantic chunking.
                raw_table = seg.get('text_tag') or seg.get('text') or ''
                if not isinstance(raw_table, str):
                    raw_table = str(raw_table)
                # Emit standalone table chunk (semantic style)
                elem = {
                    'element_id': elem_id,
                    'type': 'table',
                    'text': raw_table,
                    'original_elements': str(elem_id),
                    'page': seg.get('page'),
                    'bbox': seg.get('bbox'),
                    'source': seg.get('source'),
                    'kv_pairs': seg.get('kv_pairs') if isinstance(seg.get('kv_pairs'), list) else [],
                    'table_summary': seg.get('table_summary') or {},
                }
                chunks.append({
                    'chunk_text': {'element': [elem]},
                    'embed_text': _strip_tags(raw_table).strip(),
                })
                assigned_tables.add(elem_id)
                table_emitted = True
                break

            # Regular segments: include only the slice within the window (plain for embedding)
            offset_in_seg = slice_start - s_start
            base_plain = seg.get('text') or ''
            if not isinstance(base_plain, str):
                base_plain = str(base_plain)
            seg_text_part_plain = base_plain[offset_in_seg: offset_in_seg + slice_len]
            seg_text_part_plain = _strip_tags(seg_text_part_plain)
            if seg_text_part_plain:
                embed_text_parts.append(seg_text_part_plain)
            contributing_segs.append(seg)
            if elem_id and (not contributing_ids or contributing_ids[-1] != elem_id):
                contributing_ids.append(elem_id)

        if not table_emitted:
            embed_text = '\n'.join([p for p in embed_text_parts if p]).strip()
            if not contributing_ids:
                # empty window
                # move forward, but snap to the next boundary to avoid repeated mid-sentence cuts
                window_start = _snap_index_to_boundary(full_plain, window_start + step, direction="right")
                continue

            # De-duplicate ids while preserving order
            seen = set()
            contributing_ids = [x for x in contributing_ids if x and (x not in seen and not seen.add(x))]

            if len(contributing_ids) == 1:
                seg0 = contributing_segs[0]
                sid = contributing_ids[0]
                elem = {
                    'element_id': sid,
                    'type': str(seg0.get('type') or 'paragraph').lower(),
                    # Fixed-char windows are slices, so set text to the slice.
                    'text': embed_text,
                    'original_elements': str(sid),
                    'page': seg0.get('page'),
                    'bbox': seg0.get('bbox'),
                    'source': seg0.get('source'),
                    'kv_pairs': seg0.get('kv_pairs') if isinstance(seg0.get('kv_pairs'), list) else [],
                    'table_summary': seg0.get('table_summary') or {},
                }
            else:
                first = contributing_segs[0]
                elem = {
                    'element_id': _uuid.uuid4().hex,
                    'type': 'GroupedElement',
                    'text': embed_text,
                    'original_elements': ','.join([str(x) for x in contributing_ids if x]),
                    'page': first.get('page'),
                    'bbox': None,
                    'source': first.get('source'),
                    'kv_pairs': [],
                    'table_summary': {},
                }

            chunks.append({
                'chunk_text': {'element': [elem]},
                'embed_text': embed_text,
            })

        # Advance with overlap but avoid starting mid-sentence.
        window_start = _snap_index_to_boundary(full_plain, window_start + step, direction="right")
    return chunks


def _write_chunks(folder_path: str, folder_id: str, chunks: List[str]) -> List[Dict[str, Any]]:
    """Write individual chunk files in semantic-style layout and return list of chunk dicts.

    Each chunk file contains:
      - chunk_id: UUID for the chunk
      - chunk_text: {"element": [single synthetic element]}
      - embed_text: plain text content

    This mirrors the schema used by semantic_chunking_worker / sentence_chunking_worker
    for plain-text fallbacks.
    """
    import uuid as _uuid

    chunk_dicts: List[Dict[str, Any]] = []
    for idx, chunk in enumerate(chunks):
        element_id = f"{folder_id}-fixedchar-chunk-{idx}"
        elem = {
            "element_id": element_id,
            "type": "paragraph",
            "text": chunk,
            "original_elements": element_id,
            "page": None,
            "bbox": None,
            "source": None,
            "kv_pairs": [],
            "table_summary": {},
        }
        payload = {
            "chunk_id": str(_uuid.uuid4()),
            "chunk_text": {"element": [elem]},
            "embed_text": chunk,
        }
        chunk_path = os.path.join(folder_path, f"chunk{idx}.json")
        with open(chunk_path, "w", encoding="utf-8") as cf:
            json.dump(payload, cf, ensure_ascii=False, indent=2)
        chunk_dicts.append(payload)
    return chunk_dicts


def _write_aggregate_chunk_json(folder_path: str, chunks: List[Dict[str, Any]], filename: str = "chunk.json") -> str:
    """Write aggregate chunk.json file."""
    out_path = os.path.join(folder_path, filename)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"layout": chunks}, f, ensure_ascii=False, indent=2)
    return out_path


# ---------------- Chunking Logic -----------------

def fixed_characters_chunking(folder_id: str, chunk_size: int, chunk_overlap: int) -> int:
    """Layout-aware fixed character chunking aligning with semantic chunking metadata retention."""
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
    else:
        folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    layout_segments: Optional[List[Dict[str, Any]]] = None
    try:
        items, fname, mode = _read_layout_or_parser_output(folder_path)
        layout_segments = _normalize_segments(items)
        logger.info(f"[fixed_characters] Using layout '{fname}' with {len(layout_segments)} segments")
    except Exception:
        logger.info("[fixed_characters] No layout JSON found; falling back to plain text chunking.")

    if layout_segments:
        # doc_id from folder name; strategy name for this worker is 'fixedchar'
        doc_id = os.path.basename(folder_path.rstrip(os.sep))
        chunk_objs = _build_fixed_character_chunks(layout_segments, chunk_size=chunk_size, chunk_overlap=chunk_overlap, doc_id=doc_id, strategy='fixedchar')
        # Write per-chunk files, adding chunk_id like semantic_chunking_worker
        import uuid as _uuid
        for i, obj in enumerate(chunk_objs):
            payload = {"chunk_id": str(_uuid.uuid4()), **obj}
            out_name = f"chunk{i}.json"
            out_path = os.path.join(folder_path, out_name)
            with open(out_path, 'w', encoding='utf-8') as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        # As requested, do not create aggregate chunk.json; only separate chunk files
        return len(chunk_objs)

    # Plain text fallback (legacy behavior)
    text = _read_first_text_file(folder_path)
    step = chunk_size - chunk_overlap if chunk_overlap < chunk_size else chunk_size
    if step <= 0:
        step = chunk_size
    chunks_plain: List[str] = []
    i = 0
    while i < len(text):
        chunks_plain.append(text[i:i + chunk_size])
        i += step
    # Use semantic-style per-chunk layout in the plain-text fallback as well
    doc_id = os.path.basename(folder_path.rstrip(os.sep))
    _ = _write_chunks(folder_path, doc_id, chunks_plain)
    # Do not create aggregate chunk.json in fallback either
    return len(chunks_plain)


# --------------- Task ----------------------
@celery_app.task(name="fixedcharacters_worker.fixedcharacters_task")
def fixedcharacters_task(task_id, folder_id, chunking_config, dag_id, run_id):
    """Chunk text into fixed-size overlapping windows and POST results to API.

    Args:
        task_id: UUID task id
        folder_id: UUID/absolute folder where input .txt resides
        chunking_config: dict with ChunkingStrategy, ChunkSize, ChunkOverlap
        dag_id: upstream process name
        run_id: upstream job id
    """
    status = "failed"
    error_message = None
    num_chunks = 0

    try:
        cfg = chunking_config if isinstance(chunking_config, dict) else {}
        # Accept various casings/aliases
        size_val = (
            cfg.get("ChunkSize")
            or cfg.get("chunk_size")
            or cfg.get("size")
            or cfg.get("chunksize")
        )
        overlap_val = (
            cfg.get("ChunkOverlap")
            or cfg.get("chunk_overlap")
            or cfg.get("overlap")
        )
        if size_val is None:
            raise ValueError("ChunkSize is required in ChunkingConfig")
        if overlap_val is None:
            raise ValueError("ChunkOverlap is required in ChunkingConfig")

        chunk_size = int(size_val)
        chunk_overlap = int(overlap_val)
        if chunk_size <= 0:
            raise ValueError("ChunkSize must be > 0")
        if chunk_overlap < 0:
            raise ValueError("ChunkOverlap must be >= 0")

        num_chunks = fixed_characters_chunking(folder_id, chunk_size, chunk_overlap)
        status = "success"
    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error(f"Exception in fixed_characters_task: {error_message}", exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "num_chunks": num_chunks,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting chunking results to {WORKER_RESULTS_URL}: {payload}")
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error(f"chunking worker-results callback returned HTTP {resp.status_code}: {resp.text}")
    except Exception as cb_err:  # noqa: BLE001
        logger.error(f"Failed to POST chunking worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "num_chunks": num_chunks,
        "error": error_message,
    }


