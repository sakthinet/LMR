<#
start_workers.ps1

Starts each Celery worker in its own PowerShell window. For each worker folder this script:
 - cd's into the worker folder
 - activates the venv if one exists at ./venv/Scripts/Activate.ps1 (or ./venv/scripts/activate.ps1)
 - runs the celery command for that worker

Usage:
 - Double-click start_workers.bat from Explorer, or
 - From PowerShell: .\start_workers.ps1

Notes:
 - This opens a new PowerShell window per worker and keeps it open (-NoExit) so you can see logs.
 - Adjust paths or commands below if your venv layout differs.
#>

$workers = @(
    @{ Path = "C:\VCS\context-craft\workers\ingest"; Cmd = "celery -A folder_worker worker -Q folder --loglevel=info -n folder_worker@`%h -P solo" },
    @{ Path = "C:\VCS\context-craft\workers\Parser"; Cmd = "celery -A tesseract_worker worker -Q tesseract,runtime_tesseract --loglevel=info -n tesseract_worker@`%h -P solo" },
    @{ Path = "C:\VCS\context-craft\workers\textprocessing"; Cmd = "celery -A textprocessing_worker worker -Q textprocessing,runtime_textprocessing --loglevel=info -n textprocessing_worker@`%h -P solo" },
    @{ Path = "C:\VCS\context-craft\workers\chunking"; Cmd = "celery -A fixedcharacters_worker worker -Q fixedcharacters,runtime_fixedcharacters -l info -n fixedcharacters_worker@`%h -P solo" },
    @{ Path = "C:\VCS\context-craft\workers\vectorization"; Cmd = "celery -A nomic_embed_text_worker worker -Q nomic_embed_text -l info -n nomic_embed_text_worker@`%h -P solo" },
    @{ Path = "C:\VCS\context-craft\workers\export"; Cmd = "celery -A qdrant_worker worker -Q qdrant --loglevel=info -n qdrant_worker@`%h -P solo" }
)

foreach ($w in $workers) {
    $path = $w.Path
    $cmd = $w.Cmd
    Write-Host "Starting worker in $path" -ForegroundColor Cyan

    # Build a safe PowerShell command that: cd's to the folder, activates venv if present, then runs the celery command.
    $activateCheck = "if (Test-Path .\\venv\\Scripts\\Activate.ps1) { . .\\venv\\Scripts\\Activate.ps1 } elseif (Test-Path .\\venv\\scripts\\activate.ps1) { . .\\venv\\scripts\\activate.ps1 } else { Write-Warning 'venv activate script not found in $path' }"

    $psCommand = "cd '$path'; $activateCheck; $cmd"

    # Start a new PowerShell window and run the command, leaving it open so logs are visible
    Start-Process -FilePath "powershell.exe" -ArgumentList "-NoExit", "-Command", $psCommand -WorkingDirectory $path

    # Small pause to avoid race-starting too many windows at once
    Start-Sleep -Milliseconds 300
}

Write-Host "Launched all worker windows." -ForegroundColor Green
