import json
import logging
import os
from typing import Any, Callable, Dict, List, Optional

import requests
from celery import Celery
from dotenv import load_dotenv
from kombu import Queue

ENV_FILE = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(ENV_FILE, override=True)

EmbeddingFunction = Callable[[str, str, Dict[str, Any], "WorkerContext"], List[float]]


def ensure_float_list(values: Any) -> List[float]:
    if not isinstance(values, list):
        raise ValueError("Embedding payload is not a list")
    floats: List[float] = []
    for item in values:
        try:
            floats.append(float(item))
        except (TypeError, ValueError) as exc:
            raise ValueError("Embedding payload contains non-numeric values") from exc
    return floats


def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for vectorization workers")
    return val


def _configure_logger(name: str, level: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    try:
        logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    except Exception:  # noqa: BLE001
        logger.setLevel(logging.INFO)
    return logger


def normalize_provider(name: str) -> str:
    return (name or "").strip().lower().replace(" ", "_").replace("-", "_")


class WorkerContext:
    def __init__(self, worker_name: str, default_queue: str):
        self.worker_name = worker_name
        self.default_queue = (default_queue or "nomic_embed_text").strip() or "nomic_embed_text"
        self.broker_url = os.getenv("VECTORIZE_BROKER_URL") or _req("CELERY_BROKER_URL")
        self.result_backend = os.getenv("VECTORIZE_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
        self.data_backbone_dir = _req("DATA_BACKBONE_DIR")
        self.embeddings_api_url = os.getenv("EMBEDDINGS_API_URL")
        self.worker_results_url = _req("WORKER_RESULTS_URL")
        self.embedding_timeout = int(os.getenv("EMBEDDING_REQUEST_TIMEOUT") or "120")
        self.log_level = (os.getenv("VECTORIZE_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO")
        queue_cfg = os.getenv("VECTORIZE_QUEUES") or os.getenv("VECTORIZATION_QUEUES") or ""
        queue_names = [q.strip() for q in queue_cfg.split(",") if q.strip()]
        if self.default_queue and self.default_queue not in queue_names:
            queue_names.append(self.default_queue)
        if not queue_names:
            queue_names = [self.default_queue]
        self.queue_names = queue_names
        self.logger = _configure_logger(worker_name, self.log_level)

    def ensure_queue(self, queue_name: Optional[str]) -> str:
        name = (queue_name or self.default_queue).strip() or self.default_queue
        if name not in self.queue_names:
            self.queue_names.append(name)
        return name


def create_celery_app(ctx: WorkerContext) -> Celery:
    celery_app = Celery(
        "vectorize_worker",
        broker=ctx.broker_url,
        backend=ctx.result_backend,
    )
    celery_app.conf.task_queues = tuple(Queue(name) for name in ctx.queue_names)
    celery_app.conf.task_default_queue = ctx.default_queue
    return celery_app


def _is_abs_or_unc(path: str) -> bool:
    return bool(path) and (os.path.isabs(path) or path.startswith("\\") or path.startswith("//"))


def _iter_chunk_files(folder_path: str) -> List[str]:
    files = [f for f in os.listdir(folder_path) if f.startswith("chunk") and f.endswith(".json")]
    files.sort()
    return files


def _extract_embedding_input(chunk_data: Dict[str, Any]) -> str:
    embed_text = chunk_data.get("embed_text")
    if isinstance(embed_text, str) and embed_text.strip():
        return embed_text.strip()
    return ""


def _run_embedding(
    ctx: WorkerContext,
    folder_id: str,
    model_name: str,
    embedding_dimension: int,
    provider_label: str,
    vectorize_cfg: Dict[str, Any],
    embed_fn: EmbeddingFunction,
) -> int:
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
    else:
        folder_path = os.path.join(ctx.data_backbone_dir, folder_id)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    chunk_files = _iter_chunk_files(folder_path)
    if not chunk_files:
        raise FileNotFoundError("No chunk json files found in folder")

    updated = 0
    for chunk_file in chunk_files:
        chunk_path = os.path.join(folder_path, chunk_file)
        with open(chunk_path, "r", encoding="utf-8") as cf:
            chunk_data = json.load(cf)
        chunk_text = _extract_embedding_input(chunk_data)
        if not chunk_text:
            raise ValueError(f"Chunk {chunk_file} missing required embed_text")
        embedding = embed_fn(chunk_text, model_name, vectorize_cfg, ctx)
        if not embedding:
            raise ValueError(f"Invalid embedding received for chunk: {chunk_file}")
        if embedding_dimension and len(embedding) != embedding_dimension:
            if len(embedding) > embedding_dimension:
                embedding = embedding[:embedding_dimension]
            else:
                embedding = embedding + [0.0] * (embedding_dimension - len(embedding))
        chunk_data["embedding_model"] = model_name
        chunk_data["embedding_provider"] = provider_label
        chunk_data["embedding_dimension"] = embedding_dimension
        chunk_data["embedding_input_length"] = len(chunk_text)
        chunk_data["embedding"] = embedding
        with open(chunk_path, "w", encoding="utf-8") as cf:
            json.dump(chunk_data, cf, ensure_ascii=False, indent=2)
        updated += 1
    return updated


def _post_results(ctx: WorkerContext, payload: Dict[str, Any]) -> None:
    try:
        ctx.logger.info("Posting vectorize results to %s: %s", ctx.worker_results_url, payload)
        resp = requests.post(ctx.worker_results_url, json=payload, timeout=30)
        if resp.status_code >= 300:
            ctx.logger.error(
                "Vectorize worker-results callback returned HTTP %s: %s",
                resp.status_code,
                resp.text,
            )
    except Exception as exc:  # noqa: BLE001
        ctx.logger.error("Failed to POST vectorize worker results: %s", exc)


def execute_task(
    ctx: WorkerContext,
    provider_label: str,
    embed_fn: EmbeddingFunction,
    task_id,
    folder_id,
    vectorize_config,
    dag_id,
    run_id,
):
    status = "failed"
    error_message = None
    updated = 0
    provider_name = provider_label
    provider_key_hint = normalize_provider(provider_label)
    model_name = None
    embedding_dimension: Optional[int] = None

    cfg: Dict[str, Any] = vectorize_config if isinstance(vectorize_config, dict) else {}

    try:
        model_name = (
            cfg.get("EmbeddingModel")
            or cfg.get("embedding_model")
            or cfg.get("embeddingModel")
            or cfg.get("embeddingmodel")
            or cfg.get("model")
        )
        if not model_name:
            raise ValueError("EmbeddingModel is required in VectorizeConfig")

        dim_val = (
            cfg.get("EmbeddingDimension")
            or cfg.get("embedding_dimension")
            or cfg.get("embeddingDimension")
            or cfg.get("embeddingdimensions")
            or cfg.get("EmbeddingDimensions")
            or cfg.get("embedding_dimensions")
            or cfg.get("embeddingDimensions")
            or cfg.get("dimension")
        )
        if dim_val is None:
            raise ValueError("EmbeddingDimension is required in VectorizeConfig")
        embedding_dimension = int(dim_val)
        if embedding_dimension <= 0:
            raise ValueError("EmbeddingDimension must be > 0")

        cfg_provider = (
            cfg.get("EmbeddingProvider")
            or cfg.get("embedding_provider")
            or cfg.get("embeddingProvider")
            or cfg.get("embeddingprovider")
            or cfg.get("provider")
            or provider_label
        )
        if cfg_provider:
            normalized_cfg = normalize_provider(str(cfg_provider))
            if provider_key_hint and normalized_cfg and provider_key_hint != normalized_cfg:
                ctx.logger.info(
                    "Embedding provider mismatch (payload=%s, worker=%s); overriding to worker",
                    normalized_cfg,
                    provider_key_hint,
                )
            provider_name = str(cfg_provider)
        provider_name = provider_name or provider_label

        updated = _run_embedding(
            ctx,
            folder_id,
            str(model_name),
            embedding_dimension,
            provider_name,
            cfg,
            embed_fn,
        )
        status = "success"
    except Exception as exc:  # noqa: BLE001
        error_message = str(exc)
        ctx.logger.error("Exception in %s: %s", ctx.worker_name, error_message, exc_info=True)

    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        "num_chunks": updated,
        "embedding_provider": provider_name,
        "embedding_model": model_name,
        "embedding_dimension": embedding_dimension,
    }
    if error_message:
        payload["error_message"] = error_message

    _post_results(ctx, payload)

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "error": error_message,
    }

PROVIDER_LABEL = "ollama"
DEFAULT_QUEUE = os.getenv("OLLAMA_QUEUE_NAME") or "ollama"

context = WorkerContext("ollama_worker", DEFAULT_QUEUE)
celery_app = create_celery_app(context)


def _resolve_url(vectorize_cfg: Dict[str, Any]) -> str:
    return (
        vectorize_cfg.get("EmbeddingsApiUrl")
        or vectorize_cfg.get("EmbeddingApiUrl")
        or vectorize_cfg.get("embedding_api_url")
        or os.getenv("OLLAMA_EMBEDDINGS_URL")
        or context.embeddings_api_url
    )


def _embed_via_ollama(text: str, model_name: str, vectorize_cfg: Dict[str, Any], ctx: WorkerContext) -> List[float]:
    url = _resolve_url(vectorize_cfg)
    if not url:
        raise RuntimeError("Ollama embeddings require OLLAMA_EMBEDDINGS_URL or EMBEDDINGS_API_URL")

    options = vectorize_cfg.get("EmbeddingOptions") or vectorize_cfg.get("embedding_options") or {}
    if not isinstance(options, dict):
        options = {}
    options.setdefault("embedding_only", True)

    response = requests.post(
        url,
        json={
            "model": model_name,
            "prompt": text,
            "options": options,
        },
        timeout=ctx.embedding_timeout,
    )
    response.raise_for_status()
    data = response.json()
    embedding = data.get("embedding")
    if isinstance(embedding, list) and embedding:
        return ensure_float_list(embedding)
    if isinstance(data.get("data"), list) and data["data"]:
        candidate = data["data"][0]
        if isinstance(candidate, dict) and isinstance(candidate.get("embedding"), list):
            return ensure_float_list(candidate["embedding"])
    raise ValueError("Ollama response missing embedding")


def _register_task(task_name: str):
    queue_name = context.ensure_queue(DEFAULT_QUEUE)

    @celery_app.task(name=task_name, queue=queue_name)
    def _task(task_id, folder_id, vectorize_config, dag_id, run_id):
        return execute_task(context, PROVIDER_LABEL, _embed_via_ollama, task_id, folder_id, vectorize_config, dag_id, run_id)

    return _task


nomic_embed_text_task = _register_task("nomic_embed_text_worker.nomic_embed_text_task")
ollama_embed_task = _register_task("ollama_embed_worker.ollama_embed_task")
ollama_task = _register_task("ollama_worker.ollama_task")
