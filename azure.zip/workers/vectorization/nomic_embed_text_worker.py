import os
import json
import logging
from typing import List
import requests
from celery import Celery
from dotenv import load_dotenv
from kombu import Queue

# ---------------- Env & Logging -----------------
# Load .env from this folder (override to prefer local values)
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"), override=True)

# Strict env helper

def _req(key: str) -> str:
    val = os.getenv(key)
    if not val:
        raise RuntimeError(f"Environment variable '{key}' is required for nomic_embed_text_worker")
    return val

# Required configuration
BROKER_URL = os.getenv("VECTORIZE_BROKER_URL") or _req("CELERY_BROKER_URL")
RESULT_BACKEND = os.getenv("VECTORIZE_RESULT_BACKEND") or _req("CELERY_RESULT_BACKEND")
DATA_BACKBONE_DIR = _req("DATA_BACKBONE_DIR")
EMBEDDINGS_API_URL = _req("EMBEDDINGS_API_URL")
LOG_LEVEL = (os.getenv("VECTORIZE_LOG_LEVEL") or os.getenv("LOG_LEVEL") or "INFO").upper()
WORKER_RESULTS_URL = _req("WORKER_RESULTS_URL")  # e.g. http://localhost:8000/vectorize/worker-results
VECTORIZE_QUEUES = os.getenv("VECTORIZE_QUEUES") or os.getenv("VECTORIZATION_QUEUES") or "nomic_embed_text"

logger = logging.getLogger("nomic_embed_text_worker")
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
try:
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
except Exception:  # noqa: BLE001
    logger.setLevel(logging.INFO)

# --------------- Celery App ----------------
celery_app = Celery(
    'vectorize_worker',
    broker=BROKER_URL,
    backend=RESULT_BACKEND,
)

# Configure queues from env (comma-separated)
queue_names = [q.strip() for q in VECTORIZE_QUEUES.split(',') if q.strip()]
if not queue_names:
    queue_names = ["nomic_embed_text"]
celery_app.conf.task_queues = tuple(Queue(name) for name in queue_names)
celery_app.conf.task_default_queue = queue_names[0]

# ---------------- Helpers -----------------

def _is_abs_or_unc(p: str) -> bool:
    return bool(p) and (os.path.isabs(p) or p.startswith("\\") or p.startswith("//"))


def _iter_chunk_files(folder_path: str) -> List[str]:
    files = [f for f in os.listdir(folder_path) if f.startswith("chunk") and f.endswith(".json")]
    files.sort()
    return files


def _embed_text(text: str, model_name: str) -> List[float]:  # type: ignore[name-defined]
    response = requests.post(
        EMBEDDINGS_API_URL,
        json={
            "model": model_name,
            "prompt": text,
            "options": {"embedding_only": True},
        },
        timeout=120,
    )
    response.raise_for_status()
    data = response.json()
    return data.get("embedding") or []


# ---------------- Core Logic -----------------

def _run_embedding(folder_id: str, model_name: str, embedding_dimension: int) -> int:
    # Resolve folder path
    if _is_abs_or_unc(folder_id):
        folder_path = folder_id
    else:
        folder_path = os.path.join(DATA_BACKBONE_DIR, folder_id)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    chunk_files = _iter_chunk_files(folder_path)
    if not chunk_files:
        raise FileNotFoundError("No chunk json files found in folder")

    updated = 0
    for chunk_file in chunk_files:
        chunk_path = os.path.join(folder_path, chunk_file)
        with open(chunk_path, "r", encoding="utf-8") as cf:
            chunk_data = json.load(cf)
        chunk_text = chunk_data.get("embed_text", "")
        embedding = _embed_text(chunk_text, model_name)
        if not embedding:
            raise ValueError(f"Invalid embedding received for chunk: {chunk_file}")
        # Fit to desired dimension
        if embedding_dimension and len(embedding) != embedding_dimension:
            if len(embedding) > embedding_dimension:
                embedding = embedding[:embedding_dimension]
            else:
                embedding = embedding + [0.0] * (embedding_dimension - len(embedding))
        chunk_data["embedding_model"] = model_name
        chunk_data["embedding_dimension"] = embedding_dimension
        chunk_data["embedding"] = embedding
        with open(chunk_path, "w", encoding="utf-8") as cf:
            json.dump(chunk_data, cf, ensure_ascii=False, indent=2)
        updated += 1
    return updated


# --------------- Task ----------------------
@celery_app.task(name="nomic_embed_text_worker.nomic_embed_text_task")
def nomic_embed_text_task(task_id, folder_id, vectorize_config, dag_id, run_id):
    """Embed chunk files using the model specified in VectorizeConfig and POST results.

    Args:
        task_id: UUID task id
        folder_id: UUID/absolute folder where chunk*.json reside
        vectorize_config: dict with EmbeddingModel and EmbeddingDimension
        dag_id: upstream process name
        run_id: upstream job id
    """
    status = "failed"
    error_message = None
    updated = 0

    try:
        cfg = vectorize_config if isinstance(vectorize_config, dict) else {}
        model_name = cfg.get("EmbeddingModel") or cfg.get("embedding_model") or cfg.get("model")
        if not model_name:
            raise ValueError("EmbeddingModel is required in VectorizeConfig")
        dim_val = cfg.get("EmbeddingDimension") or cfg.get("embedding_dimension") or cfg.get("dimension")
        if dim_val is None:
            raise ValueError("EmbeddingDimension is required in VectorizeConfig")
        embedding_dimension = int(dim_val)
        if embedding_dimension <= 0:
            raise ValueError("EmbeddingDimension must be > 0")

        updated = _run_embedding(folder_id, str(model_name), embedding_dimension)
        status = "success"
    except Exception as e:  # noqa: BLE001
        error_message = str(e)
        logger.error(f"Exception in nomic_embed_text_task: {error_message}", exc_info=True)

    # Report results back to API gateway
    payload = {
        "task_id": task_id,
        "status": status,
        "process_name": dag_id or "",
        "job_id": run_id,
        "folder_id": folder_id,
        # Optionally include number of embedded chunks
        # "num_chunks": updated,
    }
    if error_message:
        payload["error_message"] = error_message

    try:
        logger.info(f"Posting vectorize results to {WORKER_RESULTS_URL}: {payload}")
        resp = requests.post(WORKER_RESULTS_URL, json=payload, timeout=30)
        if resp.status_code >= 300:
            logger.error(f"vectorize worker-results callback returned HTTP {resp.status_code}: {resp.text}")
    except Exception as cb_err:  # noqa: BLE001
        logger.error(f"Failed to POST vectorize worker results: {cb_err}")

    return {
        "task_id": task_id,
        "status": status,
        "folder_id": folder_id,
        "job_id": run_id,
        "error": error_message,
    }
