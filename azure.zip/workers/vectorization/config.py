# Config for vectorization microservice
DATA_BACKBONE_DIR = r"\\AVDGENAIL18-3\DataBackBone"
DB_DSN = "postgresql://postgres:postgres@localhost:5432/RND"
EMBEDDINGS_API_URL = "http://localhost:11434/api/embeddings"
