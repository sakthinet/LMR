"""Application Registry for Multi-Tenant RTG Service."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, List, Any
import json
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from .pipelines.rtg_config import RTGMode

@dataclass
class AppConfig:
    app_id: str
    name: str
    mode: RTGMode
    max_file_size_mb: int
    ttl_seconds: int
    chunking_strategy: str = "page"
    chunking_params: Optional[Dict[str, Any]] = None

class AppRegistry:
    def __init__(self, database_url: str):
        self.engine: Engine = create_engine(database_url)

    def register_app(self, app_id: str, name: str, mode: str, max_file_size_mb: int, ttl_seconds: int, chunking_strategy: str = "page", chunking_params: Optional[Dict[str, Any]] = None) -> AppConfig:
        config = AppConfig(
            app_id=app_id,
            name=name,
            mode=RTGMode(mode),
            max_file_size_mb=max_file_size_mb,
            ttl_seconds=ttl_seconds,
            chunking_strategy=chunking_strategy,
            chunking_params=chunking_params
        )
        
        query = text("""
            INSERT INTO apps (app_id, name, mode, max_file_size_mb, ttl_seconds, chunking_strategy, chunking_params)
            VALUES (:app_id, :name, :mode, :max_file_size_mb, :ttl_seconds, :chunking_strategy, :chunking_params)
            ON CONFLICT (app_id) DO UPDATE SET
                name = EXCLUDED.name,
                mode = EXCLUDED.mode,
                max_file_size_mb = EXCLUDED.max_file_size_mb,
                ttl_seconds = EXCLUDED.ttl_seconds,
                chunking_strategy = EXCLUDED.chunking_strategy,
                chunking_params = EXCLUDED.chunking_params
        """)
        
        with self.engine.connect() as conn:
            conn.execute(query, {
                "app_id": config.app_id,
                "name": config.name,
                "mode": config.mode.value,
                "max_file_size_mb": config.max_file_size_mb,
                "ttl_seconds": config.ttl_seconds,
                "chunking_strategy": config.chunking_strategy,
                "chunking_params": json.dumps(config.chunking_params) if config.chunking_params else None
            })
            conn.commit()
            
        return config

    def get_app(self, app_id: str) -> Optional[AppConfig]:
        query = text("SELECT * FROM apps WHERE app_id = :app_id")
        with self.engine.connect() as conn:
            result = conn.execute(query, {"app_id": app_id}).mappings().fetchone()
            
        if result:
            return self._row_to_config(result)
        return None

    def list_apps(self) -> List[AppConfig]:
        query = text("SELECT * FROM apps")
        with self.engine.connect() as conn:
            results = conn.execute(query).mappings().fetchall()
            
        return [self._row_to_config(row) for row in results]

    def delete_app(self, app_id: str) -> bool:
        query = text("DELETE FROM apps WHERE app_id = :app_id")
        with self.engine.connect() as conn:
            result = conn.execute(query, {"app_id": app_id})
            conn.commit()
            return result.rowcount > 0

    def _row_to_config(self, row: Any) -> AppConfig:
        # Handle chunking_params which might be returned as dict or string depending on driver
        c_params = row["chunking_params"]
        if isinstance(c_params, str):
            c_params = json.loads(c_params)
            
        return AppConfig(
            app_id=row["app_id"],
            name=row["name"],
            mode=RTGMode(row["mode"]),
            max_file_size_mb=row["max_file_size_mb"],
            ttl_seconds=row["ttl_seconds"],
            chunking_strategy=row["chunking_strategy"],
            chunking_params=c_params
        )
