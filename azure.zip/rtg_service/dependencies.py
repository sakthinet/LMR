"""FastAPI dependency wiring for RTG service."""

from functools import lru_cache

from redis import Redis

from .env import EnvSettings, get_env_settings
from .pipelines.executor import PipelineExecutor
from .pipelines.pipeline_builder import PipelineBuilder
from .session.cleanup_worker import CleanupWorker
from .session.memory_manager import MemoryManager
from .session.redis_session_store import RedisSessionStore


@lru_cache(maxsize=1)
def _build_redis() -> Redis:
	settings = get_env_settings()
	return Redis.from_url(
		settings.redis_url,
		decode_responses=False,
		socket_timeout=5,
		health_check_interval=30,
	)


@lru_cache(maxsize=1)
def _memory_manager() -> MemoryManager:
	return MemoryManager(get_env_settings())


@lru_cache(maxsize=1)
def _session_store() -> RedisSessionStore:
	return RedisSessionStore(_build_redis(), get_env_settings())


@lru_cache(maxsize=1)
def _pipeline_builder() -> PipelineBuilder:
	return PipelineBuilder(get_env_settings())


@lru_cache(maxsize=1)
def _pipeline_executor() -> PipelineExecutor:
	return PipelineExecutor(get_env_settings(), _pipeline_builder(), _session_store(), _memory_manager())


@lru_cache(maxsize=1)
def _cleanup_worker() -> CleanupWorker:
	worker = CleanupWorker(_memory_manager(), _session_store(), get_env_settings().cleanup_interval_seconds)
	worker.start()
	return worker


def get_settings_dep() -> EnvSettings:
	return get_env_settings()


def get_pipeline_executor() -> PipelineExecutor:
	# Note: Skipping cleanup worker initialization due to threading issues with async event loop
	# _cleanup_worker()
	return _pipeline_executor()


def get_memory_manager() -> MemoryManager:
	return _memory_manager()


def get_session_store() -> RedisSessionStore:
	return _session_store()
