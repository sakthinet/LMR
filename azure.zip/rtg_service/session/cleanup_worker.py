"""Background cleanup worker for sessions."""

from __future__ import annotations

import threading
import time
from typing import Optional

from .memory_manager import MemoryManager
from .redis_session_store import RedisSessionStore


class CleanupWorker:
	def __init__(self, memory_manager: MemoryManager, session_store: RedisSessionStore, interval_seconds: int) -> None:
		self.memory_manager = memory_manager
		self.session_store = session_store
		self.interval = interval_seconds
		self._stop = threading.Event()
		self._thread: Optional[threading.Thread] = None

	def start(self) -> None:
		if self._thread and self._thread.is_alive():
			return
		self._thread = threading.Thread(target=self._run, name="rtg-cleanup", daemon=True)
		self._thread.start()

	def stop(self) -> None:
		self._stop.set()
		if self._thread:
			self._thread.join(timeout=5)

	def _run(self) -> None:
		while not self._stop.is_set():
			expired = self.memory_manager.expired_sessions()
			for session_id in expired:
				self.session_store.delete_session(session_id)
				self.memory_manager.remove_session(session_id)
			self.memory_manager.evict_lru_until_safe()
			time.sleep(self.interval)
