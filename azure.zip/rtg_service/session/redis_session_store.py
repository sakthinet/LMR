"""Redis-backed session registry and storage."""

from __future__ import annotations

import json
import time
from typing import Dict, Iterable, List, Optional

from redis import Redis

from ..env import EnvSettings
from ..pipelines.rtg_config import ChunkRecord, RTGMode


class RedisSessionStore:
	def __init__(self, redis: Redis, settings: EnvSettings) -> None:
		self.redis = redis
		self.settings = settings

	def _session_key(self, session_id: str, app_id: str) -> str:
		return f"{self.settings.redis_session_prefix}{app_id}:{session_id}"

	def _chunk_key(self, session_id: str, app_id: str) -> str:
		return f"{self.settings.redis_chunk_prefix}{app_id}:{session_id}"

	def _registry_key(self, app_id: str) -> str:
		return f"{self.settings.redis_registry_key}:{app_id}"

	def register_session(
		self,
		session_id: str,
		app_id: str,
		mode: RTGMode,
		ttl_seconds: int,
		chunk_count: int,
	) -> int:
		pod_id = self.settings.pod_id
		expires_at = int(time.time()) + ttl_seconds
		payload = {
			"session_id": session_id,
			"app_id": app_id,
			"mode": mode.value,
			"pod_id": pod_id,
			"chunk_count": chunk_count,
			"expires_at": expires_at,
		}
		pipe = self.redis.pipeline()
		pipe.set(self._session_key(session_id, app_id), json.dumps(payload), ex=ttl_seconds)
		pipe.hset(self._registry_key(app_id), session_id, pod_id)
		pipe.execute()
		return expires_at

	def store_chunks(self, session_id: str, app_id: str, chunks: Iterable[ChunkRecord], ttl_seconds: int) -> None:
		chunk_key = self._chunk_key(session_id, app_id)
		pipe = self.redis.pipeline()
		for chunk in chunks:
			payload = {
				"chunk_id": chunk.chunk_id,
				"page_number": chunk.page_number,
				"metadata": chunk.metadata,
				"text": chunk.text,
			}
			pipe.hset(chunk_key, chunk.chunk_id, json.dumps(payload))
		pipe.expire(chunk_key, ttl_seconds)
		pipe.execute()

	def get_session_info(self, session_id: str, app_id: str) -> Optional[Dict[str, str]]:
		data = self.redis.get(self._session_key(session_id, app_id))
		if not data:
			return None
		try:
			return json.loads(data)
		except json.JSONDecodeError:
			return None

	def validate_pod(self, session_id: str, app_id: str, pod_id: str) -> tuple[bool, Optional[str]]:
		owner = self.redis.hget(self._registry_key(app_id), session_id)
		if owner is None:
			return False, None
		owner_str = owner.decode() if isinstance(owner, (bytes, bytearray)) else owner
		return owner_str == pod_id, owner_str

	def get_chunks(self, session_id: str, app_id: str, chunk_ids: Iterable[str]) -> List[ChunkRecord]:
		chunk_key = self._chunk_key(session_id, app_id)
		payloads = self.redis.hmget(chunk_key, list(chunk_ids))
		records: List[ChunkRecord] = []
		for raw in payloads:
			if not raw:
				continue
			if isinstance(raw, bytes):
				raw = raw.decode("utf-8")
			try:
				data = json.loads(raw)
			except json.JSONDecodeError:
				continue
			records.append(
				ChunkRecord(
					chunk_id=data.get("chunk_id"),
					session_id=session_id,
					page_number=int(data.get("page_number", 0)),
					text=data.get("text", ""),
					metadata=data.get("metadata", {}),
				)
			)
		return records

	def get_all_session_chunks(self, session_id: str, app_id: str) -> List[ChunkRecord]:
		chunk_key = self._chunk_key(session_id, app_id)
		payloads = self.redis.hgetall(chunk_key)
		records: List[ChunkRecord] = []
		for _, raw in payloads.items():
			if isinstance(raw, bytes):
				raw = raw.decode("utf-8")
			try:
				data = json.loads(raw)
				records.append(
					ChunkRecord(
						chunk_id=data.get("chunk_id"),
						session_id=session_id,
						page_number=int(data.get("page_number", 0)),
						text=data.get("text", ""),
						metadata=data.get("metadata", {}),
					)
				)
			except json.JSONDecodeError:
				continue
		# Sort by page number and chunk index if available
		records.sort(key=lambda x: (x.page_number, int(x.metadata.get("chunk_index", 0))))
		return records

	def delete_session(self, session_id: str, app_id: str) -> None:
		pipe = self.redis.pipeline()
		pipe.delete(self._session_key(session_id, app_id))
		pipe.delete(self._chunk_key(session_id, app_id))
		pipe.hdel(self._registry_key(app_id), session_id)
		pipe.execute()
