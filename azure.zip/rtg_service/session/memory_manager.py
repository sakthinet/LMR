"""In-memory session + memory guardrails."""

from __future__ import annotations

import psutil
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..components.indexers.hnsw_indexer import HNSWIndexer
from ..components.indexers.bm25_indexer import BM25Indexer
from ..env import EnvSettings


@dataclass
class SessionHandle:
	session_id: str
	indexer: HNSWIndexer
	bm25: Optional[BM25Indexer]
	estimated_bytes: int
	expires_at: int
	last_access: float = field(default_factory=lambda: time.time())


class MemoryManager:
	def __init__(self, settings: EnvSettings) -> None:
		self.settings = settings
		self._sessions: Dict[str, SessionHandle] = {}
		self._lock = threading.RLock()
		self.evictions_total = 0
		self.creation_failures = 0

	def _rss_bytes(self) -> int:
		return psutil.Process().memory_info().rss

	def can_accept(self, estimated_bytes: int) -> bool:
		with self._lock:
			active = len(self._sessions)
			if active >= self.settings.session_limit_per_pod:
				return False
			vm = psutil.virtual_memory()
			projected = self._rss_bytes() + estimated_bytes
			if (projected / vm.total) > self.settings.memory_high_watermark:
				return False
			return True

	def note_creation_failure(self) -> None:
		with self._lock:
			self.creation_failures += 1

	def register_session(self, session_id: str, indexer: HNSWIndexer, bm25: Optional[BM25Indexer], estimated_bytes: int, expires_at: int) -> None:
		with self._lock:
			self._sessions[session_id] = SessionHandle(
				session_id=session_id,
				indexer=indexer,
				bm25=bm25,
				estimated_bytes=estimated_bytes,
				expires_at=expires_at,
			)

	def touch(self, session_id: str) -> None:
		with self._lock:
			handle = self._sessions.get(session_id)
			if handle:
				handle.last_access = time.time()

	def get_index(self, session_id: str) -> Tuple[Optional[HNSWIndexer], Optional[BM25Indexer]]:
		with self._lock:
			handle = self._sessions.get(session_id)
			if handle:
				handle.last_access = time.time()
				return handle.indexer, handle.bm25
			return None, None

	def remove_session(self, session_id: str) -> None:
		with self._lock:
			handle = self._sessions.pop(session_id, None)
			if handle and handle.indexer:
				handle.indexer.reset()

	def evict_lru_until_safe(self) -> List[str]:
		removed: List[str] = []
		with self._lock:
			vm = psutil.virtual_memory()
			while self._sessions and (self._rss_bytes() / vm.total) > self.settings.memory_target_watermark:
				lru_session = min(self._sessions.values(), key=lambda h: h.last_access)
				removed.append(lru_session.session_id)
				self._sessions.pop(lru_session.session_id, None)
				lru_session.indexer.reset()
				self.evictions_total += 1
		return removed

	def expired_sessions(self, now_ts: Optional[int] = None) -> List[str]:
		now = now_ts or int(time.time())
		with self._lock:
			return [sid for sid, handle in self._sessions.items() if handle.expires_at <= now]

	def metrics(self) -> Dict[str, int]:
		with self._lock:
			return {
				"active_sessions": len(self._sessions),
				"memory_usage_bytes": self._rss_bytes(),
				"session_evictions_total": self.evictions_total,
				"session_creation_failures_total": self.creation_failures,
			}
