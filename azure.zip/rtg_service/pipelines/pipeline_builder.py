"""Factory for constructing RTG pipelines."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union, Any

from ..components.chunkers.page_chunker import PageChunker
from ..components.chunkers.recursive_chunker import RecursiveChunker
from ..components.embedders.ollama_embedder import OllamaEmbedder
from ..components.generators.simple_answer import SimpleAnswerSynthesizer
from ..components.indexers.hnsw_indexer import HNSWIndexer
from ..components.indexers.bm25_indexer import BM25Indexer
from ..components.rerankers.cross_encoder_reranker import Reranker
from ..components.parsers.ocr_parser import OCRParser
from ..components.parsers.tika_parser import TikaParser
from ..env import EnvSettings
from .rtg_config import RTGMode, SessionPipelineConfig


@dataclass
class PipelineComponents:
	parser: object
	chunker: Union[PageChunker, RecursiveChunker]
	embedder: OllamaEmbedder
	generator: SimpleAnswerSynthesizer


class PipelineBuilder:
	def __init__(self, settings: EnvSettings) -> None:
		self.settings = settings

	def build(self, config: SessionPipelineConfig) -> PipelineComponents:
		parser = self._build_parser(config.mode)
		chunker = self._build_chunker(config)
		embedder = self.create_embedder()
		generator = self.create_generator()
		return PipelineComponents(parser=parser, chunker=chunker, embedder=embedder, generator=generator)

	def _build_chunker(self, config: SessionPipelineConfig) -> Union[PageChunker, RecursiveChunker]:
		strategy = config.chunking_strategy
		params = config.chunking_params or {}
		
		if strategy == "recursive":
			return RecursiveChunker(
				chunk_size=params.get("chunk_size", 1000),
				chunk_overlap=params.get("chunk_overlap", 200),
				separators=params.get("separators")
			)
		return PageChunker()

	def build_indexer(self) -> HNSWIndexer:
		return HNSWIndexer(
			space=self.settings.hnsw_distance_metric,
			m=self.settings.hnsw_m,
			ef_construction=self.settings.hnsw_ef_construction,
			ef_query=self.settings.hnsw_ef_query,
		)

	def build_bm25_indexer(self) -> BM25Indexer:
		return BM25Indexer()

	def create_embedder(self) -> OllamaEmbedder:
		return OllamaEmbedder(self.settings.ollama_url, self.settings.ollama_model)

	def create_reranker(self) -> Reranker:
		return Reranker()

	def create_generator(self) -> SimpleAnswerSynthesizer:
		return SimpleAnswerSynthesizer()

	def _build_parser(self, mode: RTGMode):
		if mode == RTGMode.VISION:
			return OCRParser(self.settings.ocr_api_url)
		return TikaParser(self.settings.tika_url)
