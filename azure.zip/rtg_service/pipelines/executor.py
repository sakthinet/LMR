"""Pipeline execution orchestrator."""

from __future__ import annotations

import time
import uuid
from typing import Iterable, List, Tuple

from fastapi import UploadFile

from ..env import EnvSettings
from ..pipelines.rtg_config import RTGMode, RetrievalResult, SessionPipelineConfig
from ..session.memory_manager import MemoryManager
from ..session.redis_session_store import RedisSessionStore
from ..utils.file_utils import cleanup_temp_dir, persist_uploads
from ..utils.tracer import tracer, FileTrace, QueryTrace
from .pipeline_builder import PipelineBuilder


class PipelineExecutor:
	def __init__(
		self,
		settings: EnvSettings,
		builder: PipelineBuilder,
		session_store: RedisSessionStore,
		memory_manager: MemoryManager,
	) -> None:
		self.settings = settings
		self.builder = builder
		self.session_store = session_store
		self.memory_manager = memory_manager

	def create_session(self, files: Iterable[UploadFile], config: SessionPipelineConfig, app_id: str) -> dict:
		session_id = f"rtg-{uuid.uuid4().hex[:8]}"
		ttl = min(max(config.ttl_seconds, 60), self.settings.max_ttl_seconds)
		stored_files, tmp_dir = persist_uploads(session_id, files)
		if not stored_files:
			cleanup_temp_dir(tmp_dir)
			raise ValueError("No files uploaded")

		builder_components = self.builder.build(config)
		indexer = self.builder.build_indexer()
		bm25_indexer = self.builder.build_bm25_indexer()

		tracer.start_session(session_id, app_id)

		try:
			all_chunks = []
			for path in stored_files:
				t_start_parse = time.time()
				try:
					pages = builder_components.parser.parse(path)
				except Exception as exc:
					raise ValueError(f"Parser error for {path}: {exc}") from exc
				t_end_parse = time.time()

				t_start_chunk = time.time()
				file_chunks = builder_components.chunker.build_chunks(session_id, pages)
				t_end_chunk = time.time()
				all_chunks.extend(file_chunks)
				
				# Trace File Processing
				tracer.add_file_trace(session_id, FileTrace(
					filename=path.name,
					size_bytes=path.stat().st_size,
					page_count=len(pages),
					parse_time_ms=(t_end_parse - t_start_parse) * 1000,
					chunking_time_ms=(t_end_chunk - t_start_chunk) * 1000,
					chunk_count=len(file_chunks),
					embedding_time_ms=0, # Will be updated
					indexing_time_ms=0   # Will be updated
				))

			if not all_chunks:
				raise ValueError("No text extracted from documents")

			# Build Vector Index
			t_start_embed = time.time()
			embeddings = builder_components.embedder.embed_batch([c.text for c in all_chunks])
			t_end_embed = time.time()
			
			vector_dim = len(embeddings[0])
			estimated_bytes = len(all_chunks) * vector_dim * 4
			if not self.memory_manager.can_accept(estimated_bytes):
				self.memory_manager.note_creation_failure()
				raise MemoryError("Insufficient memory for new RTG session")

			t_start_index = time.time()
			indexer.build(embeddings, [c.chunk_id for c in all_chunks])
			
			# Build BM25 Index
			bm25_indexer.build([c.text for c in all_chunks], [c.chunk_id for c in all_chunks])
			t_end_index = time.time()

			# Update trace with amortized times
			if tracer.enabled:
				session_trace = tracer.get_trace(session_id)
				if session_trace:
					total_embed_time = (t_end_embed - t_start_embed) * 1000
					total_index_time = (t_end_index - t_start_index) * 1000
					for f in session_trace.files:
						if len(all_chunks) > 0:
							ratio = f.chunk_count / len(all_chunks)
							f.embedding_time_ms = total_embed_time * ratio
							f.indexing_time_ms = total_index_time * ratio

			chunk_ttl = max(ttl, self.settings.chunk_storage_ttl_seconds)
			self.session_store.store_chunks(session_id, app_id, all_chunks, chunk_ttl)
			expires_at = self.session_store.register_session(session_id, app_id, config.mode, ttl, len(all_chunks))
			self.memory_manager.register_session(session_id, indexer, bm25_indexer, estimated_bytes, expires_at)
			
			tracer.end_session_creation(session_id)
			
			result = {
				"session_id": session_id,
				"chunks": len(all_chunks),
				"expires_at": expires_at,
				"pod_id": self.settings.pod_id,
			}
			print(f"PipelineExecutor.create_session result: {result}")
			return result
		finally:
			cleanup_temp_dir(tmp_dir)

	def run_query(self, session_id: str, app_id: str, query: str, top_k: int) -> Tuple[str, List[RetrievalResult]]:
		t_start_total = time.time()
		indexer, bm25_indexer = self.memory_manager.get_index(session_id)
		if not indexer:
			raise ValueError("Session index not found in memory")
		
		# 1. Vector Search
		t_start_embed = time.time()
		embedder = self.builder.create_embedder()
		query_vector = embedder.embed_query(query)
		t_end_embed = time.time()

		t_start_search = time.time()
		vector_results = indexer.query(query_vector, top_k * 2) # Fetch more for fusion
		
		# 2. Keyword Search (BM25)
		bm25_results = []
		if bm25_indexer:
			bm25_results = bm25_indexer.query(query, top_k * 2)

		# 3. Hybrid Fusion (RRF)
		merged_results = self._rrf_merge(vector_results, bm25_results)
		t_end_search = time.time()
		
		top_merged_ids = [cid for cid, _ in merged_results[:top_k * 2]] # Keep top 2x for reranking

		# 4. Fetch Chunks
		t_start_proc = time.time()
		chunks = self.session_store.get_chunks(session_id, app_id, top_merged_ids)
		chunk_map = {c.chunk_id: c for c in chunks}
		
		# 5. Reranking
		reranker = self.builder.create_reranker()
		docs_to_rerank = []
		for cid in top_merged_ids:
			if cid in chunk_map:
				docs_to_rerank.append((cid, chunk_map[cid].text))
		
		reranked_results = reranker.rerank(query, docs_to_rerank, top_k)
		
		# 6. Final Results
		results: List[RetrievalResult] = []
		for chunk_id, score in reranked_results:
			chunk = chunk_map.get(chunk_id)
			if chunk:
				results.append(RetrievalResult(chunk=chunk, score=score))
		
		generator = self.builder.create_generator()
		answer = generator.synthesize(query, results)
		t_end_proc = time.time()
		
		t_end_total = time.time()
		
		tracer.trace_query(session_id, QueryTrace(
			query=query,
			total_time_ms=(t_end_total - t_start_total) * 1000,
			embedding_time_ms=(t_end_embed - t_start_embed) * 1000,
			search_time_ms=(t_end_search - t_start_search) * 1000,
			processing_time_ms=(t_end_proc - t_start_proc) * 1000,
			result_count=len(results),
			timestamp=time.time()
		))
		
		return answer, results

	def _rrf_merge(self, vector_results: List[Tuple[str, float]], bm25_results: List[Tuple[str, float]], k: int = 60) -> List[Tuple[str, float]]:
		scores = {}
		# Vector results are (id, distance), but we only care about rank here
		for rank, (chunk_id, _) in enumerate(vector_results):
			scores[chunk_id] = scores.get(chunk_id, 0) + (1 / (k + rank + 1))
		
		# BM25 results are (id, score)
		for rank, (chunk_id, _) in enumerate(bm25_results):
			scores[chunk_id] = scores.get(chunk_id, 0) + (1 / (k + rank + 1))
		
		return sorted(scores.items(), key=lambda x: x[1], reverse=True)

	def destroy_session(self, session_id: str, app_id: str) -> None:
		self.session_store.delete_session(session_id, app_id)
		self.memory_manager.remove_session(session_id)
