"""Pipeline configuration helpers for RTG modes."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Any


class RTGMode(str, Enum):
	STANDARD = "standard"
	VISION = "vision"


@dataclass
class ChunkRecord:
	chunk_id: str
	session_id: str
	page_number: int
	text: str
	metadata: Dict[str, str]


@dataclass
class SessionPipelineConfig:
	mode: RTGMode
	ttl_seconds: int
	max_pages: Optional[int] = None
	include_ocr: bool = False
	chunking_strategy: str = "page"
	chunking_params: Optional[Dict[str, Any]] = None


@dataclass
class RetrievalResult:
	chunk: ChunkRecord
	score: float
