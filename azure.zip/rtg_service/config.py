"""Runtime configuration for the RTG microservice."""

from functools import lru_cache
from typing import Literal

from pydantic import BaseSettings, Field


class Settings(BaseSettings):
	"""Central configuration object loaded from environment variables."""

	app_name: str = Field(default="rtg_service")
	pod_id: str = Field(default="rtg-pod-local", env="POD_ID")

	redis_url: str = Field(default="redis://localhost:6379/0", env="REDIS_URL")
	redis_session_prefix: str = Field(default="rtg:session:")
	redis_chunk_prefix: str = Field(default="rtg:chunks:")
	redis_registry_key: str = Field(default="rtg:registry")

	default_ttl_seconds: int = Field(default=900, env="RTG_DEFAULT_TTL")
	max_ttl_seconds: int = Field(default=1800, env="RTG_MAX_TTL")
	session_limit_per_pod: int = Field(default=32, env="RTG_SESSION_LIMIT")
	memory_high_watermark: float = Field(default=0.75, env="RTG_MEMORY_HIGH_WATERMARK")
	memory_target_watermark: float = Field(default=0.65, env="RTG_MEMORY_TARGET_WATERMARK")

	ollama_url: str = Field(default="http://localhost:11434/api/embeddings", env="OLLAMA_URL")
	ollama_model: str = Field(default="nomic-embed-text", env="OLLAMA_MODEL")

	tika_url: str = Field(default="http://localhost:9998/tika", env="TIKA_URL")
	ocr_api_url: str = Field(default="http://localhost:8884/tesseract", env="OCR_API_URL")

	hnsw_distance_metric: Literal["cosine", "ip", "l2"] = Field(default="cosine")
	hnsw_m: int = Field(default=16)
	hnsw_ef_construction: int = Field(default=200)
	hnsw_ef_query: int = Field(default=50)

	chunk_storage_ttl_seconds: int = Field(default=3600)
	cleanup_interval_seconds: int = Field(default=60)

	class Config:
		env_file = ".env"
		env_file_encoding = "utf-8"
		case_sensitive = False


@lru_cache(maxsize=1)
def get_settings() -> Settings:
	"""Return cached settings instance."""

	return Settings()

