"""Helper utilities for handling uploaded files."""

from __future__ import annotations

import shutil
import tempfile
import uuid
from pathlib import Path
from typing import Iterable, List, Tuple

from fastapi import UploadFile


def persist_uploads(session_id: str, files: Iterable[UploadFile]) -> Tuple[List[Path], Path]:
	"""Persist uploaded files under a session-specific temp directory."""

	base_dir = Path(tempfile.gettempdir()) / "rtg_service" / session_id
	base_dir.mkdir(parents=True, exist_ok=True)
	stored_paths: List[Path] = []

	for upload in files:
		filename = upload.filename or f"upload-{uuid.uuid4()}.pdf"
		suffix = Path(filename).suffix or ".bin"
		target = base_dir / f"{uuid.uuid4().hex}{suffix}"
		with target.open("wb") as out:
			shutil.copyfileobj(upload.file, out)
		stored_paths.append(target)

	return stored_paths, base_dir


def cleanup_temp_dir(path: Path) -> None:
	"""Remove a temp directory recursively, ignoring errors."""

	if path.exists():
		shutil.rmtree(path, ignore_errors=True)
