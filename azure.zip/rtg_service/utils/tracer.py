"""Tracing and Metrics Manager."""

from __future__ import annotations

import time
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from functools import wraps

logger = logging.getLogger("rtg_tracer")

@dataclass
class FileTrace:
    filename: str
    size_bytes: int
    page_count: int
    parse_time_ms: float
    chunking_time_ms: float
    chunk_count: int
    embedding_time_ms: float
    indexing_time_ms: float

@dataclass
class QueryTrace:
    query: str
    total_time_ms: float
    embedding_time_ms: float
    search_time_ms: float
    processing_time_ms: float
    result_count: int
    timestamp: float

@dataclass
class SessionTrace:
    session_id: str
    app_id: str
    start_time: float
    files: List[FileTrace] = field(default_factory=list)
    total_chunks: int = 0
    total_processing_time_ms: float = 0.0
    query_traces: List[QueryTrace] = field(default_factory=list)

class Tracer:
    def __init__(self, enabled: bool = False):
        self.enabled = enabled
        self._sessions: Dict[str, SessionTrace] = {}

    def start_session(self, session_id: str, app_id: str):
        if not self.enabled: return
        self._sessions[session_id] = SessionTrace(
            session_id=session_id,
            app_id=app_id,
            start_time=time.time()
        )

    def add_file_trace(self, session_id: str, trace: FileTrace):
        if not self.enabled or session_id not in self._sessions: return
        self._sessions[session_id].files.append(trace)
        self._sessions[session_id].total_chunks += trace.chunk_count

    def end_session_creation(self, session_id: str):
        if not self.enabled or session_id not in self._sessions: return
        session = self._sessions[session_id]
        session.total_processing_time_ms = (time.time() - session.start_time) * 1000
        logger.info(f"Session Created: {session}")

    def trace_query(self, session_id: str, trace: QueryTrace):
        if not self.enabled or session_id not in self._sessions: return
        self._sessions[session_id].query_traces.append(trace)

    def get_trace(self, session_id: str) -> Optional[SessionTrace]:
        return self._sessions.get(session_id)

    def get_all_traces(self) -> List[SessionTrace]:
        return list(self._sessions.values())

# Global Tracer Instance
tracer = Tracer(enabled=False)

def time_execution(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        return result, (end - start) * 1000
    return wrapper
