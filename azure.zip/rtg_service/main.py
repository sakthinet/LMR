"""FastAPI entry point for the RTG microservice."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import List, Optional, Dict, Any

# Allow running via ``uvicorn main:app`` when executed from inside ``rtg_service``.
if __package__ in {None, ""}:  # pragma: no cover - runtime path shim
	_current_dir = Path(__file__).resolve().parent
	_parent_dir = _current_dir.parent
	if str(_parent_dir) not in sys.path:
		sys.path.insert(0, str(_parent_dir))
	__package__ = "rtg_service"

from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import logging
import traceback

from .dependencies import (
	get_memory_manager,
	get_pipeline_executor,
	get_session_store,
	get_settings_dep,
)
from .env import EnvSettings, get_env_settings
from .pipelines.executor import PipelineExecutor
from .pipelines.rtg_config import RTGMode, SessionPipelineConfig
from .session.memory_manager import MemoryManager
from .session.redis_session_store import RedisSessionStore
from .registry import AppRegistry
from .utils.tracer import tracer

settings = get_env_settings()
app_registry = AppRegistry(database_url=settings.database_url)

app = FastAPI(title="RTG Service", version="1.0.0")
app.add_middleware(
	CORSMiddleware,
	allow_origins=["*"],
	allow_methods=["*"],
	allow_headers=["*"]
)

# Configure a file logger to capture unhandled exceptions during request
# processing (including dependency resolution). This writes full
# tracebacks to rtg_service_error.log which helps debugging 500 errors
# when console access is not available.
_file_logger = logging.getLogger("rtg_service")
if not _file_logger.handlers:
	fh = logging.FileHandler("rtg_service_error.log")
	fh.setLevel(logging.DEBUG)
	formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
	fh.setFormatter(formatter)
	_file_logger.addHandler(fh)
	_file_logger.setLevel(logging.DEBUG)


@app.middleware("http")
async def _exception_logging_middleware(request, call_next):
	try:
		return await call_next(request)
	except Exception as exc:
		# Log full traceback to file for post-mortem debugging.
		_file_logger.exception("Unhandled exception during request: %s", exc)
		# Re-raise so FastAPI/uvicorn still produce the HTTP 500 response.
		raise


def _check_session_on_pod(session_id: str, app_id: str, session_store: RedisSessionStore, settings: EnvSettings):
	ok, owner = session_store.validate_pod(session_id, app_id, settings.pod_id)
	return ok, owner


def _validate_header(session_id: str, header_session_id: str | None) -> None:
	if header_session_id and header_session_id != session_id:
		raise HTTPException(status_code=400, detail="Session header does not match path")


class AppRegistrationRequest(BaseModel):
    app_id: str
    name: str
    mode: str
    max_file_size_mb: int = 10
    ttl_seconds: int = 3600
    chunking_strategy: str = "page"
    chunking_params: Optional[Dict[str, Any]] = None

@app.post("/admin/apps")
def register_app(request: AppRegistrationRequest):
    try:
        config = app_registry.register_app(
            app_id=request.app_id,
            name=request.name,
            mode=request.mode,
            max_file_size_mb=request.max_file_size_mb,
            ttl_seconds=request.ttl_seconds,
            chunking_strategy=request.chunking_strategy,
            chunking_params=request.chunking_params
        )
        return {"status": "registered", "config": config}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/admin/apps")
def list_apps():
    return app_registry.list_apps()

@app.delete("/admin/apps/{app_id}")
def delete_app(app_id: str):
    if app_registry.delete_app(app_id):
        return {"status": "deleted", "app_id": app_id}
    raise HTTPException(status_code=404, detail="App not found")

@app.post("/grounding/session/create")
def create_session(
    files: List[UploadFile] = File(...),
    x_app_id: str = Header(..., alias="X-App-ID"),
    pipeline_executor: PipelineExecutor = Depends(get_pipeline_executor),
):
    app_config = app_registry.get_app(x_app_id)
    if not app_config:
        raise HTTPException(status_code=401, detail="Invalid or unregistered App ID")

    _file_logger.debug(f"create_session called for app={x_app_id} mode={app_config.mode}, num_files={len(files)}")
    
    # Validate file size
    total_size_mb = sum(f.size for f in files) / (1024 * 1024)
    if total_size_mb > app_config.max_file_size_mb:
         raise HTTPException(status_code=413, detail=f"Total file size {total_size_mb:.2f}MB exceeds limit of {app_config.max_file_size_mb}MB")

    config = SessionPipelineConfig(
        mode=app_config.mode, 
        ttl_seconds=app_config.ttl_seconds,
        chunking_strategy=app_config.chunking_strategy,
        chunking_params=app_config.chunking_params
    )
    try:
        # Pass app_id to executor for namespacing
        result = pipeline_executor.create_session(files, config, app_id=x_app_id)
        print(f"create_session result: {result}")
        return {"status": "ok", "mode": app_config.mode, "app_id": x_app_id, **result}
    except Exception as exc:
        _file_logger.exception("Session creation failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


class QARequest(BaseModel):
	query: str
	top_k: int = 5
	rerank: bool = False


@app.post("/grounding/session/{session_id}/qa")
async def session_qa(
	session_id: str,
	payload: QARequest,
	x_app_id: str = Header(..., alias="X-App-ID"),
	header_session_id: str | None = Header(None, alias="X-Session-Id"),
	session_store: RedisSessionStore = Depends(get_session_store),
	pipeline_executor: PipelineExecutor = Depends(get_pipeline_executor),
	settings: EnvSettings = Depends(get_settings_dep),
):
	_validate_header(session_id, header_session_id)
	ok, owner = _check_session_on_pod(session_id, x_app_id, session_store, settings)
	if owner is None:
		raise HTTPException(status_code=404, detail="Session not found")
	if not ok:
		return JSONResponse(status_code=409, content={"error": f"wrong pod for session; route to pod {owner}"})
	try:
		answer, results = pipeline_executor.run_query(session_id, x_app_id, payload.query, payload.top_k)
	except ValueError as exc:
		raise HTTPException(status_code=404, detail=str(exc))
	return {
		"session_id": session_id,
		"answer": answer,
		"chunks": [
			{
				"chunk_id": res.chunk.chunk_id,
				"page_number": res.chunk.page_number,
				"score": res.score,
				"text": res.chunk.text,
			}
			for res in results
		],
	}


@app.post("/grounding/session/{session_id}/destroy")
async def destroy_session(
	session_id: str,
	x_app_id: str = Header(..., alias="X-App-ID"),
	header_session_id: str | None = Header(None, alias="X-Session-Id"),
	session_store: RedisSessionStore = Depends(get_session_store),
	pipeline_executor: PipelineExecutor = Depends(get_pipeline_executor),
	settings: EnvSettings = Depends(get_settings_dep),
):
	_validate_header(session_id, header_session_id)
	ok, owner = _check_session_on_pod(session_id, x_app_id, session_store, settings)
	if owner is None:
		raise HTTPException(status_code=404, detail="Session not found")
	if not ok:
		return JSONResponse(status_code=409, content={"error": f"wrong pod for session; route to pod {owner}"})
	pipeline_executor.destroy_session(session_id, x_app_id)
	return {"status": "destroyed", "session_id": session_id}


@app.get("/metrics")
async def metrics(memory_manager: MemoryManager = Depends(get_memory_manager)):
	return memory_manager.metrics()


@app.get("/admin/traces")
def get_traces(enabled: Optional[bool] = None):
    if enabled is not None:
        tracer.enabled = enabled
    return {
        "enabled": tracer.enabled,
        "traces": tracer.get_all_traces()
    }

@app.get("/admin/traces/{session_id}")
def get_session_trace(session_id: str):
    trace = tracer.get_trace(session_id)
    if not trace:
        raise HTTPException(status_code=404, detail="Trace not found")
    return trace

@app.get("/admin/session/{session_id}/chunks")
def get_session_chunks(
    session_id: str, 
    x_app_id: str = Header(..., alias="X-App-ID"),
    session_store: RedisSessionStore = Depends(get_session_store)
):
    chunks = session_store.get_all_session_chunks(session_id, x_app_id)
    return {"session_id": session_id, "count": len(chunks), "chunks": chunks}

@app.get("/admin", response_class=HTMLResponse)
def admin_dashboard():
	dashboard_path = Path(__file__).parent / "admin_dashboard.html"
	if not dashboard_path.exists():
		return "<h1>Admin Dashboard not found</h1>"
	return dashboard_path.read_text(encoding="utf-8")

