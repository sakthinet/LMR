"""Cross Encoder Reranker."""

from __future__ import annotations

from typing import List, Tuple
from sentence_transformers import CrossEncoder

class Reranker:
    def __init__(self, model_name: str = "cross-encoder/ms-marco-TinyBERT-L-2-v2") -> None:
        # Using a lightweight model by default
        self.model = CrossEncoder(model_name)

    def rerank(self, query: str, docs: List[Tuple[str, str]], top_k: int) -> List[Tuple[str, float]]:
        """
        Rerank a list of (doc_id, doc_text) tuples.
        Returns list of (doc_id, score).
        """
        if not docs:
            return []
            
        # Prepare pairs for cross-encoder
        pairs = [[query, doc_text] for _, doc_text in docs]
        scores = self.model.predict(pairs)
        
        # Combine with IDs
        results = []
        for i, score in enumerate(scores):
            results.append((docs[i][0], float(score)))
            
        # Sort by score desc
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]
