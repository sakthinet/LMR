"""Simple synthesis component for QA responses."""

from __future__ import annotations

from typing import Iterable

from ...pipelines.rtg_config import RetrievalResult


class SimpleAnswerSynthesizer:
    def synthesize(self, query: str, results: Iterable[RetrievalResult]) -> str:
        snippets = []
        for res in results:
            chunk = res.chunk
            snippet = f"[Page {chunk.page_number}] {chunk.text.strip()}"
            snippets.append(snippet)
        body = "\n".join(snippets[:5])
        if not body:
            return "I'm unable to find information related to that question in the uploaded documents."
        return f"Question: {query}\n\nRelevant excerpts:\n{body}"
