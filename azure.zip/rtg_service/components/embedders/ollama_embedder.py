"""Embedding client for Ollama nomic-embed-text."""

from __future__ import annotations

import logging
from typing import Iterable, List

import requests

logger = logging.getLogger(__name__)


class OllamaEmbedder:
	def __init__(self, endpoint: str, model: str) -> None:
		self.endpoint = endpoint
		self.model = model

	def embed_batch(self, texts: Iterable[str]) -> List[List[float]]:
		embeddings: List[List[float]] = []
		for text in texts:
			payload = {"model": self.model, "prompt": text}
			resp = requests.post(self.endpoint, json=payload, timeout=60)
			resp.raise_for_status()
			data = resp.json()
			vector = data.get("embedding") or data.get("data", [{}])[0].get("embedding")
			if not vector:
				raise ValueError("Embedding response missing vector")
			embeddings.append(vector)
		return embeddings

	def embed_query(self, text: str) -> List[float]:
		return self.embed_batch([text])[0]
