"""OCR parser component using Tesseract API."""

from __future__ import annotations

import logging
import mimetypes
from pathlib import Path
from typing import List
import fitz  # PyMuPDF

import requests

logger = logging.getLogger(__name__)


class OCRParser:
	"""Call the OCR microservice to extract per-page text."""

	def __init__(self, ocr_url: str) -> None:
		self.endpoint = ocr_url.rstrip("/")

	def parse(self, pdf_path: Path) -> List[str]:
		mime_type, _ = mimetypes.guess_type(pdf_path)
		if not mime_type:
			mime_type = "application/octet-stream"

		# If it's a PDF, convert pages to images first
		if mime_type == "application/pdf":
			return self._parse_pdf_as_images(pdf_path)

		return self._parse_image(pdf_path, mime_type)

	def _parse_image(self, image_path: Path, mime_type: str) -> List[str]:
		with image_path.open("rb") as fh:
			files = {"file": (image_path.name, fh, mime_type)}
			# Provide empty options JSON to prevent "Unexpected token u" error on server
			data = {"options": "{}"}
			response = requests.post(self.endpoint, files=files, data=data, timeout=180)
		
		if not response.ok:
			logger.error(f"OCR Error: {response.status_code} - {response.text}")
			raise ValueError(f"OCR Service failed: {response.status_code} {response.text}")

		response.raise_for_status()
		data = response.json()
		logger.info(f"OCR Response keys: {data.keys()}")
		
		texts = []
		
		# Handle "pages" list format (e.g. from some PDF OCR wrappers)
		pages = data.get("pages") or []
		for page in pages:
			try:
				text = (page.get("text") or "").strip()
				if text:
					texts.append(text)
			except AttributeError:
				continue

		# Handle direct "result" format
		if not texts and "result" in data:
			text = (data["result"] or "").strip()
			if text:
				texts.append(text)

		# Handle "data.stdout" format (hertzg/tesseract-server)
		if not texts and "data" in data and isinstance(data["data"], dict):
			text = data["data"].get("stdout", "").strip()
			if text:
				texts.append(text)

		if not texts:
			logger.warning(f"OCR parser returned no text. Response: {data}")
		return texts

	def _parse_pdf_as_images(self, pdf_path: Path) -> List[str]:
		texts = []
		try:
			doc = fitz.open(pdf_path)
			for page_num in range(len(doc)):
				page = doc.load_page(page_num)
				pix = page.get_pixmap()
				img_data = pix.tobytes("png")
				
				# Send image bytes to OCR
				files = {"file": (f"page_{page_num}.png", img_data, "image/png")}
				data = {"options": "{}"}
				response = requests.post(self.endpoint, files=files, data=data, timeout=180)
				
				if response.ok:
					res_json = response.json()
					logger.info(f"OCR Response for page {page_num}: {res_json}")
					
					# Try to get text from various response formats
					page_text = ""
					
					# Format 1: { "data": { "stdout": "text..." } } (hertzg/tesseract-server)
					if "data" in res_json and isinstance(res_json["data"], dict):
						page_text = res_json["data"].get("stdout", "")
					
					# Format 2: { "result": "text..." }
					elif "result" in res_json:
						page_text = res_json["result"]
					
					# Format 3: { "pages": [ { "text": "..." } ] }
					elif "pages" in res_json:
						for p in res_json["pages"]:
							page_text += p.get("text", "") + "\n"
					
					if page_text and page_text.strip():
						texts.append(page_text.strip())
					else:
						logger.warning(f"No text extracted for page {page_num}. Response: {res_json}")
				else:
					logger.error(f"OCR failed for page {page_num}: {response.text}")
			
			doc.close()
		except Exception as e:
			logger.error(f"Failed to convert PDF to images: {e}")
			raise
			
		return texts
