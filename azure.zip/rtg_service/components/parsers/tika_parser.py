"""Apache Tika parser component."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List

import requests

logger = logging.getLogger(__name__)


class TikaParser:
	"""Parse text-based PDFs using Apache Tika server."""

	def __init__(self, tika_url: str) -> None:
		self.endpoint = tika_url.rstrip("/")

	def parse(self, pdf_path: Path) -> List[str]:
		"""Return per-page text chunks extracted by Tika."""

		url = f"{self.endpoint}/tika"
		with pdf_path.open("rb") as fh:
			response = requests.put(
				url,
				data=fh,
				headers={"Accept": "text/plain"},
				timeout=120,
			)
		response.raise_for_status()
		text = response.text
		if not text:
			logger.warning("Tika parser returned empty text for %s", pdf_path)
			return []
		return _split_pages(text)


def _split_pages(text: str) -> List[str]:
	pages = [page.strip() for page in text.split("\f")]
	return [page for page in pages if page]
