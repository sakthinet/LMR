"""hnswlib index wrapper."""

from __future__ import annotations

from typing import Dict, List, Tuple

import hnswlib


class HNSWIndexer:
	def __init__(self, space: str, m: int, ef_construction: int, ef_query: int) -> None:
		self.space = space
		self.m = m
		self.ef_construction = ef_construction
		self.ef_query = ef_query
		self.index: hnswlib.Index | None = None
		self.id_lookup: Dict[int, str] = {}

	def build(self, embeddings: List[List[float]], chunk_ids: List[str]) -> None:
		if not embeddings:
			raise ValueError("Cannot build hnsw index without embeddings")
		dim = len(embeddings[0])
		idx = hnswlib.Index(space=self.space, dim=dim)
		idx.init_index(max_elements=len(embeddings), ef_construction=self.ef_construction, M=self.m)
		ids = list(range(len(embeddings)))
		idx.add_items(embeddings, ids)
		idx.set_ef(self.ef_query)
		self.index = idx
		self.id_lookup = {internal: chunk_id for internal, chunk_id in zip(ids, chunk_ids)}

	def query(self, vector: List[float], top_k: int) -> List[Tuple[str, float]]:
		if self.index is None:
			raise RuntimeError("Index has not been built")
		labels, distances = self.index.knn_query(vector, k=min(top_k, len(self.id_lookup)))
		results = []
		for internal_id, distance in zip(labels[0], distances[0]):
			chunk_id = self.id_lookup.get(int(internal_id))
			if chunk_id:
				results.append((chunk_id, float(distance)))
		return results

	def reset(self) -> None:
		self.index = None
		self.id_lookup = {}
