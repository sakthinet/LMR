"""BM25 Indexer wrapper."""

from __future__ import annotations

import re
from typing import List, Tuple, Dict
from rank_bm25 import BM25Okapi

class BM25Indexer:
    def __init__(self) -> None:
        self.bm25: BM25Okapi | None = None
        self.chunk_ids: List[str] = []

    def _tokenize(self, text: str) -> List[str]:
        # Simple regex tokenizer
        return [t.lower() for t in re.findall(r'\w+', text)]

    def build(self, texts: List[str], chunk_ids: List[str]) -> None:
        if not texts:
            raise ValueError("Cannot build BM25 index without texts")
        
        tokenized_corpus = [self._tokenize(doc) for doc in texts]
        self.bm25 = BM25Okapi(tokenized_corpus)
        self.chunk_ids = chunk_ids

    def query(self, query: str, top_k: int) -> List[Tuple[str, float]]:
        if self.bm25 is None:
            raise RuntimeError("BM25 Index has not been built")
        
        tokenized_query = self._tokenize(query)
        scores = self.bm25.get_scores(tokenized_query)
        
        # Pair scores with chunk IDs
        scored_chunks = []
        for i, score in enumerate(scores):
            if score > 0:
                scored_chunks.append((self.chunk_ids[i], float(score)))
        
        # Sort by score desc
        scored_chunks.sort(key=lambda x: x[1], reverse=True)
        return scored_chunks[:top_k]
