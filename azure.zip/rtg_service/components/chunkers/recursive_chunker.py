"""Recursive chunker implementation."""

from __future__ import annotations

import uuid
import re
from typing import Iterable, List, Optional, Dict, Any

from ...pipelines.rtg_config import ChunkRecord


class RecursiveChunker:
    """Splits text recursively by separators (paragraphs, newlines, etc.)."""

    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200, separators: Optional[List[str]] = None):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or ["\n\n", "\n", " ", ""]

    def _split_text(self, text: str, separators: List[str]) -> List[str]:
        """Recursively split text."""
        final_chunks = []
        separator = separators[-1]
        new_separators = []
        
        for i, _s in enumerate(separators):
            if _s == "":
                separator = _s
                break
            if re.search(re.escape(_s), text):
                separator = _s
                new_separators = separators[i + 1:]
                break

        _splits = self._split_on_separator(text, separator)
        
        good_splits = []
        for s in _splits:
            if len(s) < self.chunk_size:
                good_splits.append(s)
            else:
                if new_separators:
                    good_splits.extend(self._split_text(s, new_separators))
                else:
                    good_splits.append(s)
        
        return self._merge_splits(good_splits, separator)

    def _split_on_separator(self, text: str, separator: str) -> List[str]:
        if separator == "":
            return list(text)
        return [s for s in text.split(separator) if s]

    def _merge_splits(self, splits: List[str], separator: str) -> List[str]:
        docs = []
        current_doc = []
        total = 0
        for d in splits:
            _len = len(d)
            if total + _len + (len(separator) if current_doc else 0) > self.chunk_size:
                if current_doc:
                    doc = self._join_docs(current_doc, separator)
                    if doc is not None:
                        docs.append(doc)
                    
                    while total > self.chunk_overlap or (total + _len > self.chunk_size and total > 0):
                        total -= len(current_doc[0]) + (len(separator) if len(current_doc) > 1 else 0)
                        current_doc = current_doc[1:]

            current_doc.append(d)
            total += _len + (len(separator) if len(current_doc) > 1 else 0)
            
        doc = self._join_docs(current_doc, separator)
        if doc is not None:
            docs.append(doc)
        return docs

    def _join_docs(self, docs: List[str], separator: str) -> Optional[str]:
        text = separator.join(docs)
        text = text.strip()
        if text == "":
            return None
        return text

    def build_chunks(self, session_id: str, pages: Iterable[str]) -> List[ChunkRecord]:
        chunks: List[ChunkRecord] = []
        for idx, page_text in enumerate(pages, start=1):
            text = page_text.strip()
            if not text:
                continue
            
            page_chunks = self._split_text(text, self.separators)
            
            for i, chunk_text in enumerate(page_chunks):
                chunk_id = f"{session_id}-{uuid.uuid4().hex[:8]}-{idx}-{i}"
                chunks.append(
                    ChunkRecord(
                        chunk_id=chunk_id,
                        session_id=session_id,
                        page_number=idx,
                        text=chunk_text,
                        metadata={
                            "chunk_type": "recursive", 
                            "page_number": str(idx),
                            "chunk_index": str(i)
                        },
                    )
                )
        return chunks
