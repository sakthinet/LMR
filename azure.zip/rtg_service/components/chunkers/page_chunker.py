"""Page chunker implementation."""

from __future__ import annotations

import uuid
from typing import Iterable, List

from ...pipelines.rtg_config import ChunkRecord


class PageChunker:
	"""Treat each page as a chunk, preserving ordering metadata."""

	def build_chunks(self, session_id: str, pages: Iterable[str]) -> List[ChunkRecord]:
		chunks: List[ChunkRecord] = []
		for idx, page_text in enumerate(pages, start=1):
			text = page_text.strip()
			if not text:
				continue
			chunk_id = f"{session_id}-{uuid.uuid4().hex[:8]}-{idx}"
			chunks.append(
				ChunkRecord(
					chunk_id=chunk_id,
					session_id=session_id,
					page_number=idx,
					text=text,
					metadata={"chunk_type": "page", "page_number": str(idx)},
				)
			)
		return chunks
