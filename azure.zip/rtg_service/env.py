"""Environment-driven configuration for the RTG service."""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from typing import Literal

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class EnvSettings:
	app_name: str
	pod_id: str
	redis_url: str
	redis_session_prefix: str
	redis_chunk_prefix: str
	redis_registry_key: str
	default_ttl_seconds: int
	max_ttl_seconds: int
	session_limit_per_pod: int
	memory_high_watermark: float
	memory_target_watermark: float
	ollama_url: str
	ollama_model: str
	tika_url: str
	ocr_api_url: str
	hnsw_distance_metric: Literal["cosine", "ip", "l2"]
	hnsw_m: int
	hnsw_ef_construction: int
	hnsw_ef_query: int
	chunk_storage_ttl_seconds: int
	cleanup_interval_seconds: int
	database_url: str


def _int(name: str, default: int) -> int:
	value = os.getenv(name)
	if value is None:
		return default
	try:
		return int(value)
	except ValueError:
		return default


def _float(name: str, default: float) -> float:
	value = os.getenv(name)
	if value is None:
		return default
	try:
		return float(value)
	except ValueError:
		return default


def _metric(value: str | None, default: str) -> Literal["cosine", "ip", "l2"]:
	allowed = {"cosine", "ip", "l2"}
	candidate = (value or default).lower()
	if candidate not in allowed:
		return default  # type: ignore[return-value]
	return candidate  # type: ignore[return-value]


@lru_cache(maxsize=1)
def get_env_settings() -> EnvSettings:
	return EnvSettings(
		app_name=os.getenv("APP_NAME", "rtg_service"),
		pod_id=os.getenv("POD_ID", "rtg-pod-local"),
		redis_url=os.getenv("REDIS_URL", "redis://localhost:6379/0"),
		redis_session_prefix=os.getenv("REDIS_SESSION_PREFIX", "rtg:session:"),
		redis_chunk_prefix=os.getenv("REDIS_CHUNK_PREFIX", "rtg:chunks:"),
		redis_registry_key=os.getenv("REDIS_REGISTRY_KEY", "rtg:registry"),
		default_ttl_seconds=_int("RTG_DEFAULT_TTL", 900),
		max_ttl_seconds=_int("RTG_MAX_TTL", 1800),
		session_limit_per_pod=_int("RTG_SESSION_LIMIT", 32),
		memory_high_watermark=_float("RTG_MEMORY_HIGH_WATERMARK", 0.75),
		memory_target_watermark=_float("RTG_MEMORY_TARGET_WATERMARK", 0.65),
		ollama_url=os.getenv("OLLAMA_URL", "http://localhost:11434/api/embeddings"),
		ollama_model=os.getenv("OLLAMA_MODEL", "nomic-embed-text"),
		tika_url=os.getenv("TIKA_URL", "http://localhost:9998/tika"),
		ocr_api_url=os.getenv("OCR_API_URL", "http://localhost:8884/tesseract"),
		hnsw_distance_metric=_metric(os.getenv("HNSW_DISTANCE_METRIC"), "cosine"),
		hnsw_m=_int("HNSW_M", 16),
		hnsw_ef_construction=_int("HNSW_EF_CONSTRUCTION", 200),
		hnsw_ef_query=_int("HNSW_EF_QUERY", 50),
		chunk_storage_ttl_seconds=_int("CHUNK_STORAGE_TTL", 3600),
		cleanup_interval_seconds=_int("CLEANUP_INTERVAL_SECONDS", 60),
		database_url=os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/RND"),
	)
