-- ContextCraft Database Export Script
-- This script creates a complete backup of your ContextCraft database
-- Run this in your PostgreSQL database (e.g., using pgAdmin or psql)
-- 
-- Usage:
-- 1. Connect to your contextcraft database
-- 2. Run this script to generate the export commands
-- 3. Copy and run the generated commands to create your backup

\echo 'ContextCraft Database Export Generator'
\echo '====================================='

-- Set output to a file (optional)
-- \o contextcraft_export.sql

-- Export the database schema and data
\echo ''
\echo 'To export your database, run the following command from command line:'
\echo ''
\echo 'pg_dump --host=localhost --port=5432 --username=postgres --dbname=contextcraft --verbose --clean --create --if-exists --format=plain --encoding=UTF8 --no-owner --no-privileges --file=contextcraft_backup.sql'
\echo ''
\echo 'Or use the PowerShell scripts provided in the database folder.'
\echo ''

-- Display current database information
\echo 'Current Database Information:'
\echo '============================'

SELECT 
    current_database() as database_name,
    current_user as current_user,
    version() as postgresql_version;

\echo ''
\echo 'Database Tables:'
\dt

\echo ''
\echo 'Table Row Counts:'
SELECT 
    schemaname,
    tablename,
    n_tup_ins as rows_inserted,
    n_tup_upd as rows_updated,
    n_tup_del as rows_deleted,
    n_live_tup as current_rows
FROM pg_stat_user_tables 
ORDER BY tablename;

-- Show database size
\echo ''
\echo 'Database Size Information:'
SELECT 
    pg_database.datname as database_name,
    pg_size_pretty(pg_database_size(pg_database.datname)) as size
FROM pg_database 
WHERE datname = current_database();

\echo ''
\echo 'Alternative: Manual Export Commands'
\echo '=================================='
\echo ''
\echo 'If pg_dump is not available, you can manually export data:'
\echo ''

-- Generate COPY commands for each table
DO $$
DECLARE 
    table_record RECORD;
    copy_command TEXT;
BEGIN
    FOR table_record IN 
        SELECT tablename 
        FROM pg_tables 
        WHERE schemaname = 'public' 
        ORDER BY tablename
    LOOP
        copy_command := '\copy ' || table_record.tablename || ' TO ''' || table_record.tablename || '_data.csv'' WITH CSV HEADER;';
        RAISE NOTICE '%', copy_command;
    END LOOP;
END $$;