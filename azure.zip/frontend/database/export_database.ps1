# ContextCraft Database Export Script
# This script exports the complete ContextCraft database including schema and data
# Usage: .\export_database.ps1

param(
    [string]$OutputPath = ".\contextcraft_backup.sql",
    [string]$DbHost = "localhost",
    [string]$DbPort = "5432",
    [string]$Database = "contextcraft",
    [string]$Username = "postgres"
)

Write-Host "ContextCraft Database Export Utility" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Green

# Check if pg_dump is available
try {
    $pgDumpVersion = pg_dump --version
    Write-Host "Found pg_dump: $pgDumpVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: pg_dump not found. Please ensure PostgreSQL client tools are installed and in PATH." -ForegroundColor Red
    Write-Host "You can download PostgreSQL client tools from: https://www.postgresql.org/download/" -ForegroundColor Yellow
    exit 1
}

# Set PGPASSWORD environment variable if not set
if (-not $env:PGPASSWORD) {
    Write-Host "Database password not set in PGPASSWORD environment variable." -ForegroundColor Yellow
    $securePassword = Read-Host "Enter database password" -AsSecureString
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
    $env:PGPASSWORD = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
}

Write-Host "Exporting database: $Database from ${DbHost}:${DbPort}" -ForegroundColor Cyan
Write-Host "Output file: $OutputPath" -ForegroundColor Cyan

# Create the export directory if it doesn't exist
$exportDir = Split-Path -Parent $OutputPath
if ($exportDir -and !(Test-Path $exportDir)) {
    New-Item -ItemType Directory -Path $exportDir -Force | Out-Null
}

# Export the database with schema and data
$exportArgs = @(
    "--host=$DbHost",
    "--port=$DbPort", 
    "--username=$Username",
    "--dbname=$Database",
    "--verbose",
    "--clean",
    "--create",
    "--if-exists",
    "--format=plain",
    "--encoding=UTF8",
    "--no-owner",
    "--no-privileges",
    "--file=$OutputPath"
)

Write-Host "Running pg_dump with arguments: $($exportArgs -join ' ')" -ForegroundColor Gray

try {
    & pg_dump @exportArgs
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "`nExport completed successfully!" -ForegroundColor Green
        Write-Host "Backup file created: $OutputPath" -ForegroundColor Green
        
        # Get file size
        $fileSize = (Get-Item $OutputPath).Length
        $fileSizeMB = [math]::Round($fileSize / 1MB, 2)
        Write-Host "File size: $fileSizeMB MB" -ForegroundColor Cyan
        
        Write-Host "`nTo import on another machine, run:" -ForegroundColor Yellow
        Write-Host "psql -h <hostname> -p <port> -U <username> -d postgres -f `"$OutputPath`"" -ForegroundColor White
    } else {
        Write-Host "Export failed with exit code: $LASTEXITCODE" -ForegroundColor Red
        exit $LASTEXITCODE
    }
} catch {
    Write-Host "Error during export: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} finally {
    # Clear the password from environment
    Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
}

Write-Host "`nExport Summary:" -ForegroundColor Green
Write-Host "- Schema: [OK] Included" -ForegroundColor Green  
Write-Host "- Data: [OK] Included" -ForegroundColor Green
Write-Host "- Constraints: [OK] Included" -ForegroundColor Green
Write-Host "- Indexes: [OK] Included" -ForegroundColor Green
Write-Host "- Functions/Procedures: [OK] Included" -ForegroundColor Green