// ContextCraft Database Restore Utility  
// This script restores a ContextCraft database backup using Node.js
// Run with: node restore_database.js [backup_file]

import fs from 'fs';
import path from 'path';
import postgres from 'postgres';

// Configuration
const backupFile = process.argv[2] || 'contextcraft_backup.sql';
const config = {
    connectionString: process.env.DATABASE_URL || 'postgresql://postgres:admin%4012345@localhost:5432/contextcraft',
    backupFile: backupFile,
    createDatabase: process.argv.includes('--create-db')
};

console.log('ContextCraft Database Restore Utility');
console.log('=====================================');
console.log(`Backup file: ${config.backupFile}`);
console.log(`Connection: ${config.connectionString.replace(/:[^:@]*@/, ':****@')}`);
console.log('');

async function restoreBackup() {
    // Check if backup file exists
    if (!fs.existsSync(config.backupFile)) {
        console.error(`❌ Backup file not found: ${config.backupFile}`);
        process.exit(1);
    }

    const sql = postgres(config.connectionString);
    
    try {
        console.log('📖 Reading backup file...');
        const backupContent = fs.readFileSync(config.backupFile, 'utf8');
        
        // Split into individual SQL statements
        const statements = backupContent
            .split('\n')
            .filter(line => line.trim() && !line.startsWith('--'))
            .join('\n')
            .split(';')
            .filter(stmt => stmt.trim())
            .map(stmt => stmt.trim());

        console.log(`Found ${statements.length} SQL statements to execute`);
        console.log('');

        // Execute statements
        let executed = 0;
        let errors = 0;
        
        for (const statement of statements) {
            if (!statement || statement === 'BEGIN' || statement === 'COMMIT') {
                continue;
            }
            
            try {
                await sql.unsafe(statement);
                executed++;
                
                if (executed % 10 === 0) {
                    console.log(`Executed ${executed}/${statements.length} statements...`);
                }
            } catch (error) {
                console.warn(`⚠️  Warning executing statement: ${error.message}`);
                console.warn(`   Statement: ${statement.substring(0, 100)}...`);
                errors++;
            }
        }

        console.log('');
        console.log('✅ Restore completed!');
        console.log(`📊 Executed: ${executed} statements`);
        if (errors > 0) {
            console.log(`⚠️  Warnings: ${errors} statements had issues`);
        }

        // Verify the restore
        console.log('');
        console.log('🔍 Verifying restore...');
        await verifyRestore(sql);

    } catch (error) {
        console.error('❌ Restore failed:', error.message);
        process.exit(1);
    } finally {
        await sql.end();
    }
}

async function verifyRestore(sql) {
    try {
        // Check tables
        const tables = await sql`
            SELECT tablename, 
                   (SELECT COUNT(*) FROM pg_class WHERE relname = tablename) as exists
            FROM pg_tables 
            WHERE schemaname = 'public' 
            ORDER BY tablename
        `;

        console.log('Tables found:');
        for (const table of tables) {
            const count = await sql`SELECT COUNT(*) as count FROM ${sql(table.tablename)}`;
            console.log(`  - ${table.tablename}: ${count[0].count} rows`);
        }

        // Check indexes
        const indexes = await sql`
            SELECT COUNT(*) as count 
            FROM pg_indexes 
            WHERE schemaname = 'public'
        `;

        console.log(`Indexes: ${indexes[0].count}`);
        
        console.log('');
        console.log('✅ Database restore verification completed successfully!');
        console.log('');
        console.log('Next steps:');
        console.log('1. Update your .env file with the correct DATABASE_URL');
        console.log('2. Test your application connection');
        console.log('3. Run any pending migrations if needed');
        
    } catch (error) {
        console.error('⚠️  Verification failed:', error.message);
    }
}

// Show usage if no arguments
if (process.argv.length < 3 && !fs.existsSync('contextcraft_backup.sql')) {
    console.log('Usage:');
    console.log('  node restore_database.js <backup_file>');
    console.log('  node restore_database.js contextcraft_backup.sql');
    console.log('  node restore_database.js backup.sql --create-db');
    console.log('');
    console.log('Options:');
    console.log('  --create-db    Create the database if it doesn\'t exist');
    console.log('');
    process.exit(0);
}

// Run the restore
restoreBackup().catch(console.error);