-- ContextCraft - PostgreSQL Database Schema
-- Generated on September 24, 2025
-- This schema supports Import Connectors, Parser Profiles, Vector Pipelines, and Pipeline Designer

-- Enable UUID extension for generating unique IDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable JSONB functions
CREATE EXTENSION IF NOT EXISTS "btree_gin";

-- =============================================================================
-- USERS TABLE
-- =============================================================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(255) NOT NULL UNIQUE,
    password TEXT NOT NULL,
    email VARCHAR(255) UNIQUE,
    full_name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'user' CHECK (role IN ('admin', 'user', 'viewer')),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE
);

-- =============================================================================
-- CONNECTORS TABLE (Import Connectors Page)
-- =============================================================================
CREATE TABLE connectors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL CHECK (type IN ('s3', 'gcs', 'azure-blob', 'file-share', 'google-drive', 'file-upload')),
    config JSONB NOT NULL, -- Stores connector-specific configuration
    status TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'error', 'testing', 'syncing')),
    last_sync TIMESTAMP WITH TIME ZONE,
    last_sync_status TEXT CHECK (last_sync_status IN ('success', 'failed', 'in_progress')),
    documents_count INTEGER DEFAULT 0,
    total_size_bytes BIGINT DEFAULT 0,
    error_message TEXT,
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Indexes
    CONSTRAINT connectors_name_unique UNIQUE (name)
);

-- Index for faster queries
CREATE INDEX idx_connectors_type ON connectors(type);
CREATE INDEX idx_connectors_status ON connectors(status);
CREATE INDEX idx_connectors_created_by ON connectors(created_by);
CREATE INDEX idx_connectors_config ON connectors USING GIN (config);

-- =============================================================================
-- PARSER PROFILES TABLE (Parser Profiles Page)
-- =============================================================================
CREATE TABLE parser_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL CHECK (type IN ('azure-ai', 'google-ai', 'tesseract', 'paddle', 'unstructured')),
    config JSONB NOT NULL, -- Stores parser-specific configuration
    status TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'error', 'testing')),
    version VARCHAR(50) DEFAULT '1.0.0',
    supported_formats TEXT[] DEFAULT ARRAY['pdf', 'docx', 'txt', 'html', 'json'], -- Array of supported file formats
    performance_metrics JSONB, -- Stores accuracy, speed, etc.
    test_results JSONB, -- Stores test results and validation data
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT parser_profiles_name_unique UNIQUE (name)
);

-- Indexes
CREATE INDEX idx_parser_profiles_type ON parser_profiles(type);
CREATE INDEX idx_parser_profiles_status ON parser_profiles(status);
CREATE INDEX idx_parser_profiles_created_by ON parser_profiles(created_by);
CREATE INDEX idx_parser_profiles_config ON parser_profiles USING GIN (config);
CREATE INDEX idx_parser_profiles_supported_formats ON parser_profiles USING GIN (supported_formats);

-- =============================================================================
-- PIPELINES TABLE (Vector Pipelines Page & Pipeline Designer)
-- =============================================================================
CREATE TABLE pipelines (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL DEFAULT 'document_processing' CHECK (type IN ('document_processing', 'data_ingestion', 'vector_processing', 'custom')),
    config JSONB NOT NULL, -- Complete pipeline configuration
    nodes JSONB NOT NULL, -- ReactFlow nodes configuration
    edges JSONB NOT NULL, -- ReactFlow edges configuration
    status TEXT NOT NULL DEFAULT 'configured' CHECK (status IN ('configured', 'active', 'inactive', 'running', 'completed', 'failed', 'paused')),
    version VARCHAR(50) DEFAULT '1.0.0',
    
    -- Pipeline execution tracking
    last_run TIMESTAMP WITH TIME ZONE,
    last_run_status TEXT CHECK (last_run_status IN ('success', 'failed', 'in_progress', 'cancelled')),
    last_run_duration INTEGER, -- Duration in seconds
    total_runs INTEGER DEFAULT 0,
    successful_runs INTEGER DEFAULT 0,
    failed_runs INTEGER DEFAULT 0,
    
    -- Document processing metrics
    documents_processed INTEGER DEFAULT 0,
    vectors_generated INTEGER DEFAULT 0,
    total_processing_time INTEGER DEFAULT 0, -- Total time in seconds
    average_processing_time DECIMAL(10,2), -- Average time per document
    
    -- Pipeline metadata
    metadata JSONB, -- Additional metadata like tags, categories, etc.
    schedule_config JSONB, -- Scheduling configuration if applicable
    notification_config JSONB, -- Notification settings
    
    -- Relationships
    source_connector_id UUID REFERENCES connectors(id) ON DELETE SET NULL,
    parser_profile_id UUID REFERENCES parser_profiles(id) ON DELETE SET NULL,
    
    -- Audit fields
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT pipelines_name_unique UNIQUE (name)
);

-- Indexes
CREATE INDEX idx_pipelines_type ON pipelines(type);
CREATE INDEX idx_pipelines_status ON pipelines(status);
CREATE INDEX idx_pipelines_created_by ON pipelines(created_by);
CREATE INDEX idx_pipelines_source_connector ON pipelines(source_connector_id);
CREATE INDEX idx_pipelines_parser_profile ON pipelines(parser_profile_id);
CREATE INDEX idx_pipelines_config ON pipelines USING GIN (config);
CREATE INDEX idx_pipelines_metadata ON pipelines USING GIN (metadata);
CREATE INDEX idx_pipelines_last_run ON pipelines(last_run);

-- =============================================================================
-- PIPELINE EXECUTIONS TABLE (Pipeline Run History)
-- =============================================================================
CREATE TABLE pipeline_executions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pipeline_id UUID NOT NULL REFERENCES pipelines(id) ON DELETE CASCADE,
    execution_id VARCHAR(255) NOT NULL, -- Unique execution identifier
    status TEXT NOT NULL CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
    
    -- Execution timing
    started_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP WITH TIME ZONE,
    duration INTEGER, -- Duration in seconds
    
    -- Processing metrics
    documents_processed INTEGER DEFAULT 0,
    documents_failed INTEGER DEFAULT 0,
    vectors_created INTEGER DEFAULT 0,
    bytes_processed BIGINT DEFAULT 0,
    
    -- Execution configuration (snapshot at time of execution)
    pipeline_config JSONB, -- Pipeline config at time of execution
    execution_config JSONB, -- Execution-specific configuration
    
    -- Results and logs
    results JSONB, -- Execution results and output data
    error_details JSONB, -- Error information if failed
    logs TEXT, -- Execution logs
    
    -- Triggered by
    triggered_by TEXT CHECK (triggered_by IN ('manual', 'scheduled', 'api', 'webhook')),
    triggered_by_user UUID REFERENCES users(id) ON DELETE SET NULL,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_pipeline_executions_pipeline_id ON pipeline_executions(pipeline_id);
CREATE INDEX idx_pipeline_executions_status ON pipeline_executions(status);
CREATE INDEX idx_pipeline_executions_started_at ON pipeline_executions(started_at);
CREATE INDEX idx_pipeline_executions_triggered_by_user ON pipeline_executions(triggered_by_user);
CREATE UNIQUE INDEX idx_pipeline_executions_execution_id ON pipeline_executions(execution_id);

-- =============================================================================
-- DOCUMENTS TABLE (Processed Documents Tracking)
-- =============================================================================
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    connector_id UUID REFERENCES connectors(id) ON DELETE SET NULL,
    pipeline_id UUID REFERENCES pipelines(id) ON DELETE SET NULL,
    execution_id UUID REFERENCES pipeline_executions(id) ON DELETE SET NULL,
    
    -- Document information
    filename TEXT NOT NULL,
    file_path TEXT,
    file_size BIGINT,
    file_type VARCHAR(50),
    mime_type VARCHAR(255),
    checksum VARCHAR(255), -- File hash for duplicate detection
    
    -- Processing information
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'skipped')),
    processed_at TIMESTAMP WITH TIME ZONE,
    processing_duration INTEGER, -- Duration in seconds
    
    -- Content and vectors
    raw_content TEXT, -- Original extracted text
    processed_content JSONB, -- Structured processed content
    chunks JSONB, -- Document chunks for vectorization
    vectors JSONB, -- Generated vectors
    metadata JSONB, -- Document metadata (title, author, etc.)
    
    -- Error handling
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_documents_connector_id ON documents(connector_id);
CREATE INDEX idx_documents_pipeline_id ON documents(pipeline_id);
CREATE INDEX idx_documents_execution_id ON documents(execution_id);
CREATE INDEX idx_documents_status ON documents(status);
CREATE INDEX idx_documents_file_type ON documents(file_type);
CREATE INDEX idx_documents_processed_at ON documents(processed_at);
CREATE INDEX idx_documents_checksum ON documents(checksum);
CREATE INDEX idx_documents_metadata ON documents USING GIN (metadata);

-- =============================================================================
-- API ENDPOINTS TABLE (Create API Page)
-- =============================================================================
CREATE TABLE api_endpoints (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    endpoint_path TEXT NOT NULL, -- e.g., "/api/financial/search"
    method TEXT NOT NULL DEFAULT 'POST' CHECK (method IN ('GET', 'POST', 'PUT', 'DELETE', 'PATCH')),
    
    -- Configuration
    pipeline_id UUID REFERENCES pipelines(id) ON DELETE SET NULL,
    config JSONB NOT NULL, -- API endpoint configuration
    request_schema JSONB, -- Request validation schema
    response_schema JSONB, -- Response format schema
    
    -- Security and access
    auth_required BOOLEAN DEFAULT true,
    rate_limit INTEGER DEFAULT 1000, -- Requests per hour
    allowed_origins TEXT[], -- CORS origins
    api_key_required BOOLEAN DEFAULT false,
    
    -- Status and metrics
    status TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'deprecated')),
    total_calls INTEGER DEFAULT 0,
    successful_calls INTEGER DEFAULT 0,
    failed_calls INTEGER DEFAULT 0,
    last_called TIMESTAMP WITH TIME ZONE,
    
    -- Audit
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT api_endpoints_path_method_unique UNIQUE (endpoint_path, method)
);

-- Indexes
CREATE INDEX idx_api_endpoints_pipeline_id ON api_endpoints(pipeline_id);
CREATE INDEX idx_api_endpoints_status ON api_endpoints(status);
CREATE INDEX idx_api_endpoints_created_by ON api_endpoints(created_by);
CREATE INDEX idx_api_endpoints_endpoint_path ON api_endpoints(endpoint_path);

-- =============================================================================
-- SYSTEM SETTINGS TABLE (Configuration Storage)
-- =============================================================================
CREATE TABLE system_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category VARCHAR(100) NOT NULL, -- e.g., 'embedding', 'security', 'notifications'
    key VARCHAR(255) NOT NULL,
    value JSONB NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT false,
    is_public BOOLEAN DEFAULT false, -- Can be accessed by non-admin users
    
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT system_settings_category_key_unique UNIQUE (category, key)
);

-- Indexes
CREATE INDEX idx_system_settings_category ON system_settings(category);
CREATE INDEX idx_system_settings_key ON system_settings(key);

-- =============================================================================
-- AUDIT LOG TABLE (System Activity Tracking)
-- =============================================================================
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    entity_type VARCHAR(100) NOT NULL, -- 'connector', 'parser_profile', 'pipeline', etc.
    entity_id UUID,
    action VARCHAR(100) NOT NULL, -- 'create', 'update', 'delete', 'execute', etc.
    details JSONB, -- Action details and changed fields
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);

-- =============================================================================
-- TRIGGERS FOR UPDATED_AT TIMESTAMPS
-- =============================================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to relevant tables
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_connectors_updated_at BEFORE UPDATE ON connectors FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_parser_profiles_updated_at BEFORE UPDATE ON parser_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_pipelines_updated_at BEFORE UPDATE ON pipelines FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON documents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_api_endpoints_updated_at BEFORE UPDATE ON api_endpoints FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON system_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =============================================================================
-- SAMPLE DATA INSERTS (Optional - for testing)
-- =============================================================================

-- Insert default admin user (password should be hashed in real implementation)
INSERT INTO users (username, password, email, full_name, role) VALUES 
('admin', '$2b$10$example_hashed_password', 'admin@contextcraft.com', 'System Administrator', 'admin');

-- Insert sample system settings
INSERT INTO system_settings (category, key, value, description, is_public) VALUES
('embedding', 'default_model', '"text-embedding-3-small"', 'Default embedding model for text processing', true),
('system', 'max_file_size_mb', '100', 'Maximum file size allowed for upload in MB', true),
('notifications', 'smtp_settings', '{"host": "", "port": 587, "username": "", "password": ""}', 'SMTP configuration for email notifications', false);

-- =============================================================================
-- VIEWS FOR COMMON QUERIES
-- =============================================================================

-- Pipeline summary view
CREATE VIEW pipeline_summary AS
SELECT 
    p.id,
    p.name,
    p.type,
    p.status,
    p.documents_processed,
    p.vectors_generated,
    p.total_runs,
    p.successful_runs,
    p.failed_runs,
    p.last_run,
    p.last_run_status,
    c.name as connector_name,
    pp.name as parser_profile_name,
    u.username as created_by_username,
    p.created_at,
    p.updated_at
FROM pipelines p
LEFT JOIN connectors c ON p.source_connector_id = c.id
LEFT JOIN parser_profiles pp ON p.parser_profile_id = pp.id
LEFT JOIN users u ON p.created_by = u.id;

-- Active resources view
CREATE VIEW active_resources AS
SELECT 
    'connector' as resource_type,
    id,
    name,
    status,
    created_at,
    updated_at
FROM connectors WHERE status = 'active'
UNION ALL
SELECT 
    'parser_profile' as resource_type,
    id,
    name,
    status,
    created_at,
    updated_at
FROM parser_profiles WHERE status = 'active'
UNION ALL
SELECT 
    'pipeline' as resource_type,
    id,
    name,
    status,
    created_at,
    updated_at
FROM pipelines WHERE status IN ('active', 'running');

-- =============================================================================
-- COMMENTS AND DOCUMENTATION
-- =============================================================================

-- Table comments
COMMENT ON TABLE connectors IS 'Data source connectors for importing documents from various sources (S3, GCS, Azure, etc.)';
COMMENT ON TABLE parser_profiles IS 'Document parser configurations for extracting text and structure from various file formats';
COMMENT ON TABLE pipelines IS 'Complete document processing pipelines with ReactFlow configuration';
COMMENT ON TABLE pipeline_executions IS 'Historical record of pipeline executions and their results';
COMMENT ON TABLE documents IS 'Individual documents processed through the system';
COMMENT ON TABLE api_endpoints IS 'Published API endpoints for accessing processed data';
COMMENT ON TABLE system_settings IS 'System-wide configuration settings';
COMMENT ON TABLE audit_logs IS 'System activity audit trail';

-- Column comments for key JSONB fields
COMMENT ON COLUMN connectors.config IS 'Connector-specific configuration: AWS credentials, GCS service account, Azure connection strings, etc.';
COMMENT ON COLUMN parser_profiles.config IS 'Parser-specific configuration: API keys, model settings, processing parameters, etc.';
COMMENT ON COLUMN pipelines.config IS 'Complete pipeline configuration including all stages and their settings';
COMMENT ON COLUMN pipelines.nodes IS 'ReactFlow nodes configuration for visual pipeline designer';
COMMENT ON COLUMN pipelines.edges IS 'ReactFlow edges configuration showing pipeline flow connections';