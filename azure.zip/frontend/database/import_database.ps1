# ContextCraft Database Import Script
# This script imports the ContextCraft database backup on a new machine
# Usage: .\import_database.ps1 -BackupFile "contextcraft_backup.sql"

param(
    [Parameter(Mandatory=$true)]
    [string]$BackupFile,
    [string]$DbHost = "localhost",
    [string]$DbPort = "5432", 
    [string]$Database = "contextcraft",
    [string]$Username = "postgres",
    [switch]$CreateDatabase = $false
)

Write-Host "ContextCraft Database Import Utility" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Green

# Check if backup file exists
if (!(Test-Path $BackupFile)) {
    Write-Host "ERROR: Backup file not found: $BackupFile" -ForegroundColor Red
    exit 1
}

# Check if psql is available
try {
    $psqlVersion = psql --version
    Write-Host "Found psql: $psqlVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: psql not found. Please ensure PostgreSQL client tools are installed and in PATH." -ForegroundColor Red
    Write-Host "You can download PostgreSQL client tools from: https://www.postgresql.org/download/" -ForegroundColor Yellow
    exit 1
}

# Set PGPASSWORD environment variable if not set
if (-not $env:PGPASSWORD) {
    Write-Host "Database password not set in PGPASSWORD environment variable." -ForegroundColor Yellow
    $securePassword = Read-Host "Enter database password" -AsSecureString
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword)
    $env:PGPASSWORD = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
}

Write-Host "Importing database backup: $BackupFile" -ForegroundColor Cyan
Write-Host "Target: $Database on ${DbHost}:${DbPort}" -ForegroundColor Cyan

# Create database if requested
if ($CreateDatabase) {
    Write-Host "Creating database: $Database" -ForegroundColor Yellow
    
    $createDbArgs = @(
        "--host=$DbHost",
        "--port=$DbPort",
        "--username=$Username", 
        "--dbname=postgres",
        "--command=CREATE DATABASE $Database;"
    )
    
    try {
        & psql @createDbArgs
        Write-Host "Database created successfully." -ForegroundColor Green
    } catch {
        Write-Host "Warning: Could not create database. It may already exist." -ForegroundColor Yellow
    }
}

# Import the backup
Write-Host "Importing backup file..." -ForegroundColor Cyan

$importArgs = @(
    "--host=$DbHost",
    "--port=$DbPort",
    "--username=$Username",
    "--dbname=postgres",
    "--file=$BackupFile",
    "--verbose"
)

try {
    & psql @importArgs
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "`nImport completed successfully!" -ForegroundColor Green
        
        # Verify the import by checking if tables exist
        Write-Host "Verifying import..." -ForegroundColor Cyan
        
        $verifyArgs = @(
            "--host=$DbHost",
            "--port=$DbPort", 
            "--username=$Username",
            "--dbname=$Database",
            "--command=\dt"
        )
        
        Write-Host "Tables in database:" -ForegroundColor Green
        & psql @verifyArgs
        
    } else {
        Write-Host "Import failed with exit code: $LASTEXITCODE" -ForegroundColor Red
        exit $LASTEXITCODE
    }
} catch {
    Write-Host "Error during import: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} finally {
    # Clear the password from environment
    Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
}

Write-Host "`nImport completed! Next steps:" -ForegroundColor Green
Write-Host "1. Update your .env file with the correct DATABASE_URL" -ForegroundColor Yellow
Write-Host "2. Test the application connection" -ForegroundColor Yellow
Write-Host "3. Run any pending migrations if needed" -ForegroundColor Yellow

Write-Host "`nExample DATABASE_URL format:" -ForegroundColor Cyan
Write-Host "DATABASE_URL=postgresql://username:password@${DbHost}:${DbPort}/$Database" -ForegroundColor White