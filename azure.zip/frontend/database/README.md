# ContextCraft Database Export/Import Guide

This guide explains how to export your ContextCraft database and import it on another machine.

## Available Export Methods

### Method 1: Data-Only Export (Recommended) 
✅ **Works without external tools** - Uses Node.js and your existing database connection
- Exports only your data (connectors, users, settings, etc.)
- Schema should be created using your migration files
- Best for most use cases

### Method 2: Full Database Export
- Requires PostgreSQL client tools (`pg_dump`)
- Exports both schema and data
- More complete but requires additional setup

## Prerequisites

For **Method 1** (Data-Only): No additional tools needed - uses your existing Node.js setup

For **Method 2** (Full Export): 
- PostgreSQL client tools (`pg_dump` and `psql`) must be installed
- Download from: https://www.postgresql.org/download/
- Make sure the tools are in your system PATH

## Method 1: Data-Only Export (Recommended)

### Export Your Data

```powershell
# Navigate to the database folder
cd e:\Dev_Branch\contextcraft\24_09\ContextCraftPro\database

# Export your data (connectors, users, settings, etc.)
node export_data.js
```

This creates a `contextcraft_data_export.sql` file with all your data.

### Import on Another Machine

```powershell
# 1. First, set up the database schema using your migrations
cd path\to\contextcraft\on\new\machine
npm run db:migrate

# 2. Then import your data
psql -h hostname -p port -U username -d database_name -f "contextcraft_data_export.sql"
```

## Method 2: Full Database Export

### Export Database (Source Machine)

#### Option A: Using the PowerShell Script

```powershell
# Navigate to the database folder
cd e:\Dev_Branch\contextcraft\24_09\ContextCraftPro\database

# Run the export script
.\export_database.ps1

# Or with custom parameters
.\export_database.ps1 -OutputPath "C:\backups\contextcraft_full_backup.sql" -DbHost "localhost" -DbPort "5432" -Database "contextcraft" -Username "postgres"
```

#### Option B: Manual pg_dump Command

```powershell
# Set password (optional, will be prompted if not set)
$env:PGPASSWORD = "your_password"

# Export the database
pg_dump --host=localhost --port=5432 --username=postgres --dbname=contextcraft --verbose --clean --create --if-exists --format=plain --encoding=UTF8 --no-owner --no-privileges --file=contextcraft_backup.sql
```

### Import Database (Target Machine)

#### Option A: Using the PowerShell Script

```powershell
# Copy the backup file to the target machine
# Navigate to the database folder
cd path\to\contextcraft\database

# Run the import script
.\import_database.ps1 -BackupFile "contextcraft_backup.sql"

# Or with custom parameters and create database
.\import_database.ps1 -BackupFile "contextcraft_backup.sql" -DbHost "localhost" -DbPort "5432" -Database "contextcraft" -Username "postgres" -CreateDatabase
```

#### Option B: Manual psql Command

```powershell
# Set password (optional, will be prompted if not set)
$env:PGPASSWORD = "your_password"

# Import the database
psql -h localhost -p 5432 -U postgres -d postgres -f contextcraft_backup.sql
```

## Post-Import Setup

1. **Update Environment Variables**: Update your `.env` file on the target machine:
   ```
   DATABASE_URL=postgresql://postgres:password@localhost:5432/contextcraft
   ```

2. **Test Connection**: Run your application and verify it connects to the database successfully.

3. **Run Migrations** (if needed): If you have any pending migrations:
   ```powershell
   npm run db:migrate
   ```

## Troubleshooting

### Common Issues

1. **pg_dump/psql not found**: 
   - Install PostgreSQL client tools
   - Add PostgreSQL bin directory to your PATH

2. **Permission denied**:
   - Ensure the database user has proper permissions
   - Try running as administrator

3. **Database already exists**:
   - Use the `-CreateDatabase` flag with the import script, or
   - Drop the existing database first: `DROP DATABASE contextcraft;`

4. **Password authentication failed**:
   - Set the `PGPASSWORD` environment variable, or
   - Update `pg_hba.conf` for trust authentication locally

### Available Files

#### Data Export/Import (Method 1)
- **Data Export Script**: `database/export_data.js`
- **Generated Data File**: `database/contextcraft_data_export.sql`

#### Full Database Export/Import (Method 2)  
- **PowerShell Export Script**: `database/export_database.ps1`
- **PowerShell Import Script**: `database/import_database.ps1`
- **Node.js Backup Script**: `database/backup_database.js`
- **Node.js Restore Script**: `database/restore_database.js`

#### Schema & Migrations
- **Schema Definition**: `shared/schema.ts`
- **Migration Files**: `migrations/` folder
- **Database Info Script**: `database/export_info.sql`

## Security Notes

- The scripts automatically clear password environment variables after use
- Backup files contain all your data - store securely
- Consider using encrypted backups for sensitive data
- Use strong database passwords and restrict network access

## Script Features

### Export Script
- ✅ Complete schema export
- ✅ All data included
- ✅ Constraints and indexes
- ✅ Functions and procedures
- ✅ Clean import (drops existing objects)
- ✅ UTF-8 encoding
- ✅ Cross-platform compatible format

### Import Script  
- ✅ Database creation option
- ✅ Verification after import
- ✅ Detailed error reporting
- ✅ Safe password handling
- ✅ Connection testing