// ContextCraft Database Backup Utility
// This script creates a complete backup of your ContextCraft database using Node.js
// Run with: node backup_database.js

import fs from 'fs';
import path from 'path';
import postgres from 'postgres';

// Configuration
const config = {
    connectionString: process.env.DATABASE_URL || 'postgresql://postgres:admin%4012345@localhost:5432/contextcraft',
    outputFile: 'contextcraft_backup.sql',
    includeSchema: true,
    includeData: true
};

console.log('ContextCraft Database Backup Utility');
console.log('====================================');
console.log(`Connection: ${config.connectionString.replace(/:[^:@]*@/, ':****@')}`);
console.log(`Output file: ${config.outputFile}`);
console.log('');

async function createBackup() {
    const sql = postgres(config.connectionString);
    let backupContent = [];
    
    try {
        // Add header
        backupContent.push('-- ContextCraft Database Backup');
        backupContent.push(`-- Generated on: ${new Date().toISOString()}`);
        backupContent.push('-- This file contains both schema and data');
        backupContent.push('');
        backupContent.push('BEGIN;');
        backupContent.push('');

        if (config.includeSchema) {
            console.log('Exporting database schema...');
            await exportSchema(sql, backupContent);
        }

        if (config.includeData) {
            console.log('Exporting data...');
            await exportData(sql, backupContent);
        }

        backupContent.push('COMMIT;');
        backupContent.push('');
        backupContent.push('-- Backup completed successfully');

        // Write to file
        const fullContent = backupContent.join('\n');
        fs.writeFileSync(config.outputFile, fullContent, 'utf8');
        
        const stats = fs.statSync(config.outputFile);
        const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        
        console.log('');
        console.log('✅ Backup completed successfully!');
        console.log(`📁 File: ${path.resolve(config.outputFile)}`);
        console.log(`📊 Size: ${fileSizeMB} MB`);
        console.log('');
        console.log('To restore on another machine:');
        console.log(`psql -h hostname -p port -U username -d database_name -f "${config.outputFile}"`);
        
    } catch (error) {
        console.error('❌ Backup failed:', error.message);
        process.exit(1);
    } finally {
        await sql.end();
    }
}

async function exportSchema(sql, backupContent) {
    // Get all user tables
    const tables = await sql`
        SELECT tablename, schemaname 
        FROM pg_tables 
        WHERE schemaname = 'public' 
        ORDER BY tablename
    `;

    console.log(`Found ${tables.length} tables to export`);

    for (const table of tables) {
        console.log(`  - Exporting schema for: ${table.tablename}`);
        
        // Get table definition
        const tableSchema = await sql`
            SELECT 
                'CREATE TABLE ' || quote_ident(table_schema) || '.' || quote_ident(table_name) || ' (' ||
                string_agg(
                    quote_ident(column_name) || ' ' || 
                    data_type || 
                    CASE 
                        WHEN character_maximum_length IS NOT NULL 
                        THEN '(' || character_maximum_length || ')'
                        ELSE ''
                    END ||
                    CASE 
                        WHEN is_nullable = 'NO' THEN ' NOT NULL'
                        ELSE ''
                    END ||
                    CASE 
                        WHEN column_default IS NOT NULL 
                        THEN ' DEFAULT ' || column_default
                        ELSE ''
                    END,
                    ', ' ORDER BY ordinal_position
                ) || ');' as create_statement
            FROM information_schema.columns 
            WHERE table_name = ${table.tablename} 
                AND table_schema = 'public'
            GROUP BY table_schema, table_name
        `;

        if (tableSchema.length > 0) {
            backupContent.push(`-- Table: ${table.tablename}`);
            backupContent.push(`DROP TABLE IF EXISTS ${table.tablename} CASCADE;`);
            backupContent.push(tableSchema[0].create_statement);
            backupContent.push('');
        }
    }

    // Export indexes
    const indexes = await sql`
        SELECT indexname, indexdef 
        FROM pg_indexes 
        WHERE schemaname = 'public' 
        AND indexname NOT LIKE '%_pkey'
        ORDER BY indexname
    `;

    if (indexes.length > 0) {
        backupContent.push('-- Indexes');
        for (const index of indexes) {
            backupContent.push(`${index.indexdef};`);
        }
        backupContent.push('');
    }
}

async function exportData(sql, backupContent) {
    // Get all user tables
    const tables = await sql`
        SELECT tablename 
        FROM pg_tables 
        WHERE schemaname = 'public' 
        ORDER BY tablename
    `;

    for (const table of tables) {
        console.log(`  - Exporting data for: ${table.tablename}`);
        
        // Get column names
        const columns = await sql`
            SELECT column_name 
            FROM information_schema.columns 
            WHERE table_name = ${table.tablename} 
                AND table_schema = 'public'
            ORDER BY ordinal_position
        `;

        const columnNames = columns.map(col => col.column_name);
        
        // Get data
        const data = await sql`SELECT * FROM ${sql(table.tablename)}`;
        
        if (data.length > 0) {
            backupContent.push(`-- Data for table: ${table.tablename}`);
            
            for (const row of data) {
                const values = columnNames.map(col => {
                    const value = row[col];
                    if (value === null) return 'NULL';
                    if (typeof value === 'string') return `'${value.replace(/'/g, "''")}'`;
                    if (value instanceof Date) return `'${value.toISOString()}'`;
                    return value;
                });
                
                backupContent.push(
                    `INSERT INTO ${table.tablename} (${columnNames.map(col => `"${col}"`).join(', ')}) ` +
                    `VALUES (${values.join(', ')});`
                );
            }
            backupContent.push('');
        }
    }
}

// Run the backup
createBackup().catch(console.error);