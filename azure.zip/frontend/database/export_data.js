// ContextCraft Database Data Export Utility
// This script exports only the DATA from your ContextCraft database 
// The schema should be created using your existing migration files
// Run with: node export_data.js

import fs from 'fs';
import path from 'path';
import postgres from 'postgres';

// Configuration
const config = {
    connectionString: process.env.DATABASE_URL || 'postgresql://postgres:admin%4012345@localhost:5432/contextcraft',
    outputFile: 'contextcraft_data_export.sql'
};

console.log('ContextCraft Database Data Export Utility');
console.log('=========================================');
console.log(`Connection: ${config.connectionString.replace(/:[^:@]*@/, ':****@')}`);
console.log(`Output file: ${config.outputFile}`);
console.log('');

async function exportData() {
    const sql = postgres(config.connectionString);
    let exportContent = [];
    
    try {
        // Add header
        exportContent.push('-- ContextCraft Database Data Export');
        exportContent.push(`-- Generated on: ${new Date().toISOString()}`);
        exportContent.push('-- This file contains only data, not schema');
        exportContent.push('-- Apply your schema migrations first, then run this script');
        exportContent.push('');
        exportContent.push('BEGIN;');
        exportContent.push('');

        console.log('Fetching table list...');
        
        // Get all user tables
        const tables = await sql`
            SELECT tablename 
            FROM pg_tables 
            WHERE schemaname = 'public' 
            ORDER BY tablename
        `;

        console.log(`Found ${tables.length} tables:`);
        tables.forEach(table => console.log(`  - ${table.tablename}`));
        console.log('');

        for (const table of tables) {
            console.log(`Exporting data from: ${table.tablename}`);
            
            try {
                // Get column information
                const columns = await sql`
                    SELECT column_name, data_type, is_nullable
                    FROM information_schema.columns 
                    WHERE table_name = ${table.tablename} 
                        AND table_schema = 'public'
                    ORDER BY ordinal_position
                `;

                const columnNames = columns.map(col => col.column_name);
                
                // Get all data from the table
                const rows = await sql`SELECT * FROM ${sql(table.tablename)}`;
                
                if (rows.length > 0) {
                    exportContent.push(`-- Data for table: ${table.tablename} (${rows.length} rows)`);
                    exportContent.push(`DELETE FROM "${table.tablename}"; -- Clear existing data`);
                    
                    for (const row of rows) {
                        const values = columnNames.map(col => {
                            const value = row[col];
                            if (value === null) return 'NULL';
                            if (typeof value === 'string') {
                                // Escape single quotes
                                return `'${value.replace(/'/g, "''")}'`;
                            }
                            if (value instanceof Date) {
                                return `'${value.toISOString()}'`;
                            }
                            if (typeof value === 'boolean') {
                                return value ? 'true' : 'false';
                            }
                            if (Array.isArray(value)) {
                                return `'${JSON.stringify(value)}'`;
                            }
                            if (typeof value === 'object') {
                                return `'${JSON.stringify(value)}'`;
                            }
                            return value;
                        });
                        
                        const insertStatement = `INSERT INTO "${table.tablename}" (${columnNames.map(col => `"${col}"`).join(', ')}) VALUES (${values.join(', ')});`;
                        exportContent.push(insertStatement);
                    }
                    exportContent.push('');
                    console.log(`  ✅ Exported ${rows.length} rows`);
                } else {
                    exportContent.push(`-- Table ${table.tablename} is empty`);
                    exportContent.push('');
                    console.log(`  ℹ️  Table is empty`);
                }
            } catch (error) {
                console.error(`  ❌ Error exporting ${table.tablename}: ${error.message}`);
                exportContent.push(`-- Error exporting ${table.tablename}: ${error.message}`);
                exportContent.push('');
            }
        }

        exportContent.push('COMMIT;');
        exportContent.push('');
        exportContent.push('-- Data export completed successfully');

        // Write to file
        const fullContent = exportContent.join('\n');
        fs.writeFileSync(config.outputFile, fullContent, 'utf8');
        
        const stats = fs.statSync(config.outputFile);
        const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        
        console.log('');
        console.log('✅ Data export completed successfully!');
        console.log(`📁 File: ${path.resolve(config.outputFile)}`);
        console.log(`📊 Size: ${fileSizeMB} MB`);
        console.log('');
        console.log('To import on another machine:');
        console.log('1. First, run your database migrations to create the schema');
        console.log('2. Then run: psql -h hostname -p port -U username -d database_name -f "' + config.outputFile + '"');
        
    } catch (error) {
        console.error('❌ Export failed:', error.message);
        console.error(error.stack);
        process.exit(1);
    } finally {
        await sql.end();
    }
}

// Run the export
exportData().catch(console.error);