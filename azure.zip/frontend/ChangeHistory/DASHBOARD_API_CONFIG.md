# Dashboard API Configuration

## Environment Variables

### External API Configuration
- `EXTERNAL_API_BASE_URL`: Base URL for external API (default: http://10.73.88.101:8000)
- `EXTERNAL_API_LOGS_COUNT_ENDPOINT`: Endpoint for API logs count (default: /metrics/logs/count)
- `EXTERNAL_API_VECTORIZE_COUNT_ENDPOINT`: Endpoint for documents vectorized count (default: /metrics/vectorize-documents/count)
- `EXTERNAL_API_ACTIVE_APIS_ENDPOINT`: Endpoint for active APIs status (default: /search-apis/status)

### Fallback Values
- `FALLBACK_API_CALLS_COUNT`: Fallback value for API calls count (default: 1247)
- `FALLBACK_DOCUMENTS_VECTORIZED_COUNT`: Fallback value for documents vectorized (default: 8932)
- `FALLBACK_ACTIVE_APIS_COUNT`: Fallback value for active APIs (default: 3)

## API Endpoints

### Internal Proxy Routes (accessed by frontend)
- `GET /api/dashboard/metrics/logs/count` - Returns API calls count
- `GET /api/dashboard/metrics/vectorize-documents/count` - Returns documents vectorized count
- `GET /api/dashboard/search-apis/status` - Returns active APIs count

### External API Routes (proxied by backend)
- `http://10.73.88.101:8000/metrics/logs/count` - Returns `{"total_api_calls": number}`
- `http://10.73.88.101:8000/metrics/vectorize-documents/count` - Returns document count
- `http://10.73.88.101:8000/search-apis/status` - Returns active APIs count

## Response Format

All internal API endpoints return:
```json
{
  "count": number,
  "error": string (optional),
  "fallback": boolean (optional),
  "originalResponse": object (optional, for debugging)
}
```

## Error Handling

1. If external API is unreachable → Returns N/A in frontend
2. If external API returns 404/500 → Returns N/A in frontend  
3. If response format is unexpected → Returns N/A in frontend
4. All errors are logged in server console with 📊 emojis for easy identification

## Current Status

Server running on: http://localhost:5002
Frontend should connect to: http://localhost:5002

## Field Mapping

The API response field extraction handles multiple possible field names:

### API Calls Count
- `total_api_calls` (confirmed working from Postman)
- `count`
- `api_calls`

### Documents Vectorized
- `documents_vectorized`
- `total_documents`
- `count`
- `vectorized_count`

### Active APIs
- `active_apis`
- `active_count`
- `count`
- `total_active`