# Feature Flags Implementation Guide

## Overview
ContextCraft now supports feature flags to control connector and parser visibility based on deployment requirements.

## Environment Variable

Add to your `.env` file:
```env
# Feature Flags
# FEATURE_FLAG_GOOGLE=true - Google-based features only (GCS, Google Drive, File shares, File upload)
# FEATURE_FLAG_GOOGLE=false - Full features (all cloud connectors and parsers)
FEATURE_FLAG_GOOGLE=false
```

## Feature Flag Modes

### 1. Google-Based Mode (`FEATURE_FLAG_GOOGLE=true`)
**Visible Connectors:**
- ✅ Google Cloud Storage (GCS)
- ✅ Google Drive
- ✅ File Shares
- ✅ File Upload

**Hidden Connectors:**
- ❌ AWS S3
- ❌ Azure Blob Storage

**Visible Parsers:**
- ✅ Google Document AI
- ✅ Tesseract OCR
- ✅ PaddleOCR
- ✅ Unstructured.io SDK

**Hidden Parsers:**
- ❌ Azure Document AI

### 2. Full Features Mode (`FEATURE_FLAG_GOOGLE=false`)
**All connectors and parsers are visible and available.**

## Implementation Details

### Files Modified:
1. `client/src/lib/featureFlags.ts` - Feature flags utility
2. `client/src/pages/import-connectors/ImportConnectorsPage.tsx` - Connector filtering
3. `client/src/pages/parser-profiles/ParsersPage.tsx` - Parser filtering
4. `client/src/pages/pipeline-designer/PipelineDesigner.tsx` - Pipeline component filtering
5. `vite.config.ts` - Environment variable exposure
6. `.env` - Feature flag configuration

### Key Functions:
- `isConnectorVisible(connectorType)` - Checks if connector should be shown
- `isParserVisible(parserType)` - Checks if parser should be shown
- `getFeatureFlags()` - Returns current feature flag configuration

## Usage in Components

```typescript
import { isConnectorVisible, isParserVisible, featureFlags } from "@/lib/featureFlags";

// Check if a connector should be visible
if (isConnectorVisible("s3")) {
  // Show AWS S3 connector
}

// Check if a parser should be visible
if (isParserVisible("azure-document-ai")) {
  // Show Azure Document AI parser
}

// Access feature flags directly
if (featureFlags.isGoogleBasedOnly) {
  // Google-based mode logic
}
```

## Testing

1. **Test Google-Based Mode:**
   ```env
   FEATURE_FLAG_GOOGLE=true
   ```
   - Navigate to Import Connectors - Should only show Google/File connectors
   - Navigate to Parser Profiles - Should hide Azure Document AI
   - Pipeline Designer - Should only show filtered options

2. **Test Full Features Mode:**
   ```env
   FEATURE_FLAG_GOOGLE=false
   ```
   - All connectors and parsers should be visible

## Benefits

- ✅ **No code deletion** - All components preserved, just hidden
- ✅ **Runtime switching** - Change feature flags without recompiling
- ✅ **Consistent filtering** - Applied across all relevant pages
- ✅ **Type-safe** - Full TypeScript support
- ✅ **Maintainable** - Centralized configuration in one utility file

## Deployment Considerations

- Set `FEATURE_FLAG_GOOGLE=true` for Google-focused deployments
- Set `FEATURE_FLAG_GOOGLE=false` for enterprise/full-feature deployments
- Feature flags are read at application startup and cached for performance