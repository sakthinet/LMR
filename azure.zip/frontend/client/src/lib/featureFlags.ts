// Feature flags utility for controlling component visibility
// Based on environment variables to enable/disable features

export interface FeatureFlags {
  isGoogleBasedOnly: boolean;
  isFullFeature: boolean;
}

// Get feature flags from environment variables
export const getFeatureFlags = (): FeatureFlags => {
  // Default to full features if not specified
  const envValue = import.meta.env.VITE_FEATURE_FLAG_GOOGLE;
  const isGoogleBasedOnly = envValue === 'true';
  
  // Debug logging in development
  if (import.meta.env.DEV) {
    console.log('Feature Flags Debug:', {
      envValue,
      isGoogleBasedOnly,
      allEnvVars: import.meta.env
    });
  }
  
  return {
    isGoogleBasedOnly,
    isFullFeature: !isGoogleBasedOnly
  };
};

// Feature flag instance
export const featureFlags = getFeatureFlags();

// Connector visibility configuration
export const connectorVisibility = {
  // Always visible connectors (available in both Google-based and Full features)
  alwaysVisible: [
    'file-upload',
    'file-share',
    'google-drive', 
    'gcs' // Google Cloud Storage
  ],
  
  // Only visible in Full features mode
  fullFeatureOnly: [
    's3',
    'azure-blob'
  ]
};

// Parser visibility configuration  
export const parserVisibility = {
  // Always visible parsers (available in both Google-based and Full features)
  alwaysVisible: [
    'unstructured',
    'tesseract',
    'paddle',
    'google-document-ai'
  ],
  
  // Only visible in Full features mode
  fullFeatureOnly: [
    'azure-document-ai'
  ]
};

// Helper functions to check component visibility
export const isConnectorVisible = (connectorType: string): boolean => {
  if (connectorVisibility.alwaysVisible.includes(connectorType)) {
    return true;
  }
  
  if (connectorVisibility.fullFeatureOnly.includes(connectorType)) {
    return featureFlags.isFullFeature;
  }
  
  return true; // Default to visible for unknown types
};

export const isParserVisible = (parserType: string): boolean => {
  if (parserVisibility.alwaysVisible.includes(parserType)) {
    return true;
  }
  
  if (parserVisibility.fullFeatureOnly.includes(parserType)) {
    return featureFlags.isFullFeature;
  }
  
  return true; // Default to visible for unknown types
};

// Feature flag debug info (for development)
export const getFeatureFlagDebugInfo = () => {
  console.log('Feature Flags Debug Info:', {
    isGoogleBasedOnly: featureFlags.isGoogleBasedOnly,
    isFullFeature: featureFlags.isFullFeature,
    envVar: import.meta.env.VITE_FEATURE_FLAG_GOOGLE,
    rawEnvVar: import.meta.env.VITE_FEATURE_FLAG_GOOGLE,
    comparison: `'${import.meta.env.VITE_FEATURE_FLAG_GOOGLE}' === 'true' = ${import.meta.env.VITE_FEATURE_FLAG_GOOGLE === 'true'}`,
    allEnvVars: import.meta.env
  });
};