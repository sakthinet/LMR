import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Upload, FileText, Play, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TestDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  parserName: string;
  parserType: string;
  config?: any;
}

export function TestDocumentModal({ 
  isOpen, 
  onClose, 
  parserName, 
  parserType,
  config 
}: TestDocumentModalProps) {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [testDocument, setTestDocument] = useState("");
  const [testResults, setTestResults] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file type
      const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/tiff', 'image/bmp', 'image/gif'];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Unsupported file type",
          description: "Please upload a PDF or image file (PNG, JPG, JPEG, TIFF, BMP, GIF)",
          variant: "destructive",
        });
        return;
      }

      setUploadedFile(file);
      setTestDocument(""); // Clear text if file is uploaded
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/tiff', 'image/bmp', 'image/gif'];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Unsupported file type",
          description: "Please upload a PDF or image file (PNG, JPG, JPEG, TIFF, BMP, GIF)",
          variant: "destructive",
        });
        return;
      }
      setUploadedFile(file);
      setTestDocument("");
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const runDocumentAnalysis = async () => {
    if (!uploadedFile && !testDocument.trim()) {
      toast({
        title: "No document provided",
        description: "Please upload a file or enter sample text to analyze.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    setTestResults("Analyzing document...");
    
    try {
      // Simulate API call with realistic delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock analysis results based on parser type
      const mockResults = {
        parser: {
          name: parserName,
          type: parserType,
          version: "1.0.0"
        },
        document: {
          fileName: uploadedFile?.name || "sample-text",
          fileSize: uploadedFile?.size || testDocument.length,
          fileType: uploadedFile?.type || "text/plain"
        },
        analysis: {
          extractedText: uploadedFile ? `Sample OCR extracted text from uploaded document: ${uploadedFile.name}...` : testDocument,
          confidence: Math.random() * (0.95 - 0.75) + 0.75,
          processingTime: Math.random() * (3.5 - 1.2) + 1.2,
          language: config?.language || "en",
          wordCount: uploadedFile ? Math.floor(Math.random() * 500) + 100 : testDocument.split(' ').length,
          entities: [
            { type: "PERSON", value: "John Doe", confidence: 0.92 },
            { type: "DATE", value: "2024-01-15", confidence: 0.88 },
            { type: "ORGANIZATION", value: "Acme Corp", confidence: 0.95 }
          ],
          tables: [
            {
              rows: 3,
              columns: 4,
              confidence: 0.87,
              location: { x: 50, y: 200, width: 300, height: 120 }
            }
          ]
        },
        metadata: {
          apiProvider: parserType === "tesseract" ? "Tesseract OCR" : 
                      parserType === "azure-ai" ? "Azure Document AI" :
                      parserType === "google-ai" ? "Google Document AI" :
                      parserType === "paddle" ? "PaddleOCR" :
                      "Unstructured.io SDK",
          processedAt: new Date().toISOString(),
          requestId: Math.random().toString(36).substring(7)
        }
      };

      setTestResults(JSON.stringify(mockResults, null, 2));
      
      toast({
        title: "Analysis complete",
        description: "Document has been processed successfully.",
      });
    } catch (error) {
      setTestResults("Error occurred during analysis.");
      toast({
        title: "Analysis failed",
        description: "Failed to process document. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const clearAll = () => {
    setUploadedFile(null);
    setTestDocument("");
    setTestResults("");
    setIsAnalyzing(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClose = () => {
    clearAll();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Test Document - {parserName}</DialogTitle>
          <DialogDescription>
            Upload a document or provide sample text to test your parser configuration
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upload Section */}
          <div className="space-y-4">
            <div className="space-y-4">
              <h4 className="font-medium">Document Upload</h4>
              
              {/* File Upload Area */}
              <div
                className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors"
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                data-testid="document-upload-area"
              >
                {uploadedFile ? (
                  <div className="space-y-2">
                    <FileText className="w-8 h-8 mx-auto text-primary" />
                    <p className="text-sm font-medium">{uploadedFile.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(uploadedFile.size / 1024).toFixed(1)} KB
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={removeFile}
                      data-testid="button-remove-file"
                    >
                      <X className="w-3 h-3 mr-1" />
                      Remove
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Upload className="w-8 h-8 mx-auto text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Drag and drop your document here, or
                    </p>
                    <Button
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      data-testid="button-choose-file"
                    >
                      Choose File
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Supports: PDF, PNG, JPG, JPEG, TIFF, BMP, GIF
                    </p>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.png,.jpg,.jpeg,.tiff,.bmp,.gif"
                  onChange={handleFileUpload}
                  className="hidden"
                  data-testid="input-document-upload"
                />
              </div>

              {/* Text Input Alternative */}
              <div className="space-y-2">
                <Label htmlFor="test-document" className="text-sm font-medium">
                  Or enter sample text
                </Label>
                <Textarea
                  id="test-document"
                  placeholder="Enter sample document text to test your parser..."
                  value={testDocument}
                  onChange={(e) => setTestDocument(e.target.value)}
                  disabled={!!uploadedFile}
                  data-testid="textarea-test-document"
                  rows={6}
                />
              </div>
            </div>
          </div>

          {/* Preview Section */}
          <div className="space-y-4">
            <h4 className="font-medium">Document Preview</h4>
            
            <div className="border rounded-lg p-4 min-h-[200px] bg-gray-50">
              {uploadedFile ? (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Uploaded File:</p>
                  <div className="bg-white p-3 rounded border">
                    <div className="flex items-center space-x-2">
                      <FileText className="w-4 h-4 text-primary" />
                      <span className="text-sm">{uploadedFile.name}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Size: {(uploadedFile.size / 1024).toFixed(1)} KB
                    </p>
                    {uploadedFile.type.startsWith('image/') && (
                      <div className="mt-2">
                        <img
                          src={URL.createObjectURL(uploadedFile)}
                          alt="Document preview"
                          className="max-w-full max-h-48 object-contain rounded"
                          data-testid="image-preview"
                        />
                      </div>
                    )}
                  </div>
                </div>
              ) : testDocument ? (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Text Preview:</p>
                  <div className="bg-white p-3 rounded border">
                    <pre className="text-xs whitespace-pre-wrap text-muted-foreground">
                      {testDocument.substring(0, 200)}
                      {testDocument.length > 200 && '...'}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <p className="text-sm">Upload a file or enter text to see preview</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Analysis Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium">Analysis</h4>
            <div className="space-x-2">
              <Button
                onClick={runDocumentAnalysis}
                disabled={(!uploadedFile && !testDocument.trim()) || isAnalyzing}
                data-testid="button-run-analysis"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Run Analysis
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                onClick={clearAll}
                data-testid="button-clear-all"
              >
                Clear All
              </Button>
            </div>
          </div>
          
          {testResults && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Analysis Results</Label>
              <div className="bg-gray-50 p-4 rounded-lg border max-h-64 overflow-y-auto">
                <pre className="text-xs whitespace-pre-wrap font-mono" data-testid="analysis-results">
                  {testResults}
                </pre>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}