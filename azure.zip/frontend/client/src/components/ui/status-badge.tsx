import { cn } from "@/lib/utils";
import { CheckCircle, XCircle, Clock, AlertTriangle } from "lucide-react";

interface StatusBadgeProps {
  status: "success" | "error" | "warning" | "pending";
  children: React.ReactNode;
  className?: string;
}

export function StatusBadge({ status, children, className }: StatusBadgeProps) {
  const variants = {
    success: "bg-success/10 text-success border-success/20",
    error: "bg-destructive/10 text-destructive border-destructive/20",
    warning: "bg-warning/10 text-warning border-warning/20",
    pending: "bg-muted/10 text-muted-foreground border-muted/20",
  };

  const icons = {
    success: CheckCircle,
    error: XCircle,
    warning: AlertTriangle,
    pending: Clock,
  };

  const Icon = icons[status];

  return (
    <span
      className={cn(
        "inline-flex items-center border rounded-md px-2 py-1 text-xs font-medium uppercase tracking-wide",
        variants[status],
        className
      )}
      data-testid={`status-badge-${status}`}
    >
      <Icon className="w-3 h-3 mr-1" />
      {children}
    </span>
  );
}
