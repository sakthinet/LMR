import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

type ColorVariant = "purple" | "blue" | "green" | "orange" | "red" | "indigo" | "teal" | "pink";

interface StatCardProps {
  title: string;
  value: string | number;
  description?: string;
  trend?: string;
  icon: LucideIcon;
  className?: string;
  onClick?: () => void;
  colorVariant?: ColorVariant;
}

export function StatCard({
  title,
  value,
  description,
  trend,
  icon: Icon,
  className,
  onClick,
  colorVariant = "purple",
}: StatCardProps) {
  const colorVariants = {
    purple: {
      gradient: "bg-gradient-to-br from-purple-100 to-purple-200",
      iconBg: "bg-purple-500/15",
      iconColor: "text-purple-600",
      textColor: "text-gray-700",
      mutedColor: "text-gray-600",
    },
    blue: {
      gradient: "bg-gradient-to-br from-blue-100 to-blue-200", 
      iconBg: "bg-blue-500/15",
      iconColor: "text-blue-600",
      textColor: "text-gray-700",
      mutedColor: "text-gray-600",
    },
    green: {
      gradient: "bg-gradient-to-br from-green-100 to-green-200",
      iconBg: "bg-green-500/15", 
      iconColor: "text-green-600",
      textColor: "text-gray-700",
      mutedColor: "text-gray-600",
    },
    orange: {
      gradient: "bg-gradient-to-br from-orange-100 to-orange-200",
      iconBg: "bg-orange-500/15",
      iconColor: "text-orange-600", 
      textColor: "text-gray-700",
      mutedColor: "text-gray-600",
    },
    red: {
      gradient: "bg-gradient-to-br from-red-100 to-red-200",
      iconBg: "bg-red-500/15",
      iconColor: "text-red-600",
      textColor: "text-gray-700", 
      mutedColor: "text-gray-600",
    },
    indigo: {
      gradient: "bg-gradient-to-br from-indigo-100 to-indigo-200",
      iconBg: "bg-indigo-500/15",
      iconColor: "text-indigo-600",
      textColor: "text-gray-700",
      mutedColor: "text-gray-600", 
    },
    teal: {
      gradient: "bg-gradient-to-br from-teal-100 to-teal-200",
      iconBg: "bg-teal-500/15",
      iconColor: "text-teal-600",
      textColor: "text-gray-700",
      mutedColor: "text-gray-600",
    },
    pink: {
      gradient: "bg-gradient-to-br from-pink-100 to-pink-200",
      iconBg: "bg-pink-500/15", 
      iconColor: "text-pink-600",
      textColor: "text-gray-700",
      mutedColor: "text-gray-600",
    },
  };

  const colors = colorVariants[colorVariant];

  return (
    <Card
      className={cn(
        "relative overflow-hidden border-0 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 hover:scale-105",
        colors.gradient,
        onClick && "cursor-pointer",
        className
      )}
      data-testid="stat-card"
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className={cn("p-3 rounded-lg", colors.iconBg)}>
            <Icon className={cn("w-6 h-6", colors.iconColor)} />
          </div>
        </div>
        <h3 className={cn("text-sm font-medium mb-1", colors.mutedColor)} data-testid="stat-title">
          {title}
        </h3>
        <p className={cn("text-3xl font-bold", colors.textColor)} data-testid="stat-value">
          {value}
        </p>
        {description && (
          <p className={cn("text-xs mt-1", colors.mutedColor)} data-testid="stat-description">
            {description}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
