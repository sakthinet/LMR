// Feature flag debug utility - now console-only to avoid UI interference
import { featureFlags, getFeatureFlagDebugInfo } from "@/lib/featureFlags";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// Tooltip component for showing feature flag status on hover
export function FeatureFlagTooltip({ children }: { children: React.ReactNode }) {
  // Only show in development
  if (import.meta.env.PROD) {
    return <>{children}</>;
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="inline-flex items-center gap-2">
            {children}
            <Badge 
              variant={featureFlags.isGoogleBasedOnly ? "default" : "secondary"}
              className="text-xs"
            >
              {featureFlags.isGoogleBasedOnly ? "Google Only" : "Full Features"}
            </Badge>
          </div>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="max-w-xs">
          <div className="text-xs space-y-1">
            <div><strong>Mode:</strong> {featureFlags.isGoogleBasedOnly ? "Google-based" : "Full features"}</div>
            <div><strong>Env:</strong> VITE_FEATURE_FLAG_GOOGLE={import.meta.env.VITE_FEATURE_FLAG_GOOGLE}</div>
            <div><strong>Resolved:</strong> isGoogleBasedOnly = {featureFlags.isGoogleBasedOnly.toString()}</div>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

// Console debug function - call this to log debug info
export function logFeatureFlagDebug() {
  if (import.meta.env.DEV) {
    getFeatureFlagDebugInfo();
  }
}