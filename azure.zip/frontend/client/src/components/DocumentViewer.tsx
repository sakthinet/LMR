import React, { useState, useEffect, useCallback } from 'react';
import { FileText, ZoomIn, ZoomOut, RotateCw, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';



interface DocumentViewerProps {
  file: File | null;
  filePreview: string | null;
}

export const DocumentViewer: React.FC<DocumentViewerProps> = ({ file, filePreview }) => {
  const [scale, setScale] = useState<number>(1.2);
  const [rotation, setRotation] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);

  const changeScale = (offset: number) => {
    setScale(prevScale => Math.min(Math.max(prevScale + offset, 0.5), 3.0));
  };

  const rotate = () => {
    setRotation(prevRotation => (prevRotation + 90) % 360);
  };

  const downloadFile = () => {
    if (file) {
      const url = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  // Reset states when file changes
  useEffect(() => {
    setScale(1.2);
    setRotation(0);
    setError(null);
  }, [file]);

  if (!file) {
    return (
      <div className="h-full flex items-center justify-center p-8 text-center">
        <div className="space-y-3">
          <FileText className="w-16 h-16 mx-auto text-muted-foreground" />
          <div>
            <p className="text-lg font-medium text-muted-foreground">No document selected</p>
            <p className="text-sm text-muted-foreground">Upload a document to preview</p>
          </div>
        </div>
      </div>
    );
  }

  // PDF Viewer with zoom controls
  if (file.type === 'application/pdf') {
    return (
      <div className="h-full flex flex-col">
        {/* PDF Controls */}
        <div className="flex items-center justify-between p-3 bg-white border-b">
          <div className="flex items-center space-x-2">
            <FileText className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium truncate max-w-[200px]">{file.name}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => changeScale(-0.2)}
              disabled={scale <= 0.5}
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium px-2 min-w-[50px] text-center">
              {Math.round(scale * 100)}%
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => changeScale(0.2)}
              disabled={scale >= 2.0}
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setScale(1.0);
                setRotation(0);
              }}
              title="Reset View"
            >
              <RotateCw className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={downloadFile}
              title="Download"
            >
              <Download className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* PDF Content */}
        <div className="flex-1 bg-gray-50 overflow-auto">
          {filePreview ? (
            <div 
              className="h-full flex items-center justify-center p-4"
              style={{ minHeight: '400px' }}
            >
              <iframe
                src={`${filePreview}#toolbar=0&navpanes=0&scrollbar=1`}
                className="border-0 shadow-lg rounded bg-white"
                title="PDF Preview"
                style={{
                  width: `${Math.min(scale * 100, 95)}%`,
                  height: `${Math.min(scale * 90, 90)}%`,
                  minWidth: '300px',
                  minHeight: '400px',
                  transform: `rotate(${rotation}deg)`,
                  transition: 'all 0.3s ease-in-out'
                }}
                onError={() => {
                  setError('PDF preview not supported in this browser');
                }}
              />
            </div>
          ) : (
            <div className="h-full flex items-center justify-center p-8">
              <div className="text-center space-y-3">
                <FileText className="w-16 h-16 mx-auto text-primary" />
                <div>
                  <p className="text-lg font-medium text-muted-foreground">PDF Document</p>
                  <p className="text-sm text-muted-foreground">{file.name}</p>
                  <p className="text-xs text-muted-foreground mt-2">
                    Size: {(file.size / 1024).toFixed(1)} KB
                  </p>
                  <p className="text-green-600 font-medium text-sm mt-2">✓ Ready for analysis</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Image Viewer
  if (file.type.startsWith('image/')) {
    return (
      <div className="h-full flex flex-col">
        <div className="flex items-center justify-between p-3 bg-white border-b">
          <div className="flex items-center space-x-2">
            <FileText className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">{file.name}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => changeScale(-0.2)}
              disabled={scale <= 0.5}
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium px-2">
              {Math.round(scale * 100)}%
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => changeScale(0.2)}
              disabled={scale >= 3.0}
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={rotate}
            >
              <RotateCw className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={downloadFile}
            >
              <Download className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-4 flex justify-center bg-gray-50">
            {filePreview && (
              <img
                src={filePreview}
                alt={file.name}
                style={{
                  transform: `scale(${scale}) rotate(${rotation}deg)`,
                  transformOrigin: 'center',
                  transition: 'transform 0.2s ease-in-out'
                }}
                className="max-w-none shadow-lg rounded border bg-white"
              />
            )}
          </div>
        </ScrollArea>
      </div>
    );
  }

  // Unsupported File Type
  return (
    <div className="h-full flex items-center justify-center p-8">
      <div className="text-center space-y-3">
        <FileText className="w-16 h-16 mx-auto text-orange-400" />
        <div>
          <p className="text-lg font-medium text-muted-foreground">Preview not available</p>
          <p className="text-sm text-muted-foreground">{file.name}</p>
          <p className="text-xs text-muted-foreground mt-2">
            File type: {file.type || 'Unknown'}
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={downloadFile}
            className="mt-3"
          >
            <Download className="w-4 h-4 mr-2" />
            Download File
          </Button>
        </div>
      </div>
    </div>
  );
};