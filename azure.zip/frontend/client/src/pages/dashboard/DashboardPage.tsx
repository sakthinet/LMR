import { StatCard } from "@/components/ui/stat-card";
import { StatusBadge } from "@/components/ui/status-badge";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
// No longer using Dialog modals, using collapsible sections below cards
import {
  Waypoints,
  Activity,
  FileText,
  Server,
  Search,
  Database,
  Play,
  Settings,
  Trash2,
  Plus,
  RefreshCw,
} from "lucide-react";
import { Link } from "wouter";
import { useApiCallsCount, useDocumentsVectorizedCount, useActiveApisStatus, useActiveApisData, type ActiveApi } from "@/hooks/useDashboardData";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/components/ui/theme-provider";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";

export default function DashboardPage() {
  const { toast } = useToast();
  const { theme } = useTheme();
  const queryClient = useQueryClient();
  
  // State for which section is currently open
  const [openSection, setOpenSection] = useState<'activeApis' | null>(null);
  
  // API data hooks
  const { data: apiCallsData, isLoading: isLoadingApiCalls, error: apiCallsError } = useApiCallsCount();
  const { data: documentsData, isLoading: isLoadingDocuments, error: documentsError } = useDocumentsVectorizedCount();
  const { data: activeApisData, isLoading: isLoadingActiveApis, error: activeApisError } = useActiveApisStatus();
  const { data: activeApisListData, isLoading: isLoadingActiveApisList, error: activeApisListError } = useActiveApisData();

  // Function to refresh all dashboard data
  const refreshDashboardData = () => {
    queryClient.invalidateQueries({ queryKey: ["dashboard"] });
    toast({
      title: "Dashboard Refreshed",
      description: "All data has been refreshed",
    });
  };

  // Show error toast notifications
  useEffect(() => {
    if (apiCallsError) {
      toast({
        title: "API Error",
        description: "Failed to load API calls count",
        variant: "destructive",
      });
    }
  }, [apiCallsError, toast]);

  useEffect(() => {
    if (documentsError) {
      toast({
        title: "API Error", 
        description: "Failed to load documents vectorized count",
        variant: "destructive",
      });
    }
  }, [documentsError, toast]);

  useEffect(() => {
    if (activeApisError) {
      toast({
        title: "API Error",
        description: "Failed to load active APIs status",
        variant: "destructive",
      });
    }
  }, [activeApisError, toast]);

  useEffect(() => {
    if (activeApisListError) {
      toast({
        title: "API Error",
        description: "Failed to load active APIs data",
        variant: "destructive",
      });
    }
  }, [activeApisListError, toast]);

  // Helper function to format numbers
  const formatNumber = (num: number | string) => {
    const n = typeof num === 'string' ? parseInt(num) : num;
    if (isNaN(n)) return "0";
    return new Intl.NumberFormat().format(n);
  };

  // Prepare stats with real API data
  const getStatValue = (isLoading: boolean, error: any, data: any) => {
    if (isLoading) return "...";
    if (error) return "N/A";
    if (data?.fallback) return "N/A"; // Show N/A for fallback data as requested
    return formatNumber(data?.count || 0);
  };

  // Remove trend data as requested - no longer needed

  const stats = [
    {
      title: "Active APIs",
      value: getStatValue(isLoadingActiveApis, activeApisError, activeApisData),
      description: "APIs Deployed",
      icon: Waypoints,
      onClick: () => setOpenSection(openSection === 'activeApis' ? null : 'activeApis'),
      colorVariant: "purple" as const,
    },
    {
      title: "Total API Calls",
      value: getStatValue(isLoadingApiCalls, apiCallsError, apiCallsData),
      description: "Search requests",
      icon: Activity,
      colorVariant: "blue" as const,
    },
    {
      title: "Documents Vectorized",
      value: getStatValue(isLoadingDocuments, documentsError, documentsData),
      description: "Documents processed",  
      icon: FileText,
      colorVariant: "green" as const,
    },
  ];

  // Get APIs from API data - no fallback, show empty state when no data
  const hasRealApiData = activeApisListData && !activeApisListData.fallback && Array.isArray(activeApisListData.data);
  const apisData = hasRealApiData ? activeApisListData.data : [];
  
  const apis: (ActiveApi & { icon: any })[] = apisData.map(api => ({
    ...api,
    icon: api.url?.includes('financial') ? Search : Database, // Assign icons based on URL
  }));

  // Check if we should show empty state
  const shouldShowEmptyState = !isLoadingActiveApisList && (!activeApisListData || activeApisListData.fallback || !Array.isArray(activeApisListData.data) || activeApisListData.data.length === 0);



  return (
    <div className="p-4 dashboard-page">
      {/* Dashboard Header with Refresh Button */}
      <div className="flex items-center justify-end mb-4">
        <Button
          onClick={refreshDashboardData}
          variant="outline"
          disabled={isLoadingApiCalls || isLoadingDocuments || isLoadingActiveApis || isLoadingActiveApisList}
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${(isLoadingApiCalls || isLoadingDocuments || isLoadingActiveApis || isLoadingActiveApisList) ? 'animate-spin' : ''}`} />
          Refresh Data
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4 dashboard-colorful-stats">
        {stats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>
      
      {/* Show loading indicator if any API data is still loading */}
      {(isLoadingApiCalls || isLoadingDocuments || isLoadingActiveApis || isLoadingActiveApisList) && (
        <div className="flex items-center justify-center p-4 mb-4">
          <LoadingSpinner />
          <span className="ml-2 text-sm text-muted-foreground">Loading dashboard data...</span>
        </div>
      )}

      {/* Collapsible Sections Below Cards */}
      
      {/* Active APIs Section */}
      {openSection === 'activeApis' && (
        <Card className="mb-4">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Server className="w-5 h-5 mr-2 text-primary" />
              Active APIs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-end mb-4">
              <Link href="/create-api">
                <Button data-testid="create-api-button">
                  <Plus className="w-4 h-4 mr-2" />
                  Create API
                </Button>
              </Link>
            </div>
            {shouldShowEmptyState ? (
              <div className="text-center py-8">
                <Server className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">No Active APIs Available</h3>
                <p className="text-muted-foreground mb-4">
                  API data is not available or the service is currently unavailable.
                </p>
                <Link href="/create-api">
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First API
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {apis.map((api) => (
                  <div
                    key={api.id}
                    className="flex items-center justify-between p-4 bg-muted/30 rounded-lg border border-border"
                    data-testid={`api-item-${api.id}`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <api.icon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">{api.name}</h4>
                        <p className="text-sm text-muted-foreground">{api.url}</p>
                        <div className="flex items-center mt-1">
                          <StatusBadge status="success">Active</StatusBadge>
                          <span className="text-xs text-muted-foreground ml-2">
                            Last used {api.lastUsed}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Link href="/test-api">
                        <Button variant="outline" size="sm" data-testid={`test-api-${api.id}`}>
                          <Play className="w-4 h-4 mr-1" />
                          Test
                        </Button>
                      </Link>
                      <Button variant="outline" size="sm" data-testid={`configure-api-${api.id}`}>
                        <Settings className="w-4 h-4 mr-1" />
                        Configure
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        data-testid={`delete-api-${api.id}`}
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}



    </div>
  );
}
