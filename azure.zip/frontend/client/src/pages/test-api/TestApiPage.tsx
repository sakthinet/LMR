import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Send,
  Terminal,
  Code,
  Download,
  Copy,
  Play,
  CheckCircle,
  Clock,
  AlertCircle,
} from "lucide-react";

interface SearchResult {
  id: string;
  text: string;
  source: string;
  relevance: number;
  metadata?: Record<string, any>;
}

export default function TestApiPage() {
  const [selectedApi, setSelectedApi] = useState("");
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [responseTime, setResponseTime] = useState<number | null>(null);
  const [statusCode, setStatusCode] = useState<number | null>(null);
  const [rawResponse, setRawResponse] = useState<any>(null);
  const [headers, setHeaders] = useState<Record<string, string>>({});

  // Mock available APIs
  const availableApis = [
    {
      id: "financial-search",
      name: "Financial Search API",
      endpoint: "/api/financial/search",
      description: "Search through financial documents and reports",
    },
    {
      id: "document-search",
      name: "Document Search API",
      endpoint: "/api/documents/search",
      description: "General document search across all collections",
    },
    {
      id: "legal-search",
      name: "Legal Document Search",
      endpoint: "/api/legal/search",
      description: "Search through legal documents and contracts",
    },
  ];

  const handleSendRequest = async () => {
    if (!selectedApi || !query) return;

    setIsLoading(true);
    const startTime = Date.now();

    // Simulate API call
    setTimeout(() => {
      const endTime = Date.now();
      const responseTime = endTime - startTime;

      // Mock response data
      const mockResults: SearchResult[] = [
        {
          id: "1",
          text: "The quarterly financial report shows a 15% increase in revenue compared to the previous quarter, with strong performance in the technology and healthcare sectors. Operating margins improved to 18.5%, driven by cost optimization initiatives and strategic investments in automation.",
          source: "financial_report_2024_q3.pdf",
          relevance: 0.87,
          metadata: {
            page: 12,
            section: "Executive Summary",
            date: "2024-09-30",
          },
        },
        {
          id: "2",
          text: "Budget allocation for Q4 shows optimized spending across departments, with significant cost reductions in operational expenses while maintaining growth investments. The finance department has implemented new controls that reduced administrative costs by 12%.",
          source: "budget_analysis_q4_2024.pdf",
          relevance: 0.82,
          metadata: {
            page: 8,
            section: "Budget Overview",
            date: "2024-10-15",
          },
        },
        {
          id: "3",
          text: "Market research indicates strong consumer demand in emerging markets, with potential for expansion in Southeast Asia and Latin America regions. Our competitive analysis shows we maintain a 23% market share in the primary demographic.",
          source: "market_research_2024.pdf",
          relevance: 0.76,
          metadata: {
            page: 45,
            section: "Market Analysis",
            date: "2024-08-20",
          },
        },
      ];

      setResults(mockResults);
      setResponseTime(responseTime);
      setStatusCode(200);
      setRawResponse({
        success: true,
        query: query,
        results: mockResults,
        total: mockResults.length,
        execution_time: responseTime / 1000,
      });
      setHeaders({
        "Content-Type": "application/json",
        "X-API-Version": "1.0",
        "X-Request-ID": `req_${Math.random().toString(36).substring(7)}`,
        "X-Rate-Limit-Remaining": "99",
      });
      setIsLoading(false);
    }, 1500);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const downloadResults = () => {
    const dataStr = JSON.stringify(rawResponse, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'search_results.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const selectedApiDetails = availableApis.find(api => api.id === selectedApi);

  return (
    <div className="p-4 space-y-4 md:space-y-5">
      {/* Page Content */}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-5">
        {/* Request Section */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Send className="w-5 h-5 mr-2 text-primary" />
                API Request
              </CardTitle>
              <CardDescription>
                Configure and send your search request
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="api-select">Select API Endpoint</Label>
                <Select
                  value={selectedApi}
                  onValueChange={setSelectedApi}
                >
                  <SelectTrigger data-testid="select-api-endpoint">
                    <SelectValue placeholder="Choose an endpoint" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableApis.map((api) => (
                      <SelectItem key={api.id} value={api.id}>
                        <div className="flex flex-col">
                          <span className="font-medium">{api.name}</span>
                          <span className="text-xs text-muted-foreground">{api.endpoint}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedApiDetails && (
                  <p className="text-xs text-muted-foreground">
                    {selectedApiDetails.description}
                  </p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="search-query">Search Query</Label>
                <Textarea
                  id="search-query"
                  placeholder="Enter your search query here..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="min-h-[100px] resize-none"
                  data-testid="input-search-query"
                />
              </div>
              
              <Button
                onClick={handleSendRequest}
                disabled={!selectedApi || !query || isLoading}
                className="w-full"
                data-testid="button-send-request"
              >
                {isLoading ? (
                  <>
                    <LoadingSpinner size="sm" className="mr-2" />
                    Sending Request...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Send Request
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Code className="w-5 h-5 mr-2 text-primary" />
                Request Details
              </CardTitle>
              <CardDescription>
                HTTP request information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Method:</span>
                <Badge variant="outline" className="font-mono">POST</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Content-Type:</span>
                <Badge variant="outline" className="font-mono">application/json</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Endpoint:</span>
                <Badge variant="outline" className="font-mono">
                  {selectedApiDetails?.endpoint || "Select an API"}
                </Badge>
              </div>
              {query && (
                <div className="pt-2 border-t">
                  <span className="text-muted-foreground text-xs">Request Body:</span>
                  <pre className="mt-1 p-2 bg-muted rounded text-xs font-mono overflow-x-auto">
{JSON.stringify({ query, limit: 10, include_metadata: true }, null, 2)}
                  </pre>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Response Section */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    <Terminal className="w-5 h-5 mr-2 text-primary" />
                    Response
                  </CardTitle>
                  <CardDescription>
                    API response and search results
                  </CardDescription>
                </div>
                {statusCode && responseTime && (
                  <div className="flex items-center space-x-3">
                    <Badge 
                      variant={statusCode === 200 ? "default" : "destructive"}
                      className="bg-success/10 text-success border-success/20"
                    >
                      <CheckCircle className="w-3 h-3 mr-1" />
                      {statusCode} OK
                    </Badge>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="w-3 h-3 mr-1" />
                      {responseTime}ms
                    </div>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {!results.length && !isLoading && (
                <div className="text-center py-8 text-muted-foreground">
                  <Terminal className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Send a request to see the response</p>
                </div>
              )}

              {isLoading && (
                <div className="text-center py-8">
                  <LoadingSpinner className="mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Processing your request...</p>
                </div>
              )}

              {results.length > 0 && (
                <Tabs defaultValue="results" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="results" data-testid="tab-results">Results</TabsTrigger>
                    <TabsTrigger value="json" data-testid="tab-json">Raw JSON</TabsTrigger>
                    <TabsTrigger value="headers" data-testid="tab-headers">Headers</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="results" className="space-y-4 mt-4">
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {results.map((result) => (
                        <div
                          key={result.id}
                          className="p-4 bg-muted/30 rounded-lg border border-border"
                          data-testid={`search-result-${result.id}`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <Badge variant="outline" className="text-xs">
                              Relevance: {result.relevance.toFixed(2)}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {result.source}
                            </span>
                          </div>
                          <p className="text-sm text-foreground leading-relaxed">
                            {result.text}
                          </p>
                          {result.metadata && (
                            <div className="mt-2 pt-2 border-t border-border/50">
                              <div className="grid grid-cols-2 gap-2 text-xs">
                                {Object.entries(result.metadata).map(([key, value]) => (
                                  <div key={key} className="flex justify-between">
                                    <span className="text-muted-foreground capitalize">
                                      {key}:
                                    </span>
                                    <span className="font-mono">{String(value)}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="json" className="mt-4">
                    <div className="relative">
                      <Button
                        variant="outline"
                        size="sm"
                        className="absolute right-2 top-2 z-10"
                        onClick={() => copyToClipboard(JSON.stringify(rawResponse, null, 2))}
                        data-testid="button-copy-json"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                      <pre className="p-4 bg-muted rounded-lg text-xs font-mono overflow-auto max-h-96 pr-16">
                        {JSON.stringify(rawResponse, null, 2)}
                      </pre>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="headers" className="mt-4">
                    <div className="space-y-2">
                      {Object.entries(headers).map(([key, value]) => (
                        <div key={key} className="flex justify-between text-sm">
                          <span className="text-muted-foreground font-medium">{key}:</span>
                          <span className="font-mono">{value}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              )}

              {results.length > 0 && (
                <div className="mt-4 pt-4 border-t border-border">
                  <Button
                    variant="outline"
                    onClick={downloadResults}
                    className="w-full"
                    data-testid="button-download-results"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Results
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
