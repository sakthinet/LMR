import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Cpu, Cloud, Save, TestTube } from "lucide-react";
import { Link } from "wouter";

export default function NewParserPage() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    parserType: "",
    category: "local",
    configuration: {
      language: "en",
      confidence: [85],
      enableImageProcessing: true,
      outputFormat: "text",
      customEndpoint: "",
      apiKey: "",
      region: "",
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement parser creation
    setLocation("/parsers");
  };

  const parserTypes = {
    local: [
      {
        id: "tesseract",
        name: "Tesseract OCR",
        description: "Open-source optical character recognition engine",
        icon: Cpu,
      },
      {
        id: "unstructured",
        name: "Unstructured.io SDK",
        description: "Advanced document parsing and extraction",
        icon: Cpu,
      },
    ],
    cloud: [
      {
        id: "azure-ai",
        name: "Azure Document AI",
        description: "Microsoft's cloud document intelligence service",
        icon: Cloud,
      },
      {
        id: "google-ai",
        name: "Google Document AI",
        description: "Google's document processing service",
        icon: Cloud,
      },
    ],
  };

  const currentParsers = parserTypes[formData.category as keyof typeof parserTypes];

  return (
    <div className="p-6 space-y-8">
      {/* Back Navigation */}
      <div className="flex items-center space-x-4 mb-6">
        <Link href="/parsers">
          <Button variant="outline" size="sm" data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
                <CardDescription>
                  Provide a name and description for this parser
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Parser Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Financial Document Parser"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    required
                    data-testid="input-parser-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Optional description for this parser"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    data-testid="input-parser-description"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Parser Type Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Parser Type</CardTitle>
                <CardDescription>
                  Choose between local or cloud-based parsing engines
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <RadioGroup
                  value={formData.category}
                  onValueChange={(value) =>
                    setFormData({ ...formData, category: value, parserType: "" })
                  }
                  className="grid grid-cols-2 gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="local" id="local" />
                    <Label htmlFor="local" className="flex items-center cursor-pointer">
                      <Cpu className="w-4 h-4 mr-2" />
                      Local Parsers
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cloud" id="cloud" />
                    <Label htmlFor="cloud" className="flex items-center cursor-pointer">
                      <Cloud className="w-4 h-4 mr-2" />
                      Cloud Parsers
                    </Label>
                  </div>
                </RadioGroup>

                <div className="space-y-4">
                  <Label>Select Parser Engine</Label>
                  <RadioGroup
                    value={formData.parserType}
                    onValueChange={(value) =>
                      setFormData({ ...formData, parserType: value })
                    }
                    className="space-y-4"
                  >
                    {currentParsers.map((parser) => (
                      <div
                        key={parser.id}
                        className="flex items-center space-x-3 p-4 border rounded-lg hover:bg-accent/50 transition-colors"
                      >
                        <RadioGroupItem value={parser.id} id={parser.id} />
                        <div className="flex items-center space-x-3 flex-1">
                          <parser.icon className="w-5 h-5 text-primary" />
                          <div>
                            <Label htmlFor={parser.id} className="cursor-pointer font-medium">
                              {parser.name}
                            </Label>
                            <p className="text-sm text-muted-foreground">
                              {parser.description}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>

            {/* Configuration Options */}
            {formData.parserType && (
              <Card>
                <CardHeader>
                  <CardTitle>Configuration</CardTitle>
                  <CardDescription>
                    Configure parser-specific settings
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Common Settings */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="language">Language</Label>
                      <Select
                        value={formData.configuration.language}
                        onValueChange={(value) =>
                          setFormData({
                            ...formData,
                            configuration: { ...formData.configuration, language: value },
                          })
                        }
                      >
                        <SelectTrigger data-testid="select-language">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="es">Spanish</SelectItem>
                          <SelectItem value="fr">French</SelectItem>
                          <SelectItem value="de">German</SelectItem>
                          <SelectItem value="zh">Chinese</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="outputFormat">Output Format</Label>
                      <Select
                        value={formData.configuration.outputFormat}
                        onValueChange={(value) =>
                          setFormData({
                            ...formData,
                            configuration: { ...formData.configuration, outputFormat: value },
                          })
                        }
                      >
                        <SelectTrigger data-testid="select-output-format">
                          <SelectValue placeholder="Select output format" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="text">Plain Text</SelectItem>
                          <SelectItem value="markdown">Markdown</SelectItem>
                          <SelectItem value="json">JSON</SelectItem>
                          <SelectItem value="html">HTML</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Confidence Threshold */}
                  <div className="space-y-3">
                    <Label>Confidence Threshold: {formData.configuration.confidence[0]}%</Label>
                    <Slider
                      value={formData.configuration.confidence}
                      onValueChange={(value) =>
                        setFormData({
                          ...formData,
                          configuration: { ...formData.configuration, confidence: value },
                        })
                      }
                      max={100}
                      min={50}
                      step={5}
                      className="w-full"
                    />
                    <p className="text-xs text-muted-foreground">
                      Minimum confidence level for accepting parsed text
                    </p>
                  </div>

                  {/* Image Processing */}
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Enable Image Processing</Label>
                      <p className="text-sm text-muted-foreground">
                        Process images and diagrams within documents
                      </p>
                    </div>
                    <Switch
                      checked={formData.configuration.enableImageProcessing}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          configuration: { ...formData.configuration, enableImageProcessing: checked },
                        })
                      }
                      data-testid="switch-image-processing"
                    />
                  </div>

                  {/* Cloud-specific settings */}
                  {formData.category === "cloud" && (
                    <div className="space-y-4 pt-4 border-t">
                      <h4 className="font-medium text-foreground">Cloud Configuration</h4>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="apiKey">API Key *</Label>
                          <Input
                            id="apiKey"
                            type="password"
                            placeholder="Enter your API key"
                            value={formData.configuration.apiKey}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                configuration: { ...formData.configuration, apiKey: e.target.value },
                              })
                            }
                            data-testid="input-api-key"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="region">Region</Label>
                          <Input
                            id="region"
                            placeholder="e.g., us-east-1"
                            value={formData.configuration.region}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                configuration: { ...formData.configuration, region: e.target.value },
                              })
                            }
                            data-testid="input-region"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="customEndpoint">Custom Endpoint (Optional)</Label>
                          <Input
                            id="customEndpoint"
                            placeholder="https://your-custom-endpoint.com"
                            value={formData.configuration.customEndpoint}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                configuration: { ...formData.configuration, customEndpoint: e.target.value },
                              })
                            }
                            data-testid="input-custom-endpoint"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Configuration Summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configuration Summary</CardTitle>
                <CardDescription>
                  Review your parser settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name:</span>
                  <span className="text-foreground font-medium">
                    {formData.name || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Type:</span>
                  <span className="text-foreground font-medium capitalize">
                    {formData.category || "Not selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Engine:</span>
                  <span className="text-foreground font-medium">
                    {formData.parserType ? 
                      currentParsers.find(p => p.id === formData.parserType)?.name || "Unknown"
                      : "Not selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Language:</span>
                  <span className="text-foreground font-medium uppercase">
                    {formData.configuration.language}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Confidence:</span>
                  <span className="text-foreground font-medium">
                    {formData.configuration.confidence[0]}%
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  disabled={!formData.parserType}
                  data-testid="button-test-parser"
                >
                  <TestTube className="w-4 h-4 mr-2" />
                  Test Parser
                </Button>
                <Button
                  type="submit"
                  className="w-full"
                  disabled={!formData.name || !formData.parserType}
                  data-testid="button-create-parser"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Create Parser
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  );
}
