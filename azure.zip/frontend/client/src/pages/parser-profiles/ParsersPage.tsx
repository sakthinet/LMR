import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/ui/status-badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { featureFlags, isParserVisible } from "@/lib/featureFlags";
import { FeatureFlagTooltip, logFeatureFlagDebug } from "@/components/FeatureFlagDebug";
import type { ParserProfile, InsertParserProfile } from "@shared/schema";
import {
  Plus,
  Search,
  FileText,
  Cpu,
  Cloud,
  Trash2,
  TestTube,
  Upload,
  X,
  ArrowLeft,
  Play,
  Loader2,
  FolderOpen,
  Save,
  ChevronDown,
  ChevronRight,
  Grid3X3,
  List,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { DocumentViewer } from "@/components/DocumentViewer";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface ConfigField {
  name: string;
  label: string;
  type: 'text' | 'password' | 'number' | 'textarea' | 'select' | 'switch' | 'slider';
  required?: boolean;
  options?: string[];
  min?: number;
  max?: number;
  step?: number;
  default?: any;
}

interface ParserType {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: any;
  accuracy: string;
  type: string;
  configFields: ConfigField[];
}

export default function ParsersPage() {
  const [, setLocation] = useLocation();
  const [currentView, setCurrentView] = useState<'landing' | 'new'>('landing');
  const [viewMode, setViewMode] = useState<'cards' | 'list'>('cards');
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedParsers, setSelectedParsers] = useState<string[]>([]);
  const [selectedParserType, setSelectedParserType] = useState<string>("");
  const [selectedParserForAnalysis, setSelectedParserForAnalysis] = useState<string>("");
  const [testDocument, setTestDocument] = useState("");
  const [testResults, setTestResults] = useState("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isDeleting, setIsDeleting] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  
  // Parser configuration form state
  const [parserFormData, setParserFormData] = useState<InsertParserProfile>({
    name: "",
    description: "",
    type: "",
    config: {},
    status: "inactive",
    version: "1.0.0",
    supportedFormats: ["pdf", "docx", "txt", "html", "json"],
    performanceMetrics: null,
    testResults: null,
    createdBy: null,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Log feature flag debug info
  useEffect(() => {
    logFeatureFlagDebug();
  }, []);

  // Fetch saved parser profiles
  const { data: savedParsers = [], isLoading, error } = useQuery<ParserProfile[]>({
    queryKey: ["/api/parser-profiles"],
  });

  // Debug logging for loaded parser profiles
  useEffect(() => {
    if (savedParsers && savedParsers.length > 0) {
      console.log('Loaded parser profiles:', savedParsers);
      savedParsers.forEach(parser => {
        console.log(`Parser: ${parser.name}, ID: ${parser.id}, Type: ${typeof parser.id}`);
      });
    }
    if (error) {
      console.error('Failed to load parser profiles:', error);
    }
  }, [savedParsers, error]);

  // Parser types configuration
  const allParserTypes: ParserType[] = [
    {
      id: "azure-document-ai",
      name: "Azure Document AI",
      description: "Advanced cloud-based document intelligence",
      category: "Cloud Parser",
      icon: Cloud,
      accuracy: "99%+",
      type: "azure-ai",
      configFields: [
        { name: "apiKey", label: "API Key", type: "password", required: true },
        { name: "endpoint", label: "Endpoint URL", type: "text", required: true },
        { name: "region", label: "Region", type: "select", options: ["eastus", "westus2", "centralus"], required: true },
        { name: "modelId", label: "Model ID", type: "text", required: false },
        { name: "confidenceThreshold", label: "Confidence Threshold", type: "slider", min: 0, max: 1, step: 0.1, default: 0.8 },
      ]
    },
    {
      id: "google-document-ai",
      name: "Google Document AI",
      description: "Google's document processing service",
      category: "Cloud Parser",
      icon: Cloud,
      accuracy: "98%+",
      type: "google-ai",
      configFields: [
        { name: "projectId", label: "Project ID", type: "text", required: true },
        { name: "location", label: "Location", type: "select", options: ["us", "eu"], required: true },
        { name: "processorId", label: "Processor ID", type: "text", required: true },
        { name: "credentials", label: "Service Account Key", type: "textarea", required: true },
      ]
    },
    {
      id: "tesseract",
      name: "Tesseract OCR",
      description: "Open-source optical character recognition",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "95%+",
      type: "tesseract",
      configFields: [
        { name: "language", label: "OCR Language", type: "select", options: ["eng", "spa", "fra", "deu", "ita"], required: true, default: "eng" },
      ]
    },
    {
      id: "paddle-ocr",
      name: "PaddleOCR",
      description: "High-performance multilingual OCR toolkit",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "96%+",
      type: "paddle",
      configFields: [
        { name: "detModel", label: "Detection Model", type: "select", options: ["ch_PP-OCRv3_det", "ch_PP-OCRv2_det", "en_PP-OCRv3_det"], required: true, default: "ch_PP-OCRv3_det" },
        { name: "recModel", label: "Recognition Model", type: "select", options: ["ch_PP-OCRv3_rec", "ch_PP-OCRv2_rec", "en_PP-OCRv3_rec"], required: true, default: "ch_PP-OCRv3_rec" },
        { name: "clsModel", label: "Classification Model", type: "select", options: ["ch_ppocr_mobile_v2.0_cls", "ch_ppocr_mobile_v2.0_cls_slim"], required: false },
        { name: "useAngleCls", label: "Use Angle Classification", type: "switch", default: true },
        { name: "useMp", label: "Use Multiprocessing", type: "switch", default: false },
        { name: "totalProcessNum", label: "Process Number", type: "number", min: 1, max: 8, default: 1 },
      ]
    },
    {
      id: "unstructured-io",
      name: "Unstructured.io SDK",
      description: "Extract and transform messy text documents",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "97%+",
      type: "unstructured",
      configFields: [
        { name: "apiKey", label: "API Key", type: "password", required: false },
        { name: "serverUrl", label: "Server URL", type: "text", required: false },
        { name: "strategy", label: "Processing Strategy", type: "select", options: ["auto", "fast", "ocr_only", "hi_res"], required: true, default: "auto" },
        { name: "chunkingStrategy", label: "Chunking Strategy", type: "select", options: ["by_title", "by_page", "basic"], required: false },
        { name: "maxCharacters", label: "Max Characters per Chunk", type: "number", min: 100, max: 10000, default: 1500 },
      ]
    }
  ];

  // Filter parser types based on feature flags
  const parserTypes = allParserTypes.filter(parser => isParserVisible(parser.id));

  // Filter parsers based on search term
  const filteredParsers = savedParsers.filter(parser =>
    parser.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    parser.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (parser.description && parser.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Handle new parser button click
  const handleNewParser = () => {
    setCurrentView('new');
    setSelectedParserType("");
    setParserFormData({
      name: "",
      description: "",
      type: "",
      config: {},
      status: "inactive",
      version: "1.0.0",
      supportedFormats: ["pdf", "docx", "txt", "html", "json"],
      performanceMetrics: null,
      testResults: null,
      createdBy: null,
    });
    setTestDocument("");
    setTestResults("");
    setUploadedFile(null);
    setFilePreview(null);
  };

  // Handle open parser (for editing)
  const handleOpenParser = (parser: ParserProfile) => {
    setSelectedParserType(parser.type);
    setParserFormData({
      name: parser.name,
      description: parser.description || "",
      type: parser.type,
      config: parser.config || {},
      status: parser.status,
      version: parser.version,
      supportedFormats: parser.supportedFormats,
      performanceMetrics: parser.performanceMetrics || null,
      testResults: parser.testResults || null,
      createdBy: parser.createdBy,
    });
    setCurrentView('new');
  };

  // Handle individual parser delete
  const handleDeleteParser = async (parserId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    
    // Validate parser ID
    if (!parserId || parserId.trim() === "") {
      toast({
        title: "Error",
        description: "Invalid parser ID. Cannot delete.",
        variant: "destructive",
      });
      return;
    }
    
    // Confirm deletion
    if (!window.confirm("Are you sure you want to delete this parser? This action cannot be undone.")) {
      return;
    }
    
    try {
      setIsDeleting(parserId);
      console.log('Deleting parser with ID:', parserId);
      console.log('Delete URL:', `/api/parser-profiles/${parserId}`);
      
      const response = await apiRequest("DELETE", `/api/parser-profiles/${parserId}`);
      console.log('Delete response status:', response.status);
      console.log('Delete response:', response);
      
      // Check if the response is successful
      if (response.ok) {
        queryClient.invalidateQueries({ queryKey: ["/api/parser-profiles"] });
        
        toast({
          title: "Parser deleted",
          description: "Parser has been successfully deleted.",
        });
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error: any) {
      console.error('Delete error:', error);
      
      // Extract more detailed error message
      let errorMessage = "Failed to delete parser. Please try again.";
      if (error.message) {
        // Check for specific error types
        if (error.message.includes('404')) {
          errorMessage = "Parser not found. It may have already been deleted.";
        } else if (error.message.includes('500')) {
          errorMessage = "Server error occurred while deleting parser.";
        } else {
          errorMessage = `Delete failed: ${error.message}`;
        }
      }
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsDeleting(null);
    }
  };

  // Handle bulk delete
  const handleBulkDelete = async () => {
    if (selectedParsers.length === 0) return;
    
    try {
      for (const parserId of selectedParsers) {
        setIsDeleting(parserId);
        await apiRequest("DELETE", `/api/parser-profiles/${parserId}`);
      }
      
      queryClient.invalidateQueries({ queryKey: ["/api/parser-profiles"] });
      setSelectedParsers([]);
      
      toast({
        title: "Parsers deleted",
        description: `Successfully deleted ${selectedParsers.length} parser(s).`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to delete some parsers. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(null);
    }
  };

  // Handle parser type selection
  const handleParserTypeSelect = (typeId: string) => {
    const parserType = parserTypes.find(p => p.id === typeId);
    if (parserType) {
      setSelectedParserType(typeId);
      setParserFormData(prev => ({
        ...prev,
        type: parserType.type,
        name: prev.name || `${parserType.name} Configuration`,
        description: prev.description || `Configuration for ${parserType.name} parser`,
        config: parserType.configFields.reduce((acc, field) => {
          if (field.default !== undefined) {
            acc[field.name] = field.default;
          }
          return acc;
        }, {} as any)
      }));
    }
  };

  // Handle configuration field changes
  const handleConfigChange = (fieldName: string, value: any) => {
    setParserFormData(prev => ({
      ...prev,
      config: {
        ...(prev.config as any || {}),
        [fieldName]: value
      }
    }));
  };

  // Handle parser save
  const handleSaveParser = async () => {
    try {
      setIsSaving(true);
      
      // Validate required fields
      if (!parserFormData.name) {
        toast({
          title: "Validation Error",
          description: "Parser name is required",
          variant: "destructive",
        });
        return;
      }
      
      if (!parserFormData.type && !selectedParserType) {
        toast({
          title: "Validation Error", 
          description: "Please select a parser type",
          variant: "destructive",
        });
        return;
      }
      
      // Get the correct parser type from the selected parser
      const selectedParser = parserTypes.find(p => p.id === selectedParserType);
      const correctType = selectedParser?.type || parserFormData.type;
      
      // Prepare the data to match API schema (only name, type, config)
      const saveData = {
        name: parserFormData.name,
        type: correctType,
        config: parserFormData.config || {}
      };
      
      const response = await apiRequest("POST", "/api/parser-profiles", saveData);
      
      toast({
        title: "Success", 
        description: "Parser configuration saved for current session!",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save parser profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Handle file input change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      setTestDocument(""); // Clear text input when file is uploaded
      
      // Create preview for images and PDFs
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setFilePreview(e.target?.result as string);
        };
        reader.readAsDataURL(file);
      } else if (file.type === 'application/pdf') {
        // Create object URL for PDF
        const url = URL.createObjectURL(file);
        setFilePreview(url);
      } else {
        setFilePreview(null);
      }
    }
  };

  const removeFile = () => {
    // Clean up object URL if it exists
    if (filePreview && filePreview.startsWith('blob:')) {
      URL.revokeObjectURL(filePreview);
    }
    setUploadedFile(null);
    setFilePreview(null);
  };

  const runDocumentAnalysis = async () => {
    if (!uploadedFile && !testDocument.trim()) {
      toast({
        title: "No document provided",
        description: "Please upload a document or provide sample text to analyze.",
        variant: "destructive",
      });
      return;
    }

    if (!selectedParserForAnalysis) {
      toast({
        title: "No parser selected",
        description: "Please select a parser from the dropdown before running analysis.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    setTestResults("Analyzing document...");
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const selectedParser = savedParsers.find(p => p.id === selectedParserForAnalysis);
      const mockResults = {
        parser: selectedParser?.name || "Unknown Parser",
        type: selectedParser?.type || "unknown",
        filename: uploadedFile?.name || "text-input",
        fileSize: uploadedFile?.size || testDocument.length,
        extractedText: uploadedFile ? "Sample OCR extracted text from uploaded document..." : testDocument,
        confidence: 0.95,
        entities: [
          { type: "PERSON", text: "John Doe", confidence: 0.98 },
          { type: "DATE", text: "2023-01-15", confidence: 0.92 },
          { type: "AMOUNT", text: "$1,250.00", confidence: 0.89 }
        ],
        tables: [
          { rows: 3, columns: 4, confidence: 0.87 }
        ],
        metadata: {
          processingTime: "2.1s",
          timestamp: new Date().toISOString(),
          apiProvider: selectedParser?.type === "tesseract" ? "Tesseract OCR" : "Parser Service"
        }
      };

      setTestResults(JSON.stringify(mockResults, null, 2));
      
      toast({
        title: "Document analyzed",
        description: "Analysis results are ready for review.",
      });
    } catch (error) {
      toast({
        title: "Analysis failed",
        description: "Failed to analyze document. Please try again.",
        variant: "destructive",
      });
      setTestResults("Analysis failed. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Render configuration form for selected parser type
  const renderConfigurationForm = () => {
    if (!selectedParserType) return null;
    
    const parserType = parserTypes.find(p => p.id === selectedParserType);
    if (!parserType) return null;

    return (
      <div className="space-y-4">
        {/* Basic Information */}
        <div className="space-y-3">
          <div className="space-y-2">
            <Label htmlFor="parser-name">Parser Name *</Label>
            <Input
              id="parser-name"
              placeholder="Enter parser name"
              value={parserFormData.name}
              onChange={(e) => setParserFormData(prev => ({ ...prev, name: e.target.value }))}
            />
          </div>
        </div>

        {/* Configuration Fields */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium text-muted-foreground border-b pb-2">Configuration</h4>
          {parserType.configFields.map((field) => (
            <div key={field.name} className="space-y-2">
              <Label htmlFor={field.name}>
                {field.label} {field.required && '*'}
              </Label>
              
              {(field.type === 'text' || field.type === 'password') && (
                <Input
                  id={field.name}
                  type={field.type}
                  placeholder={`Enter ${field.label.toLowerCase()}`}
                  value={(parserFormData.config as any)?.[field.name] || ''}
                  onChange={(e) => handleConfigChange(field.name, e.target.value)}
                />
              )}
              
              {field.type === 'number' && (
                <Input
                  id={field.name}
                  type="number"
                  min={field.min}
                  max={field.max}
                  step={field.step}
                  placeholder={`Enter ${field.label.toLowerCase()}`}
                  value={(parserFormData.config as any)?.[field.name] || ''}
                  onChange={(e) => handleConfigChange(field.name, parseFloat(e.target.value) || '')}
                />
              )}
              
              {field.type === 'textarea' && (
                <Textarea
                  id={field.name}
                  placeholder={`Enter ${field.label.toLowerCase()}`}
                  value={(parserFormData.config as any)?.[field.name] || ''}
                  rows={3}
                  onChange={(e) => handleConfigChange(field.name, e.target.value)}
                />
              )}
              
              {field.type === 'select' && field.options && (
                <Select
                  value={(parserFormData.config as any)?.[field.name] || ''}
                  onValueChange={(value) => handleConfigChange(field.name, value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={`Select ${field.label.toLowerCase()}`} />
                  </SelectTrigger>
                  <SelectContent>
                    {field.options.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              
              {field.type === 'switch' && (
                <div className="flex items-center space-x-2">
                  <Switch
                    id={field.name}
                    checked={(parserFormData.config as any)?.[field.name] ?? field.default ?? false}
                    onCheckedChange={(checked) => handleConfigChange(field.name, checked)}
                  />
                  <Label htmlFor={field.name} className="text-sm">
                    {field.label}
                  </Label>
                </div>
              )}
              
              {field.type === 'slider' && field.step !== undefined && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">{field.min}</span>
                    <span className="text-sm font-medium">
                      {(parserFormData.config as any)?.[field.name] ?? field.default}
                    </span>
                    <span className="text-sm text-muted-foreground">{field.max}</span>
                  </div>
                  <Slider
                    id={field.name}
                    min={field.min}
                    max={field.max}
                    step={field.step}
                    value={[(parserFormData.config as any)?.[field.name] ?? field.default ?? 0]}
                    onValueChange={(value) => handleConfigChange(field.name, value[0])}
                    className="w-full"
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Show New Parser Creation Page (3-panel layout)
  if (currentView === 'new') {
    return (
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            onClick={() => setCurrentView('landing')}
            data-testid="button-back-to-parsers"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Parsers
          </Button>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Create New Parser</h1>
            <p className="text-sm text-muted-foreground">
              Configure your document parser settings and test its functionality
            </p>
          </div>
        </div>

        {/* 3-Panel Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Panel 1: Select Parser Type + Configuration */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Plus className="w-5 h-5 mr-2 text-primary" />
                Select Parser Type
              </CardTitle>
              <CardDescription>
                Choose the type of parser you want to configure
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Parser Type Selection */}
              {!selectedParserType ? (
                <div className="space-y-2">
                  {parserTypes.map((type) => (
                    <Button
                      key={type.id}
                      variant="outline"
                      className="w-full justify-start h-auto p-4"
                      onClick={() => handleParserTypeSelect(type.id)}
                    >
                      <div className="flex items-center space-x-3 w-full">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <type.icon className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1 text-left">
                          <p className="font-medium">{type.name}</p>
                          <p className="text-sm text-muted-foreground">{type.category} • {type.accuracy}</p>
                        </div>
                      </div>
                    </Button>
                  ))}
                </div>
              ) : (
                <>
                  {/* Selected Parser Type Header */}
                  <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg border">
                    <div className="flex items-center space-x-3">
                      {(() => {
                        const selectedType = parserTypes.find(p => p.id === selectedParserType);
                        return selectedType ? (
                          <>
                            <selectedType.icon className="w-5 h-5 text-primary" />
                            <div>
                              <p className="font-medium text-sm">{selectedType.name}</p>
                              <p className="text-xs text-muted-foreground">{selectedType.category}</p>
                            </div>
                          </>
                        ) : null;
                      })()}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedParserType("");
                        setParserFormData(prev => ({ ...prev, name: "", description: "", type: "", config: {} }));
                      }}
                    >
                      Change
                    </Button>
                  </div>

                  {/* Configuration Form */}
                  {renderConfigurationForm()}

                  {/* Save Button */}
                  <div className="pt-4 border-t">
                    <Button
                      onClick={handleSaveParser}
                      disabled={!parserFormData.name || !selectedParserType || isSaving}
                      className="w-full"
                    >
                      {isSaving ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4 mr-2" />
                          Save Parser
                        </>
                      )}
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Panel 2: Upload Document + Preview */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="w-5 h-5 mr-2 text-primary" />
                Upload Document
              </CardTitle>
              <CardDescription>
                Upload a file and preview the document
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Small Upload Button at Top */}
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById('file-upload')?.click()}
                  className="flex items-center space-x-2"
                >
                  <Upload className="w-4 h-4" />
                  <span>{uploadedFile ? 'Change File' : 'Upload File'}</span>
                </Button>
                {uploadedFile && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={removeFile}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="w-4 h-4 mr-1" />
                    Remove
                  </Button>
                )}
              </div>
              
              <input
                id="file-upload"
                type="file"
                accept=".pdf,.png,.jpg,.jpeg,.tiff,.bmp,.gif"
                onChange={handleFileInputChange}
                className="hidden"
              />

              {/* Document Viewer */}
              <div className="border rounded-lg bg-white min-h-[600px]">
                <DocumentViewer 
                  file={uploadedFile} 
                  filePreview={filePreview} 
                />
              </div>

              {/* Text Input Alternative - Only show when no file uploaded */}
              {!uploadedFile && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Or enter sample text</label>
                  <Textarea
                    placeholder="Enter sample document text..."
                    value={testDocument}
                    onChange={(e) => setTestDocument(e.target.value)}
                    rows={4}
                    className="text-sm"
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Panel 3: Run Analysis + Results */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Play className="w-5 h-5 mr-2 text-primary" />
                Run Analysis
              </CardTitle>
              <CardDescription>
                Test your parser configuration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Parser Selection Dropdown */}
              <div className="space-y-2">
                <Label htmlFor="parser-selection">Select Parser</Label>
                <Select
                  value={selectedParserForAnalysis}
                  onValueChange={setSelectedParserForAnalysis}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a saved parser" />
                  </SelectTrigger>
                  <SelectContent>
                    {savedParsers.map((parser) => (
                      <SelectItem key={parser.id} value={parser.id}>
                        <div className="flex items-center space-x-2">
                          {['azure-document-ai', 'google-document-ai'].includes(parser.type) ? (
                            <Cloud className="w-4 h-4" />
                          ) : (
                            <Cpu className="w-4 h-4" />
                          )}
                          <span>{parser.name}</span>
                          <span className="text-xs text-muted-foreground">({parser.type})</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Run Analysis Button */}
              <Button
                onClick={runDocumentAnalysis}
                disabled={(!uploadedFile && !testDocument.trim()) || !selectedParserForAnalysis || isAnalyzing}
                className="w-full"
                size="lg"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Run Analysis
                  </>
                )}
              </Button>

              {/* Results */}
              {testResults && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium">Results</label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setTestDocument("");
                        setTestResults("");
                        setUploadedFile(null);
                        setFilePreview(null);
                      }}
                    >
                      Clear
                    </Button>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg border max-h-96 overflow-y-auto">
                    <pre className="text-xs whitespace-pre-wrap font-mono">
                      {testResults}
                    </pre>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Landing Page - Saved Parsers Grid with Action Buttons
  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Saved Parser Profiles</h1>
          <p className="text-sm text-muted-foreground">
            Configure document parsing and text extraction engines
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Button
            onClick={handleNewParser}
            className="px-6"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create New Parser
          </Button>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search parsers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <div className="flex items-center border rounded-lg">
            <Button
              variant={viewMode === 'cards' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('cards')}
              className="rounded-r-none"
            >
              <Grid3X3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
              className="rounded-l-none"
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Saved Parsers Grid */}
      <Card>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="text-center py-12">
              <Loader2 className="w-8 h-8 mx-auto mb-4 animate-spin text-muted-foreground" />
              <p className="text-muted-foreground">Loading parser profiles...</p>
            </div>
          ) : savedParsers.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium text-muted-foreground mb-2">No parser profiles found</p>
              <p className="text-sm text-muted-foreground mb-6">
                Create your first parser profile to get started with document processing
              </p>
              <Button onClick={handleNewParser}>
                <Plus className="w-4 h-4 mr-2" />
                Create First Parser
              </Button>
            </div>
          ) : filteredParsers.length === 0 ? (
            <div className="text-center py-8">
              <Search className="w-8 h-8 mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">No parsers match your search</p>
              <Button
                variant="outline"
                onClick={() => setSearchTerm("")}
                className="mt-4"
              >
                Clear Search
              </Button>
            </div>
          ) : viewMode === 'cards' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredParsers.map((parser) => (
                <Card key={parser.id} className="transition-all hover:shadow-md">
                  <CardHeader className="pb-3">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-muted rounded-lg">
                        {['azure-document-ai', 'google-document-ai'].includes(parser.type) ? (
                          <Cloud className="w-5 h-5 text-muted-foreground" />
                        ) : (
                          <Cpu className="w-5 h-5 text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-base">{parser.name}</CardTitle>
                        <CardDescription className="capitalize">
                          {parser.type.replace('-', ' ')}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between mb-4">
                      <StatusBadge
                        status={parser.status === "active" ? "success" : "warning"}
                      >
                        {parser.status}
                      </StatusBadge>
                      <span className="text-xs text-muted-foreground">
                        {new Date(parser.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    
                    {/* Action Buttons */}
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenParser(parser);
                        }}
                      >
                        <FolderOpen className="w-4 h-4 mr-1" />
                        Open
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={(e) => handleDeleteParser(parser.id, e)}
                        disabled={isDeleting === parser.id}
                      >
                        {isDeleting === parser.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Parser Name</TableHead>
                  <TableHead>Parser Type</TableHead>
                  <TableHead>Created Date</TableHead>
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredParsers.map((parser) => (
                  <TableRow key={parser.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="p-1.5 bg-muted rounded">
                          {['azure-document-ai', 'google-document-ai'].includes(parser.type) ? (
                            <Cloud className="w-4 h-4 text-muted-foreground" />
                          ) : (
                            <Cpu className="w-4 h-4 text-muted-foreground" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{parser.name}</p>
                          <p className="text-sm text-muted-foreground">{parser.description || 'No description'}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="capitalize font-medium">{parser.type.replace('-', ' ')}</p>
                        <StatusBadge
                          status={parser.status === "active" ? "success" : "warning"}
                          className="text-xs mt-1"
                        >
                          {parser.status}
                        </StatusBadge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">
                        {new Date(parser.createdAt).toLocaleDateString()}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenParser(parser);
                          }}
                        >
                          <FolderOpen className="w-4 h-4 mr-1" />
                          Open
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={(e) => handleDeleteParser(parser.id, e)}
                          disabled={isDeleting === parser.id}
                        >
                          {isDeleting === parser.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Trash2 className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

    </div>
  );
}