import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Package, Save, Upload, FileText, Play, Loader2, X, Cpu } from "lucide-react";
import { Link } from "wouter";
import { ParserConfigForm } from "@/components/ParserConfigForm";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function NewUnstructuredParserPage() {
  const [, setLocation] = useLocation();
  const [parserName, setParserName] = useState("");
  const [parserDescription, setParserDescription] = useState("");
  const [showTestDocumentView, setShowTestDocumentView] = useState(false);
  const [currentConfig, setCurrentConfig] = useState(null);
  const [testDocument, setTestDocument] = useState("");
  const [testResults, setTestResults] = useState("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createParserMutation = useMutation({
    mutationFn: async (data: { name: string; type: string; config: any; description?: string }) => {
      return apiRequest("POST", "/api/parser-profiles", data);
    },
    onSuccess: () => {
      toast({
        title: "Parser profile created",
        description: "Unstructured.io SDK parser has been configured successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/parser-profiles"] });
      setLocation("/parsers");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create parser profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleTestParser = () => {
    setShowTestDocumentView(true);
  };

  const handleBackToParserConfig = () => {
    setShowTestDocumentView(false);
    setTestDocument("");
    setTestResults("");
    setUploadedFile(null);
    setFilePreview(null);
    setIsAnalyzing(false);
  };

  const handleFileInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/tiff', 'image/bmp', 'image/gif', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (!allowedTypes.includes(file.type)) {
        toast({ title: "Unsupported file type", description: "Please upload a PDF, Word document, or image file", variant: "destructive" });
        return;
      }
      setUploadedFile(file);
      setTestDocument("");
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => setFilePreview(e.target?.result as string);
        reader.readAsDataURL(file);
      } else { setFilePreview(null); }
    }
  };

  const removeFile = () => { setUploadedFile(null); setFilePreview(null); };

  const runDocumentAnalysis = async () => {
    if (!uploadedFile && !testDocument.trim()) {
      toast({ title: "No document provided", description: "Please upload a document or provide sample text to analyze.", variant: "destructive" });
      return;
    }
    setIsAnalyzing(true);
    setTestResults("Analyzing document...");
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      const mockResults = {
        parser: parserName || "Unstructured.io Parser",
        type: "unstructured",
        filename: uploadedFile?.name || "text-input",
        extractedText: uploadedFile ? "Sample Unstructured.io extracted content..." : testDocument,
        confidence: 0.94,
        metadata: { processingTime: "2.3s", timestamp: new Date().toISOString(), apiProvider: "Unstructured.io" }
      };
      setTestResults(JSON.stringify(mockResults, null, 2));
      toast({ title: "Document analyzed", description: "Analysis results are ready for review." });
    } catch (error) {
      toast({ title: "Analysis failed", description: "Failed to analyze document.", variant: "destructive" });
      setTestResults("Analysis failed.");
    } finally { setIsAnalyzing(false); }
  };

  const handleSaveConfig = (config: any) => {
    if (!parserName.trim()) {
      toast({
        title: "Parser name required",
        description: "Please provide a name for this parser profile.",
        variant: "destructive",
      });
      return;
    }

    createParserMutation.mutate({
      name: parserName,
      type: "unstructured",
      config,
      description: parserDescription,
    });
  };

  return (
    <div className="p-4 space-y-4">
      {/* Back Navigation */}
      <div className="flex items-center space-x-4">
        <Link href="/parsers">
          <Button variant="outline" size="sm" data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-3">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Cpu className="w-5 h-5 mr-2 text-primary" />
                  Unstructured.io SDK Parser
                </CardTitle>
                <CardDescription>
                  Configure Unstructured.io for advanced document parsing and extraction
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="parser-name">Parser Name *</Label>
                  <Input
                    id="parser-name"
                    placeholder="e.g., Advanced Document Processor"
                    value={parserName}
                    onChange={(e) => setParserName(e.target.value)}
                    required
                    data-testid="input-parser-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parser-description">Description</Label>
                  <Textarea
                    id="parser-description"
                    placeholder="Optional description for this parser"
                    value={parserDescription}
                    onChange={(e) => setParserDescription(e.target.value)}
                    data-testid="input-parser-description"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Parser Configuration */}
            <Card>
              <CardHeader>
                <CardTitle>Parser Configuration</CardTitle>
                <CardDescription>
                  Configure your Unstructured.io SDK settings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ParserConfigForm
                  parserType="unstructured"
                  onSave={handleSaveConfig}
                  onTestParser={handleTestParser}
                />
              </CardContent>
            </Card>
          </div>

          {/* Configuration Summary */}
          <div className="space-y-3">
            <Card>
              <CardHeader>
                <CardTitle>Configuration Summary</CardTitle>
                <CardDescription>
                  Review your parser settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Parser Type:</span>
                  <span className="text-foreground font-medium">Unstructured.io SDK</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name:</span>
                  <span className="text-foreground font-medium">
                    {parserName || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Category:</span>
                  <span className="text-foreground font-medium">Local Parser</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Accuracy:</span>
                  <span className="font-medium text-success">97%</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex items-center text-muted-foreground">
                  ✓ Advanced document parsing
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Multiple file formats
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Text chunking
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Local & cloud processing
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Layout preservation
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Test Document In-Page View */}
      {showTestDocumentView && (
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={handleBackToParserConfig}>
              <ArrowLeft className="h-4 w-4 mr-2" />Back to Parser Configuration
            </Button>
          </div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />Test Document - {parserName || "Unstructured.io Parser"}
              </CardTitle>
              <CardDescription>Upload a document or provide sample text to test your parser configuration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center space-y-4">
                  {uploadedFile ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div className="flex items-center gap-3">
                          <FileText className="h-8 w-8 text-primary" />
                          <div className="text-left">
                            <p className="font-medium">{uploadedFile.name}</p>
                            <p className="text-sm text-muted-foreground">{(uploadedFile.size / 1024).toFixed(1)} KB</p>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" onClick={removeFile}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      {filePreview && (
                        <div className="max-w-md mx-auto">
                          <img src={filePreview} alt="Preview" className="max-w-full h-auto rounded-lg border" />
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Upload className="h-12 w-12 text-muted-foreground mx-auto" />
                      <div>
                        <p className="text-lg font-medium">Upload a document</p>
                        <p className="text-muted-foreground">PDF, Word, PNG, JPG, TIFF, BMP, or GIF files</p>
                      </div>
                      <Input type="file" accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.tiff,.bmp,.gif" onChange={handleFileInputChange} className="max-w-xs mx-auto" />
                    </div>
                  )}
                </div>
                <div className="relative">
                  <Label htmlFor="sample-text">Or provide sample text</Label>
                  <Textarea id="sample-text" placeholder="Paste or type sample text here..." value={testDocument} onChange={(e) => setTestDocument(e.target.value)} className="min-h-[100px] mt-2" />
                </div>
                <Button onClick={runDocumentAnalysis} disabled={isAnalyzing} className="w-full">
                  {isAnalyzing ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Analyzing...</> : <><Play className="h-4 w-4 mr-2" />Analyze Document</>}
                </Button>
              </div>
              {testResults && (
                <div className="space-y-4">
                  <Label>Analysis Results</Label>
                  <Textarea value={testResults} readOnly className="min-h-[200px] font-mono text-sm" />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}