import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Cloud, Save, Upload, FileText, Play, Loader2, X } from "lucide-react";
import { Link } from "wouter";
import { ParserConfigForm } from "@/components/ParserConfigForm";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function NewAzureParserPage() {
  const [, setLocation] = useLocation();
  const [parserName, setParserName] = useState("");
  const [parserDescription, setParserDescription] = useState("");
  const [showTestDocumentView, setShowTestDocumentView] = useState(false);
  const [currentConfig, setCurrentConfig] = useState(null);
  const [testDocument, setTestDocument] = useState("");
  const [testResults, setTestResults] = useState("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createParserMutation = useMutation({
    mutationFn: async (data: { name: string; type: string; config: any; description?: string }) => {
      return apiRequest("POST", "/api/parser-profiles", data);
    },
    onSuccess: () => {
      toast({
        title: "Parser profile created",
        description: "Azure Document AI parser has been configured successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/parser-profiles"] });
      setLocation("/parsers");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create parser profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSaveConfig = (config: any) => {
    if (!parserName.trim()) {
      toast({
        title: "Parser name required",
        description: "Please provide a name for this parser profile.",
        variant: "destructive",
      });
      return;
    }

    createParserMutation.mutate({
      name: parserName,
      type: "azure-ai",
      config,
      description: parserDescription,
    });
  };

  const handleTestParser = () => {
    setShowTestDocumentView(true);
  };

  const handleBackToParserConfig = () => {
    setShowTestDocumentView(false);
    setTestDocument("");
    setTestResults("");
    setUploadedFile(null);
    setFilePreview(null);
    setIsAnalyzing(false);
  };

  const handleFileInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/tiff', 'image/bmp', 'image/gif'];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Unsupported file type",
          description: "Please upload a PDF or image file (PNG, JPG, JPEG, TIFF, BMP, GIF)",
          variant: "destructive",
        });
        return;
      }
      setUploadedFile(file);
      setTestDocument("");
      
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setFilePreview(e.target?.result as string);
        };
        reader.readAsDataURL(file);
      } else {
        setFilePreview(null);
      }
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
    setFilePreview(null);
  };

  const runDocumentAnalysis = async () => {
    if (!uploadedFile && !testDocument.trim()) {
      toast({
        title: "No document provided",
        description: "Please upload a document or provide sample text to analyze.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    setTestResults("Analyzing document...");
    
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const mockResults = {
        parser: parserName || "Azure Document AI Parser",
        type: "azure-ai",
        filename: uploadedFile?.name || "text-input",
        fileSize: uploadedFile?.size || testDocument.length,
        extractedText: uploadedFile ? "Sample OCR extracted text from uploaded document..." : testDocument,
        confidence: 0.95,
        entities: [
          { type: "PERSON", text: "John Doe", confidence: 0.98 },
          { type: "DATE", text: "2023-01-15", confidence: 0.92 },
          { type: "AMOUNT", text: "$1,250.00", confidence: 0.89 }
        ],
        tables: [
          { rows: 3, columns: 4, confidence: 0.87 }
        ],
        metadata: {
          processingTime: "2.1s",
          timestamp: new Date().toISOString(),
          apiProvider: "Azure Document AI"
        }
      };

      setTestResults(JSON.stringify(mockResults, null, 2));
      
      toast({
        title: "Document analyzed",
        description: "Analysis results are ready for review.",
      });
    } catch (error) {
      toast({
        title: "Analysis failed",
        description: "Failed to analyze document. Please try again.",
        variant: "destructive",
      });
      setTestResults("Analysis failed. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Show test document view if selected
  if (showTestDocumentView) {
    return (
      <div className="p-4 space-y-4">
        {/* Back Button */}
        <div className="flex items-center space-x-4 mb-6">
          <Button 
            variant="outline" 
            onClick={handleBackToParserConfig}
            data-testid="button-back-to-config"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Configuration
          </Button>
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Test Document</h1>
            <p className="text-sm text-muted-foreground">
              Testing Azure Document AI Parser: {parserName || "Unnamed Parser"}
            </p>
          </div>
        </div>
        {/* Test Document Interface - Same as Google parser */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Document Upload</CardTitle>
              <CardDescription>Upload a document or provide sample text to test your parser configuration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                {uploadedFile ? (
                  <div className="space-y-2">
                    <FileText className="w-8 h-8 mx-auto text-primary" />
                    <p className="text-sm font-medium">{uploadedFile.name}</p>
                    <p className="text-xs text-muted-foreground">{(uploadedFile.size / 1024).toFixed(1)} KB</p>
                    <Button variant="outline" size="sm" onClick={removeFile}><X className="w-3 h-3 mr-1" />Remove</Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Upload className="w-8 h-8 mx-auto text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">Drag and drop your document here, or</p>
                    <Button variant="outline" onClick={() => document.getElementById('file-upload')?.click()}>Choose File</Button>
                    <p className="text-xs text-muted-foreground">Supports: PDF, PNG, JPG, JPEG, TIFF, BMP, GIF</p>
                  </div>
                )}
                <input id="file-upload" type="file" accept=".pdf,.png,.jpg,.jpeg,.tiff,.bmp,.gif" onChange={handleFileInputChange} className="hidden" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Or enter sample text</label>
                <Textarea placeholder="Enter sample document text to test your parser..." value={testDocument} onChange={(e) => setTestDocument(e.target.value)} disabled={!!uploadedFile} rows={6} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Document Preview & Analysis</CardTitle>
              <CardDescription>Preview your document and run analysis</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border rounded-lg p-4 min-h-[200px] bg-gray-50">
                {uploadedFile ? (
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Uploaded File:</p>
                    <div className="bg-white p-3 rounded border">
                      <div className="flex items-center space-x-2">
                        <FileText className="w-4 h-4 text-primary" />
                        <span className="text-sm">{uploadedFile.name}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">Size: {(uploadedFile.size / 1024).toFixed(1)} KB</p>
                      {filePreview && uploadedFile.type.startsWith('image/') && (
                        <div className="mt-2">
                          <img src={filePreview} alt="Document preview" className="max-w-full max-h-48 object-contain rounded" />
                        </div>
                      )}
                    </div>
                  </div>
                ) : testDocument ? (
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Text Preview:</p>
                    <div className="bg-white p-3 rounded border">
                      <pre className="text-xs whitespace-pre-wrap text-muted-foreground">{testDocument.substring(0, 200)}{testDocument.length > 200 && '...'}</pre>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    <p className="text-sm">Upload a file or enter text to see preview</p>
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Analysis</h4>
                <div className="space-x-2">
                  <Button onClick={runDocumentAnalysis} disabled={(!uploadedFile && !testDocument.trim()) || isAnalyzing}>
                    {isAnalyzing ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing...</> : <><Play className="w-4 h-4 mr-2" />Run Analysis</>}
                  </Button>
                  <Button variant="outline" onClick={() => { setTestDocument(""); setTestResults(""); setUploadedFile(null); setFilePreview(null); setIsAnalyzing(false); }}>Clear All</Button>
                </div>
              </div>
              {testResults && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Analysis Results</label>
                  <div className="bg-gray-50 p-4 rounded-lg border max-h-64 overflow-y-auto">
                    <pre className="text-xs whitespace-pre-wrap font-mono">{testResults}</pre>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      {/* Back Navigation */}
      <div className="flex items-center space-x-4">
        <Link href="/parsers">
          <Button variant="outline" size="sm" data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-3">
            {/* Basic Information */}
            <Card>
              <CardHeader className="p-4">
                <CardTitle className="flex items-center">
                  <Cloud className="w-5 h-5 mr-2 text-primary" />
                  Azure Document AI Parser
                </CardTitle>
                <CardDescription>
                  Configure Azure Document AI for advanced cloud-based document processing
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="parser-name">Parser Name *</Label>
                  <Input
                    id="parser-name"
                    placeholder="e.g., Financial Documents Azure AI"
                    value={parserName}
                    onChange={(e) => setParserName(e.target.value)}
                    required
                    data-testid="input-parser-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parser-description">Description</Label>
                  <Textarea
                    id="parser-description"
                    placeholder="Optional description for this parser"
                    value={parserDescription}
                    onChange={(e) => setParserDescription(e.target.value)}
                    data-testid="input-parser-description"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Parser Configuration */}
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Parser Configuration</CardTitle>
                <CardDescription>
                  Configure your Azure Document AI service settings
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <ParserConfigForm
                  parserType="azure-ai"
                  onSave={handleSaveConfig}
                  onTestParser={handleTestParser}
                />
              </CardContent>
            </Card>
          </div>

          {/* Configuration Summary */}
          <div className="space-y-3">
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Configuration Summary</CardTitle>
                <CardDescription>
                  Review your parser settings
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Parser Type:</span>
                  <span className="text-foreground font-medium">Azure Document AI</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name:</span>
                  <span className="text-foreground font-medium">
                    {parserName || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Category:</span>
                  <span className="text-foreground font-medium">Cloud Parser</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Accuracy:</span>
                  <span className="font-medium text-success">99%+</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="p-4">
                <CardTitle>Features</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-2 text-sm">
                <div className="flex items-center text-muted-foreground">
                  ✓ Advanced document intelligence
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Form and table extraction
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Multiple document types
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Cloud-based processing
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Pre-built models available
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>


    </div>
  );
}