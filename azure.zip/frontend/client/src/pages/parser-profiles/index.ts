export { default as ParsersPage } from './ParsersPage';
export { default as NewParserPage } from './NewParserPage';
export { default as NewAzureParserPage } from './NewAzureParserPage';
export { default as NewGoogleParserPage } from './NewGoogleParserPage';
export { default as NewTesseractParserPage } from './NewTesseractParserPage';
export { default as NewPaddleParserPage } from './NewPaddleParserPage';
export { default as NewUnstructuredParserPage } from './NewUnstructuredParserPage';