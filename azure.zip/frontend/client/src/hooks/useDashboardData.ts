import { useQuery } from "@tanstack/react-query";

// Use local proxy endpoints to avoid CORS issues
const API_BASE_URL = "/api/dashboard";

// Export interfaces
export type { ActiveApi, ActiveApisDataResponse };

// Interface for API response
interface ApiCountResponse {
  count: number;
  error?: string;
  fallback?: boolean;
  [key: string]: any; // Allow for additional fields
}

// Interface for Active API item
interface ActiveApi {
  id: string;
  name: string;
  url: string;
  status: string;
  lastUsed: string;
  [key: string]: any; // Allow for additional fields
}

// Interface for Active APIs data response
interface ActiveApisDataResponse {
  data: ActiveApi[];
  error?: string;
  fallback?: boolean;
}

// Hook for total API calls count
export function useApiCallsCount() {
  return useQuery({
    queryKey: ["dashboard", "metrics", "logs", "count"],
    queryFn: async (): Promise<ApiCountResponse> => {
      const response = await fetch(`${API_BASE_URL}/metrics/logs/count`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include", // Include cookies for authentication if needed
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to fetch API calls count`);
      }
      
      const data = await response.json();
      return data;
    },
    refetchInterval: 30000, // Refetch every 30 seconds
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
}

// Hook for documents vectorized count
export function useDocumentsVectorizedCount() {
  return useQuery({
    queryKey: ["dashboard", "metrics", "vectorize-documents", "count"],
    queryFn: async (): Promise<ApiCountResponse> => {
      const response = await fetch(`${API_BASE_URL}/metrics/vectorize-documents/count`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include", // Include cookies for authentication if needed
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to fetch documents vectorized count`);
      }
      
      const data = await response.json();
      return data;
    },
    refetchInterval: 30000, // Refetch every 30 seconds
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
}

// Hook for active APIs status
export function useActiveApisStatus() {
  return useQuery({
    queryKey: ["dashboard", "search-apis", "status"],
    queryFn: async (): Promise<ApiCountResponse> => {
      const response = await fetch(`${API_BASE_URL}/search-apis/status`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include", // Include cookies for authentication if needed
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to fetch active APIs status`);
      }
      
      const data = await response.json();
      return data;
    },
    refetchInterval: 30000, // Refetch every 30 seconds
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
}

// Hook for active APIs data (full JSON for grid rows)
export function useActiveApisData() {
  return useQuery({
    queryKey: ["dashboard", "search-apis", "data"],
    queryFn: async (): Promise<ActiveApisDataResponse> => {
      const response = await fetch(`${API_BASE_URL}/search-apis/data`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include", // Include cookies for authentication if needed
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: Failed to fetch active APIs data`);
      }
      
      const data = await response.json();
      return data;
    },
    refetchInterval: 30000, // Refetch every 30 seconds
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
}