import type { Express } from "express";
import { createServer, type Server } from "http";
import { dbStorage } from "./storage";
import { insertConnectorSchema, insertParserProfileSchema } from "@shared/schema";
import { z } from "zod";
import { fetch } from "undici";

// Validation schemas for connector routes
const createConnectorSchema = z.object({
  name: z.string().min(1, "Name is required"),
  type: z.enum(["s3", "gcs", "azure-blob", "file-share", "google-drive", "file-upload"]),
  config: z.object({}).passthrough(), // Allow any object for config
});

const updateConnectorSchema = z.object({
  name: z.string().min(1).optional(),
  type: z.enum(["s3", "gcs", "azure-blob", "file-share", "google-drive", "file-upload"]).optional(),
  config: z.object({}).passthrough().optional(),
  status: z.enum(["active", "inactive", "error"]).optional(),
  lastSync: z.string().nullable().optional(),
  documentsCount: z.number().int().min(0).optional(),
}).refine(data => Object.keys(data).length > 0, {
  message: "At least one field must be provided for update"
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Connector routes

  // GET /api/connectors - Get all connectors, optionally filtered by type
  app.get("/api/connectors", async (req, res) => {
    try {
      const { type } = req.query;
      const connectors = await dbStorage.getAllConnectors();
      
      // If type is provided, filter connectors by type
      if (type && typeof type === 'string') {
        const filteredConnectors = connectors.filter(connector => connector.type === type);
        res.json(filteredConnectors);
      } else {
        res.json(connectors);
      }
    } catch (error) {
      console.error("Error fetching connectors:", error);
      res.status(500).json({ error: "Failed to fetch connectors" });
    }
  });

  // GET /api/connectors/saved - Get all saved connectors for dropdown (name and id only)
  app.get("/api/connectors/saved", async (req, res) => {
    try {
      const connectors = await dbStorage.getAllConnectors();
      const savedConnectors = connectors.map(connector => ({
        id: connector.id,
        name: connector.name,
        type: connector.type
      }));
      res.json(savedConnectors);
    } catch (error) {
      console.error("Error fetching saved connectors:", error);
      res.status(500).json({ error: "Failed to fetch saved connectors" });
    }
  });

  // GET /api/connectors/:id - Get single connector by ID
  app.get("/api/connectors/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const connector = await dbStorage.getConnector(id);
      
      if (!connector) {
        return res.status(404).json({ error: "Connector not found" });
      }
      
      res.json(connector);
    } catch (error) {
      console.error("Error fetching connector:", error);
      res.status(500).json({ error: "Failed to fetch connector" });
    }
  });

  // POST /api/connectors - Create new connector
  app.post("/api/connectors", async (req, res) => {
    try {
      // Validate request body
      const validationResult = createConnectorSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const { name, type, config } = validationResult.data;
      
      // Create connector with initial status and documentsCount
      const newConnector = await dbStorage.createConnector({
        name,
        type,
        config,
      });
      
      res.status(201).json(newConnector);
    } catch (error) {
      console.error("Error creating connector:", error);
      res.status(500).json({ error: "Failed to create connector" });
    }
  });

  // PUT /api/connectors/:id - Update existing connector
  app.put("/api/connectors/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate request body
      const validationResult = updateConnectorSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const updates = validationResult.data;
      // Convert lastSync string to Date if provided
      const processedUpdates: any = { ...updates };
      if (updates.lastSync !== undefined) {
        processedUpdates.lastSync = updates.lastSync ? new Date(updates.lastSync) : null;
      }
      const updatedConnector = await dbStorage.updateConnector(id, processedUpdates);
      
      if (!updatedConnector) {
        return res.status(404).json({ error: "Connector not found" });
      }
      
      res.json(updatedConnector);
    } catch (error) {
      console.error("Error updating connector:", error);
      res.status(500).json({ error: "Failed to update connector" });
    }
  });

  // DELETE /api/connectors/:id - Delete connector
  app.delete("/api/connectors/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await dbStorage.deleteConnector(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Connector not found" });
      }
      
      res.json({ message: "Connector deleted successfully" });
    } catch (error) {
      console.error("Error deleting connector:", error);
      res.status(500).json({ error: "Failed to delete connector" });
    }
  });

  // Parser Profile routes

  // Validation schemas for parser profile routes
  const createParserProfileSchema = z.object({
    name: z.string().min(1, "Name is required"),
    type: z.enum(["azure-ai", "google-ai", "tesseract", "paddle", "unstructured"]),
    config: z.object({}).passthrough(), // Allow any object for config
  });

  const updateParserProfileSchema = z.object({
    name: z.string().min(1).optional(),
    type: z.enum(["azure-ai", "google-ai", "tesseract", "paddle", "unstructured"]).optional(),
    config: z.object({}).passthrough().optional(),
    status: z.enum(["active", "inactive", "error"]).optional(),
  }).refine(data => Object.keys(data).length > 0, {
    message: "At least one field must be provided for update"
  });

  // GET /api/parser-profiles - Get all parser profiles, optionally filtered by type
  app.get("/api/parser-profiles", async (req, res) => {
    try {
      const { type } = req.query;
      console.log('GET /api/parser-profiles - fetching from database');
      
      const parserProfiles = await dbStorage.getAllParserProfiles();
      console.log('GET /api/parser-profiles - database returned:', parserProfiles.length, 'profiles');
      
      // If no profiles in database, let's create some sample ones for testing
      if (parserProfiles.length === 0) {
        console.log('No parser profiles found in database. Creating sample data...');
        
        const sampleProfile1 = await dbStorage.createParserProfile({
          name: "Tesseract OCR Configuration",
          description: "Open-source optical character recognition",
          type: "tesseract",
          config: {
            language: "eng",
            oem: 3,
            psm: 6
          },
          status: "inactive",
          version: "1.0.0",
          supportedFormats: ["pdf", "jpg", "png", "tiff"],
          performanceMetrics: null,
          testResults: null,
          createdBy: null
        });
        
        const sampleProfile2 = await dbStorage.createParserProfile({
          name: "Tesseract OCR Configuration1",
          description: "Advanced Tesseract configuration",
          type: "tesseract",
          config: {
            language: "eng+spa",
            oem: 1,
            psm: 3
          },
          status: "inactive",
          version: "1.0.0",
          supportedFormats: ["pdf", "jpg", "png"],
          performanceMetrics: null,
          testResults: null,
          createdBy: null
        });
        
        console.log('Created sample profiles:', sampleProfile1.id, sampleProfile2.id);
        const updatedProfiles = await dbStorage.getAllParserProfiles();
        
        res.json(updatedProfiles);
        return;
      }
      
      // If type is provided, filter parser profiles by type
      if (type && typeof type === 'string') {
        const filteredProfiles = parserProfiles.filter(profile => profile.type === type);
        res.json(filteredProfiles);
      } else {
        res.json(parserProfiles);
      }
    } catch (error) {
      console.error("Error fetching parser profiles:", error);
      res.status(500).json({ error: "Failed to fetch parser profiles" });
    }
  });

  // GET /api/parser-profiles/:id - Get single parser profile by ID
  app.get("/api/parser-profiles/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const parserProfile = await dbStorage.getParserProfile(id);
      
      if (!parserProfile) {
        return res.status(404).json({ error: "Parser profile not found" });
      }
      
      res.json(parserProfile);
    } catch (error) {
      console.error("Error fetching parser profile:", error);
      res.status(500).json({ error: "Failed to fetch parser profile" });
    }
  });

  // POST /api/parser-profiles - Create new parser profile
  app.post("/api/parser-profiles", async (req, res) => {
    try {
      // Validate request body
      const validationResult = createParserProfileSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const { name, type, config } = validationResult.data;
      
      // Create parser profile with initial status
      const newParserProfile = await dbStorage.createParserProfile({
        name,
        type,
        config,
        status: "inactive",
      });
      
      res.status(201).json(newParserProfile);
    } catch (error) {
      console.error("Error creating parser profile:", error);
      res.status(500).json({ error: "Failed to create parser profile" });
    }
  });

  // PUT /api/parser-profiles/:id - Update existing parser profile
  app.put("/api/parser-profiles/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate request body
      const validationResult = updateParserProfileSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const updates = validationResult.data;
      const updatedParserProfile = await dbStorage.updateParserProfile(id, updates);
      
      if (!updatedParserProfile) {
        return res.status(404).json({ error: "Parser profile not found" });
      }
      
      res.json(updatedParserProfile);
    } catch (error) {
      console.error("Error updating parser profile:", error);
      res.status(500).json({ error: "Failed to update parser profile" });
    }
  });

  // DELETE /api/parser-profiles/:id - Delete parser profile
  app.delete("/api/parser-profiles/:id", async (req, res) => {
    try {
      const { id } = req.params;
      console.log("DELETE request for parser profile ID:", id);
      
      const deleted = await dbStorage.deleteParserProfile(id);
      console.log("Delete operation result:", deleted);
      
      if (!deleted) {
        console.log("Parser profile not found:", id);
        return res.status(404).json({ error: "Parser profile not found" });
      }
      
      console.log("Parser profile deleted successfully:", id);
      res.json({ message: "Parser profile deleted successfully" });
    } catch (error) {
      console.error("Error deleting parser profile:", error);
      res.status(500).json({ error: "Failed to delete parser profile" });
    }
  });

  // Dashboard metrics proxy routes
  const EXTERNAL_API_BASE = process.env.EXTERNAL_API_BASE_URL || "http://10.73.88.101:8000";
  const LOGS_COUNT_ENDPOINT = process.env.EXTERNAL_API_LOGS_COUNT_ENDPOINT || "/metrics/logs/count";
  const VECTORIZE_COUNT_ENDPOINT = process.env.EXTERNAL_API_VECTORIZE_COUNT_ENDPOINT || "/metrics/vectorized-documents/count";
  const ACTIVE_APIS_ENDPOINT = process.env.EXTERNAL_API_ACTIVE_APIS_ENDPOINT || "/search-api/status";
  
  // Fallback values from environment
  const fallbackApiCalls = parseInt(process.env.FALLBACK_API_CALLS_COUNT || "1247");
  const fallbackDocuments = parseInt(process.env.FALLBACK_DOCUMENTS_VECTORIZED_COUNT || "8932");
  const fallbackActiveApis = parseInt(process.env.FALLBACK_ACTIVE_APIS_COUNT || "3");

    // Proxy route for API calls count
  app.get("/api/dashboard/metrics/logs/count", async (req, res) => {
    console.log("📊 Dashboard API: Fetching API calls count...");
    try {
      const apiUrl = `${EXTERNAL_API_BASE}${LOGS_COUNT_ENDPOINT}`;
      console.log(`🌐 Calling external API: ${apiUrl}`);
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        console.error(`❌ External API error: ${response.status} ${response.statusText}`);
        return res.status(200).json({ 
          error: "Failed to fetch API calls count",
          count: fallbackApiCalls,
          fallback: true
        });
      }
      
      const data = await response.json() as any;
      console.log("✅ External API response:", data);
      
      // Extract the correct field based on the API response structure
      let count = 0;
      if (typeof data === 'number') {
        count = data;
      } else if (data && typeof data === 'object') {
        // Try different possible field names
        count = data.total_api_calls || data.count || data.api_calls || 0;
      }
      
      if (count === 0) {
        console.log("⚠️ No valid count found in response, using fallback");
        res.json({ 
          count: fallbackApiCalls,
          error: "No valid count found in API response",
          fallback: true,
          originalResponse: data
        });
      } else {
        res.json({ count });
      }
    } catch (error) {
      console.error("❌ Error fetching API calls count:", error);
      // Return mock data as fallback
      res.json({ 
        count: fallbackApiCalls,
        error: "Using fallback data due to external API unavailability",
        fallback: true
      });
    }
  });

  // Proxy route for documents vectorized count
  app.get("/api/dashboard/metrics/vectorize-documents/count", async (req, res) => {
    console.log("📊 Dashboard API: Fetching documents vectorized count...");
    try {
      const apiUrl = `${EXTERNAL_API_BASE}${VECTORIZE_COUNT_ENDPOINT}`;
      console.log(`🌐 Calling external API: ${apiUrl}`);
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        console.error(`❌ External API error: ${response.status} ${response.statusText}`);
        return res.status(200).json({ 
          error: "Failed to fetch documents vectorized count",
          count: fallbackDocuments,
          fallback: true
        });
      }
      
      const data = await response.json() as any;
      console.log("✅ External API response:", data);
      
      // Extract the correct field based on the API response structure
      let count = 0;
      if (typeof data === 'number') {
        count = data;
      } else if (data && typeof data === 'object') {
        // Try different possible field names based on actual API response
        count = data.total_vectorized_documents || data.documents_vectorized || data.total_documents || data.count || data.vectorized_count || 0;
      }
      
      if (count === 0) {
        console.log("⚠️ No valid count found in response, using fallback");
        res.json({ 
          count: fallbackDocuments,
          error: "No valid count found in API response",
          fallback: true,
          originalResponse: data
        });
      } else {
        res.json({ count });
      }
    } catch (error) {
      console.error("❌ Error fetching documents vectorized count:", error);
      // Return mock data as fallback
      res.json({ 
        count: fallbackDocuments,
        error: "Using fallback data due to external API unavailability",
        fallback: true
      });
    }
  });

  // Proxy route for active APIs status
  app.get("/api/dashboard/search-apis/status", async (req, res) => {
    console.log("📊 Dashboard API: Fetching active APIs status...");
    try {
      const apiUrl = `${EXTERNAL_API_BASE}${ACTIVE_APIS_ENDPOINT}`;
      console.log(`🌐 Calling external API: ${apiUrl}`);
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        console.error(`❌ External API error: ${response.status} ${response.statusText}`);
        return res.status(200).json({ 
          error: "Failed to fetch active APIs status",
          count: fallbackActiveApis,
          fallback: true
        });
      }
      
      const data = await response.json() as any;
      console.log("✅ External API response:", data);
      
      // Extract the correct field based on the API response structure
      let count = 0;
      if (typeof data === 'number') {
        count = data;
      } else if (data && typeof data === 'object') {
        // Try different possible field names based on actual API response
        count = data.active_count || data.active_apis?.length || data.count || data.total_active || 0;
      }
      
      if (count === 0) {
        console.log("⚠️ No valid count found in response, using fallback");
        res.json({ 
          count: fallbackActiveApis,
          error: "No valid count found in API response",
          fallback: true,
          originalResponse: data
        });
      } else {
        res.json({ count });
      }
    } catch (error) {
      console.error("❌ Error fetching active APIs status:", error);
      // Return mock data as fallback
      res.json({ 
        count: fallbackActiveApis,
        error: "Using fallback data due to external API unavailability",
        fallback: true
      });
    }
  });

  // Proxy route for active APIs data (full JSON for grid rows)
  app.get("/api/dashboard/search-apis/data", async (req, res) => {
    console.log("📊 Dashboard API: Fetching active APIs data...");
    try {
      const apiUrl = `${EXTERNAL_API_BASE}${ACTIVE_APIS_ENDPOINT}`;
      console.log(`🌐 Calling external API: ${apiUrl}`);
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        console.error(`❌ External API error: ${response.status} ${response.statusText}`);
        // Return mock data as fallback
        return res.status(200).json({ 
          data: [
            {
              id: "1",
              name: "Financial Search API",
              url: "/api/financial/search",
              status: "active",
              lastUsed: "2 mins ago"
            },
            {
              id: "2", 
              name: "Document Search API",
              url: "/api/documents/search",
              status: "active",
              lastUsed: "15 mins ago"
            }
          ],
          error: "Failed to fetch active APIs data",
          fallback: true
        });
      }
      
      const data = await response.json() as any;
      console.log("✅ External API response:", data);
      
      // Extract active APIs from the response structure
      let activeApis = [];
      if (data && Array.isArray(data.active_apis)) {
        activeApis = data.active_apis.map((api: any, index: number) => ({
          id: `${index + 1}`,
          name: api.name || `API ${index + 1}`,
          url: api.prefix || api.url || 'N/A',
          status: 'active',
          lastUsed: 'Recently',
          endpoints: api.endpoints || []
        }));
      }
      
      // Return the processed API data for grid rows
      res.json({ data: activeApis });
    } catch (error) {
      console.error("❌ Error fetching active APIs data:", error);
      // Return mock data as fallback
      res.json({ 
        data: [
          {
            id: "1",
            name: "Financial Search API", 
            url: "/api/financial/search",
            status: "active",
            lastUsed: "2 mins ago"
          },
          {
            id: "2",
            name: "Document Search API",
            url: "/api/documents/search", 
            status: "active",
            lastUsed: "15 mins ago"
          }
        ],
        error: "Using fallback data due to external API unavailability",
        fallback: true
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
