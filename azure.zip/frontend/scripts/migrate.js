#!/usr/bin/env node

/**
 * Database Migration Script for ContextCraft
 * This script applies the comprehensive database schema migration
 */

import { execSync } from 'child_process';
import { readFileSync } from 'fs';
import { join } from 'path';
import postgres from 'postgres';

const DATABASE_URL = process.env.DATABASE_URL || 'postgresql://postgres:admin%4012345@localhost:5432/contextcraft';

async function runMigration() {
  console.log('🚀 Starting ContextCraft database migration...');
  
  try {
    // Connect to database
    const sql = postgres(DATABASE_URL);
    
    console.log('📡 Connected to database');
    
    // Read migration file
    const migrationPath = join(process.cwd(), 'migrations', '0001_comprehensive_schema.sql');
    const migrationSQL = readFileSync(migrationPath, 'utf8');
    
    console.log('📄 Read migration file: 0001_comprehensive_schema.sql');
    
    // Execute migration
    console.log('⚙️ Applying migration...');
    await sql.unsafe(migrationSQL);
    
    console.log('✅ Migration completed successfully!');
    
    // Verify tables were created
    const tables = await sql`
      SELECT tablename 
      FROM pg_tables 
      WHERE schemaname = 'public'
      ORDER BY tablename;
    `;
    
    console.log('📋 Created tables:');
    tables.forEach(table => {
      console.log(`  - ${table.tablename}`);
    });
    
    // Close connection
    await sql.end();
    console.log('🎉 Database migration completed successfully!');
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runMigration();
}

export { runMigration };