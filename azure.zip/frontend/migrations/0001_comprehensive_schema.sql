-- ContextCraft - Comprehensive Database Migration
-- Generated on September 24, 2025
-- This migration implements the complete database schema

-- Enable UUID extension for generating unique IDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable JSONB functions
CREATE EXTENSION IF NOT EXISTS "btree_gin";

-- Drop existing tables if they exist (in correct order to handle foreign keys)
DROP TABLE IF EXISTS api_endpoints CASCADE;
DROP TABLE IF EXISTS pipelines CASCADE;
DROP TABLE IF EXISTS parser_profiles CASCADE;
DROP TABLE IF EXISTS connectors CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- =============================================================================
-- USERS TABLE
-- =============================================================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(255) NOT NULL UNIQUE,
    password TEXT NOT NULL,
    email VARCHAR(255) UNIQUE,
    full_name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'user' CHECK (role IN ('admin', 'user', 'viewer')),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE
);

-- =============================================================================
-- CONNECTORS TABLE (Import Connectors Page)
-- =============================================================================
CREATE TABLE connectors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL CHECK (type IN ('s3', 'gcs', 'azure-blob', 'file-share', 'google-drive', 'file-upload')),
    config JSONB NOT NULL, -- Stores connector-specific configuration
    status TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'error', 'testing', 'syncing')),
    last_sync TIMESTAMP WITH TIME ZONE,
    last_sync_status TEXT CHECK (last_sync_status IN ('success', 'failed', 'in_progress')),
    documents_count INTEGER DEFAULT 0,
    total_size_bytes BIGINT DEFAULT 0,
    error_message TEXT,
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT connectors_name_unique UNIQUE (name)
);

-- =============================================================================
-- PARSER PROFILES TABLE (Parser Profiles Page)
-- =============================================================================
CREATE TABLE parser_profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL CHECK (type IN ('azure-ai', 'google-ai', 'tesseract', 'paddle', 'unstructured')),
    config JSONB NOT NULL, -- Stores parser-specific configuration
    status TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'error', 'testing')),
    version VARCHAR(50) DEFAULT '1.0.0',
    supported_formats TEXT[] DEFAULT ARRAY['pdf', 'docx', 'txt', 'html', 'json'], -- Array of supported file formats
    performance_metrics JSONB, -- Stores accuracy, speed, etc.
    test_results JSONB, -- Stores test results and validation data
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT parser_profiles_name_unique UNIQUE (name)
);

-- =============================================================================
-- PIPELINES TABLE (Vector Pipelines Page & Pipeline Designer)
-- =============================================================================
CREATE TABLE pipelines (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL DEFAULT 'document_processing' CHECK (type IN ('document_processing', 'data_ingestion', 'vector_processing', 'custom')),
    config JSONB NOT NULL, -- Complete pipeline configuration
    nodes JSONB NOT NULL, -- ReactFlow nodes configuration
    edges JSONB NOT NULL, -- ReactFlow edges configuration
    status TEXT NOT NULL DEFAULT 'configured' CHECK (status IN ('configured', 'active', 'inactive', 'running', 'completed', 'failed', 'paused')),
    version VARCHAR(50) DEFAULT '1.0.0',
    
    -- Pipeline execution tracking
    last_run TIMESTAMP WITH TIME ZONE,
    last_run_status TEXT CHECK (last_run_status IN ('success', 'failed', 'in_progress', 'cancelled')),
    last_run_duration INTEGER, -- Duration in seconds
    total_runs INTEGER DEFAULT 0,
    successful_runs INTEGER DEFAULT 0,
    failed_runs INTEGER DEFAULT 0,
    
    -- Document processing metrics
    documents_processed INTEGER DEFAULT 0,
    vectors_generated INTEGER DEFAULT 0,
    total_processing_time INTEGER DEFAULT 0, -- Total time in seconds
    average_processing_time DECIMAL(10,2), -- Average time per document
    
    -- Pipeline metadata
    metadata JSONB, -- Additional metadata like tags, categories, etc.
    schedule_config JSONB, -- Scheduling configuration if applicable
    notification_config JSONB, -- Notification settings
    
    -- Relationships
    source_connector_id UUID REFERENCES connectors(id) ON DELETE SET NULL,
    parser_profile_id UUID REFERENCES parser_profiles(id) ON DELETE SET NULL,
    
    -- Audit fields
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT pipelines_name_unique UNIQUE (name)
);

-- =============================================================================
-- API ENDPOINTS TABLE (Create API Page)
-- =============================================================================
CREATE TABLE api_endpoints (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    endpoint_path TEXT NOT NULL, -- e.g., "/api/financial/search"
    method TEXT NOT NULL DEFAULT 'POST' CHECK (method IN ('GET', 'POST', 'PUT', 'DELETE', 'PATCH')),
    
    -- Configuration
    pipeline_id UUID REFERENCES pipelines(id) ON DELETE SET NULL,
    config JSONB NOT NULL, -- API endpoint configuration
    request_schema JSONB, -- Request validation schema
    response_schema JSONB, -- Response format schema
    
    -- Security and access
    auth_required BOOLEAN DEFAULT true,
    rate_limit INTEGER DEFAULT 1000, -- Requests per hour
    allowed_origins TEXT[], -- CORS origins
    api_key_required BOOLEAN DEFAULT false,
    
    -- Status and metrics
    status TEXT NOT NULL DEFAULT 'inactive' CHECK (status IN ('active', 'inactive', 'deprecated')),
    total_calls INTEGER DEFAULT 0,
    successful_calls INTEGER DEFAULT 0,
    failed_calls INTEGER DEFAULT 0,
    last_called TIMESTAMP WITH TIME ZONE,
    
    -- Audit
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT api_endpoints_path_method_unique UNIQUE (endpoint_path, method)
);

-- =============================================================================
-- CREATE INDEXES FOR PERFORMANCE
-- =============================================================================

-- Users indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Connectors indexes
CREATE INDEX idx_connectors_type ON connectors(type);
CREATE INDEX idx_connectors_status ON connectors(status);
CREATE INDEX idx_connectors_created_by ON connectors(created_by);
CREATE INDEX idx_connectors_config ON connectors USING GIN (config);
CREATE INDEX idx_connectors_name ON connectors(name);

-- Parser profiles indexes
CREATE INDEX idx_parser_profiles_type ON parser_profiles(type);
CREATE INDEX idx_parser_profiles_status ON parser_profiles(status);
CREATE INDEX idx_parser_profiles_created_by ON parser_profiles(created_by);
CREATE INDEX idx_parser_profiles_config ON parser_profiles USING GIN (config);
CREATE INDEX idx_parser_profiles_supported_formats ON parser_profiles USING GIN (supported_formats);

-- Pipelines indexes
CREATE INDEX idx_pipelines_type ON pipelines(type);
CREATE INDEX idx_pipelines_status ON pipelines(status);
CREATE INDEX idx_pipelines_created_by ON pipelines(created_by);
CREATE INDEX idx_pipelines_source_connector ON pipelines(source_connector_id);
CREATE INDEX idx_pipelines_parser_profile ON pipelines(parser_profile_id);
CREATE INDEX idx_pipelines_config ON pipelines USING GIN (config);
CREATE INDEX idx_pipelines_metadata ON pipelines USING GIN (metadata);
CREATE INDEX idx_pipelines_last_run ON pipelines(last_run);

-- API endpoints indexes
CREATE INDEX idx_api_endpoints_pipeline_id ON api_endpoints(pipeline_id);
CREATE INDEX idx_api_endpoints_status ON api_endpoints(status);
CREATE INDEX idx_api_endpoints_created_by ON api_endpoints(created_by);
CREATE INDEX idx_api_endpoints_endpoint_path ON api_endpoints(endpoint_path);

-- =============================================================================
-- TRIGGERS FOR UPDATED_AT TIMESTAMPS
-- =============================================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to relevant tables
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_connectors_updated_at BEFORE UPDATE ON connectors FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_parser_profiles_updated_at BEFORE UPDATE ON parser_profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_pipelines_updated_at BEFORE UPDATE ON pipelines FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_api_endpoints_updated_at BEFORE UPDATE ON api_endpoints FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =============================================================================
-- INSERT SAMPLE DATA
-- =============================================================================

-- Insert default admin user (password should be hashed in real implementation)
INSERT INTO users (username, password, email, full_name, role) VALUES 
('admin', '$2b$10$example_hashed_password', 'admin@contextcraft.com', 'System Administrator', 'admin');

-- Insert existing test data (if needed)
-- This preserves any existing connector data
-- You can add INSERT statements here to preserve existing data

-- =============================================================================
-- COMMENTS FOR DOCUMENTATION
-- =============================================================================

-- Table comments
COMMENT ON TABLE users IS 'System users with authentication and role management';
COMMENT ON TABLE connectors IS 'Data source connectors for importing documents from various sources (S3, GCS, Azure, etc.)';
COMMENT ON TABLE parser_profiles IS 'Document parser configurations for extracting text and structure from various file formats';
COMMENT ON TABLE pipelines IS 'Complete document processing pipelines with ReactFlow configuration';
COMMENT ON TABLE api_endpoints IS 'Published API endpoints for accessing processed data';

-- Column comments for key JSONB fields
COMMENT ON COLUMN connectors.config IS 'Connector-specific configuration: AWS credentials, GCS service account, Azure connection strings, etc.';
COMMENT ON COLUMN parser_profiles.config IS 'Parser-specific configuration: API keys, model settings, processing parameters, etc.';
COMMENT ON COLUMN pipelines.config IS 'Complete pipeline configuration including all stages and their settings';
COMMENT ON COLUMN pipelines.nodes IS 'ReactFlow nodes configuration for visual pipeline designer';
COMMENT ON COLUMN pipelines.edges IS 'ReactFlow edges configuration showing pipeline flow connections';