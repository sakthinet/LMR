import os
from pathlib import Path
import logging

# Optionally apply a Pydantic schema generation monkeypatch.
# This patch was introduced to work around specific pydantic internals,
# but it can interfere with OpenAPI schema generation. It is disabled by
# default; set the environment variable APPLY_PYDANTIC_PATCH=1 to enable it.
if os.getenv("APPLY_PYDANTIC_PATCH", "0") in ("1", "true", "True"):
    try:
        from pydantic_patch import patch_pydantic_schema_generation
        patch_pydantic_schema_generation()
        print("Applied Pydantic schema generation patch (APPLY_PYDANTIC_PATCH=1)")
    except Exception as e:
        print(f"Failed to apply Pydantic patch: {e}")
else:
    # Keep startup logs clean; do not apply the monkeypatch by default.
    print("Pydantic patch not applied (set APPLY_PYDANTIC_PATCH=1 to enable)")

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from core.router_loader import load_router_for_config
from airflow_token import airflow_token_manager  # dynamic token manager
from config import settings

from mcp_server.server import server as mcp_server
import threading
from contextlib import asynccontextmanager

# Routers
from routes.parser import router as parser_router
from routes.pipeline import router as pipeline_router
from routes.rbac import router as rbac_router
from routes.metrics import router as metrics_router
from routes.search_api import router as search_api_router
from routes.ingest import router as ingest_router
from routes.vectorize import router as vectorize_router
from routes.textprocessing import router as textprocessing_router
from routes.chunk import router as chunk_router
from routes.export import router as export_router
from routes.profiles import router as profiles_router
from routes.process import router as process_router
from routes.jobs import router as jobs_router
from routes.health import router as health_router
from routes.testfiles import router as testfiles_router
from routes.evaluation import router as evaluation_router

# --- Lifespan event handler replacing deprecated on_event ---
@asynccontextmanager
async def lifespan(app):
    # Expose MCP over HTTP by mounting its ASGI app if supported by the installed MCP package.
    try:
        http_app_getter = getattr(mcp_server, "streamable_http_app", None)
        if callable(http_app_getter):
            app.mount("/mcp", http_app_getter())
            logging.getLogger("contextcraft").info("Mounted MCP HTTP app at /mcp")
        else:
            logging.getLogger("contextcraft").warning(
                "MCP streamable HTTP app not available; skipping HTTP mount. Use stdio runner for desktop clients."
            )
    except Exception as e:
        logging.getLogger("contextcraft").error("Failed mounting MCP HTTP app: %s", e)

    # Initialize token manager
    try:
        airflow_token_manager.initialize()
        logging.getLogger("contextcraft").info("Airflow token manager initialized.")
    except Exception as e:
        logging.getLogger("contextcraft").error("Failed initializing Airflow token manager: %s", e)
    yield

app = FastAPI(title="ContextCraft", lifespan=lifespan)

# --- CORS ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

mounted_routers = {}

# --- Logging ---
logging.basicConfig(level=logging.INFO if not settings.debug else logging.DEBUG)
logger = logging.getLogger("contextcraft")
logger.debug("Loaded settings environment=%s debug=%s", settings.environment, settings.debug)

# Override any echo flags globally
import sqlalchemy
for eng in ["sqlalchemy.engine", "sqlalchemy.pool", "sqlalchemy.dialects", "sqlalchemy.orm"]:
    logging.getLogger(eng).setLevel(logging.WARNING)
# Disable engine echo even if settings.debug True
try:
    from database import engine, sync_engine
    engine.echo = False
    sync_engine.echo = False
except Exception:  # noqa: BLE001
    pass

# Include static routers
app.include_router(parser_router)
app.include_router(pipeline_router)
app.include_router(rbac_router)
app.include_router(metrics_router)
app.include_router(search_api_router)
app.include_router(ingest_router)
app.include_router(vectorize_router)
app.include_router(textprocessing_router)
app.include_router(chunk_router)
app.include_router(export_router)
app.include_router(profiles_router)
app.include_router(process_router)
app.include_router(jobs_router)
app.include_router(health_router, prefix="/system", tags=["System"])
app.include_router(testfiles_router)
app.include_router(evaluation_router)

def start_mcp_server():
    # Retained for backward compatibility; now unused because lifespan starts MCP.
    print("Starting MCP Server on port 9000...")
    mcp_server.run(host="0.0.0.0", port=9000)

# -------- Load dynamic generated routers on Startup --------
# Note: Dynamic routers are excluded from OpenAPI schema to prevent third-party
# library conflicts (e.g., qdrant-client) from breaking Swagger/OpenAPI generation
generated_dir = Path("generated_apis")
for pyfile in generated_dir.glob("*_router.py"):
    module_name = pyfile.stem.replace("_router", "")
    try:
        router = load_router_for_config(module_name)
        prefix = f"/api/{module_name}"
        app.include_router(router, prefix=prefix, include_in_schema=False)
        mounted_routers[module_name] = {"router": router, "prefix": prefix}
        logger.info(f"Loaded dynamic router: {module_name} (excluded from OpenAPI schema)")
    except Exception as e:  # noqa: BLE001
        logger.error(f"Failed to load {pyfile}: {e}")

# ---- OpenTelemetry Tracing (auto-instrumented) ----
try:
    from otel_setup import init_tracing, add_baggage_to_span_middleware

    init_tracing(app)
    # Install baggage->span middleware (copy selected keys if desired).
    # Provide a list of keys you care about to avoid copying all baggage.
    # Passing None will copy all baggage entries into span attributes.
    add_baggage_to_span_middleware(app, baggage_keys=None)
    logger.info("OpenTelemetry tracing initialized (with baggage middleware).")
except Exception as e:  # noqa: BLE001
    logger.error("Failed to initialize OpenTelemetry tracing: %s", e)
