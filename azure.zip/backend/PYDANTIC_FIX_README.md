# Pydantic OpenAPI Schema Generation Bug Fix

## Problem
The FastAPI `/openapi.json` endpoint was failing with a 500 Internal Server Error:
```
AttributeError: '_SpecialForm' object has no attribute 'replace'
```

## Root Cause
Starting in Pydantic 2.10.0, the `CoreSchemaOrFieldType` type annotation was changed to use nested `Literal` types:
```python
CoreSchemaOrFieldType = Literal[
    Literal['invalid', 'any', 'none', ...],  # CoreSchemaType
    Literal['model-field', 'dataclass-field', ...]  # CoreSchemaFieldType  
]
```

The `build_schema_type_to_method()` function in `pydantic/json_schema.py` uses `get_literal_values()` to extract the string values from this type. However, `get_literal_values()` was not recursively unpacking nested `Literal` types, so it returned the `_GenericAlias` objects instead of the actual string values.

When the code tried to call `.replace()` on these `_GenericAlias` objects (which are typing special forms), it failed.

## Solution
Created a monkeypatch in `pydantic_patch.py` that:
1. Properly unpacks the nested `Literal` types in `CoreSchemaOrFieldType`
2. Extracts the actual string values from each union member
3. Applies the patch before any Pydantic schema generation occurs

The patch is applied at the very beginning of `main.py` before any other imports.

## Changes Made
1. **Created `pydantic_patch.py`**: Contains the `patch_pydantic_schema_generation()` function
2. **Modified `main.py`**: Imports and applies the patch before FastAPI initialization
3. **Updated `requirements.txt`**: Pinned Pydantic to version 2.9.2 with documentation explaining why

## Testing
- ✅ `/openapi.json` now returns HTTP 200
- ✅ `/docs` (Swagger UI) loads successfully
- ✅ All endpoints are properly documented in the OpenAPI schema

## Future Work
This bug has been reported to the Pydantic maintainers. Once a proper fix is released in a future version, we can:
1. Upgrade to the fixed version
2. Remove the monkeypatch from `main.py`
3. Delete `pydantic_patch.py`
4. Update `requirements.txt` to use the latest stable version

## Version Compatibility
- **Works**: Pydantic 2.9.2 (with patch)
- **Broken**: Pydantic 2.10.0, 2.11.3 (without patch)
- **Tested**: FastAPI 0.110.2, Python 3.9.0
