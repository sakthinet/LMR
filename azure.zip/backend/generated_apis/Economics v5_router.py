import time
import asyncpg
import asyncio
import math
import os
from typing import List, Dict, Any, Optional, Tuple
from fastapi import APIRouter, Request
from pydantic import BaseModel
import httpx
from qdrant_client import QdrantClient
from qdrant_client.models import SearchParams
import json
import logging
from datetime import datetime, timedelta
router = APIRouter()

# Config Guide
# Embedding providers (allowed): Ollama, GCP, Azure, AWS, Hugging Face
# Provider env vars:
# - Ollama: OLLAMA host defaults to http://localhost:11434
# - GCP: GCP_PROJECT_ID, GCP_LOCATION (optional, default us-central1), GOOGLE_APPLICATION_CREDENTIALS
# - Azure: AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION (optional)
#          Optional per-model deployment overrides:
#          AZURE_OPENAI_EMBEDDING_DEPLOYMENT_TEXT_EMBEDDING_3_LARGE
#          AZURE_OPENAI_EMBEDDING_DEPLOYMENT_TEXT_EMBEDDING_3_SMALL
#          AZURE_OPENAI_EMBEDDING_DEPLOYMENT_TEXT_EMBEDDING_ADA_002
# - AWS: AWS_REGION (optional, default us-east-1), AWS credentials configured in environment/role
# - Hugging Face: HUGGINGFACE_API_KEY or HF_TOKEN, HUGGINGFACE_INFERENCE_URL (optional)
#
# Embedding model selection:
# - EMBEDDING_MODEL must be one of SUPPORTED_EMBEDDING_MODELS[provider]
# - If empty, first model in provider list is used as default
#
# Response formats (RESPONSE_FORMAT):
# - standard (aliases: default, simple)
# - openai (alias: openai_compatible)
# - elasticsearch (aliases: elastic, es)

# Configuration from SearchConfig (auto-populated from profile)
BASE_NAME = "Economics"
COLLECTION_NAME = "Economics"
CHUNK_TABLE_NAME = BASE_NAME + "_chunk" if BASE_NAME else "document_chunk"
METADATA_TABLE_NAME = BASE_NAME + "_document_metadata" if BASE_NAME else "document_metadata"
DATA_STORE_TYPE = "postgres"  # Postgres, MSSQL, etc.
VECTOR_STORE_TYPE = "qdrant"  # Qdrant, Pinecone, Milvus, etc.
DOC_ID_COLUMN = "folder_id"
TOP_K = 5
RETRIEVAL_MODE = "hybrid"
EMBEDDING_PROVIDER = "ollama"
EMBEDDING_MODEL = "nomic-embed-text"
API_NAME = "Economics v5"
logger = logging.getLogger(f"api.{API_NAME}")

SUPPORTED_EMBEDDING_PROVIDERS = ["ollama", "gcp", "azure", "aws", "huggingface"]
SUPPORTED_EMBEDDING_MODELS = {
    "ollama": [
        "mxbai-embed-large",
        "nomic-embed-text",
        "bge-m3"
    ],
    "gcp": [
        "text-embedding-005",
        "text-multilingual-embedding-002",
        "gemini-embedding-001"
    ],
    "azure": [
        "text-embedding-3-large",
        "text-embedding-3-small",
        "text-embedding-ada-002"
    ],
    "aws": [
        "amazon.titan-embed-text-v2:0",
        "cohere.embed-english-v3",
        "cohere.embed-multilingual-v3"
    ],
    "huggingface": [
        "BAAI/bge-m3",
        "intfloat/multilingual-e5-large-instruct",
        "sentence-transformers/all-mpnet-base-v2"
    ]
}



# Advanced Search Parameters
MAX_PAYLOAD_LENGTH = 500
CANDIDATE_LIMIT = 50
HYBRID_ALPHA = 0.5
HNSW_EF = 128
SCORE_THRESHOLD = 0.0

# Response Configuration
RESPONSE_FORMAT = "Standard"
INCLUDE_METADATA = True
INCLUDE_CHUNK_METADATA = True
INCLUDE_SCORES = True

# Performance Configuration
TIMEOUT_DURATION = 3000

# In-memory cache for search results
_SEARCH_CACHE = {} 

async def log_api_call(api_name, collection, query, top_k, mode, model, ip, agent, results_count, top_score, success, error, duration, source):
    """Log API call details to the database (only Postgres currently supported)"""
    if DATA_STORE_TYPE.lower() not in ['postgres', 'postgresql']:
        return # Logging to DB currently optimized for Postgres
        
    log_query = """
        INSERT INTO search_api_logs (
            api_name, collection_name, query_text,
            top_k, retrieval_mode, embedding_model,
            caller_ip, user_agent,
            num_results, top_result_score,
            is_success, error_message, response_time_ms, source
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
    """
    try:
        conn = await asyncpg.connect(CHUNK_DB_DSN)
        await conn.execute(log_query, api_name, collection, query, top_k, mode, model, ip, agent, results_count, top_score, success, error, duration, source)
        await conn.close()
    except Exception as e:
        print(f"Failed to log API call: {e}")

# Database Connection Configuration (auto-handled based on profile)
# Chunk Data Store Connection
if DATA_STORE_TYPE.lower() in ['postgres', 'postgresql']:
    # PostgreSQL connection from environment (normalize asyncpg DSN if present)
    _raw_dsn = os.getenv('DB_DSN') or os.getenv('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/RND')
    if '+asyncpg' in _raw_dsn:
        _raw_dsn = _raw_dsn.replace('+asyncpg', '')
    CHUNK_DB_DSN = _raw_dsn
elif DATA_STORE_TYPE.lower() in ['mssql', 'sqlserver']:
    # MSSQL connection from environment
    import pyodbc
    MSSQL_HOST = os.getenv('MSSQL_HOST', 'localhost')
    MSSQL_PORT = os.getenv('MSSQL_PORT', '1433')
    MSSQL_USER = os.getenv('MSSQL_USER', 'sa')
    MSSQL_PASSWORD = os.getenv('MSSQL_PASSWORD', '')
    MSSQL_DATABASE = os.getenv('MSSQL_DATABASE', 'RND')
    MSSQL_DRIVER = os.getenv('MSSQL_DRIVER', 'ODBC Driver 17 for SQL Server')
    CHUNK_DB_DSN = f"DRIVER={{{MSSQL_DRIVER}}};SERVER={MSSQL_HOST},{MSSQL_PORT};DATABASE={MSSQL_DATABASE};UID={MSSQL_USER};PWD={MSSQL_PASSWORD}"
else:
    # Default to PostgreSQL
    _raw_dsn = os.getenv('DB_DSN') or os.getenv('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/RND')
    if '+asyncpg' in _raw_dsn:
        _raw_dsn = _raw_dsn.replace('+asyncpg', '')
    CHUNK_DB_DSN = _raw_dsn

# Vector Store Client (auto-handled based on profile)
if VECTOR_STORE_TYPE.lower() == 'qdrant':
    QDRANT_HOST = os.getenv('QDRANT_HOST', 'localhost')
    QDRANT_PORT = int(os.getenv('QDRANT_PORT', '6333'))
    QDRANT_API_KEY = os.getenv('QDRANT_API_KEY', None)
    qdrant = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT, api_key=QDRANT_API_KEY)
    vector_client = qdrant
elif VECTOR_STORE_TYPE.lower() == 'pinecone':
    import pinecone
    PINECONE_API_KEY = os.getenv('PINECONE_API_KEY')
    PINECONE_ENV = os.getenv('PINECONE_ENVIRONMENT', 'us-west1-gcp')
    pinecone.init(api_key=PINECONE_API_KEY, environment=PINECONE_ENV)
    vector_client = pinecone.Index(COLLECTION_NAME)
elif VECTOR_STORE_TYPE.lower() == 'milvus':
    from pymilvus import connections, Collection
    MILVUS_HOST = os.getenv('MILVUS_HOST', 'localhost')
    MILVUS_PORT = os.getenv('MILVUS_PORT', '19530')
    connections.connect(host=MILVUS_HOST, port=MILVUS_PORT)
    vector_client = Collection(COLLECTION_NAME)
elif VECTOR_STORE_TYPE.lower() == 'weaviate':
    import weaviate
    WEAVIATE_URL = os.getenv('WEAVIATE_URL', 'http://localhost:8080')
    WEAVIATE_API_KEY = os.getenv('WEAVIATE_API_KEY', None)
    vector_client = weaviate.Client(url=WEAVIATE_URL, auth_client_secret=weaviate.AuthApiKey(WEAVIATE_API_KEY) if WEAVIATE_API_KEY else None)
else:
    # Default to Qdrant
    qdrant = QdrantClient(host="localhost", port=6333)
    vector_client = qdrant




class QueryInput(BaseModel):
    search_term: str

# Database Connection Helpers
async def get_chunk_db_connection():
    """Get database connection based on DATA_STORE_TYPE"""
    if DATA_STORE_TYPE.lower() in ['postgres', 'postgresql']:
        return await asyncpg.connect(CHUNK_DB_DSN)
    elif DATA_STORE_TYPE.lower() in ['mssql', 'sqlserver']:
        # For MSSQL, return pyodbc connection (synchronous)
        return pyodbc.connect(CHUNK_DB_DSN)
    else:
        # Default to PostgreSQL
        return await asyncpg.connect(CHUNK_DB_DSN)

async def execute_chunk_query(query: str, *params):
    """Execute query on chunk database with timeout support (Postgres/MSSQL)"""
    timeout = TIMEOUT_DURATION / 1000.0
    
    if DATA_STORE_TYPE.lower() in ['postgres', 'postgresql']:
        # Use asyncpg for PostgreSQL
        try:
            conn = await asyncio.wait_for(asyncpg.connect(CHUNK_DB_DSN), timeout=timeout)
            try:
                results = await asyncio.wait_for(conn.fetch(query, *params), timeout=timeout)
                return [dict(r) for r in results]
            finally:
                await conn.close()
        except asyncio.TimeoutError:
            logger.error(f"PostgreSQL query timed out after {timeout}s")
            raise Exception("Database query timed out")
    
    elif DATA_STORE_TYPE.lower() in ['mssql', 'sqlserver']:
        # Use pyodbc for MSSQL (synchronous, wrap in executor)
        loop = asyncio.get_running_loop()
        def _run_mssql():
            conn = pyodbc.connect(CHUNK_DB_DSN, timeout=int(timeout))
            try:
                cursor = conn.cursor()
                # Convert PostgreSQL-style $1, $2 to MSSQL ? placeholders
                mssql_query = query
                for i in range(len(params), 0, -1):
                    mssql_query = mssql_query.replace(f'${i}', '?')
                
                cursor.execute(mssql_query, params)
                columns = [column[0] for column in cursor.description]
                results = [dict(zip(columns, row)) for row in cursor.fetchall()]
                return results
            finally:
                conn.close()
        
        try:
            return await asyncio.wait_for(loop.run_in_executor(None, _run_mssql), timeout=timeout + 1.0)
        except asyncio.TimeoutError:
            logger.error(f"MSSQL query timed out after {timeout}s")
            raise Exception("Database query timed out")
    return []


# PostgreSQL table-name resolution helpers (case-insensitive safety)
CHUNK_DB_SCHEMA = os.getenv("CHUNK_DB_SCHEMA", "public")
_TABLE_NAME_CACHE: Dict[str, str] = {}


def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


async def _resolve_postgres_table_name(configured_name: str) -> str:
    """Resolve actual PostgreSQL table name (case-insensitive) within schema."""
    cache_key = f"{CHUNK_DB_SCHEMA}.{configured_name}".lower()
    cached = _TABLE_NAME_CACHE.get(cache_key)
    if cached:
        return cached

    timeout = TIMEOUT_DURATION / 1000.0
    lookup_sql = """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = $1
          AND lower(table_name) = lower($2)
        ORDER BY CASE WHEN table_name = $2 THEN 0 ELSE 1 END, table_name
        LIMIT 1
    """

    conn = None
    try:
        conn = await asyncio.wait_for(asyncpg.connect(CHUNK_DB_DSN), timeout=timeout)
        row = await asyncio.wait_for(conn.fetchrow(lookup_sql, CHUNK_DB_SCHEMA, configured_name), timeout=timeout)
        if not row:
            raise Exception(
                f"relation '{configured_name}' does not exist in schema '{CHUNK_DB_SCHEMA}'"
            )
        resolved = str(row["table_name"])
        _TABLE_NAME_CACHE[cache_key] = resolved
        return resolved
    finally:
        if conn is not None:
            await conn.close()


async def _resolve_table_refs() -> Tuple[str, str, str, str]:
    """Return (chunk_ref, metadata_ref, chunk_plain, metadata_plain)."""
    chunk_name = CHUNK_TABLE_NAME
    metadata_name = METADATA_TABLE_NAME

    if DATA_STORE_TYPE.lower() in ['postgres', 'postgresql']:
        chunk_name = await _resolve_postgres_table_name(CHUNK_TABLE_NAME)
        metadata_name = await _resolve_postgres_table_name(METADATA_TABLE_NAME)
        chunk_ref = f"{_quote_ident(CHUNK_DB_SCHEMA)}.{_quote_ident(chunk_name)}"
        metadata_ref = f"{_quote_ident(CHUNK_DB_SCHEMA)}.{_quote_ident(metadata_name)}"
        return chunk_ref, metadata_ref, chunk_name, metadata_name

    # Non-Postgres stores keep existing behavior
    return chunk_name, metadata_name, chunk_name, metadata_name

async def search_vector_store(vector: List[float], limit: int):
    """Search vector store based on selected provider with timeout support"""
    timeout = TIMEOUT_DURATION / 1000.0
    
    if VECTOR_STORE_TYPE.lower() == 'qdrant':
        # Qdrant client is partially sync, we wrap the search
        loop = asyncio.get_running_loop()
        try:
            hits = await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: qdrant.search(
                        collection_name=COLLECTION_NAME,
                        query_vector=vector,
                        limit=limit,
                        search_params=SearchParams(hnsw_ef=HNSW_EF),
                    )
                ),
                timeout=timeout
            )
            return hits
        except asyncio.TimeoutError:
            logger.error(f"Qdrant search timed out after {timeout}s")
            return []
            
    elif VECTOR_STORE_TYPE.lower() == 'pinecone':
        try:
            results = vector_client.query(vector=vector, top_k=limit, include_metadata=True)
            return results['matches']
        except Exception as e:
            logger.error(f"Pinecone search failed: {e}")
            return []
            
    elif VECTOR_STORE_TYPE.lower() == 'milvus':
        try:
            search_params = {"metric_type": "COSINE", "params": {"ef": HNSW_EF}}
            results = vector_client.search(
                data=[vector],
                anns_field="embedding",
                param=search_params,
                limit=limit
            )
            return results[0]
        except Exception as e:
            logger.error(f"Milvus search failed: {e}")
            return []
            
    elif VECTOR_STORE_TYPE.lower() == 'weaviate':
        try:
            result = vector_client.query.get(
                COLLECTION_NAME, ["chunk_id", "chunk_text"]
            ).with_near_vector({"vector": vector}).with_limit(limit).do()
            return result['data']['Get'][COLLECTION_NAME]
        except Exception as e:
            logger.error(f"Weaviate search failed: {e}")
            return []
    return []

def truncate_payload(payload: dict, max_length: int) -> dict:
    truncated = {}
    for key, value in payload.items():
        if isinstance(value, str) and len(value) > max_length:
            truncated[key] = value[:max_length] + "..."
        else:
            truncated[key] = value
    return truncated

def normalize_embedding_provider(provider: str) -> str:
    if not provider:
        return "ollama"
    normalized = provider.strip().lower().replace("_", "").replace("-", "").replace(" ", "")
    aliases = {
        "ollama": "ollama",
        "gcp": "gcp",
        "googlecloud": "gcp",
        "vertexai": "gcp",
        "azure": "azure",
        "azureopenai": "azure",
        "aws": "aws",
        "bedrock": "aws",
        "huggingface": "huggingface",
        "hf": "huggingface"
    }
    return aliases.get(normalized, normalized)

def resolve_embedding_model(provider: str, requested_model: str) -> str:
    supported = SUPPORTED_EMBEDDING_MODELS.get(provider, [])
    model = (requested_model or "").strip()
    if not model:
        return supported[0] if supported else ""
    if model in supported:
        return model
    raise Exception(f"Unsupported embedding model '{model}' for provider '{provider}'. Supported models: {supported}")

async def get_embedding_from_ollama(text: str, model: str, timeout: float):
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(
            "http://localhost:11434/api/embeddings",
            json={"model": model, "prompt": text}
        )
        response.raise_for_status()
        return response.json()["embedding"]

async def get_embedding_from_gcp(text: str, model: str, timeout: float):
    project_id = os.getenv("GCP_PROJECT_ID")
    location = os.getenv("GCP_LOCATION", "us-central1")
    if not project_id:
        raise Exception("GCP_PROJECT_ID is required for GCP embeddings")

    try:
        from google.auth.transport.requests import Request
        from google.oauth2 import service_account
    except Exception as e:
        raise Exception(f"google-auth dependency is required for GCP embeddings: {e}")

    credentials_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
    if not credentials_path:
        raise Exception("GOOGLE_APPLICATION_CREDENTIALS is required for GCP embeddings")

    credentials = service_account.Credentials.from_service_account_file(
        credentials_path,
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )
    credentials.refresh(Request())

    url = f"https://{location}-aiplatform.googleapis.com/v1/projects/{project_id}/locations/{location}/publishers/google/models/{model}:predict"
    body = {"instances": [{"content": text}]}
    headers = {
        "Authorization": f"Bearer {credentials.token}",
        "Content-Type": "application/json"
    }

    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(url, headers=headers, json=body)
        response.raise_for_status()
        data = response.json()

    predictions = data.get("predictions", [])
    if not predictions:
        raise Exception(f"No predictions returned from GCP model '{model}'")

    first = predictions[0]
    if "embeddings" in first and "values" in first["embeddings"]:
        return first["embeddings"]["values"]
    if "values" in first:
        return first["values"]
    raise Exception(f"Unexpected GCP embedding response format for model '{model}'")

async def get_embedding_from_azure(text: str, model: str, timeout: float):
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
    deployment_map = {
        "text-embedding-3-large": os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_TEXT_EMBEDDING_3_LARGE", "text-embedding-3-large"),
        "text-embedding-3-small": os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_TEXT_EMBEDDING_3_SMALL", "text-embedding-3-small"),
        "text-embedding-ada-002": os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT_TEXT_EMBEDDING_ADA_002", "text-embedding-ada-002")
    }

    if not endpoint or not api_key:
        raise Exception("AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY are required for Azure embeddings")

    deployment = deployment_map.get(model)
    if not deployment:
        raise Exception(f"No Azure deployment configured for model '{model}'")

    url = f"{endpoint.rstrip('/')}/openai/deployments/{deployment}/embeddings?api-version={api_version}"
    headers = {"api-key": api_key, "Content-Type": "application/json"}
    payload = {"input": text}

    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(url, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()

    return data["data"][0]["embedding"]

async def get_embedding_from_aws(text: str, model: str, timeout: float):
    try:
        import boto3
    except Exception as e:
        raise Exception(f"boto3 dependency is required for AWS embeddings: {e}")

    region = os.getenv("AWS_REGION", "us-east-1")
    session = boto3.session.Session(region_name=region)
    bedrock = session.client("bedrock-runtime")

    if model.startswith("amazon.titan"):
        body = json.dumps({"inputText": text})
    elif model.startswith("cohere.embed"):
        body = json.dumps({"texts": [text], "input_type": "search_query"})
    else:
        raise Exception(f"Unsupported AWS embedding model '{model}'")

    loop = asyncio.get_running_loop()
    response = await loop.run_in_executor(
        None,
        lambda: bedrock.invoke_model(modelId=model, body=body)
    )

    payload = json.loads(response["body"].read())
    if "embedding" in payload:
        return payload["embedding"]
    if "embeddings" in payload and payload["embeddings"]:
        return payload["embeddings"][0]
    raise Exception(f"Unexpected AWS embedding response format for model '{model}'")

async def get_embedding_from_huggingface(text: str, model: str, timeout: float):
    api_token = os.getenv("HUGGINGFACE_API_KEY") or os.getenv("HF_TOKEN")
    inference_base = os.getenv("HUGGINGFACE_INFERENCE_URL", "https://api-inference.huggingface.co")
    url = f"{inference_base.rstrip('/')}/pipeline/feature-extraction/{model}"
    headers = {"Content-Type": "application/json"}
    if api_token:
        headers["Authorization"] = f"Bearer {api_token}"

    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(url, headers=headers, json={"inputs": text})
        response.raise_for_status()
        data = response.json()

    if isinstance(data, list) and data and isinstance(data[0], list):
        if data and data[0] and isinstance(data[0][0], (int, float)):
            return data[0]
        if data and data[0] and isinstance(data[0][0], list):
            token_vectors = data[0]
            dims = len(token_vectors[0])
            pooled = [0.0] * dims
            for token_vec in token_vectors:
                for i in range(dims):
                    pooled[i] += float(token_vec[i])
            return [v / max(len(token_vectors), 1) for v in pooled]
    raise Exception(f"Unexpected Hugging Face embedding response format for model '{model}'")

def build_standard_response(query_text: str, retrieval_mode: str, final_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        "status": "success",
        "query": query_text,
        "retrieval_mode": retrieval_mode,
        "results": final_results
    }

def build_openai_response(query_text: str, retrieval_mode: str, final_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    data = []
    for idx, item in enumerate(final_results):
        data.append({
            "object": "retrieval.result",
            "index": idx,
            "id": item.get("chunk_id"),
            "score": item.get("score"),
            "content": item.get("chunk_text"),
            "metadata": {
                "doc_id": item.get("doc_id"),
                "chunk_metadata": item.get("chunk_metadata"),
                "document_metadata": item.get("document_metadata")
            }
        })
    return {
        "object": "list",
        "status": "success",
        "query": query_text,
        "retrieval_mode": retrieval_mode,
        "data": data,
        "has_more": False
    }

def build_elasticsearch_response(query_text: str, retrieval_mode: str, final_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    hits = []
    for item in final_results:
        hits.append({
            "_id": item.get("chunk_id"),
            "_score": item.get("score"),
            "_source": {
                "chunk_text": item.get("chunk_text"),
                "doc_id": item.get("doc_id"),
                "chunk_metadata": item.get("chunk_metadata"),
                "document_metadata": item.get("document_metadata")
            }
        })
    max_score = max([h["_score"] for h in hits if h.get("_score") is not None], default=None)
    return {
        "status": "success",
        "query": query_text,
        "retrieval_mode": retrieval_mode,
        "hits": {
            "total": {"value": len(hits), "relation": "eq"},
            "max_score": max_score,
            "hits": hits
        }
    }

def build_formatted_response(query_text: str, retrieval_mode: str, final_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    fmt = (RESPONSE_FORMAT or "standard").strip().lower().replace("-", "_")
    if fmt in ["standard", "default", "simple"]:
        return build_standard_response(query_text, retrieval_mode, final_results)
    if fmt in ["openai", "openai_compatible"]:
        return build_openai_response(query_text, retrieval_mode, final_results)
    if fmt in ["elasticsearch", "elastic", "es"]:
        return build_elasticsearch_response(query_text, retrieval_mode, final_results)
    logger.warning(f"Unsupported response format '{RESPONSE_FORMAT}', falling back to standard")
    return build_standard_response(query_text, retrieval_mode, final_results)

async def get_embedding(text: str):
    """Get embedding from configured provider with timeout"""
    timeout = TIMEOUT_DURATION / 1000.0

    provider = normalize_embedding_provider(EMBEDDING_PROVIDER)
    if provider not in SUPPORTED_EMBEDDING_PROVIDERS:
        raise Exception(f"Unsupported embedding provider '{EMBEDDING_PROVIDER}'. Supported providers: {SUPPORTED_EMBEDDING_PROVIDERS}")

    model = resolve_embedding_model(provider, EMBEDDING_MODEL)

    if provider == "ollama":
        return await get_embedding_from_ollama(text, model, timeout)
    if provider == "gcp":
        return await get_embedding_from_gcp(text, model, timeout)
    if provider == "azure":
        return await get_embedding_from_azure(text, model, timeout)
    if provider == "aws":
        return await get_embedding_from_aws(text, model, timeout)
    if provider == "huggingface":
        return await get_embedding_from_huggingface(text, model, timeout)

    raise Exception(f"Embedding provider routing failed for '{provider}'")

@router.post("/search")
async def search(input: QueryInput, request: Request):
    query_text = input.search_term
    start_time = time.time()
    
    # Context info for logging
    caller_ip = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")
    source = request.headers.get("X-Source", "default")

    # Metrics for logging
    status = True
    error_message = None
    num_results = 0
    top_result_score = None

    try:
        chunk_table_ref, metadata_table_ref, chunk_table_name, metadata_table_name = await _resolve_table_refs()

        # Step 1: Get embedding (required for semantic/hybrid)
        vector = None
        if RETRIEVAL_MODE.lower() in ["semantic", "hybrid"]:
            try:
                vector = await get_embedding(query_text)
            except Exception as e:
                raise Exception(f"Embedding generation failed: {str(e)}")

        # Step 2: Candidate Collection
        candidates: Dict[str, Dict[str, Any]] = {}
        pg_text_max = 0.0
        vector_score_max = 0.0

        # Step 2a: Keyword Search (Keyword or Hybrid)
        if RETRIEVAL_MODE.lower() in ["keyword", "hybrid"]:
            keyword_rows = await execute_chunk_query(
                f"""
                SELECT chunk_id::text as chunk_id, "{DOC_ID_COLUMN}"::text as doc_id, chunk_text, metadata_json,
                       ts_rank(to_tsvector('english', coalesce(chunk_text, '')), plainto_tsquery($1)) as text_rank
                  FROM {chunk_table_ref}
                WHERE to_tsvector('english', coalesce(chunk_text, '')) @@ plainto_tsquery($1)
                ORDER BY text_rank DESC
                LIMIT $2
                """,
                query_text,
                CANDIDATE_LIMIT
            )
            for r in keyword_rows:
                cid = r["chunk_id"]
                rank = float(r["text_rank"] or 0.0)
                candidates[cid] = {
                    "chunk_id": cid,
                    "doc_id": r["doc_id"],
                    "chunk_text": r["chunk_text"],
                    "chunk_metadata": r["metadata_json"],
                    "text_rank": rank,
                    "vector_score": 0.0
                }
                if rank > pg_text_max:
                    pg_text_max = rank

        # Step 2b: Vector Search (Semantic or Hybrid)
        if vector and RETRIEVAL_MODE.lower() in ["semantic", "hybrid"]:
            vector_hits = await search_vector_store(vector, CANDIDATE_LIMIT)
            for hit in vector_hits:
                # Handle different vector store response formats
                if VECTOR_STORE_TYPE.lower() == 'qdrant':
                    cid = str(hit.id)
                    score = float(getattr(hit, "score", 0.0))
                elif VECTOR_STORE_TYPE.lower() == 'pinecone':
                    cid = str(hit.id)
                    score = float(hit.score or 0.0)
                else:
                    cid = str(getattr(hit, 'id', ''))
                    score = float(getattr(hit, 'score', 0.0))
                
                if score > vector_score_max:
                    vector_score_max = score
                
                if cid in candidates:
                    candidates[cid]["vector_score"] = score
                else:
                    candidates[cid] = {
                        "chunk_id": cid,
                        "doc_id": None,
                        "chunk_text": None,
                        "chunk_metadata": None,
                        "text_rank": 0.0,
                        "vector_score": score
                    }

        if not candidates:
            return build_formatted_response(query_text, RETRIEVAL_MODE, [])

        # Step 2c: Fetch missing details for vector candidates
        missing_ids = [cid for cid, v in candidates.items() if v["chunk_text"] is None]
        if missing_ids:
            # Handle list params for different DBs
            if DATA_STORE_TYPE.lower() in ['postgres', 'postgresql']:
                rows = await execute_chunk_query(
                    f"SELECT chunk_id::text, \"{DOC_ID_COLUMN}\"::text as doc_id, chunk_text, metadata_json FROM {chunk_table_ref} WHERE chunk_id = ANY($1::uuid[])",
                    missing_ids
                )
            else:
                placeholders = ",".join(["?"] * len(missing_ids))
                rows = await execute_chunk_query(
                    f"SELECT chunk_id, {DOC_ID_COLUMN} as doc_id, chunk_text, metadata_json FROM {chunk_table_name} WHERE chunk_id IN ({placeholders})",
                    *missing_ids
                )
            for r in rows:
                cid = r["chunk_id"]
                if cid in candidates:
                    candidates[cid].update({
                        "doc_id": r["doc_id"],
                        "chunk_text": r["chunk_text"],
                        "chunk_metadata": r["metadata_json"]
                    })

        # Step 3: Scoring & Ranking
        pg_text_max = pg_text_max if pg_text_max > 0 else 1.0
        vector_score_max = vector_score_max if vector_score_max > 0 else 1.0
        
        # Retrieval Weights
        if RETRIEVAL_MODE.lower() == "keyword":
            v_w, t_w = 0.0, 1.0
        elif RETRIEVAL_MODE.lower() == "semantic":
            v_w, t_w = 1.0, 0.0
        elif RETRIEVAL_MODE.lower() == "hybrid":
            v_w, t_w = HYBRID_ALPHA, (1.0 - HYBRID_ALPHA)
        else:
            raise Exception(f"Unsupported retrieval_mode: {RETRIEVAL_MODE}. Supported: keyword, semantic, hybrid")

        scored_results = []
        for cid, item in candidates.items():
            t_norm = item["text_rank"] / pg_text_max
            v_norm = item["vector_score"] / vector_score_max
            combined_score = (v_w * v_norm) + (t_w * t_norm)
            
            if combined_score >= SCORE_THRESHOLD:
                # Prepare result item
                res_item = {
                    "chunk_id": cid,
                    "score": round(combined_score, 4),
                    "chunk_text": item["chunk_text"],
                    "doc_id": item["doc_id"],
                    "chunk_metadata": item["chunk_metadata"]
                }
                # Optional: Vector Score details
                if INCLUDE_SCORES:
                    res_item["details"] = {"vector_norm": round(v_norm, 4), "text_norm": round(t_norm, 4)}
                scored_results.append(res_item)

        # Sort and limit
        scored_results.sort(key=lambda x: x["score"], reverse=True)
        top_results = scored_results[:TOP_K]

        # Step 4: Metadata Enrichment
        if INCLUDE_METADATA:
            doc_ids = list({r["doc_id"] for r in top_results if r["doc_id"]})
            if doc_ids:
                if DATA_STORE_TYPE.lower() in ['postgres', 'postgresql']:
                    doc_rows = await execute_chunk_query(
                        f"SELECT \"{DOC_ID_COLUMN}\"::text as doc_id, document_name, source_path, source_type, metadata_json FROM {metadata_table_ref} WHERE \"{DOC_ID_COLUMN}\" = ANY($1)",
                        doc_ids
                    )
                else:
                    placeholders = ",".join(["?"] * len(doc_ids))
                    doc_rows = await execute_chunk_query(
                        f"SELECT {DOC_ID_COLUMN} as doc_id, document_name, source_path, source_type, metadata_json FROM {metadata_table_name} WHERE {DOC_ID_COLUMN} IN ({placeholders})",
                        *doc_ids
                    )
                docs_map = {r["doc_id"]: r for r in doc_rows}
                for r in top_results:
                    r["document_metadata"] = docs_map.get(r["doc_id"])

        # Step 5: Final Formatting
        final_results = []
        for r in top_results:
            item = {"chunk_id": r["chunk_id"]}
            if INCLUDE_SCORES: item["score"] = r["score"]
            
            text = r["chunk_text"] or ""
            item["chunk_text"] = truncate_payload({"chunk_text": text}, MAX_PAYLOAD_LENGTH)["chunk_text"]
            
            if INCLUDE_CHUNK_METADATA: item["chunk_metadata"] = r["chunk_metadata"]
            if INCLUDE_METADATA: item["document_metadata"] = r.get("document_metadata")
            
            final_results.append(item)

        num_results = len(final_results)
        top_result_score = final_results[0]["score"] if final_results else None
        
        response = build_formatted_response(query_text, RETRIEVAL_MODE, final_results)
            
        return response

    except Exception as e:
        status = False
        error_message = str(e)
        logger.error(f"Search failed for query '{query_text}': {error_message}")
        return {"status": "error", "message": error_message}
    
    finally:
        # Logging
        duration = int((time.time() - start_time) * 1000)
        await log_api_call(
            API_NAME, COLLECTION_NAME, query_text, TOP_K, RETRIEVAL_MODE,
            EMBEDDING_MODEL, caller_ip, user_agent, num_results,
            top_result_score, status, error_message, duration, source
        )