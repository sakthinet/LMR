from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from collections.abc import AsyncGenerator  # use typing.AsyncGenerator for Python <3.9
from sqlalchemy import create_engine
from config import settings

# Use environment-provided database URL
DATABASE_URL = settings.database_url

# Force echo False to suppress SQL logging
engine = create_async_engine(DATABASE_URL, echo=False)
async_session_maker = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_maker() as session:
        yield session

# Add a synchronous engine and SessionLocal for use by sync workers (e.g. Celery tasks)
# Create a sync URL by removing the async driver suffix
DATABASE_URL_SYNC = DATABASE_URL.replace("+asyncpg", "")

sync_engine = create_engine(DATABASE_URL_SYNC, echo=False)
SessionLocal = sessionmaker(bind=sync_engine, autocommit=False, autoflush=False)
