from fastapi import Request, HTTPException
from typing import Optional
import secrets

SESSION_COOKIE = "session_token"

# Simple session token generator (not secure for production)
def create_session_token(username: str) -> str:
    return secrets.token_urlsafe(32) + "_" + username

# Dependency to get user from session cookie
def get_user_from_session(request: Request) -> Optional[str]:
    token = request.cookies.get(SESSION_COOKIE)
    if not token or "_" not in token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    username = token.split("_", 1)[1]
    return username

# Delete session cookie from response
def delete_session_cookie(response):
    response.delete_cookie(SESSION_COOKIE)
