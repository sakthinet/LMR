from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from core.models import SearchConfig

TEMPLATES_DIR = Path("templates")
GENERATED_DIR = Path("generated_apis")
GENERATED_DIR.mkdir(exist_ok=True, parents=True)

env = Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)))
template = env.get_template("search_router.py.j2")


def render_template_to_file(cfg: SearchConfig):
    output_path = GENERATED_DIR / f"{cfg.name}_router.py"
    with open(output_path, "w") as f:
        f.write(template.render(cfg=cfg))
