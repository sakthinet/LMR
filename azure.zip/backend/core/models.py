from pydantic import BaseModel, Field
from typing import Optional, List


class SearchConfig(BaseModel):
    # Core API identity
    name: str

    # Pipeline-driven inputs
    pipeline_name: Optional[str] = None
    pipeline_id: Optional[str] = None

    # Search settings from UI
    top_k: int = 10
    retrieval_mode: Optional[str] = "semantic"   # keyword, semantic, hybrid
    payload_max_length: int = 500
    hnsw_ef: int = 128
    score_threshold: float = 0.0
    candidate_limit: int = 50
    alpha: float = Field(default=0.5, ge=0.0, le=1.0)

    embedding_provider: Optional[str] = None
    embedding_model: Optional[str] = None

    response_format: str = "standard"
    include_document_metadata: bool = True
    include_chunk_metadata: bool = True
    include_scores: bool = True
    timeout_duration: int = 5000  # milliseconds

    # Internal fields (resolved from DB/profile in create/update flow)
    profile_name: Optional[str] = None
    data_store: Optional[str] = "Postgres"       # e.g. Postgres, MSSQL
    vector_store: Optional[str] = "Qdrant"       # e.g. Qdrant, Pinecone
    chunk_database: Optional[str] = None          # chunk table DB/schema name
    vector_database: Optional[str] = None         # vector collection / DB name

    # Keep default; not sourced from DB.
    doc_id_column: Optional[str] = "folder_id"


class SearchConfigCreateRequest(BaseModel):
    name: str
    pipeline_name: str

    top_k: int
    retrieval_mode: str
    payload_max_length: int
    hnsw_ef: int
    score_threshold: float
    candidate_limit: int
    alpha: float = Field(ge=0.0, le=1.0)

    embedding_provider: str
    embedding_model: str

    response_format: str
    include_document_metadata: bool
    include_chunk_metadata: bool
    include_scores: bool = True
    timeout_duration: int

class PipelineRequest(BaseModel):
    pipelineName: str
    sourceType: str
    uncPath: Optional[str] = None
    formats: List[str]
    parser: str
    preprocessing: List[str]
    targetLanguage: Optional[str] = None

    # Flattened chunking
    chunkingStrategy: str
    chunkSize: int
    chunkOverlap: int

    # Flattened embedding
    embeddingModel: str
    embeddingDimension: int

    # Flattened vector DB
    vectorDbType: str
    vectorCollection: str
    vectorMetric: str
