"""
Monkeypatch for Pydantic json_schema bug where CoreSchemaOrFieldType 
contains nested Literal types that aren't being unpacked properly.
"""
import typing
from typing import get_args

def patched_get_literal_values_recursive(annotation):
    """Recursively extract literal values from nested Literal types."""
    if not hasattr(annotation, '__args__'):
        yield annotation
        return
    
    # Check if this is a Literal type
    origin = getattr(annotation, '__origin__', None)
    if origin is typing.Literal:
        # This is a Literal, unpack its args
        for arg in annotation.__args__:
            # Recursively process each arg in case it's also a Literal
            yield from patched_get_literal_values_recursive(arg)
    else:
        # Not a Literal, just yield the annotation itself
        yield annotation

def patch_pydantic_schema_generation():
    """Apply the monkeypatch to fix Pydantic's schema generation."""
    try:
        from pydantic import json_schema
        from pydantic.json_schema import GenerateJsonSchema, CoreSchemaOrFieldType
        
        # Save the original method
        original_build = GenerateJsonSchema.build_schema_type_to_method
        
        def patched_build_schema_type_to_method(self):
            """Patched version that properly unpacks nested Literals."""
            import os
            
            mapping = {}
            
            # Get the union args first
            union_args = get_args(CoreSchemaOrFieldType)
            
            # For each union member, extract the literal values
            core_schema_types = []
            for union_member in union_args:
                # Each union member is a Literal type, extract its values
                if hasattr(union_member, '__args__'):
                    core_schema_types.extend(union_member.__args__)
            
            for key in core_schema_types:
                if not isinstance(key, str):
                    continue
                method_name = f'{key.replace("-", "_")}_schema'
                try:
                    mapping[key] = getattr(self, method_name)
                except AttributeError as e:
                    if os.getenv('PYDANTIC_PRIVATE_ALLOW_UNHANDLED_SCHEMA_TYPES'):
                        continue
                    raise TypeError(
                        f'No method for generating JsonSchema for core_schema.type={key!r} '
                        f'(expected: {type(self).__name__}.{method_name})'
                    ) from e
            return mapping
        
        # Apply the patch
        GenerateJsonSchema.build_schema_type_to_method = patched_build_schema_type_to_method
        print("✓ Applied Pydantic schema generation patch")
        return True
    except Exception as e:
        print(f"✗ Failed to apply Pydantic patch: {e}")
        return False

if __name__ == "__main__":
    # Test the patch
    patch_pydantic_schema_generation()
    
    from pydantic import BaseModel
    from typing import Any
    
    class TestModel(BaseModel):
        config: dict[str, Any]
    
    schema = TestModel.model_json_schema()
    print("✓ Test passed!")
    print(schema)
