from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional

__all__ = [
    "normalize_unc_path",
    "get_shared_path",
    "get_import_folder",
]


def normalize_unc_path(value: str) -> str:
    """Normalize a UNC or local path read from env.

    Handles variants like:
    - "////server/share" or "//server/share"
    - "\\\\server\\share" or "\\server\share"
    - quoted strings
    - mixed separators

    Returns a string starting with \\ for UNC paths, or original for local paths.
    """
    if not value:
        return value

    s = value.strip().strip('"').strip("'")
    # Convert all forward slashes to backslashes for Windows UNC
    s = s.replace('/', '\\')

    # Collapse multiple backslashes everywhere to a single backslash first
    s = re.sub(r"\\{2,}", r"\\", s)

    # If it looks like a UNC (starts with a backslash), ensure it starts with exactly two
    if s.startswith('\\'):
        if not s.startswith('\\\\'):
            s = '\\' + s
    elif s.startswith('.\\') or (len(s) > 1 and s[1:3] == ':\\'):
        # local relative or drive path, leave as-is after collapsing
        pass
    else:
        # If it started with two forward slashes originally, after replace it might now be '////' -> '\\'
        # Already handled by collapse above. If it should be UNC, ensure two leading backslashes.
        if value.startswith('//') or value.startswith('////'):
            if not s.startswith('\\\\'):
                s = '\\' + s

    return s


def get_shared_path(env_var_name: str, default: Optional[str] = None) -> Path:
    """Return a normalized Path from an environment variable.

    - Reads the env var
    - Falls back to default if provided
    - Normalizes UNC/backslashes and quotes
    """
    raw = os.getenv(env_var_name, default or "")
    normalized = normalize_unc_path(raw)
    return Path(normalized) if normalized else Path("")


def get_import_folder() -> Path:
    """Convenience wrapper for a common shared path (IMPORT_PATH)."""
    return get_shared_path("IMPORT_PATH", r"\\\\AVDGENAIL18-3\\SampleInput")
