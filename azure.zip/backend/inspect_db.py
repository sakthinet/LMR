import sys
import os

# Add current directory to sys.path so we can import database
sys.path.append(os.getcwd())

from sqlalchemy import inspect
from database import sync_engine

def inspect_table(table_name):
    inspector = inspect(sync_engine)
    if not inspector.has_table(table_name):
        print(f"Table '{table_name}' does not exist.")
        return

    columns = inspector.get_columns(table_name)
    print(f"Columns in '{table_name}':")
    for column in columns:
        print(f"  - {column['name']} ({column['type']})")

if __name__ == "__main__":
    print("Inspecting database tables...")
    inspect_table("system_services")
    inspect_table("system_health_status")
    inspect_table("system_capabilities")
