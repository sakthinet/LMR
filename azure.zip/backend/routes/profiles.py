from fastapi import APIRouter
from sqlalchemy import text
from database import SessionLocal
import logging
import json
import re
import html
import xml.etree.ElementTree as ET
from pydantic import BaseModel
from typing import Optional  # NEW
from sqlalchemy.exc import IntegrityError  # NEW
import base64

router = APIRouter(prefix="/profiles", tags=["Profiles"]) 
logger = logging.getLogger("profiles")

# Request model
class ProfileCreate(BaseModel):
    name: str
    type: str
    config: dict
    description: Optional[str] = None

# NEW: Update model
class ProfileUpdate(BaseModel):
    name: str  # identifies the row to update (profile_name)
    type: str  # identifies the row to update (step_type)
    config: Optional[dict] = None

@router.get("/exists")
def profile_exists(name: str, type: str):
    """Return true if a profile with the given name and type exists."""
    session = SessionLocal()
    try:
        sql = text(
            """
            SELECT 1
            FROM public.profiles
            WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
              AND LOWER(TRIM(step_type)) = LOWER(TRIM(:type))
            LIMIT 1
            """
        )
        row = session.execute(sql, {"name": name, "type": type}).first()
        return bool(row)
    except Exception as e:  # noqa: BLE001
        logger.error(f"Profile exists check failed: {e}", exc_info=True)
        return False
    finally:
        session.close()

# Create profile route
@router.post("/add")
def add_profile(payload: ProfileCreate):
    """Create a new profile in public.profiles table."""
    session = SessionLocal()
    try:
        # Guard against existing name (DB has a UNIQUE constraint on profile_name)
        exists_sql = text(
            """
            SELECT 1 FROM public.profiles
            WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
            LIMIT 1
            """
        )
        if session.execute(exists_sql, {"name": payload.name}).first():
            return {"status": "error", "message": "Profile with the same name already exists."}

        insert_sql = text(
            """
            INSERT INTO public.profiles (profile_name, step_type, profile_config, created_at, updated_at, description)
            VALUES (:name, :type, CAST(:config AS JSONB), now(), now(), :description)
            RETURNING id
            """
        )
        row = session.execute(
            insert_sql,
            {
                "name": payload.name,
                "type": payload.type,
                "config": json.dumps(payload.config),
                "description": payload.description,
            },
        ).fetchone()
        session.commit()
        new_id = row[0] if row else None
        return {"status": "success", "id": new_id}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Create profile failed: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

# NEW: Update profile by profile_name
@router.put("/update")
def update_profile(payload: ProfileUpdate):
    """Update an existing profile in public.profiles matched by profile_name AND step_type.
    Only fields provided (e.g., config) will be updated. Both name and type must match.
    """
    session = SessionLocal()
    try:
        # Ensure the profile exists (match by name AND type)
        exists_sql = text(
            """
            SELECT id FROM public.profiles
            WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
              AND LOWER(TRIM(step_type)) = LOWER(TRIM(:type))
            LIMIT 1
            """
        )
        row = session.execute(exists_sql, {"name": payload.name, "type": payload.type}).first()
        if not row:
            return {"status": "error", "message": "Profile not found for given name and type"}

        # Build dynamic SET clause
        sets = []
        params: dict = {"name": payload.name, "type": payload.type}
        if payload.config is not None:
            sets.append("profile_config = CAST(:config AS JSONB)")
            params["config"] = json.dumps(payload.config)
        # Always update timestamp
        sets.append("updated_at = now()")

        if len(sets) == 1:  # only updated_at would be changed
            return {"status": "error", "message": "No update fields provided"}

        update_sql = text(
            f"""
            UPDATE public.profiles
            SET {', '.join(sets)}
            WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
              AND LOWER(TRIM(step_type)) = LOWER(TRIM(:type))
            RETURNING id
            """
        )
        updated = session.execute(update_sql, params).fetchone()
        session.commit()
        if not updated:
            return {"status": "error", "message": "Update failed"}
        return {"status": "success", "id": updated[0]}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Update profile failed: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

# NEW: Delete profile by profile_name and step_type
@router.delete("/delete")
def delete_profile(name: str, type: str):
    """Delete a profile matched by profile_name AND step_type (case-insensitive).
    If the profile is referenced by pipelines (via FK), return a friendly error.
    """
    session = SessionLocal()
    try:
        delete_sql = text(
            """
            DELETE FROM public.profiles
            WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
              AND LOWER(TRIM(step_type)) = LOWER(TRIM(:type))
            RETURNING id
            """
        )
        row = session.execute(delete_sql, {"name": name, "type": type}).fetchone()
        session.commit()
        if not row:
            return {"status": "error", "message": "Profile not found"}
        return {"status": "success", "id": row[0]}
    except IntegrityError as ie:  # noqa: BLE001
        session.rollback()
        # If FK violation (e.g., Postgres 23503), convert to friendly message
        try:
            pgcode = getattr(getattr(ie, "orig", None), "pgcode", None)
        except Exception:
            pgcode = None
        if pgcode == "23503":
            return {"status": "error", "message": "Profile is used in a pipeline and cannot be deleted."}
        return {"status": "error", "message": "Profile cannot be deleted due to related references."}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Delete profile failed: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

# NEW: Check profile existence by name and type (for preventing duplicates)
# @router.get("/checkprofile")
# def check_profile(name: str, type: str):
#     """Return yes/no if a profile with the given name and type exists in public.profiles."""
#     session = SessionLocal()
#     try:
#         sql = text(
#             """
#             SELECT 1 FROM public.profiles
#             WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
#               AND LOWER(TRIM(step_type)) = LOWER(TRIM(:type))
#             LIMIT 1
#             """
#         )
#         row = session.execute(sql, {"name": name, "type": type}).first()
#         return {"exists": "yes" if row else "no"}
#     except Exception as e:  # noqa: BLE001
#         logger.error(f"Check profile failed: {e}", exc_info=True)
#         return {"status": "error", "message": str(e)}
#     finally:
#         session.close()

# NEW: List profiles by type
@router.get("/list")
def list_profiles(type: str):
    """Return all profiles for the given type with id, name, type, created_at, updated_at."""
    session = SessionLocal()
    try:
        rows = session.execute(
            text(
                """
                SELECT id, profile_name, step_type, created_at, updated_at, description
                FROM public.profiles
                WHERE LOWER(TRIM(step_type)) = LOWER(TRIM(:type))
                ORDER BY profile_name
                """
            ),
            {"type": type},
        ).mappings().all()
        profiles = [
            {
                "id": r["id"],
                "name": r["profile_name"],
                "type": r["step_type"],
                "created_at": r["created_at"],
                "updated_at": r["updated_at"],
                "description": r["description"],
            }
            for r in rows
        ]
        return {"profiles": profiles}
    except Exception as e:  # noqa: BLE001
        logger.error(f"List profiles failed: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

# NEW: Get a single profile config by name and type
@router.get("/getconfig")
def get_profile_config(name: str, type: str):
    """Fetch and return the profile_config JSON for the given profile name and type."""
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT profile_config
                FROM public.profiles
                WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
                  AND LOWER(TRIM(step_type)) = LOWER(TRIM(:type))
                LIMIT 1
                """
            ),
            {"name": name, "type": type},
        ).first()
        if not row:
            return {"status": "error", "message": "Profile not found"}

        raw_cfg = row[0]
        config = None
        try:
            if isinstance(raw_cfg, dict):
                config = raw_cfg
            elif isinstance(raw_cfg, (bytes, bytearray, memoryview)):
                config = json.loads(bytes(raw_cfg).decode("utf-8"))
            elif isinstance(raw_cfg, str):
                config = json.loads(raw_cfg)
        except Exception:
            # If parsing fails, return as-is string
            config = raw_cfg if isinstance(raw_cfg, dict) else {}

        return {"status": "success", "config": config}
    except Exception as e:  # noqa: BLE001
        logger.error(f"Get profile config failed: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

@router.get("/listcapability")
def listcapability(capability_type: str):
    session = SessionLocal()
    try:
        rows = session.execute(
            text("""
                SELECT *
                FROM system_capabilities
                WHERE LOWER(TRIM(capability_type)) = LOWER(TRIM(:ctype))
                  AND is_enabled = true
                ORDER BY id ASC
            """),
            {"ctype": capability_type},
        ).mappings().all()

        return {"capabilities": rows, "count": len(rows)}

    finally:
        session.close()
