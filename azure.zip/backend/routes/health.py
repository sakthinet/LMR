from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text, select, update, func
from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, String, DateTime, Boolean, Text, JSON, Integer
from datetime import datetime, timedelta
import httpx
import asyncio
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from database import get_async_session
from config import settings
from kombu import Connection
from celery import Celery
import logging
import json
import time

# Configure logging
logger = logging.getLogger(__name__)

router = APIRouter()

# Initialize Celery for inspection
celery_app = Celery('health_check', broker=settings.celery_broker_url)

# --- Database Models (Local Definition) ---
Base = declarative_base()

class SystemService(Base):
    __tablename__ = "system_services"
    service_key = Column(String, primary_key=True)
    display_name = Column(String, nullable=False)
    description = Column(String)
    service_category = Column(String, nullable=False)
    is_required = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class SystemHealthStatus(Base):
    __tablename__ = "system_health_status"
    service_key = Column(String, primary_key=True)
    status = Column(String)
    last_checked = Column(DateTime)
    details = Column(JSON)

class SystemCapability(Base):
    __tablename__ = "system_capabilities"
    id = Column(Integer, primary_key=True)
    capability_key = Column(String)
    capability_type = Column(String)
    is_enabled = Column(Boolean)
    runtime_enabled = Column(Boolean)

class WorkerCapability(Base):
    __tablename__ = "worker_capabilities"
    worker_type = Column(String, primary_key=True)
    display_name = Column(String)
    service_key = Column(String)
    supports_scale_to_zero = Column(Boolean, default=True)
    min_instances = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

# --- Pydantic Schemas ---
class ServiceHealth(BaseModel):
    key: str
    name: str
    status: str
    details: Optional[Any] = None

class HealthResponse(BaseModel):
    overall_status: str
    services: List[ServiceHealth]

# --- Health Check Functions ---

async def check_postgres(session: AsyncSession) -> str:
    try:
        await session.execute(text("SELECT 1"))
        return "healthy"
    except Exception as e:
        logger.error(f"Postgres health check failed: {e}")
        try:
            await session.rollback()
        except Exception:
            pass
        return "unhealthy"

async def check_airflow() -> str:
    if not settings.airflow_api_url:
        return "unknown"
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            # Assuming standard Airflow health endpoint
            url = f"{settings.airflow_api_url.rstrip('/')}/monitor/health"
            response = await client.get(url)
            if response.status_code == 200:
                data = response.json()
                # Check metadatabase and scheduler status
                if data.get("metadatabase", {}).get("status") == "healthy" and \
                   data.get("scheduler", {}).get("status") == "healthy":
                    return "healthy"
            return "unhealthy"
    except Exception as e:
        logger.error(f"Airflow health check failed: {e}")
        return "unhealthy"

def _check_rabbitmq_sync():
    try:
        conn = Connection(settings.celery_broker_url, transport_options={'visibility_timeout': 2})
        conn.connect()
        conn.release()
        return "healthy"
    except Exception as e:
        logger.error(f"RabbitMQ health check failed: {e}")
        return "unhealthy"

async def check_rabbitmq() -> str:
    return await asyncio.to_thread(_check_rabbitmq_sync)

def _check_processing_sync(capabilities):
    try:
        conn = Connection(settings.celery_broker_url)
        conn.connect()
        channel = conn.channel()
        
        # Also inspect celery workers to get accurate count of connected nodes
        # This is more reliable than queue.consumer_count for some broker types
        # and allows us to match worker names to types if needed.
        # However, for speed in the main health check, we might want to rely on queue stats first.
        # But user reported queue stats showing 0. Let's try to use inspect().ping() if possible,
        # or stick to queue stats but ensure we are looking at the right queue.
        
        inspector = celery_app.control.inspect(timeout=0.5)
        active_workers = inspector.ping() or {}
        # active_workers keys are like "celery@hostname" or "nomic_embed_text_worker@hostname"
        
    except Exception as e:
        return {"status": "unhealthy", "details": f"Broker connection failed: {str(e)}"}

    details = {}
    has_unhealthy = False
    has_active = False

    for cap in capabilities:
        w_type = cap.worker_type
        q_name = w_type 
        
        queue_depth = 0
        consumer_count = 0
        
        # 1. Check Queue Metrics
        try:
            queue = channel.queue_declare(queue=q_name, passive=True)
            queue_depth = queue.message_count if queue else 0
            consumer_count = queue.consumer_count if queue else 0
        except Exception:
            queue_depth = 0
            consumer_count = 0

        # 2. Cross-check with Celery Ping (Pattern Matching)
        # If consumer_count is 0, check if any active worker name starts with the worker_type
        # This handles cases where RabbitMQ stats might lag or be confusing.
        # Example: w_type="nomic_embed_text_worker", worker_name="nomic_embed_text_worker@host"
        if consumer_count == 0 and active_workers:
            matching_workers = [
                w_name for w_name in active_workers.keys() 
                if w_name.startswith(w_type) or f"-{w_type}" in w_name
            ]
            if matching_workers:
                consumer_count = len(matching_workers)

        status = "idle"
        if consumer_count > 0:
            status = "healthy"
            has_active = True
        elif queue_depth > 0:
            status = "unhealthy"
            has_unhealthy = True
        else:
             if not cap.supports_scale_to_zero:
                 status = "unhealthy"
                 has_unhealthy = True
             else:
                 status = "idle"
        
        details[cap.service_key] = {
            "status": status,
            "consumers": consumer_count,
            "depth": queue_depth,
            "worker_type": w_type,
            "display_name": cap.display_name
        }

    conn.release()
    
    if has_unhealthy:
        final_status = "unhealthy"
    elif has_active:
        final_status = "healthy"
    else:
        final_status = "idle"

    return {"status": final_status, "details": details}

async def check_processing_services(session: AsyncSession) -> Dict[str, Any]:
    """
    Checks workers and queues.
    Returns: {"status": "healthy"|"idle"|"unhealthy", "details": "..."}
    """
    try:
        # Get worker capabilities to know what workers to check
        result = await session.execute(select(WorkerCapability))
        capabilities = result.scalars().all()
        
        if not capabilities:
            return {"status": "unknown", "details": "No worker capabilities found"}

        # Run blocking MQ check in thread
        return await asyncio.to_thread(_check_processing_sync, capabilities)

    except Exception as e:
        logger.error(f"Processing services check failed: {e}")
        try:
            await session.rollback()
        except Exception:
            pass
        return {"status": "unhealthy", "details": str(e)}

# --- Main Endpoint ---

@router.get("/health", response_model=HealthResponse)
async def get_system_health(session: AsyncSession = Depends(get_async_session)):
    """
    Evaluates system health, persists status, and returns UI-friendly response.
    """
    
    # 1. Evaluate Health
    health_results = {}
    
    # Backend API (Self)
    health_results["backend_api"] = {"status": "healthy", "details": "Responding"}
    
    # Metadata Store
    pg_status = await check_postgres(session)
    health_results["metadata_store"] = {"status": pg_status, "details": "PostgreSQL connection check"}
    
    # Workflow Orchestrator
    af_status = await check_airflow()
    health_results["workflow_orchestrator"] = {"status": af_status, "details": "Airflow API check"}
    
    # Message Queue
    mq_status = await check_rabbitmq()
    health_results["message_queue"] = {"status": mq_status, "details": "RabbitMQ connection check"}
    
    # Processing Services
    proc_result = await check_processing_services(session)
    health_results["processing_services"] = proc_result
    
    # 2. Persist Health Status
    timestamp = datetime.utcnow()
    for key, result in health_results.items():
        # Upsert logic
        # Check if exists
        stmt = select(SystemHealthStatus).where(SystemHealthStatus.service_key == key)
        existing = (await session.execute(stmt)).scalar_one_or_none()
        
        # Ensure details is a dict for JSONB column
        details_val = result.get("details")
        if isinstance(details_val, str):
            details_val = {"message": details_val}
        elif details_val is None:
            details_val = {}
        
        if existing:
            existing.status = result["status"]
            existing.last_checked = timestamp
            existing.details = details_val
        else:
            new_record = SystemHealthStatus(
                service_key=key,
                status=result["status"],
                last_checked=timestamp,
                details=details_val
            )
            session.add(new_record)
    
    # 3. Capability Gating
    # If processing_services is unhealthy, disable runtime capabilities
    proc_status = health_results["processing_services"]["status"]
    
    if proc_status == "unhealthy":
        # Disable all runtime_enabled
        await session.execute(
            update(SystemCapability).values(runtime_enabled=False)
        )
    else:
        # Restore runtime_enabled where is_enabled is True
        # We assume if processing is healthy/idle, capabilities can run if configured
        await session.execute(
            update(SystemCapability)
            .where(SystemCapability.is_enabled == True)
            .values(runtime_enabled=True)
        )
        # Ensure disabled ones stay disabled
        await session.execute(
            update(SystemCapability)
            .where(SystemCapability.is_enabled == False)
            .values(runtime_enabled=False)
        )
    
    await session.commit()
    
    # 4. Format Response
    # Fetch display names from system_services
    services_list = []
    overall_status = "healthy"
    
    # Priority for overall status: unhealthy > degraded > idle > healthy
    status_priority = {"unhealthy": 0, "degraded": 1, "idle": 2, "healthy": 3, "unknown": 4}
    current_priority = 3
    
    # Get all defined services to ensure we return what's expected in UI
    defined_services_res = await session.execute(select(SystemService))
    defined_services = defined_services_res.scalars().all()
    
    defined_keys = {s.service_key: s.display_name for s in defined_services}
    service_category_map = {s.service_key: s.service_category for s in defined_services}
    
    # If DB is empty for system_services, fallback to keys we checked
    if not defined_keys:
        defined_keys = {k: k.replace("_", " ").title() for k in health_results.keys()}

    # Helper to structure processing services
    def structure_processing_details(raw_details):
        if not isinstance(raw_details, dict):
            return raw_details
            
        structured = {}
        
        # Helper to aggregate status
        def aggregate_status(current, new):
            priority = {"unhealthy": 0, "degraded": 1, "idle": 2, "healthy": 3, "unknown": 4}
            if priority.get(new, 4) < priority.get(current, 4):
                return new
            return current

        for svc_key, info in raw_details.items():
            category = service_category_map.get(svc_key, "Unknown")
            
            if category not in structured:
                structured[category] = {"status": "unknown", "count": 0}
            
            current_status = structured[category]["status"]
            new_status = info.get("status", "unknown")
            
            # Update status (worst case wins)
            if current_status == "unknown":
                structured[category]["status"] = new_status
            else:
                structured[category]["status"] = aggregate_status(current_status, new_status)
            
            # Increment count (number of running worker instances in this category)
            # We use the 'consumers' count from RabbitMQ which represents active connections
            structured[category]["count"] += info.get("consumers", 0)

        return structured

    # Calculate Overall Status
    statuses = [health_results.get(k, {}).get("status", "unknown") for k in health_results.keys()]
    if "unhealthy" in statuses:
        overall_status = "unhealthy"
    elif "degraded" in statuses:
        overall_status = "degraded"
    elif all(s == "idle" for s in statuses if s != "unknown"):
        overall_status = "idle"
    else:
        overall_status = "healthy"

    # Build Service List
    # We want to exclude individual workers from the top level list if they are already inside processing_services
    worker_keys = set()
    if "processing_services" in health_results:
        details = health_results["processing_services"].get("details", {})
        if isinstance(details, dict):
            worker_keys = set(details.keys())

    for key, name in defined_keys.items():
        # Skip if this is a worker that is already aggregated
        if key in worker_keys:
            continue
            
        res = health_results.get(key, {"status": "unknown", "details": "Not evaluated"})
        
        # Special handling for processing_services to structure details
        final_details = res.get("details")
        if key == "processing_services":
            final_details = structure_processing_details(final_details)
        elif isinstance(final_details, dict):
             # For other services, if details is a dict, keep it (ServiceHealth now supports Any)
             pass
        elif final_details is None:
             final_details = None
        else:
             # Ensure string if it was a string
             final_details = str(final_details)

        services_list.append(ServiceHealth(
            key=key,
            name=name,
            status=res["status"],
            details=final_details
        ))

    return HealthResponse(
        overall_status=overall_status,
        services=services_list
    )

@router.get("/health/workers/detailed")
async def get_detailed_worker_health(session: AsyncSession = Depends(get_async_session)):
    """
    Returns a tabular view of worker health:
    - Category
    - Worker Name
    - Machine Name
    - Status (Idle, Busy, Hung)
    - Tasks Waiting
    - Last Processed
    - Uptime
    """
    
    # 1. Get Capabilities and Categories
    stmt = select(WorkerCapability, SystemService.service_category)\
        .outerjoin(SystemService, WorkerCapability.service_key == SystemService.service_key)
    
    result = await session.execute(stmt)
    rows = result.all()
    
    capabilities = []
    cap_map = {}
    
    for row in rows:
        cap = row[0]
        category = row[1]
        capabilities.append(cap)
        cap_map[cap.worker_type] = category if category else cap.worker_type.capitalize()
    
    # 2. Celery Inspection
    def _inspect_celery():
        try:
            i = celery_app.control.inspect(timeout=2.0)
            return {
                "ping": i.ping() or {},
                "active": i.active() or {},
                "stats": i.stats() or {},
                "active_queues": i.active_queues() or {}
            }
        except Exception as e:
            logger.error(f"Celery inspection failed: {e}")
            return None

    celery_info = await asyncio.to_thread(_inspect_celery)
    if not celery_info:
        return []

    ping_results = celery_info.get("ping", {})
    active_tasks = celery_info.get("active", {})
    stats = celery_info.get("stats", {})
    active_queues_info = celery_info.get("active_queues", {})

    # 3. RabbitMQ Queue Metrics (for Waiting Tasks)
    queues_to_check = set()
    worker_to_queues = {}
    
    for w_name, queues in active_queues_info.items():
        q_names = [q['name'] for q in queues]
        worker_to_queues[w_name] = q_names
        queues_to_check.update(q_names)
    
    for cap in capabilities:
        queues_to_check.add(cap.worker_type)

    def _get_queue_depths(queues):
        depths = {}
        try:
            conn = Connection(settings.celery_broker_url)
            conn.connect()
            channel = conn.channel()
            for q_name in queues:
                try:
                    q = channel.queue_declare(queue=q_name, passive=True)
                    depths[q_name] = q.message_count
                except Exception:
                    depths[q_name] = -1
            conn.release()
        except Exception as e:
            logger.error(f"Queue metrics check failed: {e}")
        return depths

    queue_depths = await asyncio.to_thread(_get_queue_depths, list(queues_to_check))

    # 4. Last Processed Timestamp from DB
    try:
        stmt = text("""
            SELECT worker_name, MAX(completed_at) as last_seen
            FROM task_details 
            WHERE status IN ('SUCCESS', 'FAILURE', 'REVOKED')
            GROUP BY worker_name
        """)
        db_result = await session.execute(stmt)
        last_seen_map = {row.worker_name: row.last_seen for row in db_result}
    except Exception as e:
        logger.warning(f"Could not fetch last seen times: {e}")
        last_seen_map = {}

    # 5. Build the Tabular Data
    detailed_workers = []
    
    for worker_name in ping_results.keys():
        # Machine Name
        try:
            machine_name = worker_name.split('@')[1]
        except IndexError:
            machine_name = "Unknown"

        # Category
        category = "Unknown"
        for w_type, cat_name in cap_map.items():
            if worker_name.startswith(w_type):
                category = cat_name
                break
        
        if category == "Unknown":
            w_queues = worker_to_queues.get(worker_name, [])
            for q in w_queues:
                if q in cap_map:
                    category = cap_map[q]
                    break
            if category == "Unknown" and w_queues:
                 category = w_queues[0].capitalize()
        
        # Status Logic
        tasks = active_tasks.get(worker_name, [])
        status_val = "Idle"
        status_reason = "No active tasks"
        
        if tasks:
            status_val = "Busy"
            status_reason = f"Processing {len(tasks)} task(s)"
            now = time.time()
            for t in tasks:
                t_start = t.get('time_start')
                if t_start:
                    duration = now - t_start
                    if duration > 180: # 3 minutes
                        status_val = "Hung"
                        status_reason = f"Task {t.get('id')} running for {int(duration)}s"
                        break
        
        # Tasks Waiting
        w_queues = worker_to_queues.get(worker_name, [])
        waiting_count = 0
        for q in w_queues:
            d = queue_depths.get(q, 0)
            if d > 0:
                waiting_count += d
        
        # Last Processed
        last_processed = last_seen_map.get(worker_name)
        
        # Uptime
        w_stats = stats.get(worker_name, {})
        uptime_seconds = w_stats.get('uptime', 0)
        uptime_str = str(timedelta(seconds=uptime_seconds))

        detailed_workers.append({
            "category": category,
            "worker_name": worker_name,
            "machine_name": machine_name,
            "status": status_val,
            "status_reason": status_reason,
            "tasks_waiting": waiting_count,
            "last_processed_at": last_processed,
            "uptime": uptime_str
        })

    return detailed_workers
