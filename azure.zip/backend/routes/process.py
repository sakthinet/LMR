from sqlalchemy import text
from database import SessionLocal
from pydantic import BaseModel
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
import logging
import requests
from datetime import datetime, timezone
from pathlib import Path
import shutil
import os
from typing import Optional
from airflow_token import get_airflow_token
from config import settings
from utils.path_utils import get_shared_path

router = APIRouter(prefix="/process", tags=["Process"])
logger = logging.getLogger("contextcraft")

API_BASE = settings.airflow_api_url.rstrip('/')

# --- Models ---
from pydantic import BaseModel

class UnpauseRequest(BaseModel):
    dag_id: Optional[str] = None
    processname: Optional[str] = None

class RemoveProcessRequest(BaseModel):
    dag_id: Optional[str] = None
    processname: Optional[str] = None


# Request model for document details by process
class DocumentDetailsRequest(BaseModel):
    process_name: str

# Response model for document details
class DocumentDetailsResponse(BaseModel):
    document_name: str
    folder_id: Optional[str]
    job_id: Optional[str]
    last_successful_stage: Optional[str]
    updated_at: Optional[str]

# --- Helper: Change DAG pause status ---
def dag_status_change(dag_id: str, paused: bool, token: Optional[str] = None):
    """PATCH the DAG to set is_paused using bearer token.
    paused=True pauses the DAG, paused=False unpauses it.
    Raises RuntimeError on failure conditions.
    """
    if token is None:
        token = get_airflow_token()
    url = f"{API_BASE}/dags/{dag_id}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    body = {"is_paused": paused}
    r = requests.patch(url, headers=headers, json=body, timeout=15)
    if settings.debug:
        logger.debug("PATCH %s -> %s", url, r.status_code)
        logger.debug("Resp headers: %s", dict(r.headers))
        logger.debug("Resp body: %.500s", r.text)
    if r.status_code == 401:
        raise RuntimeError("Unauthorized (401). Token invalid or expired.")
    if r.status_code == 404:
        raise RuntimeError(f"DAG '{dag_id}' not found (404).")
    if r.status_code not in (200, 202):  # 200 expected; 202 possible
        raise RuntimeError(f"Unexpected status {r.status_code}: {r.text}")
    return r.json()


@router.get("/list", summary="List Airflow processes (DAGs) with basic details")
async def list_processes():
    """Return total number of Airflow DAGs and a summarized list.

    Fields per process:
      process_name -> dag_id
      status       -> "Paused" if is_paused else "Active"
      schedule     -> timetable_description
      next_run     -> next_dagrun_logical_date
    """
    url = f"{settings.airflow_api_url}/dags"
    headers = {
        "Authorization": f"Bearer {get_airflow_token()}",
        "Content-Type": "application/json",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=20)
        if resp.status_code != 200:
            return JSONResponse(status_code=resp.status_code, content={"error": resp.text})
        js = resp.json()
        total_entries = js.get("total_entries", 0)
        dags = js.get("dags", [])
        processes = []
        for dag in dags:
            is_paused = dag.get("is_paused")
            processes.append({
                "process_name": dag.get("dag_id"),
                "status": "Paused" if is_paused else "Active",
                "schedule": dag.get("timetable_description"),
                "next_run": dag.get("next_dagrun_logical_date"),
            })
        return {"total_entries": total_entries, "processes": processes}
    except Exception as e:  # noqa: BLE001
        logger.exception("Failed fetching Airflow DAG list")
        return JSONResponse(status_code=500, content={"error": str(e)})


@router.post("/check-name", summary="Check whether a DAG with the given process name (dag_id) exists on the Airflow server")
async def check_process_name(body: UnpauseRequest):
    """Accepts JSON {"dag_id": "..."} or {"processname": "..."} and returns {"exists": true|false}.

    Uses Airflow GET /dags/{dag_id} which returns 200 when the DAG exists and 404 when not found.
    """
    dag_id = body.dag_id or body.processname
    if not dag_id:
        raise HTTPException(status_code=422, detail="dag_id or processname required")

    try:
        token = get_airflow_token()
        url = f"{API_BASE}/dags/{dag_id}"
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        }
        r = requests.get(url, headers=headers, timeout=15)
        if settings.debug:
            logger.debug("GET %s -> %s", url, r.status_code)
            logger.debug("Resp body: %.500s", r.text)

        if r.status_code == 200:
            return {"exists": True}
        if r.status_code == 404:
            return {"exists": False}
        if r.status_code == 401:
            raise HTTPException(status_code=401, detail="Unauthorized (Airflow token invalid or expired)")

        # Unexpected status: propagate error details
        return JSONResponse(status_code=r.status_code, content={"error": r.text})
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        logger.exception("Failed checking DAG existence for %s", dag_id)
        return JSONResponse(status_code=500, content={"error": str(e)})


# @router.post("/unpause-process", summary="Unpause a process (DAG)")
# async def unpause_process(body: UnpauseRequest):
#     dag_id = body.dag_id or body.processname
#     if not dag_id:
#         raise HTTPException(status_code=422, detail="dag_id or processname required")
#     try:
#         resp = dag_status_change(dag_id, paused=False)
#         return {"status": "success", "dag_id": dag_id, "response": resp}
#     except RuntimeError as re:  # known error conditions
#         raise HTTPException(status_code=400, detail=str(re))
#     except Exception as e:  # noqa: BLE001
#         logger.exception("Unpause failed for %s", dag_id)
#         raise HTTPException(status_code=500, detail=str(e))

@router.post("/deploy-process", summary="Activates a process. Then the process runs as per the process schedule.")
async def deploy_process(body: UnpauseRequest):
    dag_id = body.dag_id or body.processname
    if not dag_id:
        raise HTTPException(status_code=422, detail="dag_id or processname required")
    try:
        resp = dag_status_change(dag_id, paused=False)
        return {"status": "success", "dag_id": dag_id, "response": resp}
    except RuntimeError as re:  # known error conditions
        raise HTTPException(status_code=400, detail=str(re))
    except Exception as e:  # noqa: BLE001
        logger.exception("Unpause failed for %s", dag_id)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/manual-run-process", summary="Manually runs a process once (trigger a DAG run).")
async def manual_run_process(body: UnpauseRequest):
    dag_id = body.dag_id or body.processname
    if not dag_id:
        raise HTTPException(status_code=422, detail="dag_id or processname required")
    try:
        token = get_airflow_token()
        dag_run_url = f"{API_BASE}/dags/{dag_id}/dagRuns"
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        logical_date = datetime.now(timezone.utc).isoformat()
        payload = {"conf": {}, "logical_date": logical_date}
        r = requests.post(dag_run_url, headers=headers, json=payload, timeout=15)
        if settings.debug:
            logger.debug("POST %s -> %s", dag_run_url, r.status_code)
            logger.debug("Resp headers: %s", dict(r.headers))
            logger.debug("Resp body: %.500s", r.text)
        if r.status_code == 401:
            raise RuntimeError("Unauthorized (401). Token invalid or expired.")
        if r.status_code == 404:
            raise RuntimeError(f"DAG '{dag_id}' not found (404).")
        if r.status_code not in (200, 201, 202):
            raise RuntimeError(f"Unexpected status {r.status_code}: {r.text}")
        trigger_resp = r.json()
        return {"status": "success", "dag_id": dag_id, "trigger": trigger_resp}
    except RuntimeError as re:  # known error conditions
        raise HTTPException(status_code=400, detail=str(re))
    except Exception as e:  # noqa: BLE001
        logger.exception("Trigger failed for %s", dag_id)
        raise HTTPException(status_code=500, detail=str(e))


# @router.post("/deploy-run-process", summary="Activates and manually run the process once. Then the process runs as per the process schedule.")
# async def deploy_run_process(body: UnpauseRequest):
#     dag_id = body.dag_id or body.processname
#     if not dag_id:
#         raise HTTPException(status_code=422, detail="dag_id or processname required")
#
#     # First unpause the DAG
#     try:
#         unpause_resp = dag_status_change(dag_id, paused=False)
#     except RuntimeError as re:  # known error conditions
#         raise HTTPException(status_code=400, detail=str(re))
#     except Exception as e:  # noqa: BLE001
#         logger.exception("Unpause failed for %s", dag_id)
#         raise HTTPException(status_code=500, detail=str(e))
#
#     # Then trigger a DAG run
#     try:
#         token = get_airflow_token()
#         dag_run_url = f"{API_BASE}/dags/{dag_id}/dagRuns"
#         headers = {
#             "Authorization": f"Bearer {token}",
#             "Accept": "application/json",
#             "Content-Type": "application/json",
#         }
#         logical_date = datetime.now(timezone.utc).isoformat()
#         payload = {"conf": {}, "logical_date": logical_date}
#         r = requests.post(dag_run_url, headers=headers, json=payload, timeout=15)
#         if settings.debug:
#             logger.debug("POST %s -> %s", dag_run_url, r.status_code)
#             logger.debug("Resp headers: %s", dict(r.headers))
#             logger.debug("Resp body: %.500s", r.text)
#         if r.status_code == 401:
#             raise RuntimeError("Unauthorized (401). Token invalid or expired.")
#         if r.status_code == 404:
#             raise RuntimeError(f"DAG '{dag_id}' not found (404).")
#         if r.status_code not in (200, 201, 202):
#             raise RuntimeError(f"Unexpected status {r.status_code}: {r.text}")
#         trigger_resp = r.json()
#         return {
#             "status": "success",
#             "dag_id": dag_id,
#             "unpause": unpause_resp,
#             "trigger": trigger_resp,
#         }
#     except RuntimeError as re:
#         raise HTTPException(status_code=400, detail=str(re))
#     except Exception as e:  # noqa: BLE001
#         logger.exception("Trigger failed for %s", dag_id)
#         raise HTTPException(status_code=500, detail=str(e))


# @router.post("/pause-process", summary="Pauses a process so its not scheduled to run.")
# async def pause_process(body: UnpauseRequest):
#     dag_id = body.dag_id or body.processname
#     if not dag_id:
#         raise HTTPException(status_code=422, detail="dag_id or processname required")
#     try:
#         resp = dag_status_change(dag_id, paused=True)
#         return {"status": "success", "dag_id": dag_id, "response": resp}
#     except RuntimeError as re:  # known error conditions
#         raise HTTPException(status_code=400, detail=str(re))
#     except Exception as e:  # noqa: BLE001
#         logger.exception("Pause failed for %s", dag_id)
#         raise HTTPException(status_code=500, detail=str(e))


@router.post("/remove-process")
async def remove_process(body: RemoveProcessRequest):
    """Archive (effectively remove) a DAG by moving its python file into an 'archived' subfolder.
    Accepts {"dag_id": "..."} or {"processname": "..."} like the other endpoints.
    """
    dag_id = body.dag_id or body.processname
    if not dag_id:
        raise HTTPException(status_code=422, detail="dag_id or processname required")

    # Normalize and resolve Airflow DAGs directory from env or settings using utility
    raw = os.getenv("AIRFLOW_DAGS_DIR", settings.airflow_dags_dir or "")
    airflow_dags_dir = get_shared_path("AIRFLOW_DAGS_DIR", settings.airflow_dags_dir or None)

    if not airflow_dags_dir.exists() or not airflow_dags_dir.is_dir():
        raise HTTPException(status_code=500, detail=f"Airflow DAGs directory not accessible: {raw}")

    dag_file = airflow_dags_dir / f"{dag_id}.py"
    if not dag_file.exists():
        raise HTTPException(status_code=404, detail=f"DAG file not found: {dag_file}")

    # Determine archive directory from settings/env or fallback to subdirectory
    archive_path_str = os.getenv("AIRFLOW_ARCHIVE_DIR", settings.airflow_archive_dir)
    if archive_path_str:
        archived_dir = Path(archive_path_str)
    else:
        archived_dir = airflow_dags_dir / "archived"

    try:
        archived_dir.mkdir(parents=True, exist_ok=True)
        
        # If archived_dir is inside airflow_dags_dir, ensure .airflowignore prevents scanning
        # resolve() helps compare absolute paths
        try:
            if airflow_dags_dir.resolve() in archived_dir.resolve().parents or airflow_dags_dir.resolve() == archived_dir.resolve():
                # It is inside, so we need to ignore it
                # Calculate relative path for .airflowignore
                rel_path = archived_dir.relative_to(airflow_dags_dir)
                ignore_entry = str(rel_path).replace("\\", "/") # Ensure forward slashes for regex/glob compatibility if needed
                
                ignore_file = airflow_dags_dir / ".airflowignore"
                should_append = False
                current_content = ""
                
                if not ignore_file.exists():
                    should_append = True
                else:
                    try:
                        current_content = ignore_file.read_text(encoding="utf-8")
                        if ignore_entry not in current_content.splitlines():
                            should_append = True
                    except Exception:
                        should_append = True

                if should_append:
                    with open(ignore_file, "a", encoding="utf-8") as f:
                        prefix = "\n" if current_content and not current_content.endswith("\n") else ""
                        f.write(f"{prefix}{ignore_entry}\n")
        except Exception:
            # Ignore path resolution errors or if paths are on different drives
            pass

    except Exception as e:  # noqa: BLE001
        logger.exception("Failed creating archived dir or updating .airflowignore")
        raise HTTPException(status_code=500, detail=f"Cannot prepare archive environment: {e}")
    # Destination path; avoid overwrite by appending timestamp if needed
    dest = archived_dir / dag_file.name
    if dest.exists():
        ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
        dest = archived_dir / f"{dag_id}_{ts}.py"
    try:
        shutil.move(str(dag_file), str(dest))
        logger.info("Archived DAG %s -> %s", dag_file, dest)
        return {
            "status": "archived",
            "dag_id": dag_id,
            "from": str(dag_file),
            "to": str(dest)
        }
    except Exception as e:  # noqa: BLE001
        logger.exception("Failed to archive DAG %s", dag_id)
        raise HTTPException(status_code=500, detail=str(e))
    
@router.post("/document-details", summary="Fetch all document details for a process name")
async def document_details_by_process(body: DocumentDetailsRequest):
    """
    Returns all documents for the given process_name from document_details table.
    Output: document_name, folder_id, job_id, last_successful_stage, updated_at
    """
    session = SessionLocal()
    try:
        sql = text(
            """
            SELECT document_name, folder_id, job_id, last_successful_stage, updated_at
            FROM public.document_details
            WHERE LOWER(TRIM(process_name)) = LOWER(TRIM(:process_name))
            ORDER BY updated_at DESC
            """
        )
        rows = session.execute(sql, {"process_name": body.process_name}).fetchall()
        result = []
        for r in rows:
            result.append({
                "document_name": r[0],
                "folder_id": r[1],
                "job_id": r[2],
                "last_successful_stage": r[3],
                "updated_at": r[4].isoformat() if r[4] else None
            })
        return {"status": "success", "documents": result}
    except Exception as e:
        logger.exception("Failed to fetch document details for process: %s", body.process_name)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()
