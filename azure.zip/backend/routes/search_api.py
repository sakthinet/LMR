from fastapi import APIRouter, HTTPException, Request
from core.models import SearchConfig, SearchConfigCreateRequest
from core.template_engine import render_template_to_file
from core.router_loader import load_router_for_config
from database import SessionLocal
from sqlalchemy import text
import os
import sys
from pathlib import Path
import logging
import asyncpg
import json
import hashlib
from typing import List, Tuple, Dict, Any, Optional

router = APIRouter(prefix="/search-api", tags=["SearchAPI"])
logger = logging.getLogger("contextcraft")
mounted_routers = {}


def _normalize_api_name(name: str) -> str:
    return (name or "").strip().lower().replace(" ", "_")


def _find_matching_api_names(session, name: str) -> List[str]:
    """Return all DB API names matching user input by exact or slug-normalized form."""
    slug = _normalize_api_name(name)
    rows = session.execute(
        text(
            """SELECT DISTINCT name
                   FROM search_api
                  WHERE lower(name) = lower(:raw)
                     OR lower(replace(name, ' ', '_')) = :slug
                     OR lower(name) = lower(:spaced)"""
        ),
        {
            "raw": name,
            "slug": slug,
            "spaced": (name or "").replace("_", " "),
        },
    ).mappings().all()
    matched = [str(r.get("name")) for r in rows if r.get("name")]
    if not matched:
        matched = [name]
    return sorted(set(matched))


def _delete_generated_router_files(api_names: List[str]) -> List[str]:
    """Delete generated router files for provided API names and slug-equivalent variants."""
    from core.template_engine import GENERATED_DIR

    normalized_targets = {_normalize_api_name(n) for n in api_names if n}
    deleted: List[str] = []

    for pyfile in GENERATED_DIR.glob("*_router.py"):
        stem_name = pyfile.stem.replace("_router", "")
        if _normalize_api_name(stem_name) in normalized_targets:
            pyfile.unlink(missing_ok=True)
            deleted.append(str(pyfile))
    return deleted


def _resolve_profile_stores(profile_config: Any) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str], dict]:
    """Attempt to extract chunk_store, chunk_database, vector_store, vector_database
    from a profile_config which may vary in shape. Returns tuple plus a dict
    of discovered keys for debugging.
    """
    discovered = {}
    if not profile_config:
        return None, None, None, None, discovered
    
    if isinstance(profile_config, dict):
        # Track discovered keys as a simple mapping of key->True for debugging
        discovered = {k: True for k in profile_config.keys()}
        
        # Case-insensitive key lookup with multiple fallback patterns
        def get_key(obj: dict, *keys: str) -> Optional[str]:
            if not isinstance(obj, dict):
                return None
            for key in keys:
                if key in obj:
                    return obj[key]
            # Case-insensitive search
            lower_keys = {k.lower(): k for k in obj.keys()}
            for key in keys:
                lower_key = key.lower()
                if lower_key in lower_keys:
                    return obj[lower_keys[lower_key]]
            return None
        
        # Try direct fields or nested stores
        chunk_store = get_key(profile_config, "chunk_store", "ChunkStore", "chunkStore", "chunk_store_name")
        chunk_database = get_key(profile_config, "chunk_database", "chunkDatabase", "chunk_db")
        vector_store = get_key(profile_config, "vector_store", "VectorStore", "vectorStore", "vector_store_name")
        vector_database = get_key(profile_config, "vector_database", "vectorDatabase", "vector_db")
        
        # Try nested "stores" object
        if isinstance(profile_config.get("stores"), dict):
            stores = profile_config["stores"]
            chunk_store = chunk_store or get_key(stores, "chunk_store", "ChunkStore", "chunkStore")
            chunk_database = chunk_database or get_key(stores, "chunk_database", "chunkDatabase")
            vector_store = vector_store or get_key(stores, "vector_store", "VectorStore", "vectorStore")
            vector_database = vector_database or get_key(stores, "vector_database", "vectorDatabase")
        
        # Try nested "target" or "destination" patterns
        for target_key in ["target", "destination"]:
            target_obj = profile_config.get(target_key)
            if isinstance(target_obj, dict):
                chunk_store = chunk_store or get_key(target_obj, "chunk_store", "ChunkStore")
                chunk_database = chunk_database or get_key(target_obj, "chunk_database", "chunkDatabase")
                vector_store = vector_store or get_key(target_obj, "vector_store", "VectorStore")
                vector_database = vector_database or get_key(target_obj, "vector_database", "vectorDatabase")
    
    return chunk_store, chunk_database, vector_store, vector_database, discovered


def _render_versioned_and_alias(cfg: SearchConfig, version_number: int) -> Tuple[Path, Path, str]:
    """Render template to file and compute hash. Returns (versioned_path, alias_path, template_hash)."""
    render_template_to_file(cfg)
    
    from core.template_engine import GENERATED_DIR
    alias_path = GENERATED_DIR / f"{cfg.name}_router.py"
    
    if alias_path.exists():
        content = alias_path.read_bytes()
        template_hash = hashlib.sha256(content).hexdigest()
    else:
        template_hash = ""
    
    return alias_path, alias_path, template_hash


def _mount_router(name: str, request: Request) -> str:
    """Mount router on app and return prefix."""
    slug = name.replace(' ', '_').lower()
    prefix = f"/api/{slug}"
    
    app_router = request.app.router
    app_router.routes = [
        r for r in app_router.routes
        if not (hasattr(r, "path") and r.path.startswith(prefix))
    ]
    
    for mod_name in [
        f"generated_apis.{name}_router",
        f"{name}_router",
        f"app.generated_apis.{name}_router",
    ]:
        if mod_name in sys.modules:
            del sys.modules[mod_name]
    
    router_obj = load_router_for_config(name)
    alt_prefix = f"/api/{name}"
    for r in router_obj.routes:
        if not (hasattr(r, "path") and isinstance(r.path, str)):
            continue
        matched = None
        if r.path.startswith(prefix):
            matched = prefix
        elif r.path.startswith(alt_prefix):
            matched = alt_prefix
        if matched:
            new_path = r.path[len(matched):]
            if not new_path.startswith("/"):
                new_path = "/" + new_path
            r.path = new_path
    
    request.app.include_router(router_obj, prefix=prefix, include_in_schema=False)
    mounted_routers[name] = {"router": router_obj, "prefix": prefix, "slug": slug}
    logger.info(f"✅ Mounted routes for {name}")
    
    return prefix


def _unmount_router_runtime(name: str, request: Request) -> None:
    """Remove mounted runtime routes for both slug and legacy API prefixes."""
    slug = name.replace(' ', '_').lower()
    prefixes = {
        f"/api/{slug}",
        f"/api/{name}",
    }

    app_router = request.app.router
    app_router.routes = [
        r for r in app_router.routes
        if not (
            hasattr(r, "path")
            and any(str(getattr(r, "path", "")).startswith(prefix) for prefix in prefixes)
        )
    ]
    # Keep local mounted registry in sync for both key styles.
    mounted_routers.pop(name, None)
    mounted_routers.pop(slug, None)


async def generate_router(cfg: SearchConfig, request: Request):
    """Render the generated router file and mount it directly on the FastAPI app so
    routes become available immediately without restarting the server.
    """
    render_template_to_file(cfg)
    router_obj = load_router_for_config(cfg.name)
    # Use a slugified prefix to avoid spaces/unsafe chars in URL paths
    slug = cfg.name.replace(' ', '_').lower()
    prefix = f"/api/{slug}"

    # Clean up any previously mounted routes on the app for this prefix
    app_router = request.app.router
    app_router.routes = [
        r for r in app_router.routes
        if not (hasattr(r, "path") and r.path.startswith(prefix))
    ]

    # Remove any previously cached module variants to ensure fresh import
    for mod_name in [
        f"generated_apis.{cfg.name}_router",
        f"{cfg.name}_router",
        f"app.generated_apis.{cfg.name}_router",
    ]:
        if mod_name in sys.modules:
            del sys.modules[mod_name]

    # Ensure generated router routes don't already embed the '/api/{name}' prefix.
    # Some older generated files used full paths like '/api/{name}/search' which would
    # duplicate when we mount with prefix='/api/{name}'. Normalize those to be relative.
    try:
        alt_prefix = f"/api/{cfg.name}"
        for r in router_obj.routes:
            if not (hasattr(r, "path") and isinstance(r.path, str)):
                continue
            matched = None
            if r.path.startswith(prefix):
                matched = prefix
            elif r.path.startswith(alt_prefix):
                matched = alt_prefix
            if matched:
                new_path = r.path[len(matched):]
                if not new_path.startswith("/"):
                    new_path = "/" + new_path
                # assign normalized path
                r.path = new_path
    except Exception:
        logger.exception("Failed to normalize generated router paths; proceeding to mount as-is")

    # Mount onto the application (not the local router) so changes are active immediately
    request.app.include_router(router_obj, prefix=prefix, include_in_schema=False)
    mounted_routers[cfg.name] = {"router": router_obj, "prefix": prefix, "slug": slug}
    logger.info(f"✅ Mounted routes for {cfg.name}:")
    for route in router_obj.routes:
        try:
            logger.info(f"- {prefix}{route.path}")
        except Exception:
            logger.info("- (route)")
    return {"status": "mounted", "endpoint": f"{prefix}/search"}


@router.post("/create")
async def create_search_api(payload: SearchConfigCreateRequest, request: Request):
    """Create a new Search API entry and version 1, then generate and mount its router.
    
    Pipeline-driven creation: `pipeline_name` is required in incoming JSON.
    Resolve pipeline -> export profile and enrich `cfg` with resolved
    `profile_name`, `chunk_database`, `vector_store`, and `vector_database`.
    """
    cfg = SearchConfig(
        name=payload.name,
        pipeline_name=payload.pipeline_name,
        top_k=payload.top_k,
        retrieval_mode=payload.retrieval_mode,
        payload_max_length=payload.payload_max_length,
        hnsw_ef=payload.hnsw_ef,
        score_threshold=payload.score_threshold,
        candidate_limit=payload.candidate_limit,
        alpha=payload.alpha,
        embedding_provider=payload.embedding_provider,
        embedding_model=payload.embedding_model,
        response_format=payload.response_format,
        include_document_metadata=payload.include_document_metadata,
        include_chunk_metadata=payload.include_chunk_metadata,
        include_scores=payload.include_scores,
        timeout_duration=payload.timeout_duration,
    )

    pipeline_name = payload.pipeline_name
    
    session = SessionLocal()
    mounted_successfully = False
    try:
        if not pipeline_name:
            raise HTTPException(status_code=400, detail="pipeline_name is required for /search-api/create")

        pd = session.execute(
            text("SELECT * FROM pipeline_details WHERE pipeline_name = :val LIMIT 1"),
            {"val": pipeline_name},
        ).mappings().first()
        if not pd:
            raise HTTPException(status_code=404, detail="Pipeline not found")
        
        export_profile_id = pd.get("export_profile_id")
        if not export_profile_id:
            raise HTTPException(status_code=400, detail="Pipeline does not have export profile mapping configured")
        
        prof = session.execute(
            text("SELECT profile_name, profile_config FROM profiles WHERE id = :id"),
            {"id": export_profile_id},
        ).mappings().first()
        if not prof:
            raise HTTPException(status_code=404, detail="Export profile not found")
        
        profile_name = prof.get("profile_name")
        profile_config = prof.get("profile_config") or {}
        
        chunk_store, chunk_database, vector_store, vector_database, discovered = _resolve_profile_stores(profile_config)
        
        if not (chunk_store and chunk_database and vector_store and vector_database):
            raise HTTPException(
                status_code=400,
                detail={
                    "error": "Profile does not have all required stores",
                    "discovered_keys": list(discovered.keys()),
                    "required": ["chunk_store", "chunk_database", "vector_store", "vector_database"],
                }
            )
        
        cfg.profile_name = profile_name
        cfg.data_store = chunk_store
        cfg.chunk_database = chunk_database
        cfg.vector_store = vector_store
        cfg.vector_database = vector_database
        cfg.pipeline_name = pipeline_name
        cfg.pipeline_id = str(pd.get("id") or "") or None
        
        # Insert into consolidated search_api table
        existing = session.execute(
            text("SELECT id FROM search_api WHERE name = :name"),
            {"name": cfg.name},
        ).mappings().first()

        if existing:
            raise HTTPException(status_code=409, detail=f"Search API '{cfg.name}' already exists")

        # Persist the resolved config (including chunk/vector stores) and API path
        config_dict = cfg.model_dump()
        config_json = json.dumps(config_dict, ensure_ascii=False)
        pipeline_name_val = pipeline_name
        slug = cfg.name.replace(" ", "_").lower()
        api_path = f"/api/{slug}/search"

        session.execute(
            text(
                """INSERT INTO search_api (name, version, is_active, pipeline_name, api_path, config_json)
                       VALUES (:name, 1, TRUE, :pipeline_name, :api_path, CAST(:config_json AS JSONB))"""
            ),
            {
                "name": cfg.name,
                "pipeline_name": pipeline_name_val,
                "api_path": api_path,
                "config_json": config_json,
            },
        )

        # Render router for version 1 and mount it before committing DB state.
        # This guarantees DB entry is persisted only when runtime mount succeeds.
        _render_versioned_and_alias(cfg, 1)
        prefix = _mount_router(cfg.name, request)
        mounted_successfully = True

        session.commit()
        return {
            "status": "created",
            "name": cfg.name,
            "version_number": 1,
            "endpoint": f"{prefix}/search",
            "resolved_config": cfg.model_dump(),
        }
    except HTTPException:
        session.rollback()
        if mounted_successfully:
            _unmount_router_runtime(cfg.name, request)
        raise
    except Exception as e:
        session.rollback()
        if mounted_successfully:
            _unmount_router_runtime(cfg.name, request)
        logger.exception("create_search_api error: %s", e)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()


@router.get("/{name}")
async def get_search_api_config(name: str, request: Request):
    """Return the active (currently mounted) config for the named Search API.

    Also guards reserved names so that paths like /search-api/list or
    /search-api/status correctly reach their dedicated handlers instead of
    being treated as an API name.
    """

    # If a reserved keyword accidentally routes here, delegate to the
    # appropriate handler so that UI calls like GET /search-api/list work.
    if name == "list":
        return await list_search_apis()
    if name == "status":
        return await check_status(request)
    if name == "logs":
        return await get_search_api_logs()

    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """SELECT id, name, version, is_active, pipeline_name, config_json, created_at, updated_at
                       FROM search_api
                       WHERE name = :name AND is_active = TRUE
                       ORDER BY version DESC
                       LIMIT 1"""
            ),
            {"name": name},
        ).mappings().first()

        if not row:
            raise HTTPException(status_code=404, detail=f"Search API '{name}' not found")

        raw = row.get("config_json") or {}
        try:
            cfg = json.loads(raw) if isinstance(raw, (str, bytes)) else raw
        except Exception:
            cfg = raw

        return {
            "name": name,
            "version_number": row.get("version"),
            "is_active": bool(row.get("is_active")),
            "pipeline_name": row.get("pipeline_name"),
            "created_at": row.get("created_at"),
            "updated_at": row.get("updated_at"),
            "config": cfg,
        }
    finally:
        session.close()


@router.get("/{name}/versions")
async def get_search_api_versions(name: str):
    """Return version history and metadata for a named Search API from the unified table."""
    session = SessionLocal()
    try:
        rows = session.execute(
            text(
                """SELECT name, version, is_active, pipeline_name, created_at, updated_at
                       FROM search_api
                       WHERE name = :name
                       ORDER BY version DESC"""
            ),
            {"name": name},
        ).mappings().all()

        if not rows:
            raise HTTPException(status_code=404, detail=f"Search API '{name}' not found")

        versions = [
            {
                "version_number": r.get("version"),
                "is_active": bool(r.get("is_active")),
                "pipeline_name": r.get("pipeline_name"),
                "created_at": r.get("created_at"),
                "updated_at": r.get("updated_at"),
            }
            for r in rows
        ]

        first = rows[0]
        return {
            "name": name,
            "created_at": first.get("created_at"),
            "updated_at": first.get("updated_at"),
            "versions": versions,
        }
    finally:
        session.close()


@router.get("/list")
async def list_search_apis():
    """List all active search APIs (current active version per name)."""

    session = SessionLocal()
    try:
        sql = """SELECT name, version, pipeline_name, created_at, updated_at
               FROM search_api
               WHERE is_active = TRUE
               ORDER BY name"""
        rows = session.execute(text(sql)).mappings().all()
        apis = [dict(r) for r in rows]
        return {"page": 1, "size": len(apis), "apis": apis}
    finally:
        session.close()
@router.post("/update/{name}")
async def update_search_api(name: str, body: Dict[str, Any], request: Request):
    """Update a Search API's configuration, creating a new version.

    Accepts JSON body with SearchConfig fields (plus any extra metadata). If
    `pipeline_name` or `pipeline_id` is provided, resolves and enriches the
    config. The full JSON body is stored in raw_config for this version.
    """
    
    session = SessionLocal()
    mounted_successfully = False
    try:
        # Ensure API exists
        existing = session.execute(
            text("SELECT COALESCE(MAX(version), 0) as max_ver FROM search_api WHERE name = :name"),
            {"name": name},
        ).mappings().first()
        if not existing or (existing["max_ver"] or 0) == 0:
            raise HTTPException(status_code=404, detail=f"Search API '{name}' not found")

        next_version = int(existing["max_ver"] or 0) + 1
        
        # Validate and construct new config
        cfg = SearchConfig.model_validate(body)
        cfg.name = name
        
        # Resolve pipeline if provided
        pipeline_name = body.get("pipeline_name") or body.get("pipelineName")
        pipeline_id = body.get("pipeline_id") or body.get("pipelineId")
        
        if pipeline_name or pipeline_id:
            query_col = "pipeline_name" if pipeline_name else "id"
            query_val = pipeline_name or pipeline_id
            
            pd = session.execute(
                text(f"SELECT * FROM pipeline_details WHERE {query_col} = :val LIMIT 1"),
                {"val": query_val},
            ).mappings().first()
            if not pd:
                raise HTTPException(status_code=404, detail="Pipeline not found")
            
            export_profile_id = pd.get("export_profile_id")
            if not export_profile_id:
                raise HTTPException(status_code=400, detail="Pipeline does not have export profile mapping")
            
            prof = session.execute(
                text("SELECT profile_name, profile_config FROM profiles WHERE id = :id"),
                {"id": export_profile_id},
            ).mappings().first()
            if not prof:
                raise HTTPException(status_code=404, detail="Export profile not found")
            
            profile_name = prof.get("profile_name")
            profile_config = prof.get("profile_config") or {}
            
            chunk_store, chunk_database, vector_store, vector_database, discovered = _resolve_profile_stores(profile_config)
            
            if not (chunk_store and chunk_database and vector_store and vector_database):
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": "Profile does not have all required stores",
                        "discovered_keys": list(discovered.keys()),
                    }
                )
            
            cfg.profile_name = profile_name
            cfg.data_store = chunk_store
            cfg.chunk_database = chunk_database
            cfg.vector_store = vector_store
            cfg.vector_database = vector_database
        
        # Deactivate previous versions for this API name
        session.execute(
            text("UPDATE search_api SET is_active = FALSE WHERE name = :name"),
            {"name": name},
        )

        # Insert new active version row into consolidated search_api table
        config_dict = cfg.model_dump()
        config_json = json.dumps(config_dict, ensure_ascii=False)
        pipeline_name_val = pipeline_name or body.get("pipelineName") or None
        slug = name.replace(" ", "_").lower()
        api_path = f"/api/{slug}/search"

        session.execute(
            text(
                """INSERT INTO search_api (name, version, is_active, pipeline_name, api_path, config_json)
                       VALUES (:name, :version, TRUE, :pipeline_name, :api_path, CAST(:config_json AS JSONB))"""
            ),
            {
                "name": name,
                "version": next_version,
                "pipeline_name": pipeline_name_val,
                "api_path": api_path,
                "config_json": config_json,
            },
        )

        # Render router and mount before commit so DB row is persisted only if load/mount succeeds.
        _render_versioned_and_alias(cfg, next_version)
        prefix = _mount_router(cfg.name, request)
        mounted_successfully = True

        session.commit()
        return {
            "status": "updated",
            "name": cfg.name,
            "version_number": next_version,
            "endpoint": f"{prefix}/search",
            "resolved_config": cfg.model_dump(),
        }
    except HTTPException:
        session.rollback()
        if mounted_successfully:
            _unmount_router_runtime(name, request)
        raise
    except Exception as e:
        session.rollback()
        if mounted_successfully:
            _unmount_router_runtime(name, request)
        logger.exception("update_search_api error: %s", e)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()


@router.post("/generate_from_pipeline")
async def generate_from_pipeline(pipeline_name: str = None, pipeline_id: str = None, request: Request = None):
    """Generate a Search API from a pipeline's export profile.
    
    Resolves pipeline → export profile → stores, creates SearchConfig snapshot,
        inserts a new versioned row into the unified search_api table, and generates the router.
    """
    if not pipeline_name and not pipeline_id:
        raise HTTPException(status_code=400, detail="pipeline_name or pipeline_id required")
    
    session = SessionLocal()
    mounted_successfully = False
    try:
        query_col = "pipeline_name" if pipeline_name else "id"
        query_val = pipeline_name or pipeline_id
        
        pd = session.execute(
            text(f"SELECT * FROM pipeline_details WHERE {query_col} = :val LIMIT 1"),
            {"val": query_val},
        ).mappings().first()
        if not pd:
            raise HTTPException(status_code=404, detail="Pipeline not found")
        
        export_profile_id = pd.get("export_profile_id")
        if not export_profile_id:
            raise HTTPException(status_code=400, detail="Pipeline does not have export profile mapping")
        
        prof = session.execute(
            text("SELECT profile_name, profile_config FROM profiles WHERE id = :id"),
            {"id": export_profile_id},
        ).mappings().first()
        if not prof:
            raise HTTPException(status_code=404, detail="Export profile not found")
        
        profile_name = prof.get("profile_name")
        profile_config = prof.get("profile_config") or {}
        
        chunk_store, chunk_database, vector_store, vector_database, discovered = _resolve_profile_stores(profile_config)
        
        if not (chunk_store and chunk_database and vector_store and vector_database):
            raise HTTPException(
                status_code=400,
                detail={
                    "error": "Profile does not have all required stores",
                    "discovered_keys": list(discovered.keys()),
                }
            )
        
        # Create SearchConfig from pipeline
        api_name = pipeline_name or f"pipeline_{pipeline_id}"
        cfg = SearchConfig(
            name=api_name,
            profile_name=profile_name,
            data_store=chunk_store,
            chunk_database=chunk_database,
            vector_store=vector_store,
            vector_database=vector_database,
        )
        
        # Determine next version from consolidated search_api table
        ver_row = session.execute(
            text("SELECT COALESCE(MAX(version), 0) as max_ver FROM search_api WHERE name = :name"),
            {"name": cfg.name},
        ).mappings().first()
        next_version = int(ver_row["max_ver"] or 0) + 1

        # Deactivate previous versions (if any) and insert new active version row
        session.execute(
            text("UPDATE search_api SET is_active = FALSE WHERE name = :name"),
            {"name": cfg.name},
        )

        config_dict = cfg.model_dump()
        config_json = json.dumps(config_dict, ensure_ascii=False)
        slug = cfg.name.replace(" ", "_").lower()
        api_path = f"/api/{slug}/search"
        session.execute(
            text(
                """INSERT INTO search_api (name, version, is_active, pipeline_name, api_path, config_json)
                       VALUES (:name, :version, :is_active, :pipeline_name, :api_path, CAST(:config_json AS JSONB))"""
            ),
            {
                "name": cfg.name,
                "version": next_version,
                "is_active": True,
                "pipeline_name": pipeline_name or pipeline_id,
                "api_path": api_path,
                "config_json": config_json,
            },
        )

        # Render and mount before commit so DB entry exists only when runtime load succeeds.
        _render_versioned_and_alias(cfg, next_version)
        prefix = _mount_router(cfg.name, request)
        mounted_successfully = True

        session.commit()
        return {
            "status": "created",
            "name": cfg.name,
            "version_number": next_version,
            "endpoint": f"{prefix}/search",
            "resolved_config": cfg.model_dump(),
        }
    except HTTPException:
        session.rollback()
        if mounted_successfully and request is not None:
            _unmount_router_runtime(cfg.name, request)
        raise
    except Exception as e:
        session.rollback()
        if mounted_successfully and request is not None:
            _unmount_router_runtime(cfg.name, request)
        logger.exception("generate_from_pipeline error: %s", e)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()


@router.post("/{name}/activate/{version}")
def activate_search_api_version(name: str, version: int, request: Request):
    """Activate a specific version for a Search API (rollback support)."""
    session = SessionLocal()
    try:
        # Ensure the requested version exists
        ver = session.execute(
            text(
                """SELECT config_json
                       FROM search_api
                       WHERE name = :name AND version = :version
                       LIMIT 1"""
            ),
            {"name": name, "version": version},
        ).mappings().first()
        if not ver:
            raise HTTPException(status_code=404, detail=f"Version {version} for API '{name}' not found")

        # Flip active flags for all versions of this API
        session.execute(
            text("UPDATE search_api SET is_active = FALSE WHERE name = :name"),
            {"name": name},
        )
        session.execute(
            text(
                "UPDATE search_api SET is_active = TRUE WHERE name = :name AND version = :version"
            ),
            {"name": name, "version": version},
        )
        session.commit()

        # Re-render router from stored config for this version
        cfg_data = ver["config_json"] or {}
        cfg = SearchConfig.model_validate(cfg_data)
        _render_versioned_and_alias(cfg, version)
        
        prefix = _mount_router(name, request)
        return {
            "status": "activated",
            "name": name,
            "version_number": version,
            "endpoint": f"{prefix}/search",
        }
    except HTTPException:
        raise
    except Exception as e:
        session.rollback()
        logger.error("activate_search_api_version error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()

@router.delete("/delete/{name}")
async def delete_router(name: str, request: Request):
    """Cascade-delete a Search API by name (supports slug/name variants).

    Sequence:
    1) unmount runtime routes
    2) delete generated router files
    3) delete evaluation run records
    4) delete search_api rows
    """
    session = SessionLocal()
    try:
        matched_names = _find_matching_api_names(session, name)
        existing_rows = 0
        for nm in matched_names:
            row = session.execute(
                text("SELECT COUNT(*) AS cnt FROM search_api WHERE name = :name"),
                {"name": nm},
            ).mappings().first()
            existing_rows += int((row or {}).get("cnt") or 0)

        # 1) Unmount runtime routes first
        slug = _normalize_api_name(name)
        prefix = f"/api/{slug}"
        app_router = request.app.router
        before_cnt = len(app_router.routes)
        for nm in matched_names:
            _unmount_router_runtime(nm, request)
        _unmount_router_runtime(name, request)
        app_level_removed = len(app_router.routes) != before_cnt

        # 2) Delete generated router files for matched names
        deleted_files = _delete_generated_router_files(matched_names + [name])

        # 3) Delete evaluation run records (queries first, then runs)
        eval_runs_removed = 0
        eval_queries_removed = 0
        for nm in matched_names:
            q_res = session.execute(
                text(
                    """DELETE FROM evaluation_run_query
                           WHERE run_id IN (
                               SELECT run_id FROM evaluation_run WHERE api_name = :name
                           )"""
                ),
                {"name": nm},
            )
            r_res = session.execute(
                text("DELETE FROM evaluation_run WHERE api_name = :name"),
                {"name": nm},
            )
            eval_queries_removed += int(q_res.rowcount or 0)
            eval_runs_removed += int(r_res.rowcount or 0)

        # 4) Delete DB entries for this API names
        search_api_removed = 0
        for nm in matched_names:
            res = session.execute(
                text("DELETE FROM search_api WHERE name = :name"),
                {"name": nm},
            )
            search_api_removed += int(res.rowcount or 0)
        session.commit()

        logger.info(
            "API '%s' cascade deleted. routes_removed=%s, db_rows_removed=%s, eval_runs_removed=%s, eval_queries_removed=%s, files_deleted=%d",
            name,
            app_level_removed,
            search_api_removed,
            eval_runs_removed,
            eval_queries_removed,
            len(deleted_files),
        )
        return {
            "status": "deleted" if (search_api_removed > 0 or app_level_removed or len(deleted_files) > 0) else "already_deleted",
            "name": name,
            "matched_names": matched_names,
            "app_level_routes_removed": app_level_removed,
            "search_api_rows_removed": search_api_removed,
            "evaluation_runs_removed": eval_runs_removed,
            "evaluation_run_queries_removed": eval_queries_removed,
            "router_files_deleted": deleted_files,
            "prefix": prefix,
        }
    except HTTPException:
        session.rollback()
        raise
    except Exception as e:
        session.rollback()
        logger.exception("delete_router error: %s", e)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()

@router.get("/status")
async def check_status(request: Request):
    # Collect dynamic API names actually mounted on the FastAPI app (not only those added via this module)
    active_names = set()
    for r in request.app.routes:
        if hasattr(r, "path") and r.path.startswith("/api/"):
            # Expected pattern: /api/{name}/search (may include other endpoints too)
            parts = r.path.split("/")
            # ['', 'api', '{name}', ...]
            if len(parts) >= 3 and parts[2]:
                active_names.add(parts[2])

    # Names mounted through this endpoint during current process lifetime
    mounted_names_local = set(mounted_routers.keys())

    # Files present on disk
    generated_dir = Path("generated_apis")  # align with main.py loader
    file_names = {p.stem.replace("_router", "") for p in generated_dir.glob("*_router.py")}

    # Orphaned = present on disk but not currently active
    orphaned_files = sorted(file_names - active_names)

    # Build per-name endpoint listing (only for active ones)
    routes_info = []
    for name in sorted(active_names):
        prefix = f"/api/{name}"
        endpoints = [r.path for r in request.app.routes if hasattr(r, "path") and r.path.startswith(prefix)]
        routes_info.append({
            "name": name,
            "prefix": prefix,
            "endpoints": endpoints,
            "mounted_via_generate_endpoint": name in mounted_names_local
        })

    return {
        "status": "ok",
        "active_count": len(active_names),
        "active_apis": routes_info,
        # Backward compatibility: provide original key expected by dashboard
        "mounted_routers": routes_info,
        # Optional alias some UIs may use
        "apis": routes_info,
        "mounted_via_endpoint_count": len(mounted_names_local),
        "orphaned_router_files": orphaned_files,
    }


@router.get("/logs")
async def get_search_api_logs(limit: int = 100, api_name: str | None = None):
    """
    Fetch recent search API logs from the database.

    Returns selected columns from `search_api_logs` table:
      api_name, collection_name, query_text, top_k, retrieval_mode,
      embedding_model, num_results, response_time_ms
    """
    DB_DSN = "postgresql://postgres:postgres@localhost:5432/RND"
    base_query = """
        SELECT api_name, collection_name, query_text, top_k, retrieval_mode, embedding_model, num_results, response_time_ms
        FROM search_api_logs
    """
    where_clause = ""
    params = []
    if api_name:
        where_clause = "WHERE api_name = $1"
        params = [api_name]

    order_limit = " ORDER BY called_at DESC, id DESC LIMIT $%d" % (len(params) + 1)
    sql = base_query + (" " + where_clause if where_clause else "") + order_limit
    try:
        conn = await asyncpg.connect(DB_DSN)
        rows = await conn.fetch(sql, *(params + [limit]))
        await conn.close()
        logs = [dict(r) for r in rows]
        return {"logs": logs}
    except Exception as e:
        logger.exception("Failed to fetch search_api_logs: %s", e)
        return {"error": str(e)}

