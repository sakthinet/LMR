from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, ValidationError, model_validator
from typing import Optional, List, Dict, Any
import ipaddress
import os
import uuid
import logging
import ntpath

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.keywrap import aes_key_wrap, aes_key_unwrap

from sqlalchemy.exc import IntegrityError
from sqlalchemy import select
from sqlalchemy.orm import Session

import psycopg2
from psycopg2 import OperationalError

from database import SessionLocal
from models import ConnectionProfile  # one-table model
from auth.session import create_session_token, delete_session_cookie, SESSION_COOKIE, get_user_from_session
from config import settings
from typing import Dict
from utils.path_utils import normalize_unc_path as normalize_unc_path_util

router = APIRouter(prefix="/rbac", tags=["RBAC"])

logger = logging.getLogger("rbac")


# -------------------------
# Auth Routes
# -------------------------
@router.post("/login")
async def login(username: str = Form(...), password: str = Form(...)):
    if settings.auth_users.get(username) == password:
        token = create_session_token(username)
        response = JSONResponse(content={"message": "Login successful"})
        response.set_cookie(
            SESSION_COOKIE,
            token,
            httponly=True,
            secure=False,
            samesite="Lax",
        )
        return response
    return JSONResponse(status_code=401, content={"status": "error", "message": "Invalid credentials"})


@router.get("/me")
async def get_current_user():
    # Auth temporarily disabled; always returns anonymous user
    return {"user": "anonymous"}


@router.post("/logout")
async def logout():
    response = JSONResponse(content={"message": "Logged out"})
    delete_session_cookie(response)
    return response


"""RBAC and Connection Profile routes.

Connection profile schema (request):

{
    "profile_name": "string",
    "profile_type": "string",
    "connection": {
        "type": "postgres",
        "parameters": {
            "endpoint": {
                "host": "string",
                "port": 5432,
                "database": "string"
            },
            "auth": {
                "method": "password",
                "username": "string",
                "password": "string"
            }
        }
    }
}

Only non-secret metadata is stored in metadata_json. Password is always
encrypted using envelope encryption (DEK wrapped by KEK via DPAPI).
"""


class PathAuthorizeRequest(BaseModel):
    path: str = Field(..., min_length=1, description="UNC or absolute path to authorize")


class PathAuthorizeResponse(BaseModel):
    path: str
    accessible: bool
    read: bool
    write: bool


def _normalize_unc_path(raw_path: str) -> str:
    """Normalize UNC / absolute paths for consistent RBAC checks.

    Uses `utils.path_utils.normalize_unc_path` as the canonical pre-normalizer,
    then applies Windows path normalization (`ntpath.normpath`) so behavior is
    consistent even if the service runs on non-Windows hosts.

    Handles:
    - extra/missing UNC slashes
    - mixed separators (/ and \\)
    - repeated inner separators
    - trailing separators
    """
    if not raw_path or not isinstance(raw_path, str):
        raise HTTPException(status_code=400, detail="path must be a non-empty string")

    s = raw_path.strip()
    if not s:
        raise HTTPException(status_code=400, detail="path must be a non-empty string")

    s = normalize_unc_path_util(s)

    if s.startswith("\\"):
        s = "\\\\" + s.lstrip("\\")

    normalized = ntpath.normpath(s)

    if normalized.startswith("\\") and not normalized.startswith("\\\\"):
        normalized = "\\" + normalized

    return normalized


class ConnectionProfileConnection(BaseModel):
        """Top-level connection spec used in createConnectionProfile.

        "type" is the discriminator (e.g., "postgres"). "parameters" is kept
        as a flexible mapping so new connection types can be added without
        changing this DTO, while we still validate structure for known types
        (currently postgres) inside the route implementation.

        The request JSON may supply connection-specific fields either nested
        under "parameters" or flat alongside "type". In the flat case, this
        model automatically normalizes all extra keys into "parameters" so
        that route logic can always read from ``connection.parameters``.
        """

        type: str = Field(..., min_length=1)
        parameters: Dict[str, Any] = Field(default_factory=dict)

        @model_validator(mode="before")
        @classmethod
        def _flatten_parameters(cls, values: Any):  # type: ignore[override]
            # Allow requests like:
            #   {"type": "llama_cloud", "base_url": "...", "api_key": "..."}
            # by moving all non-"type" keys into "parameters".
            if isinstance(values, dict) and "parameters" not in values:
                params = {k: v for k, v in values.items() if k not in {"type"}}
                values = {**values, "parameters": params}
            return values


class CreateConnectionProfileRequest(BaseModel):
        profile_name: str = Field(..., min_length=1)
        profile_type: str = Field(..., min_length=1)
        connection: ConnectionProfileConnection


class ConnectionProfileResponse(BaseModel):
    connection_id: str
    name: str
    type: str
    connection_type: str
    metadata: dict
    secret_set: bool


class TestConnectionProfileRequest(BaseModel):
    profile_name: str = Field(..., min_length=1)


class TestConnectionProfileResponse(BaseModel):
    connection_id: str
    profile_name: str
    connection_type: str
    success: bool
    message: str


class ListConnectionProfilesResponseItem(BaseModel):
    connection_id: str
    name: str
    type: str
    connection_type: str
    metadata: dict
    secret_set: bool


class ListConnectionProfilesResponse(BaseModel):
    items: List[ListConnectionProfilesResponseItem]


class DecryptConnectionProfileRequest(BaseModel):
    profile_name: str = Field(..., min_length=1)


class DecryptConnectionProfileResponse(BaseModel):
    connection_id: str
    profile_name: str
    connection_type: str
    password: str
    # Optional API base URL for API-style profiles (e.g., llama_cloud)
    base_url: Optional[str] = None
    # Non-secret metadata for the connection (endpoint/auth, etc.).
    metadata: Dict[str, Any] = Field(default_factory=dict)


@router.post("/authorize/path", response_model=PathAuthorizeResponse)
async def authorize_path(payload: PathAuthorizeRequest, request: Request):
    """Return effective permissions for the current user on a path.

    This route is intentionally thin:
    - Resolves the current user from the session cookie.
    - Normalizes the incoming UNC/absolute path.
    - Delegates permission resolution to services.rbac_service.

    No policy evaluation or rule computation is performed here.
    """

    # Try to resolve the logged-in user; if there is no valid
    # session cookie, fall back to an anonymous identity so that
    # this endpoint can be exercised without an explicit login.
    try:
        username = get_user_from_session(request)
    except HTTPException as exc:
        if exc.status_code == 401:
            username = "anonymous"
        else:
            raise
    normalized_path = _normalize_unc_path(payload.path)

    try:
        perms = get_effective_permissions(username, normalized_path)
    except NotImplementedError as e:
        # Surface a clear integration error so the caller knows RBAC
        # still needs to be wired to the real engine.
        raise HTTPException(status_code=501, detail=str(e)) from e
    except Exception as e:
        logger.exception(
            "Failed to resolve RBAC permissions for user %s on path %s: %s",
            username,
            normalized_path,
            e,
        )
        raise HTTPException(status_code=500, detail="Failed to resolve permissions") from e

    read = bool(perms.get("read"))
    write = bool(perms.get("write"))

    # Enforce the invariant that write implies read.
    if write and not read:
        read = True

    accessible = read or write

    return PathAuthorizeResponse(
        path=normalized_path,
        accessible=accessible,
        read=read,
        write=write,
    )


# -------------------------
# Internal validation models for postgres parameters
# -------------------------

class _PostgresEndpoint(BaseModel):
    host: str = Field(..., min_length=1)
    port: int = Field(5432, ge=1, le=65535)
    database: Optional[str] = None


class _PostgresAuth(BaseModel):
    method: str = Field(..., min_length=1)
    username: str = Field(..., min_length=1)
    password: str = Field(..., min_length=1)


class _PostgresParameters(BaseModel):
    endpoint: _PostgresEndpoint
    auth: _PostgresAuth


# -------------------------
# Crypto Helpers
# -------------------------
def _load_kek() -> tuple[bytes, str]:
    """Load the KEK directly from environment variables.

    This version does not use DPAPI or any on-disk keystore. Instead it
    expects a base64-encoded KEK and an optional key id to be provided
    via the process environment:

    - CONTEXTCRAFT_KEK_B64: required, base64-encoded KEK bytes
    - CONTEXTCRAFT_KEK_KEY_ID: optional, stable non-secret identifier
    """

    env_kek_b64 = os.getenv("CONTEXTCRAFT_KEK_B64")
    if not env_kek_b64:
        raise RuntimeError("CONTEXTCRAFT_KEK_B64 must be set to a base64-encoded KEK")

    try:
        import base64 as _b64

        kek_bytes = _b64.b64decode(env_kek_b64)
    except Exception as exc:
        raise RuntimeError("Failed to decode CONTEXTCRAFT_KEK_B64") from exc

    env_kek_key_id = os.getenv("CONTEXTCRAFT_KEK_KEY_ID") or "env-kek"
    return kek_bytes, env_kek_key_id

def get_effective_permissions(username: str, path: str) -> Dict[str, bool]:
    """Return effective permissions for a user on a given path.

    This implementation is a pragmatic default:
    - It checks filesystem accessibility from the *backend process* account
      using os.path.exists and os.access.
    - It does NOT impersonate the end user; if you have a central RBAC
      engine or AD-based ACL evaluation, replace this with a call into
      that system.

    Returned mapping:
      {"read": bool, "write": bool}
    """

    try:
        exists = os.path.exists(path)
    except Exception as e:
        logger.exception("Failed to stat path '%s' for user '%s': %s", path, username, e)
        exists = False

    if not exists:
        # If the path does not exist or cannot be seen by the backend
        # account, treat it as not accessible.
        return {"read": False, "write": False}

    # os.access checks effective permissions of the backend process user.
    can_read = os.access(path, os.R_OK)
    can_write = os.access(path, os.W_OK)

    # write implies read from an API perspective
    if can_write and not can_read:
        can_read = True

    return {"read": bool(can_read), "write": bool(can_write)}

def _build_aad(connection_id: uuid.UUID) -> bytes:
    """
    Stable AAD for one-table design:
    - does NOT depend on profile_name (which can change)
    """
    return f"{connection_id}:db_password".encode("utf-8")


def _encrypt_password(password: str, aad: bytes) -> dict:
    """
    Envelope encryption:
    - Generate DEK (32 bytes)
    - Encrypt password via AES-256-GCM with nonce (12 bytes) => ct||tag
    - Store tag separately (16 bytes)
    - Wrap DEK using KEK (AES key wrap RFC3394)
    """
    dek = os.urandom(32)    # 256-bit
    nonce = os.urandom(12)  # 96-bit nonce for GCM

    ct_with_tag = AESGCM(dek).encrypt(nonce, password.encode("utf-8"), aad)
    if len(ct_with_tag) < 16:
        raise RuntimeError("Ciphertext too short to contain GCM tag")

    ciphertext = ct_with_tag[:-16]
    tag = ct_with_tag[-16:]

    kek_bytes, kek_key_id = _load_kek()
    wrapped_dek = aes_key_wrap(kek_bytes, dek)

    return {
        "ciphertext": ciphertext,
        "nonce": nonce,
        "tag": tag,
        "wrapped_dek": wrapped_dek,
        "kek_key_id": kek_key_id,
        "algo": "AES-256-GCM",
    }


def decrypt_password_for_profile(cp: ConnectionProfile) -> str:
    """
    Decrypts the password stored in the connection_profile row.
    """
    if cp.nonce is None or len(cp.nonce) != 12:
        raise RuntimeError("Invalid nonce length; expected 12 bytes")
    if cp.tag is None or len(cp.tag) != 16:
        raise RuntimeError("Invalid tag length; expected 16 bytes")

    aad = _build_aad(cp.connection_id)

    kek_bytes, env_kek_key_id = _load_kek()
    if cp.kek_key_id and cp.kek_key_id != env_kek_key_id:
        raise RuntimeError("KEK mismatch: secret wrapped with a different KEK id")

    try:
        dek = aes_key_unwrap(kek_bytes, cp.wrapped_dek)
    except Exception as e:
        raise RuntimeError("Failed to unwrap DEK") from e

    try:
        ct_with_tag = cp.ciphertext + cp.tag
        pt = AESGCM(dek).decrypt(cp.nonce, ct_with_tag, aad)
        return pt.decode("utf-8")
    except Exception as e:
        raise RuntimeError("Failed to decrypt password") from e


# -------------------------
# Routes (One-table)
# -------------------------
@router.post("/createConnectionProfile", response_model=ConnectionProfileResponse)
async def create_connection_profile(payload: CreateConnectionProfileRequest):
    """Create a new connection profile.

    Fixed fields stay at the top-level (profile_name, profile_type). All
    connection-specific details are under ``connection`` so that new
    connection types can be added from the frontend without changing this
    DTO frequently.
    """

    # Determine high-level connection type primarily from profile_type so
    # that clients can use coarse values like "Postgres", "Qdrant",
    # "API Connection" and reserve connection.type for broader
    # categories like "DB" / "API" without strict validation.
    profile_type_raw = (payload.profile_type or "").strip().lower()
    conn_type_raw_req = (payload.connection.type or "").strip().lower()

    # Treat common profile_type aliases as postgres.
    is_postgres = profile_type_raw in {"postgres", "postgresql", "database", "db"}

    if is_postgres:
        conn_type = "postgres"
    else:
        # Normalize qdrant-style profile types so that missing secrets are
        # allowed for those connections.
        if profile_type_raw in {"qdrant", "vector_store", "vectorstore"}:
            conn_type = "qdrant"
        else:
            # Fallback to whatever the client provided for connection.type
            # or the raw profile_type; we do not enforce a fixed enum here.
            conn_type = conn_type_raw_req or profile_type_raw or "unknown"

    # Normalize and validate connection-specific parameters.
    params_raw = payload.connection.parameters or {}

    # Postgres: strict validation and normalized structure
    if is_postgres:
        # Support both the new nested shape and a legacy flat shape
        # to avoid breaking existing clients.
        def _build_pg_params_from_flat(flat: Dict[str, Any]) -> "_PostgresParameters":
            missing = [k for k in ("host", "username", "password") if not flat.get(k)]
            if missing:
                raise HTTPException(
                    status_code=400,
                    detail=f"Missing required connection parameters: {', '.join(missing)}",
                )
            structured = {
                "endpoint": {
                    "host": flat.get("host"),
                    "port": flat.get("port", 5432),
                    "database": flat.get("database"),
                },
                "auth": {
                    "method": flat.get("method", "password"),
                    "username": flat.get("username"),
                    "password": flat.get("password"),
                },
            }
            return _PostgresParameters(**structured)

        try:
            if "endpoint" in params_raw and "auth" in params_raw:
                # New nested shape
                pg_params = _PostgresParameters(**params_raw)
            else:
                # Fallback: legacy flat shape
                pg_params = _build_pg_params_from_flat(params_raw)
        except ValidationError as e:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid connection.parameters for postgres: {e.errors()}",
            ) from e

        host = pg_params.endpoint.host.strip()
        if not host:
            raise HTTPException(status_code=400, detail="endpoint.host must be non-empty")

        # Basic host validation: allow either IP (v4/v6) or DNS name.
        # We only reject empty; if ipaddress parsing fails, we still accept
        # assuming it is a DNS hostname.
        try:
            ipaddress.ip_address(host)
        except ValueError:
            # Not an IP; treat as DNS name and accept
            pass

        if pg_params.auth.method.lower() != "password":
            raise HTTPException(status_code=400, detail="auth.method must be 'password' for postgres")

        secret_value = pg_params.auth.password
        # Non-secret metadata only; do NOT store password here.
        metadata = {
            "endpoint": {
                "host": host,
                "port": pg_params.endpoint.port,
                "database": pg_params.endpoint.database,
            },
            "auth": {
                "method": pg_params.auth.method,
                "username": pg_params.auth.username,
            },
        }

    else:
        # Generic connection type (e.g., llama_cloud API, qdrant). We treat
        # parameters as flexible but still extract a single secret
        # value (password/api_key) and strip it out of metadata_json.
        #
        # Accept both a nested shape:
        #   {"endpoint": {...}, "auth": {"api_key": "..."}}
        # and a flat shape:
        #   {"base_url": "...", "api_key": "..."}

        if "endpoint" in params_raw or "auth" in params_raw:
            # Already nested; use as-is.
            endpoint = params_raw.get("endpoint") or {}
            auth_meta = params_raw.get("auth") or {}
        else:
            # Normalize flat parameters into nested endpoint/auth.
            endpoint = {
                # Common naming variants for an API base URL
                "base_url": params_raw.get("base_url") or params_raw.get("url") or params_raw.get("endpoint"),
            }
            auth_meta = {
                "method": params_raw.get("method", "api_key"),
                "username": params_raw.get("username"),
                "password": params_raw.get("password"),
                "api_key": params_raw.get("api_key"),
            }

        secret_value = (
            auth_meta.get("password")
            or auth_meta.get("api_key")
            or params_raw.get("password")
            or params_raw.get("api_key")
        )

        # For some connection types (e.g., qdrant without auth), it is
        # valid to omit any secret entirely. In that case we store only
        # metadata and leave the encrypted secret fields empty.
        if not secret_value and conn_type not in {"qdrant"}:
            raise HTTPException(
                status_code=400,
                detail="Missing secret in connection.parameters (expected 'password' or 'api_key')",
            )

        # For non-postgres, we do not enforce host validation rules; we
        # simply pass through whatever endpoint/auth metadata is provided
        # (minus the secret itself).
        metadata = {
            "endpoint": endpoint,
            "auth": {k: v for k, v in auth_meta.items() if k not in {"password", "api_key"}},
        }

    db: Session = SessionLocal()
    try:
        existing = db.execute(
            select(ConnectionProfile).where(ConnectionProfile.name == payload.profile_name)
        ).scalar_one_or_none()
        if existing is not None:
            raise HTTPException(status_code=409, detail="Connection profile with this name already exists")

        # Generate connection_id in app so encryption can happen before insert
        connection_id = uuid.uuid4()

        # Only encrypt when a secret is actually provided. For metadata-only
        # profiles (e.g., qdrant with no auth), we leave the secret fields
        # empty.
        enc = None
        if secret_value:
            aad = _build_aad(connection_id)
            enc = _encrypt_password(secret_value, aad)

        cp = ConnectionProfile(
            connection_id=connection_id,
            name=payload.profile_name,
            type=payload.profile_type,
            connection_type=conn_type,
            metadata_json=metadata,

            ciphertext=enc["ciphertext"] if enc else None,
            nonce=enc["nonce"] if enc else None,
            tag=enc["tag"] if enc else None,
            wrapped_dek=enc["wrapped_dek"] if enc else None,
            kek_key_id=enc["kek_key_id"] if enc else None,
            algo=enc["algo"] if enc else None,
        )

        db.add(cp)
        db.commit()
        db.refresh(cp)

        return ConnectionProfileResponse(
            connection_id=str(cp.connection_id),
            name=cp.name,
            type=cp.type,
            connection_type=cp.connection_type,
            metadata=cp.metadata_json or {},
            secret_set=bool(cp.ciphertext and cp.nonce and cp.tag and cp.wrapped_dek and cp.kek_key_id),
        )

    except HTTPException:
        db.rollback()
        raise
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Connection profile with this name already exists")
    except Exception as e:
        db.rollback()
        # Surface the underlying error type and message to help debug KEK/env issues.
        # Provide extra diagnostics if the KEK env var appears to be misconfigured.
        msg = f"Failed to create connection profile: {type(e).__name__}: {e}"
        if isinstance(e, RuntimeError) and "CONTEXTCRAFT_KEK_B64" in str(e):
            raw_kek = os.getenv("CONTEXTCRAFT_KEK_B64")
            present = raw_kek is not None
            length = len(raw_kek) if raw_kek else 0
            msg = (
                "KEK env misconfigured: CONTEXTCRAFT_KEK_B64 present="
                f"{present}, length={length}. Underlying error: {e}"
            )

        raise HTTPException(
            status_code=500,
            detail=msg,
        ) from e
    finally:
        db.close()


@router.put("/updateConnectionProfile", response_model=ConnectionProfileResponse)
async def update_connection_profile(payload: CreateConnectionProfileRequest):
    """Update an existing connection profile.

    Uses the same request shape as create_connection_profile. Looks up an
    existing profile by profile_name and overwrites its connection
    details, while preserving existing metadata/secret when fields are
    omitted from the request.
    """

    db: Session = SessionLocal()
    try:
        cp = db.execute(
            select(ConnectionProfile).where(ConnectionProfile.name == payload.profile_name)
        ).scalar_one_or_none()

        if cp is None:
            raise HTTPException(status_code=404, detail="Connection profile not found")

        params_raw = payload.connection.parameters or {}

        # Determine effective connection type.
        # For safety, we primarily trust the existing row's
        # connection_type so that an arbitrary value like "Database"
        # in the request does not accidentally change a postgres
        # profile into a generic API profile.
        conn_type_raw_req = (payload.connection.type or "").strip().lower()
        existing_conn_type_raw = (cp.connection_type or "").strip().lower()

        is_postgres = (
            existing_conn_type_raw in ("postgres", "postgresql")
            or conn_type_raw_req in ("postgres", "postgresql")
        )

        if is_postgres:
            conn_type = "postgres"
        else:
            conn_type_raw = conn_type_raw_req or existing_conn_type_raw
            conn_type = conn_type_raw or "unknown"

        secret_value: Optional[str] = None

        if is_postgres:
            # Reuse the same strict validation as create_connection_profile.
            def _build_pg_params_from_flat(flat: Dict[str, Any]) -> "_PostgresParameters":
                missing = [k for k in ("host", "username", "password") if not flat.get(k)]
                if missing:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Missing required connection parameters: {', '.join(missing)}",
                    )
                structured = {
                    "endpoint": {
                        "host": flat.get("host"),
                        "port": flat.get("port", 5432),
                        "database": flat.get("database"),
                    },
                    "auth": {
                        "method": flat.get("method", "password"),
                        "username": flat.get("username"),
                        "password": flat.get("password"),
                    },
                }
                return _PostgresParameters(**structured)

            try:
                if "endpoint" in params_raw and "auth" in params_raw:
                    pg_params = _PostgresParameters(**params_raw)
                else:
                    pg_params = _build_pg_params_from_flat(params_raw)
            except ValidationError as e:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid connection.parameters for postgres: {e.errors()}",
                ) from e

            host = pg_params.endpoint.host.strip()
            if not host:
                raise HTTPException(status_code=400, detail="endpoint.host must be non-empty")

            try:
                ipaddress.ip_address(host)
            except ValueError:
                # Not an IP; treat as DNS name and accept
                pass

            if pg_params.auth.method.lower() != "password":
                raise HTTPException(status_code=400, detail="auth.method must be 'password' for postgres")

            secret_value = pg_params.auth.password
            metadata: Dict[str, Any] = {
                "endpoint": {
                    "host": host,
                    "port": pg_params.endpoint.port,
                    "database": pg_params.endpoint.database,
                },
                "auth": {
                    "method": pg_params.auth.method,
                    "username": pg_params.auth.username,
                },
            }

        else:
            # Generic/API-style connection (e.g., llama_cloud, qdrant).
            # Start from existing metadata and overlay incoming fields so
            # that omitted fields are preserved instead of nulled out.
            existing_meta = cp.metadata_json or {}
            existing_endpoint = existing_meta.get("endpoint") or {}
            existing_auth = existing_meta.get("auth") or {}

            if "endpoint" in params_raw or "auth" in params_raw:
                endpoint_in = params_raw.get("endpoint") or {}
                auth_in = params_raw.get("auth") or {}
                endpoint = {**existing_endpoint, **endpoint_in}
                # Strip secrets from metadata; keep only non-secret fields.
                auth_for_metadata = {
                    **{k: v for k, v in existing_auth.items() if k not in {"password", "api_key"}},
                    **{k: v for k, v in auth_in.items() if k not in {"password", "api_key"}},
                }
                # Secret, if any, comes only from the incoming payload.
                secret_source = auth_in
            else:
                # Flat shape: map base_url/method/username, preserving
                # existing endpoint/auth when not provided.
                base_url_val = (
                    params_raw.get("base_url")
                    or params_raw.get("url")
                    or params_raw.get("endpoint")
                )
                if base_url_val is not None:
                    endpoint = {**existing_endpoint, "base_url": base_url_val}
                else:
                    endpoint = existing_endpoint

                auth_for_metadata = {
                    k: v for k, v in existing_auth.items() if k not in {"password", "api_key"}
                }
                method_val = params_raw.get("method")
                username_val = params_raw.get("username")
                if method_val is not None:
                    auth_for_metadata["method"] = method_val
                if username_val is not None:
                    auth_for_metadata["username"] = username_val

                secret_source = params_raw

            # Secret is optional for some connection types (e.g., qdrant
            # without auth). If provided, we re-encrypt it; if omitted, we
            # keep the existing encrypted secret.
            secret_value = (
                (secret_source or {}).get("password")
                or (secret_source or {}).get("api_key")
            )

            has_existing_secret = bool(
                cp.ciphertext and cp.nonce and cp.tag and cp.wrapped_dek and cp.kek_key_id
            )
            if not secret_value and not has_existing_secret and conn_type not in {"qdrant"}:
                raise HTTPException(
                    status_code=400,
                    detail="Missing secret in connection.parameters (expected 'password' or 'api_key')",
                )

            metadata = {
                "endpoint": endpoint,
                "auth": auth_for_metadata,
            }

        # Encrypt new secret when provided; otherwise, preserve any
        # existing encrypted secret (if present).
        if secret_value:
            aad = _build_aad(cp.connection_id)
            enc = _encrypt_password(secret_value, aad)
            cp.ciphertext = enc["ciphertext"]
            cp.nonce = enc["nonce"]
            cp.tag = enc["tag"]
            cp.wrapped_dek = enc["wrapped_dek"]
            cp.kek_key_id = enc["kek_key_id"]
            cp.algo = enc["algo"]

        cp.type = payload.profile_type
        cp.connection_type = conn_type
        cp.metadata_json = metadata

        db.add(cp)
        db.commit()
        db.refresh(cp)

        return ConnectionProfileResponse(
            connection_id=str(cp.connection_id),
            name=cp.name,
            type=cp.type,
            connection_type=cp.connection_type,
            metadata=cp.metadata_json or {},
            secret_set=bool(cp.ciphertext and cp.nonce and cp.tag and cp.wrapped_dek and cp.kek_key_id),
        )

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        msg = f"Failed to update connection profile: {type(e).__name__}: {e}"
        if isinstance(e, RuntimeError) and "CONTEXTCRAFT_KEK_B64" in str(e):
            raw_kek = os.getenv("CONTEXTCRAFT_KEK_B64")
            present = raw_kek is not None
            length = len(raw_kek) if raw_kek else 0
            msg = (
                "KEK env misconfigured: CONTEXTCRAFT_KEK_B64 present="
                f"{present}, length={length}. Underlying error: {e}"
            )

        raise HTTPException(status_code=500, detail=msg) from e
    finally:
        db.close()


@router.post("/testConnectionProfile", response_model=TestConnectionProfileResponse)
async def test_connection_profile(payload: TestConnectionProfileRequest):
    db: Session = SessionLocal()
    try:
        cp = db.execute(
            select(ConnectionProfile).where(ConnectionProfile.name == payload.profile_name)
        ).scalar_one_or_none()

        if cp is None:
            raise HTTPException(status_code=404, detail="Connection profile not found")

        # Simple health check:
        # - If a secret is stored, verify it can be decrypted.
        # - If no secret is stored (metadata-only profile), treat as success.
        has_secret = bool(cp.ciphertext and cp.nonce and cp.tag and cp.wrapped_dek and cp.kek_key_id)

        if has_secret:
            try:
                _ = decrypt_password_for_profile(cp)
                success = True
                message = "Profile found and secret decrypted successfully"
            except Exception:
                success = False
                message = "Profile found but failed to decrypt stored secret"
        else:
            success = True
            message = "Profile found with no stored secret (metadata-only)"

        return TestConnectionProfileResponse(
            connection_id=str(cp.connection_id),
            profile_name=cp.name,
            connection_type=cp.connection_type,
            success=success,
            message=message,
        )

    finally:
        db.close()


@router.get("/listConnectionProfiles", response_model=ListConnectionProfilesResponse)
async def list_connection_profiles(profile_type: Optional[str] = None):
    """
    Returns ONLY safe fields (do not serialize ORM objects directly).
    """
    db: Session = SessionLocal()
    try:
        stmt = select(ConnectionProfile)
        if profile_type:
            stmt = stmt.where(ConnectionProfile.type == profile_type)

        rows = db.execute(stmt).scalars().all()
        items: list[ListConnectionProfilesResponseItem] = []

        for cp in rows:
            secret_set = bool(cp.ciphertext and cp.nonce and cp.tag and cp.wrapped_dek and cp.kek_key_id)
            items.append(
                ListConnectionProfilesResponseItem(
                    connection_id=str(cp.connection_id),
                    name=cp.name,
                    type=cp.type,
                    connection_type=cp.connection_type,
                    metadata=cp.metadata_json or {},
                    secret_set=secret_set,
                )
            )

        return ListConnectionProfilesResponse(items=items)
    finally:
        db.close()


@router.post("/decryptConnectionProfile", response_model=DecryptConnectionProfileResponse)
async def decrypt_connection_profile(payload: DecryptConnectionProfileRequest):
    """
    ⚠️ Returns plaintext password (for testing).
    Protect this route before production (auth, allowlist, audit, etc.).
    """
    db: Session = SessionLocal()
    try:
        cp = db.execute(
            select(ConnectionProfile).where(ConnectionProfile.name == payload.profile_name)
        ).scalar_one_or_none()

        if cp is None:
            raise HTTPException(status_code=404, detail="Connection profile not found")

        # If an encrypted secret is stored, decrypt it; otherwise treat
        # password as empty so metadata-only profiles (e.g., qdrant without
        # auth) can still be used for their endpoint configuration.
        has_secret = bool(cp.ciphertext and cp.nonce and cp.tag and cp.wrapped_dek and cp.kek_key_id)
        if has_secret:
            try:
                password = decrypt_password_for_profile(cp)
            except Exception as e:
                # Include underlying error to help debug KEK/env issues.
                raise HTTPException(
                    status_code=500,
                    detail=f"Failed to decrypt password: {type(e).__name__}: {e}",
                ) from e
        else:
            password = ""

        # For API-style profiles (e.g., llama_cloud, qdrant) and also
        # database-style ones (e.g., postgres), surface a base URL derived
        # from metadata_json so workers can configure clients without
        # hard-coding endpoints. We treat this generically for any
        # connection_type that stores an "endpoint" mapping.
        metadata = cp.metadata_json or {}
        base_url: Optional[str] = None
        endpoint = metadata.get("endpoint") or {}
        if isinstance(endpoint, dict):
            # Convention: store API endpoint as
            # { "endpoint": { "base_url": "https://..." } }
            base_url_val = endpoint.get("base_url") or endpoint.get("url")
            if isinstance(base_url_val, str) and base_url_val.strip():
                base_url = base_url_val.strip()

        return DecryptConnectionProfileResponse(
            connection_id=str(cp.connection_id),
            profile_name=cp.name,
            connection_type=cp.connection_type,
            password=password,
            base_url=base_url,
            metadata=metadata,
        )
    finally:
        db.close()
