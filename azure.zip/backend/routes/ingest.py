from fastapi import APIRouter, Form
from typing import List, Optional
import os
import shutil
import uuid
from models import log_task_execution
import datetime
from celery import Celery
from config import settings  # NEW
from sqlalchemy import text  # NEW
from pydantic import BaseModel, ConfigDict, Field  # NEW
from typing import Dict, Any  # NEW
import json  # NEW
from sqlalchemy.exc import IntegrityError  # NEW
import logging

celery_app = Celery(broker=settings.celery_broker_url)

router = APIRouter(prefix="/ingest", tags=["Ingest"])

# NEW: Request model for new ingest payload
class IngestRequest(BaseModel):
    dag_id: str
    run_id: str
    import_config: Dict[str, Any]
    model_config = ConfigDict(extra="allow")

# NEW: Worker results models
class FolderResult(BaseModel):
    folder_id: str
    document_name: Optional[str] = None
    file_hash: Optional[str] = None
    source_path: Optional[str] = None
    model_config = ConfigDict(extra="allow")

class WorkerResult(BaseModel):
    task_id: str
    status: str
    process_name: Optional[str] = None
    job_id: Optional[str] = None
    error_message: Optional[str] = None
    folders: List[FolderResult] = Field(default_factory=list)
    cdc_enabled: Optional[bool] = False
    model_config = ConfigDict(extra="allow")

logger = logging.getLogger(__name__)

@router.post("/files")
def ingest_files(
    req: IngestRequest,
):
    # Create DB session
    from database import SessionLocal
    session = SessionLocal()
    try:
        # Persist to public.task_details per new schema with UUID collision retry
        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, started_at, job_id, payload
            ) VALUES (
                :id, :process_name, :task_type, :status, now(), :job_id, CAST(:payload AS JSONB)
            )
            """

        )

        MAX_RETRIES = 5
        task_id = None
        for _ in range(MAX_RETRIES):
            candidate = str(uuid.uuid4())
            try:
                session.execute(
                    insert_sql,
                    {
                        "id": candidate,
                        "process_name": req.dag_id,
                        "task_type": "Import",
                        "status": "submitted",
                        "job_id": req.run_id,
                        "payload": json.dumps(req.import_config),
                    },
                )
                session.commit()
                task_id = candidate
                break
            except IntegrityError:
                session.rollback()
                continue
        if not task_id:
            return {"status": "error", "message": "Could not allocate unique task id after retries"}

        # Determine import source and enqueue worker task
        import_source = str(req.import_config.get("ImportSource", "")).strip()
        if not import_source:
            return {"status": "error", "message": "ImportSource is required in import_config"}

        # Route per import source; Folder -> ingest_worker.ingest_files_task
        if import_source.lower() == "folder":
            queue_name = "folder"  # normalized lowercase
            worker_name = f"{queue_name}_worker.{queue_name}_task".lower()
            # Update task_details with worker and queue info  # NEW
            session.execute(
                text(
                    """
                    UPDATE public.task_details
                    SET worker_name = :worker_name,
                        queue_name = :queue_name
                    WHERE id = :id
                    """
                ),
                {"worker_name": worker_name.lower(), "queue_name": queue_name, "id": task_id},
            )
            session.commit()

            celery_app.send_task(
                worker_name.lower(),
                args=[task_id, req.import_config, req.dag_id, req.run_id],
                queue=queue_name,
            )
        else:
            # Unsupported source for now
            return {"status": "error", "message": f"Unsupported ImportSource: {import_source}"}

        return {"task_id": task_id, "status": "submitted"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

@router.post("/worker-results")
def worker_results(body: WorkerResult):
    """Callback endpoint for workers to report results and finalize bookkeeping.

    Expects JSON with: task_id, status, folders[{folder_id, document_name}], process_name, job_id, error_message
    """
    from database import SessionLocal
    session = SessionLocal()

    try:
        logger.info(f"Received worker results for task {body.task_id}: {body.model_dump_json()}")
        raw_folders = body.folders or []

        def _truthy(val: Optional[Any]) -> bool:
            if isinstance(val, bool):
                return val
            if isinstance(val, str):
                return val.strip().lower() in {"true", "1", "yes", "y", "on"}
            if isinstance(val, (int, float)):
                return val != 0
            return bool(val)

        # CDC detection (top-level or any folder)
        cdc_enabled = _truthy(getattr(body, "cdc_enabled", None))
        if not cdc_enabled:
            for fr in raw_folders:
                marker = getattr(fr, "cdc_enabled", None)
                if _truthy(marker):
                    cdc_enabled = True
                    break

        # Per-folder status and processing
        folder_statuses = {}
        processed_folders = []
        skipped_folders = []
        success_folders = []
        # track folder_ids that represent updated files (existing file replaced)
        updated_folder_ids = set()

        # Get DB columns for document_details
        cols_info = session.execute(
            text(
                """
                SELECT column_name, data_type
                FROM information_schema.columns
                WHERE table_schema = 'public' AND table_name = 'document_details'
                """
            )
        ).mappings().all()
        col_names = {c["column_name"]: c.get("data_type") for c in cols_info}

        def build_insert_for_row(fr: FolderResult):
            cols = []
            vals = []
            safe_doc_name = fr.document_name or fr.folder_id or "unknown"
            params = {
                "id": str(uuid.uuid4()),
                "folder_id": fr.folder_id,
                "document_name": safe_doc_name,
                "process_name": body.process_name or "",
                "job_id": body.job_id or "",
            }
            if "id" in col_names:
                cols.append("id"); vals.append(":id")
            if "folder_id" in col_names:
                cols.append("folder_id"); vals.append(":folder_id")
            if "document_name" in col_names:
                cols.append("document_name"); vals.append(":document_name")
            if "source_path" in col_names and fr.source_path:
                cols.append("source_path"); vals.append(":source_path"); params["source_path"] = fr.source_path
            if "file_hash" in col_names and fr.file_hash:
                cols.append("file_hash"); vals.append(":file_hash"); params["file_hash"] = fr.file_hash
            if "process_name" in col_names:
                cols.append("process_name"); vals.append(":process_name")
            if "job_id" in col_names:
                cols.append("job_id"); vals.append(":job_id")
            if "ingestion_status" in col_names:
                cols.append("ingestion_status"); vals.append(":ingestion_status"); params["ingestion_status"] = "success"
            if "parsing_status" in col_names:
                cols.append("parsing_status"); vals.append(":parsing_status"); params["parsing_status"] = "pending"
            if "text_processing_status" in col_names:
                cols.append("text_processing_status"); vals.append(":text_processing_status"); params["text_processing_status"] = "pending"
            if "chunking_status" in col_names:
                cols.append("chunking_status"); vals.append(":chunking_status"); params["chunking_status"] = "pending"
            if "embedding_status" in col_names:
                cols.append("embedding_status"); vals.append(":embedding_status"); params["embedding_status"] = "pending"
            if "export_status" in col_names:
                cols.append("export_status"); vals.append(":export_status"); params["export_status"] = "pending"
            if "last_successful_stage" in col_names:
                cols.append("last_successful_stage"); vals.append(":last_successful_stage"); params["last_successful_stage"] = "ingestion"
            if "updated_at" in col_names:
                dt = (col_names.get("updated_at") or "").lower()
                cols.append("updated_at")
                if "timestamp" in dt:
                    vals.append("now()")
                else:
                    vals.append(":updated_at"); params["updated_at"] = None
            # If this row is an updated document (replacement), and the table
            # has a `reprocess_flag` column, set it to true so downstream export knows
            # this is a replacement. Use a new attribute set during CDC logic.
            if "reprocess_flag" in col_names:
                if getattr(fr, "_reprocess", False):
                    cols.append("reprocess_flag"); vals.append(":reprocess_flag"); params["reprocess_flag"] = True
                else:
                    cols.append("reprocess_flag"); vals.append(":reprocess_flag"); params["reprocess_flag"] = False
            sql = f"INSERT INTO public.document_details ({', '.join(cols)}) VALUES ({', '.join(vals)})"
            return sql, params

        # CDC enabled logic
        if cdc_enabled:
            for idx, fr in enumerate(raw_folders):
                # Check for existing document
                existing_row = None
                if fr.document_name and fr.source_path:
                    existing_row = session.execute(
                        text(
                            """
                            SELECT id, file_hash, folder_id
                            FROM public.document_details
                            WHERE document_name = :document_name
                              AND source_path = :source_path
                            ORDER BY updated_at DESC NULLS LAST, id DESC
                            LIMIT 1
                            """
                        ),
                        {"document_name": fr.document_name, "source_path": fr.source_path},
                    ).mappings().first()

                if not existing_row:
                    # No document exists: success
                    folder_statuses[fr.folder_id] = "success"
                    processed_folders.append(fr)
                    success_folders.append(fr)
                else:
                    existing_hash = existing_row.get("file_hash")
                    # If previous hash is null and new hash is not null, treat as changed (first CDC-on ingest after CDC-off)
                    same_hash = (
                        existing_hash is not None
                        and fr.file_hash is not None
                        and str(existing_hash) == str(fr.file_hash)
                    )
                    is_first_cdc_on = (
                        (existing_hash is None or str(existing_hash).strip() == "")
                        and fr.file_hash is not None
                    )
                    if same_hash:
                        # Duplicate: skipped
                        folder_statuses[fr.folder_id] = "skipped"
                        skipped_folders.append(fr)
                        # Log duplicate
                        session.execute(
                            text(
                                """
                                INSERT INTO public.document_change_log
                                    (document_name, folder_id, change_type, similarity_score, process_name, job_name)
                                VALUES
                                    (:document_name, :folder_id, :change_type, :similarity_score, :process_name, :job_name)
                                """
                            ),
                            {
                                "document_name": fr.document_name or fr.folder_id or "unknown",
                                "folder_id": fr.folder_id,
                                "change_type": "Duplicate",
                                "similarity_score": None,
                                "process_name": body.process_name or "",
                                "job_name": body.job_id or "",
                            },
                        )
                        # Do not insert into document_details
                    elif is_first_cdc_on or not same_hash:
                        # Updated: success (either first CDC-on ingest after CDC-off, or hash changed)
                        fr._reprocess = True  # mark for reprocess_flag=true downstream
                        folder_statuses[fr.folder_id] = "success"
                        processed_folders.append(fr)
                        success_folders.append(fr)
                        # Preserve previous folder_id before deletion
                        previous_folder_id = existing_row.get("folder_id")
                        # Log change using the preserved previous folder_id
                        session.execute(
                            text(
                                """
                                INSERT INTO public.document_change_log
                                    (document_name, folder_id, change_type, similarity_score, process_name, job_name)
                                VALUES
                                    (:document_name, :folder_id, :change_type, :similarity_score, :process_name, :job_name)
                                """
                            ),
                            {
                                "document_name": fr.document_name or fr.folder_id or "unknown",
                                "folder_id": previous_folder_id,
                                "change_type": "Changed",
                                "similarity_score": None,
                                "process_name": body.process_name or "",
                                "job_name": body.job_id or "",
                            },
                        )
                        # Delete old document_details
                        existing_id = existing_row.get("id")
                        if existing_id:
                            session.execute(
                                text("DELETE FROM public.document_details WHERE id = :id"),
                                {"id": existing_id},
                            )
                        else:
                            session.execute(
                                text(
                                    """
                                    DELETE FROM public.document_details
                                    WHERE document_name = :document_name
                                      AND source_path = :source_path
                                    """
                                ),
                                {"document_name": fr.document_name, "source_path": fr.source_path},
                            )
        else:
            # CDC disabled: all folders are success, ensure reprocess_flag false
            for fr in raw_folders:
                setattr(fr, "_reprocess", False)
                folder_statuses[fr.folder_id] = "success"
                processed_folders.append(fr)
                success_folders.append(fr)

        # Insert document_details for all success folders
        for fr in success_folders:
            sql, params = build_insert_for_row(fr)
            session.execute(text(sql), params)
        session.commit()

        # Final task status
        if cdc_enabled:
            # OR of all folder statuses: success if any folder succeeded
            final_status = "success" if any(s == "success" for s in folder_statuses.values()) else "failed"
        else:
            # Success if at least one folder id exists, else failure
            final_status = "success" if len(success_folders) > 0 else "failed"

        # Build reserved_json
        reserved_json = body.model_dump(exclude_none=True)
        reserved_json["folders"] = [fr.model_dump(exclude_none=True) for fr in processed_folders]
        reserved_json["cdc_enabled"] = cdc_enabled
        reserved_json["folder_statuses"] = folder_statuses
        reserved_json["final_status"] = final_status
        reserved_json["skipped_folders"] = [fr.model_dump(exclude_none=True) for fr in skipped_folders]

        upd = text(
            """
            UPDATE public.task_details
            SET status = :st,
                reserved = CAST(:reserved AS JSONB),
                completed_at = now()
            WHERE id = :id
            """
        )
        result = session.execute(
            upd,
            {
                "id": body.task_id,
                "st": final_status,
                "reserved": json.dumps(reserved_json),
            },
        )
        session.commit()
        
        if result.rowcount == 0:
            logger.error(f"Failed to update task_details for task_id {body.task_id}. Task not found?")
            return {"status": "error", "message": f"Task {body.task_id} not found"}

        logger.info(f"Successfully updated task {body.task_id} with status {final_status}")
        return {"status": "ok"}
    except Exception as e:  # noqa: BLE001
        logger.error(f"Error processing worker results for task {body.task_id}: {e}", exc_info=True)
        session.rollback()
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

@router.get("/status/{task_id}")
def get_ingest_status(task_id: str):  # CHANGED
    from database import SessionLocal
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT id, status, reserved
                FROM public.task_details
                WHERE id = :id
                """
            ),
            {"id": task_id},
        ).mappings().first()
        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        status = (row.get("status") or "").strip().lower() or "pending"
        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        # Parse folder_ids from reserved JSON (worker result)
        folder_ids: List[str] = []
        reserved_val = row.get("reserved")
        try:
            data = None
            if isinstance(reserved_val, dict):
                data = reserved_val
            elif isinstance(reserved_val, (bytes, bytearray, memoryview)):
                data = json.loads(bytes(reserved_val).decode("utf-8"))
            elif isinstance(reserved_val, str):
                data = json.loads(reserved_val)
            if isinstance(data, dict):
                # Prefer folders array from worker result
                folders = data.get("folders")
                if isinstance(folders, list):
                    folder_ids = [str(item.get("folder_id")) for item in folders if isinstance(item, dict) and item.get("folder_id")]
                # Back-compat: support reserved.folder_ids if present
                if not folder_ids:
                    ids = data.get("folder_ids")
                    if isinstance(ids, list):
                        folder_ids = [str(x) for x in ids]
        except Exception:
            folder_ids = []

        return {"task_id": task_id, "status": "success", "folder_ids": folder_ids or []}
    except Exception as e:  # noqa: BLE001
        return {"task_id": task_id, "status": "error", "message": str(e), "folder_ids": []}
    finally:
        session.close()
