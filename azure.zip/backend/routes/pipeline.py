from fastapi import APIRouter, HTTPException, Request
from core.models import PipelineRequest
from core.template_engine import render_template_to_file
from core.router_loader import load_router_for_config
import os
import sys
from pathlib import Path
from datetime import datetime, timezone
import requests
import logging
from pydantic import BaseModel, ConfigDict, field_validator
from typing import Optional, List, Dict, Union
from jinja2 import Environment, FileSystemLoader
import shutil  # added for copying to Airflow DAGs share
from utils.path_utils import get_shared_path
from airflow_token import get_airflow_token  # NEW
from config import settings  # NEW
from sqlalchemy import text  # NEW
from database import SessionLocal  # NEW
import json  # NEW: parse profile_configs as JSON

# Use settings dynamically instead of fixed module constants
API_BASE = settings.airflow_api_url.rstrip('/')  # for unpause logic
router = APIRouter(prefix="/pipeline", tags=["Pipeline"])
logger = logging.getLogger("contextcraft")
mounted_routers = {}

# Directories for template generation
TEMPLATES_DIR = Path("templates")
GENERATED_DIR = Path("generated_apis")
GENERATED_DIR.mkdir(parents=True, exist_ok=True)

# --- New request model matching airflow_pipeline.py.j2 placeholders ---
class DeployPipelineRequest(BaseModel):
    processname: str
    schedule: Optional[str] = None
    datasource: str
    folderuncpath: str
    formats: List[str]
    parser: str
    textprocessing: List[str]
    chunking: str
    chunksize: int
    chunkoverlap: int
    embeddingmodel: str
    embeddingdimension: int
    vectordatabase: str
    tablename: str
    searchtype: str
    numfiles: int

    # Coercion validators to accept string input
    @field_validator("formats", "textprocessing", mode="before")
    @classmethod
    def _listify(cls, v):
        if v is None:
            return []
        if isinstance(v, list):
            return v
        if isinstance(v, str):
            v = v.strip()
            if not v:
                return []
            # support comma separated
            return [p.strip() for p in v.split(",") if p.strip()]
        return [str(v)]

    @field_validator("chunksize", "chunkoverlap", "embeddingdimension", "numfiles", mode="before")
    @classmethod
    def _intify(cls, v):
        if v is None:
            return None
        if isinstance(v, int):
            return v
        if isinstance(v, (float,)):
            return int(v)
        if isinstance(v, str):
            try:
                return int(v.strip())
            except Exception:
                pass
        return v

    # Pydantic v2 style config replacing deprecated schema_extra
    model_config = ConfigDict(json_schema_extra={
        "example": {
            "processname": "DemoPipeline",
            "schedule": None,
            "datasource": "Folder",
            "folderuncpath": "\\\\AVDGENAIL18-3\\temp",
            "formats": ["PDF"],
            "parser": "Tesseract",
            "textprocessing": ["remove page numbers"],
            "chunking": "fixed characters",
            "chunksize": 500,
            "chunkoverlap": 50,
            "embeddingmodel": "nomic-embed-text",
            "embeddingdimension": 768,
            "vectordatabase": "qdrant",
            "tablename": "document_vectors",
            "searchtype": "cosine",
            "numfiles": 5,
        }
    })

# NEW: Save Pipeline request model
class SavePipelineRequest(BaseModel):
    pipeline_name: str
    import_profile_id: Optional[int] = None
    parsing_profile_id: Optional[int] = None
    text_processing_profile_id: Optional[int] = None
    chunking_profile_id: Optional[int] = None
    embedding_profile_id: Optional[int] = None
    export_profile_id: Optional[int] = None

# NEW: Update Pipeline request model
class UpdatePipelineRequest(BaseModel):
    pipeline_name: str
    import_profile_id: Optional[int] = None
    parsing_profile_id: Optional[int] = None
    text_processing_profile_id: Optional[int] = None
    chunking_profile_id: Optional[int] = None
    embedding_profile_id: Optional[int] = None
    export_profile_id: Optional[int] = None

# NEW: Build Process request model (new architecture)
class BuildProcessRequest(BaseModel):
    process_name: str
    # Optional pipeline_name allows callers to specify an existing pipeline
    # (in `pipeline_details`) to source profile ids from. If provided,
    # the route will prefer `pipeline_name` when looking up profiles.
    pipeline_name: Optional[str] = None
    start_date_time: str
    schedule: Union[int, str]
    end_date_time: Optional[str] = None

# NEW: Save a pipeline into pipeline_details (uses pipeline_name column and profile IDs)
@router.post(
    "/save-pipeline",
    summary="Save a pipeline into pipeline_details (uses pipeline_name column and profile IDs)",
)
def save_pipeline(req: SavePipelineRequest):
    session = SessionLocal()
    try:
        # Check duplicate pipeline name in new table
        exists_sql = text(
            """
            SELECT 1 FROM public.pipeline_details
            WHERE LOWER(TRIM(pipeline_name)) = LOWER(TRIM(:name))
            LIMIT 1
            """
        )
        if session.execute(exists_sql, {"name": req.pipeline_name}).first():
            return {"status": "error", "message": "Pipeline with the same name already exists. Please select another name."}

        insert_sql = text(
            """
            INSERT INTO public.pipeline_details (
                pipeline_name,
                import_profile_id,
                parsing_profile_id,
                text_processing_profile_id,
                chunking_profile_id,
                embedding_profile_id,
                export_profile_id
            ) VALUES (
                :name,
                :import_profile_id,
                :parsing_profile_id,
                :text_processing_profile_id,
                :chunking_profile_id,
                :embedding_profile_id,
                :export_profile_id
            ) RETURNING id
            """
        )
        row = session.execute(
            insert_sql,
            {
                "name": req.pipeline_name,
                "import_profile_id": req.import_profile_id,
                "parsing_profile_id": req.parsing_profile_id,
                "text_processing_profile_id": req.text_processing_profile_id,
                "chunking_profile_id": req.chunking_profile_id,
                "embedding_profile_id": req.embedding_profile_id,
                "export_profile_id": req.export_profile_id,
            },
        ).fetchone()
        session.commit()
        new_id = row[0] if row else None
        return {"status": "success", "id": new_id}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.exception("Failed to save pipeline")
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

# NEW: Update a pipeline by unique pipeline_name in pipeline_details
@router.put("/update-pipeline",summary="Update a pipeline by unique pipeline_name in pipeline_details")
def update_pipeline(req: UpdatePipelineRequest):
    session = SessionLocal()
    try:
        # Ensure pipeline exists in new table
        exists_sql = text(
            """
            SELECT id FROM public.pipeline_details
            WHERE LOWER(TRIM(pipeline_name)) = LOWER(TRIM(:name))
            LIMIT 1
            """
        )
        row = session.execute(exists_sql, {"name": req.pipeline_name}).first()
        if not row:
            return {"status": "error", "message": "Pipeline not found"}

        sets = []
        params: dict = {"name": req.pipeline_name}
        if req.import_profile_id is not None:
            sets.append("import_profile_id = :import_profile_id")
            params["import_profile_id"] = req.import_profile_id
        if req.parsing_profile_id is not None:
            sets.append("parsing_profile_id = :parsing_profile_id")
            params["parsing_profile_id"] = req.parsing_profile_id
        if req.text_processing_profile_id is not None:
            sets.append("text_processing_profile_id = :text_processing_profile_id")
            params["text_processing_profile_id"] = req.text_processing_profile_id
        if req.chunking_profile_id is not None:
            sets.append("chunking_profile_id = :chunking_profile_id")
            params["chunking_profile_id"] = req.chunking_profile_id
        if req.embedding_profile_id is not None:
            sets.append("embedding_profile_id = :embedding_profile_id")
            params["embedding_profile_id"] = req.embedding_profile_id
        if req.export_profile_id is not None:
            sets.append("export_profile_id = :export_profile_id")
            params["export_profile_id"] = req.export_profile_id

        if not sets:
            return {"status": "error", "message": "No update fields provided"}

        update_sql = text(
            f"""
            UPDATE public.pipeline_details
            SET {', '.join(sets)}
            WHERE LOWER(TRIM(pipeline_name)) = LOWER(TRIM(:name))
            RETURNING id
            """
        )
        updated = session.execute(update_sql, params).fetchone()
        session.commit()
        if not updated:
            return {"status": "error", "message": "Update failed"}
        return {"status": "success", "id": updated[0]}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.exception("Failed to update pipeline")
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

# NEW: Delete a pipeline by unique pipeline_name from pipeline_details
@router.delete("/delete-pipeline/{pipeline_name}",summary="Delete a pipeline by unique pipeline_name from pipeline_details")
def delete_template(pipeline_name: str):
    session = SessionLocal()
    try:
        delete_sql = text(
            """
            DELETE FROM public.pipeline_details
            WHERE LOWER(TRIM(pipeline_name)) = LOWER(TRIM(:name))
            RETURNING id
            """
        )
        row = session.execute(delete_sql, {"name": pipeline_name}).fetchone()
        session.commit()
        if not row:
            return {"status": "error", "message": "Pipeline not found"}
        return {"status": "success", "id": row[0]}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.exception("Failed to delete pipeline")
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

# NEW: Check if a pipeline with the same name exists in pipeline_details
@router.get("/check-pipeline",summary="Check if a pipeline with the same name exists in pipeline_details")
def check_template(pipeline_name: str):
    session = SessionLocal()
    try:
        sql = text(
            """
            SELECT 1 FROM public.pipeline_details
            WHERE LOWER(TRIM(pipeline_name)) = LOWER(TRIM(:name))
            LIMIT 1
            """
        )
        row = session.execute(sql, {"name": pipeline_name}).first()
        return {"exists": "yes" if row else "no"}
    except Exception as e:  # noqa: BLE001
        logger.exception("Failed to check pipeline")
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.get("/list", summary="List saved pipelines (id and name only)")
def list_pipelines():
    """Return a list of pipelines with only id and pipeline_name from pipeline_details."""
    session = SessionLocal()
    try:
        sql = text(
            """
            SELECT id, pipeline_name FROM public.pipeline_details ORDER BY LOWER(pipeline_name) ASC
            """
        )
        rows = session.execute(sql).fetchall()
        result = []
        for r in rows:
            # SQLAlchemy returns Row objects; index into tuple
            pid = r[0]
            pname = r[1]
            result.append({"id": pid, "pipeline_name": pname})
        return {"status": "success", "pipelines": result}
    except Exception as e:  # noqa: BLE001
        logger.exception("Failed to list pipelines")
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.get("/getconfig", summary="Get pipeline details by pipeline_name")
def get_pipeline_config(pipeline_name: str):
    """Return the pipeline_details row for the given pipeline_name as a JSON object.

    The pipeline_name is matched case-insensitively and trimmed.
    """
    session = SessionLocal()
    try:
        sql = text(
            """
            SELECT id, pipeline_name, import_profile_id, parsing_profile_id,
                   text_processing_profile_id, chunking_profile_id,
                   embedding_profile_id, export_profile_id
            FROM public.pipeline_details
            WHERE LOWER(TRIM(pipeline_name)) = LOWER(TRIM(:name))
            LIMIT 1
            """
        )
        row = session.execute(sql, {"name": pipeline_name}).first()
        if not row:
            return {"status": "error", "message": "Pipeline not found"}

        pipeline = {
            "id": row[0],
            "pipeline_name": row[1],
            "import_profile_id": row[2],
            "parsing_profile_id": row[3],
            "text_processing_profile_id": row[4],
            "chunking_profile_id": row[5],
            "embedding_profile_id": row[6],
            "export_profile_id": row[7],
        }

        return {"status": "success", "pipeline": pipeline}
    except Exception as e:  # noqa: BLE001
        logger.exception("Failed to get pipeline config")
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

@router.post("/build-process")
async def build_process(req: BuildProcessRequest):
    """Render airflow_pipeline.py.j2 using the new architecture.

    Inputs: process_name, start_date_time, schedule, end_date_time (optional)
    Looks up profile IDs in pipeline_details and fetches profile_configs from profiles.
    Builds cfg_dict with dag_id, start_date, end_date, schedule and six *Config entries.
    """
    try:
        # Helper to map numeric schedule codes to cron strings
        def map_schedule(value: Union[int, str]) -> str:
            mapping = {
                0: "* * * * *",      # every minute
                1: "*/5 * * * *",    # every 5 minutes
                2: "*/30 * * * *",   # every 30 minutes
                3: "0 * * * *",      # every hour
                4: "0 0 * * *",      # every day
            }
            try:
                key = int(value)
                return mapping.get(key, str(value))
            except Exception:
                # If caller passed a cron expression directly, just return it
                return str(value)

        # Fetch profile ids for this pipeline
        session = SessionLocal()
        try:
            details_sql = text(
                """
                SELECT import_profile_id, parsing_profile_id, text_processing_profile_id,
                       chunking_profile_id, embedding_profile_id, export_profile_id
                FROM public.pipeline_details
                WHERE LOWER(TRIM(pipeline_name)) = LOWER(TRIM(:name))
                LIMIT 1
                """
            )
            # Require an explicit pipeline_name for profile lookup in pipeline_details.
            # The `process_name` remains the DAG id/name used for template generation
            # but will NOT be used to fetch profile ids anymore.
            pipeline_lookup = (req.pipeline_name or "").strip()
            if not pipeline_lookup:
                raise HTTPException(status_code=400, detail="pipeline_name is required to fetch pipeline profiles from pipeline_details")

            row = session.execute(details_sql, {"name": pipeline_lookup}).first()
            if not row:
                raise HTTPException(status_code=404, detail="Pipeline not found in pipeline_details")

            (
                import_profile_id,
                parsing_profile_id,
                text_processing_profile_id,
                chunking_profile_id,
                embedding_profile_id,
                export_profile_id,
            ) = row

            def fetch_profile_config(pid: Optional[int]):
                if not pid:
                    return {}
                cfg_row = session.execute(
                    text("SELECT profile_config FROM public.profiles WHERE id = :id LIMIT 1"),
                    {"id": pid},
                ).first()
                if not cfg_row:
                    return {}
                cfg_val = cfg_row[0]
                # If DB returned a JSON string, parse it; if it's already a dict/list, return as is
                if isinstance(cfg_val, str):
                    try:
                        return json.loads(cfg_val)
                    except Exception:
                        # Fallback: return empty object on parse failure
                        return {}
                return cfg_val if isinstance(cfg_val, (dict, list)) else {}

            import_cfg = fetch_profile_config(import_profile_id)
            parser_cfg = fetch_profile_config(parsing_profile_id)
            textproc_cfg = fetch_profile_config(text_processing_profile_id)
            chunking_cfg = fetch_profile_config(chunking_profile_id)
            vectorize_cfg = fetch_profile_config(embedding_profile_id)
            export_cfg = fetch_profile_config(export_profile_id)
        finally:
            session.close()

        env = Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)))
        try:
            template = env.get_template("airflow_pipeline.py.j2")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Template not found: {e}")

        schedule_str = map_schedule(req.schedule)
        # Parse start_date_time and end_date_time to datetime objects with UTC
        from datetime import datetime, timezone
        def parse_dt(dt_str):
            if not dt_str:
                return None
            # Try ISO format first
            try:
                return datetime.fromisoformat(dt_str).replace(tzinfo=timezone.utc)
            except Exception:
                pass
            # Fallback: try common formats
            for fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"]:
                try:
                    return datetime.strptime(dt_str, fmt).replace(tzinfo=timezone.utc)
                except Exception:
                    continue
            return None

        start_dt = parse_dt(req.start_date_time)
        end_dt = parse_dt(req.end_date_time) if req.end_date_time else None

        def dt_to_code(dt):
            if not dt:
                return "None"
            return f"datetime({dt.year}, {dt.month}, {dt.day}, {dt.hour}, {dt.minute}, tzinfo=timezone.utc)"

        cfg_dict = {
            "dag_id": req.process_name,
            "start_date": dt_to_code(start_dt),
            "end_date": dt_to_code(end_dt),
            "schedule": schedule_str,
            "ImportConfig": import_cfg,
            "ParserConfig": parser_cfg,
            "TextProcessingConfig": textproc_cfg,
            "ChunkingConfig": chunking_cfg,
            "VectorizeConfig": vectorize_cfg,
            "ExportConfig": export_cfg,
        }

        rendered = template.render(cfg=cfg_dict)
        output_filename = f"{req.process_name}.py"

        # Resolve Airflow DAGs directory (UNC-aware)
        airflow_dags_dir = get_shared_path("AIRFLOW_DAGS_DIR", settings.airflow_dags_dir)
        logger.debug(
            "Airflow DAGs UNC raw=%s repr=%s exists=%s is_dir=%s",
            str(airflow_dags_dir),
            repr(str(airflow_dags_dir)),
            airflow_dags_dir.exists(),
            airflow_dags_dir.is_dir(),
        )

        if not airflow_dags_dir or not airflow_dags_dir.exists() or not airflow_dags_dir.is_dir():
            logger.error("Airflow DAGs directory not found or inaccessible: %s", airflow_dags_dir)
            return {"status": "error", "message": f"Airflow DAGs directory not accessible: {airflow_dags_dir}"}

        airflow_copy_path = airflow_dags_dir / output_filename

        # Create a temporary file locally and then move it into the Airflow DAGs folder.
        # This avoids leaving a permanent copy in generated_apis.
        import tempfile
        tmp_file = None
        try:
            GENERATED_DIR.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", delete=False, dir=str(GENERATED_DIR), suffix=".py") as tf:
                tf.write(rendered)
                tmp_file = Path(tf.name)

            # Move the temp file into the Airflow DAGs directory (atomic when possible)
            shutil.move(str(tmp_file), str(airflow_copy_path))
            logger.info("Moved generated DAG to Airflow folder: %s", airflow_copy_path)
            # Ensure no leftover in generated_apis
            if tmp_file and tmp_file.exists():
                try:
                    tmp_file.unlink()
                except Exception:
                    pass
            return {"status": "success"}
        except Exception as e:
            logger.exception("Failed to write/move DAG to Airflow folder %s", airflow_copy_path)
            # Cleanup temp file if present
            try:
                if tmp_file and tmp_file.exists():
                    tmp_file.unlink()
            except Exception:
                pass
            return {"status": "error", "message": str(e)}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to deploy pipeline")
        return {"status": "error", "message": str(e)}
