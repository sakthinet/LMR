from fastapi import Body, APIRouter, Form
from typing import List, Optional, Dict, Any
import uuid
import datetime
from models import TaskStatus
from database import SessionLocal
from celery import Celery
import logging
from config import settings
from sqlalchemy import text, create_engine
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.exc import IntegrityError
import json
import requests
import os
from pathlib import Path
import importlib.util
from qdrant_client import QdrantClient

logger = logging.getLogger("export")
logging.basicConfig(level=logging.INFO)

router = APIRouter(prefix="/export", tags=["Export"])

celery_app = Celery('export_worker', broker=settings.celery_broker_url)



# ---- Models ----
class ExportRequest(BaseModel):
    dag_id: str
    pipeline_name: Optional[str] = None
    export_profile_name: Optional[str] = None
    run_id: str
    folder_id: str
    export_config: Dict[str, Any] = Field(default_factory=dict, alias="ExportConfig")
    model_config = ConfigDict(extra="allow")

class ExportWorkerResult(BaseModel):
    task_id: str
    status: str
    process_name: Optional[str] = None
    job_id: Optional[str] = None
    error_message: Optional[str] = None
    folder_id: Optional[str] = None
    model_config = ConfigDict(extra="allow")


def _normalize(name: str) -> str:
    n = (name or "").strip().lower()
    n = n.replace(" ", "_").replace("-", "_")
    return n




@router.get("/reprocess-flag")
def get_reprocess_flag(folder_id: str):
    # Return reprocess flag for a folder_id from public.document_details.
    # Workers should call this endpoint instead of reading the DB directly.
    if not isinstance(folder_id, str) or not folder_id.strip():
        return {"status": "error", "message": "folder_id is required"}

    session = SessionLocal()
    try:
        row = session.execute(
            text("SELECT id, folder_id, reprocess_flag as reprocess, process_name AS pipeline_name FROM public.document_details WHERE folder_id = :fid LIMIT 1"),
            {"fid": folder_id.strip()},
        ).mappings().first()

        if not row:
            return {"status": "not_found", "folder_id": folder_id.strip(), "reprocess": False}

        rep = row.get("reprocess")
        pipeline_name = row.get("pipeline_name")
        doc_id = row.get("id")
        return {
            "status": "success",
            "folder_id": str(row.get("folder_id")),
            "reprocess": bool(rep),
            "pipeline_name": pipeline_name,
            "id": str(doc_id) if doc_id else None
        }
    except Exception as e:  # noqa: BLE001
        logger.error("Failed to read document_details reprocess flag: %s", e, exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.get("/document-change-previous")
def get_previous_folder_id(folder_id: str):
    """Return folder_id from document_change_log for a given folder_id, if any."""
    if not isinstance(folder_id, str) or not folder_id.strip():
        return {"status": "error", "message": "folder_id is required"}

    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT folder_id
                FROM public.document_change_log
                WHERE folder_id = :fid
                ORDER BY id DESC
                LIMIT 1
                """
            ),
            {"fid": folder_id.strip()},
        ).mappings().first()

        if not row:
            return {"status": "not_found", "folder_id": folder_id.strip(), "previous_folder_id": None}

        return {
            "status": "success",
            "folder_id": folder_id.strip(),
            "previous_folder_id": row.get("folder_id"),
        }
    except Exception as e:
        logger.error("Failed to fetch previous_folder_id: %s", e, exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.post("/reprocess-reset")
def reset_reprocess_flag(folder_id: str = Form(...)):
    """Set reprocess_flag to false for the given folder_id in document_details."""
    if not isinstance(folder_id, str) or not folder_id.strip():
        return {"status": "error", "message": "folder_id is required"}

    session = SessionLocal()
    try:
        result = session.execute(
            text(
                """
                UPDATE public.document_details
                SET reprocess_flag = false
                WHERE folder_id = :fid
                RETURNING id
                """
            ),
            {"fid": folder_id.strip()},
        )
        session.commit()
        row = result.first()
        if not row:
            return {"status": "not_found", "folder_id": folder_id.strip()}
        return {"status": "success", "folder_id": folder_id.strip(), "id": str(row[0])}
    except Exception as e:
        session.rollback()
        logger.error("Failed to reset reprocess flag: %s", e, exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

@router.get("/vector-store-registry")
def get_or_create_vector_store_registry(
    folder_id: str,
    export_profile_name: str,
    chunk_store_type: Optional[str] = "postgres",
    chunk_store_name: Optional[str] = None,
    vector_store_type: Optional[str] = "qdrant",
    vector_store_name: Optional[str] = None,
    vector_store_namespace: Optional[str] = None,
):
    # Get or create a vector store registry record for this folder and profile.
    # Contract (used by export workers):
    # - Workers must ensure a registry record exists before exporting.
    # - Uses INSERT .. ON CONFLICT to avoid duplicate inserts.
    if not folder_id or not export_profile_name:
        return {"status": "error", "message": "folder_id and export_profile_name are required"}
    if folder_id.strip().lower() == "unknown" or not folder_id.strip():
        return {"status": "error", "message": "Invalid or missing folder_id (received: 'unknown' or empty)"}

    session = SessionLocal()
    try:
        # Fetch process_name from document_details where folder_id matches the caller's folder_id
        doc_details = None
        if folder_id:
            fetch_sql = text("""
                SELECT process_name FROM public.document_details WHERE folder_id = :fid LIMIT 1
            """)
            doc_details = session.execute(fetch_sql, {"fid": folder_id}).first()
        if not doc_details:
            return {"status": "error", "message": f"No document_details found for folder_id={folder_id}"}
        process_name_val = str(doc_details[0])
        # Try to insert, but if duplicate, fetch existing
        try:
            insert_sql = text(
                """
                INSERT INTO public.vector_store_registry (
                    id, pipeline_name, export_profile_name, chunk_store_type, chunk_store_name,
                    vector_store_type, vector_store_name, vector_store_namespace,
                    is_initialized, last_used_at, updated_at
                )
                VALUES (
                    nextval('vector_store_registry_id_seq'), :pname, :ename, :ctype, :cname, :vtype, :vname, :vns,
                    true, now(), now()
                )
                ON CONFLICT (pipeline_name, export_profile_name)
                DO NOTHING
                RETURNING id, pipeline_name, export_profile_name
                """
            )
            row = (
                session.execute(
                    insert_sql,
                    {
                        "pname": process_name_val,
                        "ename": export_profile_name,
                        "ctype": chunk_store_type or "postgres",
                        "cname": chunk_store_name or "",
                        "vtype": vector_store_type or "qdrant",
                        "vname": vector_store_name or "",
                        "vns": vector_store_namespace or ""
                    }
                )
                .mappings()
                .first()
            )
            session.commit()
            if not row:
                # Conflict occurred (row already exists); fetch existing
                fetch_existing = text(
                    """
                    SELECT id, pipeline_name, export_profile_name
                    FROM public.vector_store_registry
                    WHERE pipeline_name = :pname AND export_profile_name = :ename
                    LIMIT 1
                    """
                )
                row = (
                    session.execute(
                        fetch_existing,
                        {"pname": process_name_val, "ename": export_profile_name}
                    )
                    .mappings()
                    .first()
                )
        except IntegrityError as ie:
            session.rollback()
            fetch_existing = text(
                """
                SELECT id, pipeline_name, export_profile_name
                FROM public.vector_store_registry
                WHERE pipeline_name = :pname AND export_profile_name = :ename
                LIMIT 1
                """
            )
            row = (
                session.execute(
                    fetch_existing,
                    {"pname": process_name_val, "ename": export_profile_name}
                )
                .mappings()
                .first()
            )
        if not row:
            return {"status": "error", "message": "Could not insert or fetch registry row"}
        return {
            "status": "success",
            "registry": {
                "id": row.get("id"),
                "pipeline_name": row.get("pipeline_name"),
                "export_profile_name": row.get("export_profile_name"),
            },
        }
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error("Failed to get/create vector store registry: %s", e, exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.post("/data")
def submit_export_task(req: ExportRequest):
    logger.info(f"Received export_config: {json.dumps(req.export_config or {})}")
    session = SessionLocal()
    try:
        cfg = req.export_config or {}

        # Set CDC flag based on presence of folder_id in document_details
        cdc_flag = False
        try:
            exists_row = session.execute(
                text("SELECT 1 FROM public.document_details WHERE folder_id = :fid LIMIT 1"),
                {"fid": req.folder_id},
            ).first()
            cdc_flag = bool(exists_row)
        except Exception as e:
            logger.warning("Could not determine CDC flag from document_details: %s", e)
        cfg["cdc"] = cdc_flag

        # Use VectorStore as the only key for worker/queue selection
        raw_target = (
            cfg.get("VectorStore") or
            cfg.get("vectorstore")
        )
        target = _normalize(str(raw_target or ""))
        if not target:
            return {"status": "error", "message": "VectorStore is required in ExportConfig"}

        # Prefer export_profile_name from config, else fallback to top-level
        export_profile_name = cfg.get("export_profile_name") or req.export_profile_name

        # Insert into public.task_details with UUID collision retry
        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, started_at, job_id, payload
            ) VALUES (
                :id, :process_name, :task_type, :status, now(), :job_id, CAST(:payload AS JSONB)
            )
            """
        )
        MAX_RETRIES = 5
        task_id = None
        for _ in range(MAX_RETRIES):
            candidate = str(uuid.uuid4())
            try:
                session.execute(
                    insert_sql,
                    {
                        "id": candidate,
                        "process_name": req.dag_id,
                        "task_type": "Export",
                        "status": "submitted",
                        "job_id": req.run_id,
                        "payload": json.dumps(cfg),
                    },
                )
                session.commit()
                task_id = candidate
                break
            except IntegrityError:
                session.rollback()
                continue
        if not task_id:
            return {"status": "error", "message": "Could not allocate unique task id after retries"}

        # Determine worker and queue names per target
        worker_name = f"{target}_worker.{target}_task".lower()
        queue_name = target.lower()
        # Update task_details with worker & queue
        session.execute(
            text(
                """
                UPDATE public.task_details
                SET worker_name = :worker_name,
                    queue_name = :queue_name
                WHERE id = :id
                """
            ),
            {"worker_name": worker_name, "queue_name": queue_name, "id": task_id},
        )
        session.commit()

        # Enqueue Celery task
        celery_app.send_task(
            worker_name,
            args=[
                task_id,
                req.folder_id,
                cfg,
                req.dag_id,
                req.run_id,
                req.pipeline_name,
                export_profile_name,
            ],
            queue=queue_name,
        )

        return {"task_id": task_id, "status": "submitted"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Export endpoint error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()



@router.post("/worker-results")
def worker_results(body: ExportWorkerResult):

    session = SessionLocal()
    try:
        status_raw = (body.status or "").strip().lower()
        status_norm = "success" if status_raw in ("success", "succeeded", "completed") else (
            "failed" if status_raw in ("error", "failed") else status_raw
        )

        reserved_json = body.model_dump(exclude_none=True)
        if isinstance(body, BaseModel):
            try:
                extra_items = {k: v for k, v in body.__dict__.items() if k not in reserved_json}
                reserved_json.update(extra_items)
            except Exception:
                pass

        upd = text("UPDATE public.task_details SET status = :st, reserved = CAST(:reserved AS JSONB), completed_at = now() WHERE id = :id")
        res = session.execute(
            upd,
            {"id": body.task_id, "st": status_norm or "success", "reserved": json.dumps(reserved_json)},
        )
        session.commit()

        rowcount = getattr(res, "rowcount", None)
        if rowcount == 0:
            return {"status": "error", "message": f"task_id not found: {body.task_id}"}

        # Determine folder_id from payload
        folder_id_eff: Optional[str] = body.folder_id
        if not folder_id_eff:
            try:
                if isinstance(reserved_json, dict):
                    if not folder_id_eff and isinstance(reserved_json.get("folders"), list):
                        for item in reserved_json.get("folders"):
                            if isinstance(item, dict) and item.get("folder_id"):
                                folder_id_eff = str(item.get("folder_id"))
                                break
                    if not folder_id_eff and reserved_json.get("folder_id"):
                        folder_id_eff = str(reserved_json.get("folder_id"))
                    if not folder_id_eff and isinstance(reserved_json.get("folder_ids"), list) and reserved_json["folder_ids"]:
                        folder_id_eff = str(reserved_json["folder_ids"][0])
            except Exception:
                folder_id_eff = None

        # On success, update document_details
        if status_norm == "success" and folder_id_eff:
            cols_info = session.execute(
                text("SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'document_details'")
            ).mappings().all()
            col_names = {r.get("column_name"): r.get("data_type") for r in cols_info if r.get("column_name")}
            sets = []
            params = {"fid": folder_id_eff}
            if "export_status" in col_names:
                sets.append("export_status = :es"); params["es"] = "success"
            if "vector_db_status" in col_names:
                sets.append("vector_db_status = :vds"); params["vds"] = "success"
            if "last_successful_stage" in col_names:
                sets.append("last_successful_stage = :lss"); params["lss"] = "export"
            if "updated_at" in col_names:
                dt = (col_names.get("updated_at") or "").lower()
                if "timestamp" in dt:
                    sets.append("updated_at = now()")
                else:
                    sets.append("updated_at = :ua"); params["ua"] = None

            if sets:
                upd_doc = text(f"UPDATE public.document_details SET {', '.join(sets)} WHERE folder_id = :fid")
                session.execute(upd_doc, params)
                session.commit()

        return {"status": "ok"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Export worker-results error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.get("/status/{task_id}")
def get_export_status(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text("SELECT id, status, reserved FROM public.task_details WHERE id = :id"),
            {"id": task_id},
        ).mappings().first()
        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        status = (row.get("status") or "").strip().lower() or "pending"
        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        # Success: extract folder_ids from reserved JSON
        folder_ids: List[str] = []
        reserved_val = row.get("reserved")
        try:
            data = None
            if isinstance(reserved_val, dict):
                data = reserved_val
            elif isinstance(reserved_val, (bytes, bytearray, memoryview)):
                data = json.loads(bytes(reserved_val).decode("utf-8"))
            elif isinstance(reserved_val, str):
                data = json.loads(reserved_val)
            if isinstance(data, dict):
                folders = data.get("folders")
                if isinstance(folders, list):
                    folder_ids = [str(it.get("folder_id")) for it in folders if isinstance(it, dict) and it.get("folder_id")]
                if not folder_ids:
                    ids_val = data.get("folder_ids")
                    if isinstance(ids_val, list):
                        folder_ids = [str(x) for x in ids_val if x]
                if not folder_ids and data.get("folder_id"):
                    folder_ids = [str(data.get("folder_id"))]
        except Exception:  # noqa: BLE001
            folder_ids = []

        return {"task_id": task_id, "status": "success", "folder_ids": folder_ids or []}
    except Exception as e:  # noqa: BLE001
        logger.error(f"Export status error: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e), "folder_ids": []}
    finally:
        session.close()


@router.get("/qdrant/get-collections", summary="Get list of Qdrant collections")
def get_qdrant_collections():
    # Fetch collections from Qdrant using QDRANT_URL from environment (default http://localhost:6333).
    # Returns JSON: {"collections": ["name1", "name2", ...]}
    qdrant_url = os.getenv("QDRANT_URL", "http://10.73.88.101:6333")
    endpoint = qdrant_url.rstrip("/") + "/collections"
    try:
        resp = requests.get(endpoint, timeout=10)
        if resp.status_code != 200:
            logger.error("Qdrant collections fetch failed %s: %s", resp.status_code, resp.text)
            return {"status": "error", "message": f"Qdrant returned {resp.status_code}: {resp.text}"}
        data = resp.json()
        # Support both v1 and v2 response shapes
        collections = []
        try:
            # v1: {"result": {"collections": [{"name": "..."}, ...]}}
            if isinstance(data, dict) and "result" in data and isinstance(data["result"], dict) and "collections" in data["result"]:
                for c in data["result"]["collections"]:
                    if isinstance(c, dict) and "name" in c:
                        collections.append(c["name"])
            # v2 (or alternate): {"collections": [{"name":...}]}
            elif isinstance(data, dict) and "collections" in data and isinstance(data["collections"], list):
                for c in data["collections"]:
                    if isinstance(c, dict) and "name" in c:
                        collections.append(c["name"])
            else:
                # Fallback: try to extract any 'name' fields from top-level list
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and "name" in item:
                            collections.append(item["name"])
        except Exception:
            logger.exception("Failed parsing Qdrant response")

        return {"collections": collections}
    except Exception as e:
        logger.exception("Error contacting Qdrant at %s", endpoint)
        return {"status": "error", "message": str(e)}


