from fastapi import APIRouter
from fastapi.responses import JSONResponse
from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import requests
import logging
from database import get_async_session
from config import settings
from airflow_token import get_airflow_token  # NEW

router = APIRouter(prefix="/jobs", tags=["Jobs"])
logger = logging.getLogger("contextcraft")


@router.get("/getjobs")
async def get_jobs(dag_id: str):
    url = f"{settings.airflow_api_url}/dags/{dag_id}/dagRuns"
    headers = {
        "Authorization": f"Bearer {get_airflow_token()}",
        "Content-Type": "application/json",
    }
    try:
        response = requests.get(url, headers=headers)
       
        if response.status_code != 200:
            return JSONResponse(status_code=response.status_code, content={"error": response.text})
        data = response.json()
        runs = data.get("dag_runs", [])
        dag_runs = [
            {
                "job_name": run.get("dag_run_id") or run.get("run_id"),
                "process_name": run.get("dag_id"),
                "execution_date": run.get("logical_date"),
                "state": run.get("state"),
            }
            for run in runs
        ]
        return {"dag_runs": dag_runs, "raw": data}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


from pydantic import BaseModel


class JobDocumentRequest(BaseModel):
    job_id: str


@router.post("/document-details")
async def job_document_details(body: JobDocumentRequest, session: AsyncSession = Depends(get_async_session)):
    """Return document details (document_name, folder_id) and task status columns for a given job_id.

    Response structure:
      { "job_id": "...", "documents": [ { "document_name": ..., "folder_id": ..., "ingestion_status": ..., ... }, ... ] }
    """
    try:
        job_id = (body.job_id or "").strip()
        if not job_id:
            return JSONResponse(status_code=422, content={"error": "job_id is required"})

        sql = text(
            """
            SELECT document_name, folder_id, ingestion_status, parsing_status,
                   text_processing_status, chunking_status, embedding_status, export_status
            FROM public.document_details
            WHERE job_id = :job_id
            ORDER BY updated_at ASC NULLS LAST
            """
        )
        result = await session.execute(sql, {"job_id": job_id})
        rows = result.mappings().all()

        documents = []
        for r in rows:
            documents.append({
                "document_name": r.get("document_name"),
                "folder_id": r.get("folder_id"),
                "ingestion_status": r.get("ingestion_status"),
                "parsing_status": r.get("parsing_status"),
                "text_processing_status": r.get("text_processing_status"),
                "chunking_status": r.get("chunking_status"),
                "embedding_status": r.get("embedding_status"),
                "export_status": r.get("export_status"),
            })

        return {"job_id": job_id, "documents": documents}
    except Exception as e:
        logger.exception("Failed fetching document details for job_id=%s", body.job_id)
        return JSONResponse(status_code=500, content={"error": str(e)})


class JobTaskRequest(BaseModel):
    job_id: str


@router.post("/task-details")
async def job_task_details(body: JobTaskRequest, session: AsyncSession = Depends(get_async_session)):
    """Return task rows from public.task_details for a given job_id.

    Each task includes: task_type, status, queue_name, worker_name, payload (request JSON),
    reserved (response JSON), started_at, completed_at
    """
    try:
        job_id = (body.job_id or "").strip()
        if not job_id:
            return JSONResponse(status_code=422, content={"error": "job_id is required"})

        sql = text(
            """
            SELECT id, task_type, status, queue_name, worker_name, payload, reserved, started_at, completed_at
            FROM public.task_details
            WHERE job_id = :job_id
            ORDER BY started_at ASC NULLS LAST
            """
        )
        result = await session.execute(sql, {"job_id": job_id})
        rows = result.mappings().all()

        tasks = []
        for r in rows:
            tasks.append({
                "task": r.get("task_type"),
                "status": r.get("status"),
                "queue": r.get("queue_name"),
                "worker": r.get("worker_name"),
                "request_json": r.get("payload"),
                "response_json": r.get("reserved"),
                "start": r.get("started_at"),
                "end": r.get("completed_at"),
            })

        return {"job_id": job_id, "tasks": tasks}
    except Exception as e:
        logger.exception("Failed fetching task details for job_id=%s", body.job_id)
        return JSONResponse(status_code=500, content={"error": str(e)})


