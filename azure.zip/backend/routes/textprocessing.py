from fastapi import APIRouter, Form, File, UploadFile
from typing import List, Optional, Dict, Any
import uuid
import datetime
# from models import ProcessingTask, TaskStatus  # REMOVED unused
from database import SessionLocal
from celery import Celery
import logging
from config import settings
from sqlalchemy import text
from pydantic import BaseModel, ConfigDict, Field
import json
from sqlalchemy.exc import IntegrityError
import os
from pathlib import Path
from utils.path_utils import get_shared_path

logger = logging.getLogger("textprocessing")
logging.basicConfig(level=logging.INFO)

router = APIRouter(prefix="/textprocessing", tags=["TextProcessing"])

celery_app = Celery('textprocessing_worker', broker=settings.celery_broker_url)

# NEW: Request model for new textprocessing payload
class TextProcessingRequest(BaseModel):
    dag_id: str
    run_id: str
    folder_id: str
    text_processing_config: Dict[str, Any] = Field(default_factory=dict, alias="TextProcessingConfig")
    model_config = ConfigDict(extra="allow")

# NEW: worker-results model
class TextProcessingWorkerResult(BaseModel):
    task_id: str
    status: str
    process_name: Optional[str] = None
    job_id: Optional[str] = None
    error_message: Optional[str] = None
    folder_id: Optional[str] = None
    applied_filters: Optional[List[str]] = None
    model_config = ConfigDict(extra="allow")

@router.post("/process")
def submit_textprocessing_task(
    req: TextProcessingRequest,  # CHANGED to JSON contract
):
    try:
        # Create DB session
        session = SessionLocal()

        # Define worker and queue names up front to insert in a single query
        worker_name = "textprocessing_worker.textprocessing_task".lower()
        queue_name = settings.queue_textprocessing.lower()

        # Generate unique task_id with collision retry and insert into task_details
        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, started_at, job_id, payload, worker_name, queue_name
            ) VALUES (
                :id, :process_name, :task_type, :status, now(), :job_id, CAST(:payload AS JSONB), :worker_name, :queue_name
            )
            """
        )
        MAX_RETRIES = 5
        task_id = None
        for _ in range(MAX_RETRIES):
            candidate = str(uuid.uuid4())
            try:
                session.execute(
                    insert_sql,
                    {
                        "id": candidate,
                        "process_name": req.dag_id,
                        "task_type": "TextProcessing",
                        "status": "submitted",
                        "job_id": req.run_id,
                        "payload": json.dumps(req.text_processing_config),
                        "worker_name": worker_name,
                        "queue_name": queue_name,
                    },
                )
                session.commit()
                task_id = candidate
                break
            except IntegrityError as e:  # Only retry on unique/duplicate id
                session.rollback()
                # Postgres duplicate key error code is 23505
                pgcode = getattr(getattr(e, "orig", None), "pgcode", None)
                if pgcode == "23505" or (getattr(e, "orig", None) and "duplicate key" in str(e.orig).lower()):
                    continue
                raise
        if not task_id:
            return {"status": "error", "message": "Could not allocate unique task id after retries"}

        # Enqueue task
        celery_app.send_task(
            worker_name,
            args=[task_id, req.folder_id, req.dag_id, req.run_id, req.text_processing_config],
            queue=queue_name,
        )
        return {"task_id": task_id, "status": "submitted"}
    except Exception as e:
        logger.error(f"TextProcessing endpoint error: {e}", exc_info=True)
        try:
            session.rollback()
        except Exception:
            pass
        return {"status": "error", "message": str(e)}
    finally:
        try:
            session.close()
        except Exception:
            pass

@router.post("/worker-results")
def worker_results(body: TextProcessingWorkerResult):
    """Store textprocessing worker results JSON into task_details.reserved and finalize task status.

    On success, update public.document_details for the matching folder_id to set
    text_processing_status and last_successful_stage.
    """
    session = SessionLocal()
    try:
        status_raw = (body.status or "").strip().lower()
        status_norm = "success" if status_raw in ("success", "succeeded", "completed") else (
            "failed" if status_raw in ("error", "failed") else status_raw
        )

        # Persist entire worker payload into reserved JSONB and finalize status
        reserved_json = body.model_dump(exclude_none=True)
        if isinstance(body, BaseModel):
            try:
                extra_items = {k: v for k, v in body.__dict__.items() if k not in reserved_json}
                reserved_json.update(extra_items)
            except Exception:
                pass

        upd = text(
            """
            UPDATE public.task_details
            SET status = :st,
                reserved = CAST(:reserved AS JSONB),
                completed_at = now()
            WHERE id = :id
            """
        )
        res = session.execute(
            upd,
            {"id": body.task_id, "st": status_norm or "success", "reserved": json.dumps(reserved_json)},
        )
        session.commit()

        # Ensure existing row updated; do not insert new
        rowcount = getattr(res, "rowcount", None)
        if rowcount == 0:
            return {"status": "error", "message": f"task_id not found: {body.task_id}"}

        # Skip document_details updates for runtime textprocessing runs
        process_name_eff = (body.process_name or (reserved_json.get("process_name") if isinstance(reserved_json, dict) else "") or "").strip()
        if process_name_eff.lower() in ("runtimetesting", "runtimetextprocessing"):
            return {"status": "ok"}

        # Determine folder_id from payload
        folder_id_eff: Optional[str] = body.folder_id
        if not folder_id_eff:
            try:
                if isinstance(reserved_json, dict):
                    if not folder_id_eff and isinstance(reserved_json.get("folders"), list):
                        for item in reserved_json.get("folders"):
                            if isinstance(item, dict) and item.get("folder_id"):
                                folder_id_eff = str(item.get("folder_id"))
                                break
                    if not folder_id_eff and reserved_json.get("folder_id"):
                        folder_id_eff = str(reserved_json.get("folder_id"))
                    if not folder_id_eff and isinstance(reserved_json.get("folder_ids"), list) and reserved_json["folder_ids"]:
                        folder_id_eff = str(reserved_json["folder_ids"][0])
            except Exception:
                folder_id_eff = None

        # On success, update document_details status fields
        if status_norm == "success" and folder_id_eff:
            cols_info = session.execute(
                text(
                    """
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_schema = 'public' AND table_name = 'document_details'
                    """
                )
            ).mappings().all()
            col_names = {c["column_name"]: c.get("data_type") for c in cols_info}

            sets = []
            params = {"fid": folder_id_eff}
            if "text_processing_status" in col_names:
                sets.append("text_processing_status = :tps"); params["tps"] = "success"
            if "last_successful_stage" in col_names:
                sets.append("last_successful_stage = :lss"); params["lss"] = "text_processing"
            if "updated_at" in col_names:
                dt = (col_names.get("updated_at") or "").lower()
                if "timestamp" in dt:
                    sets.append("updated_at = now()")
                else:
                    sets.append("updated_at = :ua"); params["ua"] = None

            if sets:
                upd_doc = text(
                    f"""
                    UPDATE public.document_details
                    SET {', '.join(sets)}
                    WHERE folder_id = :fid
                    """
                )
                session.execute(upd_doc, params)
                session.commit()

        return {"status": "ok"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"TextProcessing worker-results error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

@router.get("/status/{task_id}")
def get_textprocessing_status(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT id, status, reserved
                FROM public.task_details
                WHERE id = :id
                """
            ),
            {"id": task_id},
        ).mappings().first()
        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        status = (row.get("status") or "").strip().lower() or "pending"
        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        # Success: extract folder_ids from reserved JSON
        folder_ids: List[str] = []
        reserved_val = row.get("reserved")
        try:
            data = None
            if isinstance(reserved_val, dict):
                data = reserved_val
            elif isinstance(reserved_val, (bytes, bytearray, memoryview)):
                data = json.loads(bytes(reserved_val).decode("utf-8"))
            elif isinstance(reserved_val, str):
                data = json.loads(reserved_val)
            if isinstance(data, dict):
                # Prefer folders array if present
                folders = data.get("folders")
                if isinstance(folders, list):
                    folder_ids = [str(it.get("folder_id")) for it in folders if isinstance(it, dict) and it.get("folder_id")]
                # Fallbacks: folder_ids array or single folder_id
                if not folder_ids:
                    ids_val = data.get("folder_ids")
                    if isinstance(ids_val, list):
                        folder_ids = [str(x) for x in ids_val if x]
                if not folder_ids and data.get("folder_id"):
                    folder_ids = [str(data.get("folder_id"))]
        except Exception:  # noqa: BLE001
            folder_ids = []

        return {"task_id": task_id, "status": "success", "folder_ids": folder_ids or []}
    except Exception as e:  # noqa: BLE001
        logger.error(f"TextProcessing status error: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e), "folder_ids": []}
    finally:
        session.close()

# NEW: Runtime textprocessing endpoint for testing from frontend
@router.post("/runtime-textprocess")
def runtime_textprocess(
    textprocessing_profile: str = Form(...),
    input_text: Optional[str] = Form(None, alias="text"),
    layout_json: Optional[str] = Form(None),
    layout_json_file: Optional[UploadFile] = File(None),
):
    """
        Accept either:
            - raw text (form field 'text'), or
            - a layout JSON (form field 'layout_json' as a string), or
            - an uploaded layout JSON file (form file 'layout_json_file'),
        along with a textprocessing_profile name. Fetch TextProcessingConfig from profiles table, create a
        unique runtime folder directly under DataBackBone, write the provided content, insert a row into
        public.task_details, enqueue the textprocessing worker task to the runtime queue, and return the task_id.
    """
    session = SessionLocal()
    try:
        # Fetch profile config from public.profiles (step_type = 'TextProcessing')
        row = session.execute(
            text(
                """
                SELECT profile_config
                FROM public.profiles
                WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
                  AND LOWER(TRIM(step_type)) = LOWER(TRIM('TextProcessing'))
                LIMIT 1
                """
            ),
            {"name": textprocessing_profile},
        ).first()
        if not row:
            return {"status": "error", "message": f"TextProcessing profile not found: {textprocessing_profile}"}

        raw_cfg = row[0]
        cfg: Dict[str, Any] = {}
        try:
            if isinstance(raw_cfg, dict):
                cfg = raw_cfg
            elif isinstance(raw_cfg, (bytes, bytearray, memoryview)):
                cfg = json.loads(bytes(raw_cfg).decode("utf-8"))
            elif isinstance(raw_cfg, str):
                cfg = json.loads(raw_cfg)
        except Exception as je:  # noqa: BLE001
            return {"status": "error", "message": f"Invalid profile config JSON: {je}"}

        # Worker and queue
        worker_name = "textprocessing_worker.textprocessing_task".lower()
        queue_name = "runtime_textprocessing".lower()

        # Resolve DataBackBone root robustly (UNC + env support)
        base_root = get_shared_path("DATA_BACKBONE_DIR", settings.data_backbone_dir or None)
        if not base_root.exists() or not base_root.is_dir():
            return {"status": "error", "message": f"DataBackBone path does not exist or is not accessible: {settings.data_backbone_dir}"}

        # Generate IDs and runtime folder
        task_id = str(uuid.uuid4())
        folder_id = str(uuid.uuid4())
        folder_name = f"Runtime_{folder_id}"
        runtime_dir = base_root / folder_name
        runtime_dir.mkdir(parents=True, exist_ok=True)
        print(f"Runtime textprocess folder created: {runtime_dir}")

        # Decide which input we have and write it out
        wrote_any = False
        # Priority 1: uploaded layout JSON file
        if layout_json_file is not None:
            try:
                contents = layout_json_file.file.read()
                try:
                    # Validate JSON parsable
                    json.loads(contents.decode("utf-8"))
                except Exception as je:
                    return {"status": "error", "message": f"Invalid JSON in uploaded file: {je}"}
                json_path = runtime_dir / "input.layout.json"
                with open(json_path, "wb") as jh:
                    jh.write(contents)
                wrote_any = True
            finally:
                try:
                    layout_json_file.file.close()
                except Exception:
                    pass
        # Priority 2: layout_json string
        elif layout_json is not None and str(layout_json).strip() != "":
            try:
                _ = json.loads(layout_json)
            except Exception as je:
                return {"status": "error", "message": f"Invalid layout_json content: {je}"}
            json_path = runtime_dir / "input.layout.json"
            with open(json_path, "w", encoding="utf-8") as jh:
                jh.write(layout_json)
            wrote_any = True
        # Priority 3: raw text
        elif input_text is not None:
            txt_path = runtime_dir / "input.txt"
            with open(txt_path, "w", encoding="utf-8") as out_f:
                out_f.write(input_text)
            wrote_any = True
        else:
            return {"status": "error", "message": "Provide either 'layout_json_file', 'layout_json', or 'text'"}

        # Insert into task_details
        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, worker_name, queue_name, started_at, job_id, payload
            ) VALUES (
                :id, :process_name, :task_type, :status, :worker_name, :queue_name, now(), :job_id, CAST(:payload AS JSONB)
            )
            """
        )
        session.execute(
            insert_sql,
            {
                "id": task_id,
                "process_name": "RuntimeTextprocessing",
                "task_type": "TextProcessing",
                "status": "submitted",
                "worker_name": worker_name,
                "queue_name": queue_name,
                "job_id": "RuntimeTextprocessing",
                "payload": json.dumps(cfg),
            },
        )
        session.commit()

        # Enqueue worker with only the folder identifier (relative). Worker will resolve full path
        # and will prefer *.layout.json if present, else fallback to input.txt.
        celery_app.send_task(
            worker_name,
            args=[task_id, folder_name, "RuntimeTextprocessing", "RuntimeTextprocessing", cfg],
            queue=queue_name,
        )

        return {"task_id": task_id, "status": "submitted"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Runtime textprocess endpoint error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


# NEW: Check runtime textprocessing status/result
@router.get("/runtime_status/{task_id}")
def get_runtime_textprocess_status(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT id, status, reserved
                FROM public.task_details
                WHERE id = :id
                """
            ),
            {"id": task_id},
        ).mappings().first()
        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet."}

        status = (row.get("status") or "").strip().lower() or "pending"
        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet."}

        # Extract folder_id/path and process metadata from reserved JSON
        reserved_val = row.get("reserved")
        folder_id_eff = None
        data = None
        try:
            if isinstance(reserved_val, dict):
                data = reserved_val
            elif isinstance(reserved_val, (bytes, bytearray, memoryview)):
                data = json.loads(bytes(reserved_val).decode("utf-8"))
            elif isinstance(reserved_val, str):
                data = json.loads(reserved_val)
            if isinstance(data, dict):
                if data.get("folder_id"):
                    folder_id_eff = str(data.get("folder_id"))
                elif isinstance(data.get("folders"), list):
                    for it in data.get("folders"):
                        if isinstance(it, dict) and it.get("folder_id"):
                            folder_id_eff = str(it.get("folder_id"))
                            break
        except Exception:  # noqa: BLE001
            folder_id_eff = None

        # Detect runtime textprocessing (matches how worker-results skips doc_details updates)
        is_runtime = False
        try:
            if isinstance(data, dict):
                pn = str(data.get("process_name") or "").strip().lower()
                job = str(data.get("job_id") or "").strip().lower()
                if pn in ("runtimetextprocessing", "runtimetesting") or job in ("runtimetextprocessing", "runtimetesting"):
                    is_runtime = True
        except Exception:
            is_runtime = False

        processed_json = None
        if folder_id_eff:
            try:
                base_root = get_shared_path("DATA_BACKBONE_DIR", settings.data_backbone_dir or None)
                fpath = Path(folder_id_eff)
                if not fpath.is_absolute():
                    fpath = base_root / fpath

                json_path = None
                if is_runtime:
                    # Runtime: any JSON file is acceptable
                    json_path_val = None
                    if isinstance(data, dict):
                        json_path_val = data.get("updated_json") or data.get("json_path")

                    if json_path_val:
                        jp = Path(str(json_path_val))
                        json_path = jp if jp.is_absolute() else (base_root / jp)
                    elif fpath.is_dir():
                        json_files = [p for p in fpath.iterdir() if p.is_file() and p.suffix.lower() == ".json"]
                        if json_files:
                            json_path = json_files[0]
                else:
                    # Non-runtime: prefer canonical *.parser_output.json in the folder
                    if fpath.is_dir():
                        json_files = [
                            p for p in fpath.iterdir()
                            if p.is_file()
                            and p.suffix.lower() == ".json"
                            and p.name.lower().endswith(".parser_output.json")
                        ]
                        if json_files:
                            json_path = json_files[0]

                if json_path and json_path.is_file():
                    with open(json_path, 'r', encoding='utf-8', errors='ignore') as fh:
                        processed_json = json.load(fh)
            except Exception:  # noqa: BLE001
                processed_json = None

        return {"task_id": task_id, "status": "success", "Processed_json": processed_json}
    except Exception as e:  # noqa: BLE001
        logger.error(f"Runtime textprocess status error: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e)}
    finally:
        session.close()
