from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Query, Form, Request
from fastapi.responses import JSONResponse, FileResponse
from sqlalchemy import text
from typing import List, Optional, Dict, Any, Union
import uuid
import shutil
import os
import base64
import hashlib
import re
from pathlib import Path
from datetime import datetime
import fitz  # PyMuPDF
import logging
from pydantic import BaseModel, Field
import json

from config import settings
from database import SessionLocal
from utils.path_utils import normalize_unc_path

router = APIRouter(prefix="/evaluation", tags=["Test Files"])
logger = logging.getLogger("contextcraft")

# --- Constants & Helpers ---

# A minimal 1x1 pixel gray PNG for placeholder
PLACEHOLDER_PNG_BYTES = (
    b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x01\x00\x00\x00\x00'
    b'7n\xf9$\x00\x00\x00\nIDATx\x9cc`\x00\x00\x00\x02\x00\x01H\xaf\xa4q\x00\x00\x00\x00IEND\xaeB`\x82'
)

def get_db_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()

def _ensure_directory(path: Path):
    if not path.exists():
        path.mkdir(parents=True, exist_ok=True)

def _generate_thumbnail(file_path: Path, thumb_path: Path, mime_type: str):
    """
    Generates a thumbnail for PDF or Images using PyMuPDF (fitz).
    Falls back to a placeholder for other types or failures.
    """
    generated = False
    try:
        # Check if supported by PyMuPDF (PDF, XPS, EPUB, standard images)
        # fitz.open() handles file detection automatically
        if mime_type.startswith("image/") or mime_type == "application/pdf":
            doc = fitz.open(str(file_path))
            if doc.page_count > 0:
                page = doc[0]  # First page
                
                # Calculate zoom to fit within ~200x200 box while maintaining aspect ratio
                # Default 72 DPI. 
                # A4 is ~595x842. Scale 0.3 -> ~178x252
                rect = page.rect
                max_dimension = 250
                zoom = 1.0
                if rect.width > 0 and rect.height > 0:
                    zoom = min(max_dimension / rect.width, max_dimension / rect.height)
                
                mat = fitz.Matrix(zoom, zoom)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                pix.save(str(thumb_path))
                doc.close()
                generated = True
            else:
                doc.close()
    except Exception as e:
        logger.warning(f"Failed to generate thumbnail for {file_path}: {e}")

    # Fallback to placeholder if not generated
    if not generated:
        try:
            with open(thumb_path, "wb") as f:
                f.write(PLACEHOLDER_PNG_BYTES)
        except Exception as e:
            logger.error(f"Failed to write placeholder thumbnail: {e}")

# --- Pydantic Models for Datasets ---

class DatasetCreate(BaseModel):
    name: str
    description: Optional[str] = None

class DatasetResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    created_at: str

# --- Pydantic Models for Output Saving ---

class SaveParserOutputRequest(BaseModel):
    test_file_id: str
    parser_profile_name: str
    output_json: Dict[str, Any]

class SaveTextProcessingOutputRequest(BaseModel):
    test_file_id: str
    parser_profile_name: str
    textprocessing_profile_name: str
    output_json: Dict[str, Any]

class SaveChunkingOutputRequest(BaseModel):
    test_file_id: str
    parser_profile_name: str
    textprocessing_profile_name: Optional[str] = None
    chunking_profile_name: str
    output_json: Union[Dict[str, Any], List[Any]]

# --- Helpers for Output Saving ---

def _get_test_file_root(test_file_id: str) -> Path:
    """Resolve the root folder for a specific test file in the data backbone."""
    base_dir = settings.data_backbone_dir
    if base_dir:
        # Normalize potentially messy UNC path from env
        clean_path = normalize_unc_path(base_dir)
        return Path(clean_path) / "test-files" / test_file_id
    
    # Fallback
    return Path("backend_data").resolve() / "test-files" / test_file_id

def _validate_test_file_exists(session, test_file_id: str):
    """Ensure the test file exists in the database."""
    result = session.execute(
        text("SELECT id FROM public.test_files_details WHERE id = :id"),
        {"id": test_file_id}
    ).fetchone()
    if not result:
        raise HTTPException(status_code=404, detail=f"Test file {test_file_id} not found")

def _normalize_profile_value(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    normalized = " ".join(str(value).strip().split())
    return normalized or None

def _safe_filename_part(value: Optional[str]) -> str:
    normalized = _normalize_profile_value(value) or "none"
    clean = re.sub(r"[^A-Za-z0-9._-]+", "_", normalized).strip("._")
    if not clean:
        clean = "profile"
    digest = hashlib.md5(normalized.lower().encode("utf-8")).hexdigest()[:8]
    return f"{clean}_{digest}"

def _write_json_file(file_path: Path, data: Dict[str, Any]):
    """Safely write JSON data to a file, ensuring parent directories exist."""
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Failed to write file {file_path}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to write output file: {str(e)}")

# --- Routes ---

# --- Dataset Routes ---

@router.post("/dataset/create", response_model=Dict[str, str])
async def create_dataset(dataset: DatasetCreate, session = Depends(get_db_session)):
    try:
        # Normalize name
        clean_name = dataset.name.strip()
        if not clean_name:
            raise HTTPException(status_code=400, detail="Dataset name cannot be empty")

        # Check if exists (Case Insensitive)
        check_query = text("SELECT id FROM public.datasets WHERE LOWER(TRIM(name)) = LOWER(TRIM(:name))")
        if session.execute(check_query, {"name": clean_name}).fetchone():
            raise HTTPException(status_code=409, detail=f"Dataset '{clean_name}' already exists")

        insert_query = text("""
            INSERT INTO public.datasets (name, description)
            VALUES (:name, :description)
            RETURNING id
        """)
        
        result = session.execute(insert_query, {
            "name": clean_name, 
            "description": dataset.description
        }).fetchone()
        
        session.commit()
        
        return {"id": str(result[0]), "status": "success", "message": "Dataset created"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create dataset failed: {e}")
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/datasets/list", response_model=List[DatasetResponse])
async def list_datasets(session = Depends(get_db_session)):
    try:
        query = text("""
            SELECT id, name, description, created_at
            FROM public.datasets
            ORDER BY created_at DESC
        """)
        rows = session.execute(query).fetchall()
        
        datasets = []
        for row in rows:
            datasets.append({
                "id": str(row[0]),
                "name": row[1],
                "description": row[2],
                "created_at": row[3].isoformat() if row[3] else ""
            })
            
        return datasets
    except Exception as e:
        logger.error(f"List datasets failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/dataset/delete/{dataset_id}")
async def delete_dataset(dataset_id: str, session = Depends(get_db_session)):
    try:
        delete_query = text("DELETE FROM public.datasets WHERE id = CAST(:id AS uuid)")
        result = session.execute(delete_query, {"id": dataset_id})
        
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Dataset not found")
            
        session.commit()
        return {"status": "success", "message": "Dataset deleted"}
        
    except Exception as e:
        logger.error(f"Delete dataset failed: {e}")
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))

# --- File Routes ---

@router.post("/dataset/file/upload")
async def upload_test_file(
    file: UploadFile = File(...),
    dataset_id: Optional[str] = Form(None),
    session = Depends(get_db_session)
):
    try:
        # Prepare Dataset ID
        d_id = None
        if dataset_id and dataset_id.strip():
            d_id = dataset_id.strip()

        # 0. Check for Duplicate File (Scoped to Dataset)
        fname_to_check = file.filename or "unknown_file"
        
        if d_id:
             check_query = text("""
                SELECT id FROM public.test_files_details 
                WHERE file_name = :fname AND dataset_id = CAST(:did AS uuid)
             """)
             dup = session.execute(check_query, {"fname": fname_to_check, "did": d_id}).fetchone()
        else:
             # Check for duplicates in root (dataset_id IS NULL)
             check_query = text("""
                SELECT id FROM public.test_files_details 
                WHERE file_name = :fname AND dataset_id IS NULL
             """)
             dup = session.execute(check_query, {"fname": fname_to_check}).fetchone()

        if dup:
            folder_msg = "in this dataset" if d_id else "in the root folder"
            raise HTTPException(status_code=409, detail=f"File '{fname_to_check}' already exists {folder_msg}")

        # 1. Resolve Data Backbone Path
        base_dir = settings.data_backbone_dir
        if base_dir:
            # Normalize potentially messy UNC path from env
            clean_path = normalize_unc_path(base_dir)
            backbone_path = Path(clean_path)
        else:
            # Fallback for development if env var not set
            backbone_path = Path("backend_data").resolve()
        
        # 2. Generate UUID and Directories
        file_uuid = str(uuid.uuid4())
        base_file_dir = backbone_path / "test-files" / file_uuid
        original_dir = base_file_dir / "original"
        thumb_dir = base_file_dir / "thumbnail"
        
        _ensure_directory(original_dir)
        _ensure_directory(thumb_dir)
        
        # 3. Define Paths
        original_filename = file.filename or "unknown_file"
        file_path = original_dir / original_filename
        thumb_path = thumb_dir / "thumbnail.png"
        
        # 4. Save File (Stream copy to avoid memory issues)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        # 5. Generate Thumbnail
        # Guess mime type from upload if available, or extension
        content_type = file.content_type or "application/octet-stream"
        _generate_thumbnail(file_path, thumb_path, content_type)
        
        # 6. Persist Metadata to DB
        insert_query = text("""
            INSERT INTO public.test_files_details 
            (id, file_name, mime_type, storage_path, thumbnail_path, created_at, dataset_id)
            VALUES (:id, :file_name, :mime_type, :storage_path, :thumbnail_path, :created_at, CAST(:dataset_id AS uuid))
        """)
        
        session.execute(insert_query, {
            "id": file_uuid,
            "file_name": original_filename,
            "mime_type": content_type,
            "storage_path": str(file_path).replace("\\", "/"),
            "thumbnail_path": str(thumb_path).replace("\\", "/"),
            "created_at": datetime.now(),
            "dataset_id": d_id
        })
        session.commit()
        
        return {
            "file_id": file_uuid, 
            "file_name": original_filename,
            "dataset_id": d_id
        }

    except Exception as e:
        logger.error(f"Upload failed: {e}")
        # Cleanup if DB insert fails? (Optional enhancement)
        raise HTTPException(status_code=500, detail=str(e))


class ListFilesRequest(BaseModel):
    dataset_name: str

@router.post("/dataset/files/list")
async def list_test_files(
    payload: ListFilesRequest,
    session = Depends(get_db_session)
):
    try:
        base_sql = """
            SELECT tf.id, tf.file_name, tf.mime_type, tf.created_at, tf.thumbnail_path, d.name, tf.dataset_id
            FROM public.test_files_details tf
            LEFT JOIN public.datasets d ON tf.dataset_id = d.id
            WHERE LOWER(TRIM(d.name)) = LOWER(TRIM(:dname))
            ORDER BY tf.created_at DESC
        """

        result = session.execute(text(base_sql), {"dname": payload.dataset_name.strip()}).fetchall()
        
        files = []
        for row in result:
            thumb_b64 = None
            th_path_str = row[4]
            if th_path_str:
                try:
                    p = Path(th_path_str)
                    if p.exists() and p.is_file():
                        with open(p, "rb") as f:
                            thumb_b64 = base64.b64encode(f.read()).decode("utf-8")
                except Exception:
                    pass
            
            # If still None, use placeholder? Or let frontend handle it? 
            # Looking at profiles.py, it sends None if missing. 
            # But let's check if we want to send the placeholder from memory if file read failed but we have PLACEHOLDER_PNG_BYTES in this file.
            if not thumb_b64:
                 thumb_b64 = base64.b64encode(PLACEHOLDER_PNG_BYTES).decode("utf-8")

            files.append({
                "id": str(row[0]),
                "file_name": row[1],
                "mime_type": row[2],
                "created_at": row[3].isoformat() if row[3] else None,
                "thumbnail": thumb_b64,  # Changed from thumbnail_path to thumbnail (base64)
                "dataset_name": row[5],
                "dataset_id": str(row[6]) if row[6] else None
            })
            
        return {"status": "success", "files": files}
        
    except Exception as e:
        logger.error(f"List files failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/dataset/file/read/{file_id}")
async def view_test_file(
    file_id: str,
    session = Depends(get_db_session)
):
    try:
        # Validate UUID format to prevent SQL errors
        try:
            uuid.UUID(file_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid file_id format")

        # 1. Fetch file info from DB
        query = text("""
            SELECT storage_path, mime_type, file_name
            FROM public.test_files_details
            WHERE id = :id
        """)
        result = session.execute(query, {"id": file_id}).fetchone()
        
        if not result:
            raise HTTPException(status_code=404, detail="File not found")
            
        storage_path_str = result[0]
        mime_type = result[1]
        file_name = result[2]
        
        if not storage_path_str:
             raise HTTPException(status_code=404, detail="File path missing in database")

        path_obj = Path(storage_path_str)
        
        if not path_obj.exists():
            # Try to resolve relative path if absolute fails, or handle normalization if needed
            # But upload uses explicit path, so usually it should match.
            raise HTTPException(status_code=404, detail=f"File missing on disk: {storage_path_str}")
            
        return FileResponse(
            path=path_obj, 
            media_type=mime_type or "application/octet-stream", 
            filename=file_name
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"View file failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/dataset/file/delete/{file_id}")
async def delete_test_file(
    file_id: str,
    session = Depends(get_db_session)
):
    try:
        # Validate UUID
        try:
            uuid.UUID(file_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid file_id format")

        # Check existence
        check_query = text("SELECT id FROM public.test_files_details WHERE id = :id")
        if not session.execute(check_query, {"id": file_id}).fetchone():
            raise HTTPException(status_code=404, detail="File not found")

        # Delete database entries
        session.execute(text("DELETE FROM public.chunking_profile_output WHERE test_file_id = :id"), {"id": file_id})
        session.execute(text("DELETE FROM public.textprocessing_profile_output WHERE test_file_id = :id"), {"id": file_id})
        session.execute(text("DELETE FROM public.parser_profile_output WHERE test_file_id = :id"), {"id": file_id})
        session.execute(text("DELETE FROM public.test_files_details WHERE id = :id"), {"id": file_id})
        
        session.commit()

        # Delete files from disk
        file_root = _get_test_file_root(file_id)
        
        if file_root.exists() and file_root.is_dir():
            shutil.rmtree(file_root)
            
        return {"status": "success", "message": f"File {file_id} deleted successfully"}

    except HTTPException:
        raise
    except Exception as e:
        session.rollback()
        logger.error(f"Delete file failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# --- Output Save Endpoints ---

@router.post("/profile/parser/file/output/save")
def save_parser_output(
    req: SaveParserOutputRequest,
    session = Depends(get_db_session)
):
    try:
        parser_profile_name = _normalize_profile_value(req.parser_profile_name)
        if not parser_profile_name:
            raise HTTPException(status_code=400, detail="parser_profile_name is required")

        # 1. Validate Test File
        _validate_test_file_exists(session, req.test_file_id)

        # 2. Prepare Paths
        test_file_root = _get_test_file_root(req.test_file_id)
        # databackbone/test-files/{test_file_id}/parser/{parser_profile_name}.json
        output_filename = f"{_safe_filename_part(parser_profile_name)}.json"
        output_path = test_file_root / "parser" / output_filename
        
        # 3. Construct Payload
        payload = {
            "test_file_id": req.test_file_id,
            "parser_profile": parser_profile_name,
            "output": req.output_json
        }

        # 4. Write File
        _write_json_file(output_path, payload)

        # 5. DB Upsert
        # Check if output already exists by normalized profile key.
        check_sql = text("""
            SELECT id FROM public.parser_profile_output
            WHERE test_file_id = :tf_id
              AND LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp_name))
            ORDER BY created_at DESC
        """)
        existing_rows = session.execute(
            check_sql,
            {"tf_id": req.test_file_id, "pp_name": parser_profile_name},
        ).fetchall()
        existing_row = existing_rows[0] if existing_rows else None

        if existing_row:
            # Update existing record
            update_sql = text("""
                UPDATE public.parser_profile_output
                SET parser_profile_name = :pp_name, output_path = :path, created_at = :now
                WHERE id = :id
            """)
            session.execute(update_sql, {
                "pp_name": parser_profile_name,
                "path": str(output_path).replace("\\", "/"),
                "now": datetime.now(),
                "id": existing_row.id
            })
            new_id = existing_row.id

            duplicate_ids = [row.id for row in existing_rows[1:]]
            for duplicate_id in duplicate_ids:
                session.execute(
                    text("DELETE FROM public.parser_profile_output WHERE id = :id"),
                    {"id": duplicate_id},
                )
        else:
            # Insert new record
            insert_sql = text("""
                INSERT INTO public.parser_profile_output
                (id, test_file_id, parser_profile_name, output_path, created_at)
                VALUES (:id, :tf_id, :pp_name, :path, :now)
            """)
            
            new_id = str(uuid.uuid4())
            session.execute(insert_sql, {
                "id": new_id,
                "tf_id": req.test_file_id,
                "pp_name": parser_profile_name,
                "path": str(output_path).replace("\\", "/"),
                "now": datetime.now()
            })
        
        session.commit()
        
        return {"status": "success", "id": new_id, "path": str(output_path)}

    except HTTPException:
        raise
    except Exception as e:
        session.rollback()
        logger.exception("Failed to save parser output")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/profile/textprocessing/file/output/save")
def save_textprocessing_output(
    req: SaveTextProcessingOutputRequest,
    session = Depends(get_db_session)
):
    try:
        parser_profile_name = _normalize_profile_value(req.parser_profile_name)
        textprocessing_profile_name = _normalize_profile_value(req.textprocessing_profile_name)
        if not parser_profile_name or not textprocessing_profile_name:
            raise HTTPException(status_code=400, detail="parser_profile_name and textprocessing_profile_name are required")

        # 1. Validate Test File
        _validate_test_file_exists(session, req.test_file_id)
        
        # 2. Check upstream dependency?
        # Requirement: "Ensure parser output exists for this file + parser profile"
        # We check DB for existence.
        check_parser = text("""
            SELECT id FROM public.parser_profile_output
              WHERE test_file_id = :tf_id
                AND LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp_name))
        """)
        if not session.execute(check_parser, {"tf_id": req.test_file_id, "pp_name": parser_profile_name}).fetchone():
            raise HTTPException(status_code=400, detail=f"Parser output for profile '{parser_profile_name}' not found. Cannot save text processing result.")

        # 3. Prepare Paths
        test_file_root = _get_test_file_root(req.test_file_id)
        # databackbone/test-files/{test_file_id}/textprocessing/{parser_profile_name}__{textprocessing_profile_name}.json
        output_filename = f"{_safe_filename_part(parser_profile_name)}__{_safe_filename_part(textprocessing_profile_name)}.json"
        output_path = test_file_root / "textprocessing" / output_filename

        # 4. Construct Payload
        payload = {
            "test_file_id": req.test_file_id,
            "parser_profile": parser_profile_name,
            "textprocessing_profile": textprocessing_profile_name,
            "output": req.output_json
        }

        # 5. Write File
        _write_json_file(output_path, payload)

        # 6. DB Upsert
        check_sql = text("""
            SELECT id FROM public.textprocessing_profile_output
            WHERE test_file_id = :tf_id 
              AND LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp_name))
              AND LOWER(TRIM(textprocessing_profile_name)) = LOWER(TRIM(:tp_name))
            ORDER BY created_at DESC
        """)
        existing_rows = session.execute(check_sql, {
            "tf_id": req.test_file_id, 
            "pp_name": parser_profile_name,
            "tp_name": textprocessing_profile_name
        }).fetchall()
        existing_row = existing_rows[0] if existing_rows else None

        if existing_row:
            update_sql = text("""
                UPDATE public.textprocessing_profile_output
                SET parser_profile_name = :pp_name,
                    textprocessing_profile_name = :tp_name,
                    output_path = :path,
                    created_at = :now
                WHERE id = :id
            """)
            session.execute(update_sql, {
                "pp_name": parser_profile_name,
                "tp_name": textprocessing_profile_name,
                "path": str(output_path).replace("\\", "/"),
                "now": datetime.now(),
                "id": existing_row.id
            })
            new_id = existing_row.id

            duplicate_ids = [row.id for row in existing_rows[1:]]
            for duplicate_id in duplicate_ids:
                session.execute(
                    text("DELETE FROM public.textprocessing_profile_output WHERE id = :id"),
                    {"id": duplicate_id},
                )
        else:
            insert_sql = text("""
                INSERT INTO public.textprocessing_profile_output
                (id, test_file_id, parser_profile_name, textprocessing_profile_name, output_path, created_at)
                VALUES (:id, :tf_id, :pp_name, :tp_name, :path, :now)
            """)

            new_id = str(uuid.uuid4())
            session.execute(insert_sql, {
                "id": new_id,
                "tf_id": req.test_file_id,
                "pp_name": parser_profile_name,
                "tp_name": textprocessing_profile_name,
                "path": str(output_path).replace("\\", "/"),
                "now": datetime.now()
            })
        
        session.commit()
        return {"status": "success", "id": new_id, "path": str(output_path)}

    except HTTPException:
        raise
    except Exception as e:
        session.rollback()
        logger.exception("Failed to save text processing output")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/profile/chunking/file/output/save")
def save_chunking_output(
    req: SaveChunkingOutputRequest,
    session = Depends(get_db_session)
):
    try:
        parser_profile_name = _normalize_profile_value(req.parser_profile_name)
        textprocessing_profile_name = _normalize_profile_value(req.textprocessing_profile_name)
        chunking_profile_name = _normalize_profile_value(req.chunking_profile_name)
        if not parser_profile_name or not chunking_profile_name:
            raise HTTPException(status_code=400, detail="parser_profile_name and chunking_profile_name are required")

        _validate_test_file_exists(session, req.test_file_id)

        check_parser = text("""
            SELECT id FROM public.parser_profile_output
            WHERE test_file_id = :tf_id
              AND LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp_name))
        """)
        if not session.execute(check_parser, {"tf_id": req.test_file_id, "pp_name": parser_profile_name}).fetchone():
            raise HTTPException(status_code=400, detail=f"Parser output for profile '{parser_profile_name}' not found. Cannot save chunking result.")

        if textprocessing_profile_name:
            check_tp = text("""
                SELECT id FROM public.textprocessing_profile_output
                WHERE test_file_id = :tf_id
                  AND LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp_name))
                  AND LOWER(TRIM(textprocessing_profile_name)) = LOWER(TRIM(:tp_name))
            """)
            if not session.execute(
                check_tp,
                {
                    "tf_id": req.test_file_id,
                    "pp_name": parser_profile_name,
                    "tp_name": textprocessing_profile_name,
                },
            ).fetchone():
                raise HTTPException(
                    status_code=400,
                    detail=f"Text processing output for profile '{textprocessing_profile_name}' not found. Cannot save chunking result.",
                )

        test_file_root = _get_test_file_root(req.test_file_id)
        tp_key = textprocessing_profile_name if textprocessing_profile_name else "none"
        output_filename = f"{_safe_filename_part(parser_profile_name)}__{_safe_filename_part(tp_key)}__{_safe_filename_part(chunking_profile_name)}.json"
        output_path = test_file_root / "chunking" / output_filename

        chunk_count = 0
        if isinstance(req.output_json, list):
            chunk_count = len(req.output_json)
        elif isinstance(req.output_json, dict):
            if "chunks" in req.output_json and isinstance(req.output_json["chunks"], list):
                chunk_count = len(req.output_json["chunks"])
            else:
                chunk_count = 1

        payload = {
            "test_file_id": req.test_file_id,
            "parser_profile": parser_profile_name,
            "textprocessing_profile": textprocessing_profile_name,
            "chunking_profile": chunking_profile_name,
            "chunk_count": chunk_count,
            "chunks": req.output_json,
        }
        _write_json_file(output_path, payload)

        params = {
            "tf_id": req.test_file_id,
            "pp_name": parser_profile_name,
            "cp_name": chunking_profile_name,
        }
        if textprocessing_profile_name:
            check_sql = text("""
                SELECT id FROM public.chunking_profile_output
                WHERE test_file_id = :tf_id
                  AND LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp_name))
                  AND LOWER(TRIM(textprocessing_profile_name)) = LOWER(TRIM(:tp_name))
                  AND LOWER(TRIM(chunking_profile_name)) = LOWER(TRIM(:cp_name))
                ORDER BY created_at DESC
            """)
            params["tp_name"] = textprocessing_profile_name
        else:
            check_sql = text("""
                SELECT id FROM public.chunking_profile_output
                WHERE test_file_id = :tf_id
                  AND LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp_name))
                  AND textprocessing_profile_name IS NULL
                  AND LOWER(TRIM(chunking_profile_name)) = LOWER(TRIM(:cp_name))
                ORDER BY created_at DESC
            """)

        existing_rows = session.execute(check_sql, params).fetchall()
        existing_row = existing_rows[0] if existing_rows else None

        if existing_row:
            update_sql = text("""
                UPDATE public.chunking_profile_output
                SET parser_profile_name = :pp_name,
                    textprocessing_profile_name = :tp_name,
                    chunking_profile_name = :cp_name,
                    output_path = :path,
                    chunk_count = :count,
                    created_at = :now
                WHERE id = :id
            """)
            session.execute(
                update_sql,
                {
                    "pp_name": parser_profile_name,
                    "tp_name": textprocessing_profile_name,
                    "cp_name": chunking_profile_name,
                    "path": str(output_path).replace("\\", "/"),
                    "count": chunk_count,
                    "now": datetime.now(),
                    "id": existing_row.id,
                },
            )
            new_id = existing_row.id

            duplicate_ids = [row.id for row in existing_rows[1:]]
            for duplicate_id in duplicate_ids:
                session.execute(
                    text("DELETE FROM public.chunking_profile_output WHERE id = :id"),
                    {"id": duplicate_id},
                )
        else:
            insert_sql = text("""
                INSERT INTO public.chunking_profile_output
                (id, test_file_id, parser_profile_name, textprocessing_profile_name, chunking_profile_name, chunk_count, output_path, created_at)
                VALUES (:id, :tf_id, :pp_name, :tp_name, :cp_name, :count, :path, :now)
            """)
            new_id = str(uuid.uuid4())
            session.execute(
                insert_sql,
                {
                    "id": new_id,
                    "tf_id": req.test_file_id,
                    "pp_name": parser_profile_name,
                    "tp_name": textprocessing_profile_name,
                    "cp_name": chunking_profile_name,
                    "count": chunk_count,
                    "path": str(output_path).replace("\\", "/"),
                    "now": datetime.now(),
                },
            )

        session.commit()
        return {"status": "success", "id": new_id, "path": str(output_path)}

    except HTTPException:
        raise
    except Exception as e:
        session.rollback()
        logger.exception("Failed to save chunking output")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------------
# Read-only listing API for profile test pages
# GET /test-files/profile-tests/files
# ---------------------------------------------------------------------------
@router.get("/profile/files/list")
def list_profile_test_files(
    request: Request,
    step: str = Query(..., description="One of: parser, textprocessing, chunking"),
    parser_profile: Optional[str] = Query(None),
    textprocessing_profile: Optional[str] = Query(None),
    chunking_profile: Optional[str] = Query(None),
    dataset_name: Optional[str] = Query(None),
    session = Depends(get_db_session),
):
    try:
        step = (step or "").lower()
        if step not in {"parser", "textprocessing", "chunking"}:
            raise HTTPException(status_code=400, detail="Invalid step parameter")

        query_params = request.query_params
        parser_profile = _normalize_profile_value(parser_profile or query_params.get("parserProfile"))
        textprocessing_profile = _normalize_profile_value(textprocessing_profile or query_params.get("textprocessingProfile"))
        chunking_profile = _normalize_profile_value(chunking_profile or query_params.get("chunkingProfile"))
        dataset_name = _normalize_profile_value(dataset_name or query_params.get("datasetName"))

        # Prepare dataset filter params
        ds_val = dataset_name.strip() if dataset_name else None
        
        # Helper to normalize DB rows into file dict with base64 thumbnail
        def _make_file_dict(fid, fname, fpath, **kwargs):
             thumb_b64 = None
             if fpath:
                try:
                    p = Path(fpath)
                    if p.exists() and p.is_file():
                        with open(p, "rb") as f:
                            thumb_b64 = base64.b64encode(f.read()).decode("utf-8")
                except Exception:
                    pass

             if not thumb_b64:
                 thumb_b64 = base64.b64encode(PLACEHOLDER_PNG_BYTES).decode("utf-8")

             d = {
                "file_id": str(fid),
                "file_name": fname,
                "thumbnail": thumb_b64,
            }
             d.update(kwargs)
             return d

        # A) Parser step
        if step == "parser":
            # 1) All test files
            q_all = text("""
                SELECT t.id, t.file_name, t.thumbnail_path
                FROM public.test_files_details t
                LEFT JOIN public.datasets d ON t.dataset_id = d.id
                WHERE (:ds_name IS NULL OR LOWER(TRIM(d.name)) = LOWER(TRIM(:ds_name)))
                ORDER BY t.created_at DESC
            """)
            all_rows = session.execute(q_all, {"ds_name": ds_val}).fetchall()
            test_files = [_make_file_dict(r[0], r[1], r[2]) for r in all_rows]

            # 2) Parsed files for the given parser_profile (empty if not provided)
            parsed_files = []
            if parser_profile:
                q_parsed = text("""
                    SELECT DISTINCT t.id, t.file_name, t.thumbnail_path, t.created_at
                    FROM public.parser_profile_output p
                    JOIN public.test_files_details t ON p.test_file_id = t.id
                    LEFT JOIN public.datasets d ON t.dataset_id = d.id
                                        WHERE LOWER(TRIM(p.parser_profile_name)) = LOWER(TRIM(:pp))
                      AND (:ds_name IS NULL OR LOWER(TRIM(d.name)) = LOWER(TRIM(:ds_name)))
                    ORDER BY t.created_at DESC
                """)
                rows = session.execute(q_parsed, {"pp": parser_profile, "ds_name": ds_val}).fetchall()
                parsed_files = [_make_file_dict(r[0], r[1], r[2]) for r in rows]

            return {"test_files": test_files, "parsed_files": parsed_files}

        # B) Textprocessing step
        if step == "textprocessing":
            # parsed_files grouped by parser_profile_name
            parsed_params = {"ds_name": ds_val}
            parsed_where = "WHERE (:ds_name IS NULL OR LOWER(TRIM(d.name)) = LOWER(TRIM(:ds_name)))"
            
            if parser_profile:
                parsed_where += " AND LOWER(TRIM(p.parser_profile_name)) = LOWER(TRIM(:pp))"
                parsed_params["pp"] = parser_profile

            q_parsed_group = text(f"""
                SELECT DISTINCT p.parser_profile_name, t.id, t.file_name, t.thumbnail_path, t.created_at
                FROM public.parser_profile_output p
                JOIN public.test_files_details t ON p.test_file_id = t.id
                LEFT JOIN public.datasets d ON t.dataset_id = d.id
                {parsed_where}
                ORDER BY p.parser_profile_name, t.created_at DESC
            """)
            parsed_rows = session.execute(q_parsed_group, parsed_params).fetchall()

            parsed_map = {}
            for row in parsed_rows:
                pname = row[0]
                # row currently: (parser_profile_name, id, file_name, thumbnail_path, created_at)
                file_dict = _make_file_dict(row[1], row[2], row[3])
                parsed_map.setdefault(pname, []).append(file_dict)

            parsed_files = [{"parser_profile": k, "files": v} for k, v in parsed_map.items()]

            # text_processed_files grouped by textprocessing_profile_name
            params = {"ds_name": ds_val}
            where_clause = "WHERE (:ds_name IS NULL OR LOWER(TRIM(d.name)) = LOWER(TRIM(:ds_name)))"
            
            if parser_profile:
                where_clause += " AND LOWER(TRIM(tp.parser_profile_name)) = LOWER(TRIM(:pp))"
                params["pp"] = parser_profile
                
            if textprocessing_profile:
                where_clause += " AND LOWER(TRIM(tp.textprocessing_profile_name)) = LOWER(TRIM(:tp))"
                params["tp"] = textprocessing_profile

            q_textproc = text(f"""
                SELECT DISTINCT tp.textprocessing_profile_name, t.id, t.file_name, t.thumbnail_path, t.created_at, tp.parser_profile_name
                FROM public.textprocessing_profile_output tp
                JOIN public.test_files_details t ON tp.test_file_id = t.id
                LEFT JOIN public.datasets d ON t.dataset_id = d.id
                {where_clause}
                ORDER BY tp.textprocessing_profile_name, t.created_at DESC
            """)
            tp_rows = session.execute(q_textproc, params).fetchall()

            tp_map = {}
            for row in tp_rows:
                tpname = row[0]
                file_dict = _make_file_dict(row[1], row[2], row[3], parser_profile=row[5])
                tp_map.setdefault(tpname, []).append(file_dict)

            text_processed_files = [{"textprocessing_profile": k, "files": v} for k, v in tp_map.items()]

            return {"parsed_files": parsed_files, "text_processed_files": text_processed_files}

        # C) Chunking step
        if step == "chunking":
            # parsed_files grouped by parser_profile_name (same as textprocessing)
            parsed_params = {"ds_name": ds_val}
            parsed_where = "WHERE (:ds_name IS NULL OR LOWER(TRIM(d.name)) = LOWER(TRIM(:ds_name)))"
            
            if parser_profile:
                parsed_where += " AND LOWER(TRIM(p.parser_profile_name)) = LOWER(TRIM(:pp))"
                parsed_params["pp"] = parser_profile

            q_parsed_group = text(f"""
                SELECT DISTINCT p.parser_profile_name, t.id, t.file_name, t.thumbnail_path, t.created_at
                FROM public.parser_profile_output p
                JOIN public.test_files_details t ON p.test_file_id = t.id
                LEFT JOIN public.datasets d ON t.dataset_id = d.id
                {parsed_where}
                ORDER BY p.parser_profile_name, t.created_at DESC
            """)
            parsed_rows = session.execute(q_parsed_group, parsed_params).fetchall()
            parsed_map = {}
            for row in parsed_rows:
                pname = row[0]
                file_dict = _make_file_dict(row[1], row[2], row[3])
                parsed_map.setdefault(pname, []).append(file_dict)
            parsed_files = [{"parser_profile": k, "files": v} for k, v in parsed_map.items()]

            # text_processed_files grouped by textprocessing_profile_name
            tp_params = {"ds_name": ds_val}
            tp_where = "WHERE (:ds_name IS NULL OR LOWER(TRIM(d.name)) = LOWER(TRIM(:ds_name)))"
            
            if parser_profile:
                tp_where += " AND LOWER(TRIM(tp.parser_profile_name)) = LOWER(TRIM(:pp))"
                tp_params["pp"] = parser_profile
                
            if textprocessing_profile:
                tp_where += " AND LOWER(TRIM(tp.textprocessing_profile_name)) = LOWER(TRIM(:tp))"
                tp_params["tp"] = textprocessing_profile

            q_textproc = text(f"""
                SELECT DISTINCT tp.textprocessing_profile_name, t.id, t.file_name, t.thumbnail_path, t.created_at, tp.parser_profile_name
                FROM public.textprocessing_profile_output tp
                JOIN public.test_files_details t ON tp.test_file_id = t.id
                LEFT JOIN public.datasets d ON t.dataset_id = d.id
                {tp_where}
                ORDER BY tp.textprocessing_profile_name, t.created_at DESC
            """)
            tp_rows = session.execute(q_textproc, tp_params).fetchall()
            tp_map = {}
            for row in tp_rows:
                tpname = row[0]
                file_dict = _make_file_dict(row[1], row[2], row[3], parser_profile=row[5])
                tp_map.setdefault(tpname, []).append(file_dict)
            text_processed_files = [{"textprocessing_profile": k, "files": v} for k, v in tp_map.items()]

            # chunked_files grouped by chunking_profile_name (include chunk_count)
            params = {"ds_name": ds_val}
            where_clause = "WHERE (:ds_name IS NULL OR LOWER(TRIM(d.name)) = LOWER(TRIM(:ds_name)))"
            
            if parser_profile:
                where_clause += " AND LOWER(TRIM(c.parser_profile_name)) = LOWER(TRIM(:pp))"
                params["pp"] = parser_profile
                
            if textprocessing_profile:
                where_clause += " AND LOWER(TRIM(c.textprocessing_profile_name)) = LOWER(TRIM(:tp))"
                params["tp"] = textprocessing_profile
                
            if chunking_profile:
                where_clause += " AND LOWER(TRIM(c.chunking_profile_name)) = LOWER(TRIM(:cp))"
                params["cp"] = chunking_profile

            q_chunked = text(f"""
                SELECT DISTINCT c.chunking_profile_name, t.id, t.file_name, t.thumbnail_path, c.chunk_count, t.created_at, c.parser_profile_name, c.textprocessing_profile_name
                FROM public.chunking_profile_output c
                JOIN public.test_files_details t ON c.test_file_id = t.id
                LEFT JOIN public.datasets d ON t.dataset_id = d.id
                {where_clause}
                ORDER BY c.chunking_profile_name, t.created_at DESC
            """)
            ch_rows = session.execute(q_chunked, params).fetchall()

            ch_map = {}
            for row in ch_rows:
                cname = row[0]
                file_dict = _make_file_dict(row[1], row[2], row[3], chunk_count=row[4], parser_profile=row[6], textprocessing_profile=row[7])
                ch_map.setdefault(cname, []).append(file_dict)

            chunked_files = [{"chunking_profile": k, "files": v} for k, v in ch_map.items()]

            return {
                "parsed_files": parsed_files,
                "text_processed_files": text_processed_files,
                "chunked_files": chunked_files,
            }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Failed to list profile test files")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/profile/file/data/{file_id}")
def get_profile_test_data(
    request: Request,
    file_id: str,
    step: str = Query(..., description="One of: parser, textprocessing, chunking"),
    profile_name: Optional[str] = Query(None),
    parser_profile: Optional[str] = Query(None),
    textprocessing_profile: Optional[str] = Query(None),
    chunking_profile: Optional[str] = Query(None),
    include_output: bool = Query(True, description="Whether to fetch output json"),
    session = Depends(get_db_session)
):
    try:
        # 1. Get File Info
        f_query = text("SELECT storage_path, file_name, mime_type FROM public.test_files_details WHERE id = :id")
        f_row = session.execute(f_query, {"id": file_id}).fetchone()
        if not f_row:
             raise HTTPException(status_code=404, detail="File not found")
        
        storage_path = f_row[0]
        file_name = f_row[1]
        mime_type = f_row[2]
        file_b64 = None

        if storage_path:
            p = Path(storage_path)
            if p.exists() and p.is_file():
                with open(p, "rb") as f:
                    file_b64 = base64.b64encode(f.read()).decode("utf-8")
        
        # 2. Check Output
        output_json = None
        step = step.lower()
        query_params = request.query_params
        profile_name = _normalize_profile_value(profile_name or query_params.get("profileName"))
        parser_profile = _normalize_profile_value(parser_profile or query_params.get("parserProfile"))
        textprocessing_profile = _normalize_profile_value(textprocessing_profile or query_params.get("textprocessingProfile"))
        chunking_profile = _normalize_profile_value(chunking_profile or query_params.get("chunkingProfile"))
        output_path_str = None

        if profile_name and include_output:
            if step == "parser":
                q = text("""
                    SELECT output_path FROM public.parser_profile_output
                    WHERE test_file_id = :id
                      AND LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pname))
                    ORDER BY created_at DESC LIMIT 1
                """)
                res = session.execute(q, {"id": file_id, "pname": profile_name}).fetchone()
                if res: output_path_str = res[0]

            elif step == "textprocessing":
                q = text("""
                    SELECT output_path, parser_profile_name FROM public.textprocessing_profile_output
                    WHERE test_file_id = :id
                      AND LOWER(TRIM(textprocessing_profile_name)) = LOWER(TRIM(:pname))
                      AND (:pp IS NULL OR LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp)))
                    ORDER BY created_at DESC
                """)
                rows = session.execute(q, {"id": file_id, "pname": profile_name, "pp": parser_profile}).fetchall()
                if rows:
                    if parser_profile is None:
                        parser_variants = {str(row[1]).strip().lower() for row in rows if row[1] is not None}
                        if len(parser_variants) > 1:
                            raise HTTPException(
                                status_code=409,
                                detail="Ambiguous textprocessing output. Please provide parser_profile.",
                            )
                    output_path_str = rows[0][0]

            elif step == "chunking":
                q = text("""
                    SELECT output_path, parser_profile_name, textprocessing_profile_name FROM public.chunking_profile_output
                    WHERE test_file_id = :id
                      AND LOWER(TRIM(chunking_profile_name)) = LOWER(TRIM(:pname))
                      AND (:pp IS NULL OR LOWER(TRIM(parser_profile_name)) = LOWER(TRIM(:pp)))
                      AND (:tp IS NULL OR LOWER(TRIM(textprocessing_profile_name)) = LOWER(TRIM(:tp)))
                    ORDER BY created_at DESC
                """)
                rows = session.execute(
                    q,
                    {
                        "id": file_id,
                        "pname": profile_name,
                        "pp": parser_profile,
                        "tp": textprocessing_profile,
                    },
                ).fetchall()
                if rows:
                    if parser_profile is None:
                        parser_variants = {str(row[1]).strip().lower() for row in rows if row[1] is not None}
                        if len(parser_variants) > 1:
                            raise HTTPException(
                                status_code=409,
                                detail="Ambiguous chunking output. Please provide parser_profile.",
                            )
                    if textprocessing_profile is None:
                        tp_variants = {str(row[2]).strip().lower() for row in rows if row[2] is not None}
                        if len(tp_variants) > 1:
                            raise HTTPException(
                                status_code=409,
                                detail="Ambiguous chunking output. Please provide textprocessing_profile.",
                            )
                    output_path_str = rows[0][0]
        
        if output_path_str:
            out_p = Path(output_path_str)
            if out_p.exists():
                try:
                    with open(out_p, "r", encoding="utf-8") as f:
                        output_json = json.load(f)
                except Exception as e:
                    logger.error(f"Failed to read output json {out_p}: {e}")

        return {
            "file_id": file_id,
            "file_name": file_name,
            "mime_type": mime_type,
            "file_content": file_b64,
            "output": output_json
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get profile test data failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

