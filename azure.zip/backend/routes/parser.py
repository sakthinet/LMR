from fastapi import APIRouter, UploadFile, File, Form
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from pydantic import BaseModel, ConfigDict, Field
from typing import Optional, Dict, Any, List
from html import unescape as _html_unescape
from pathlib import Path
import uuid
import uuid as _uuid
import os
import json
import re
import shutil
import logging

from celery import Celery

from models import TaskStatus
from database import SessionLocal
from config import settings
from utils.path_utils import get_shared_path

logger = logging.getLogger("parser")
logging.basicConfig(level=logging.INFO)

router = APIRouter(prefix="/parser", tags=["Parser"])
celery_app = Celery(broker=settings.celery_broker_url)

_re = re


# ----------------------------
# Helpers
# ----------------------------

def _html_to_text(s: str) -> str:
    s2 = _re.sub(r"<[^>]+>", "", s or "")
    s3 = _html_unescape(s2)
    return _re.sub(r"\s+", " ", s3).strip()


def _summarize_table(html: str) -> Dict[str, Any]:
    rows = len(_re.findall(r"<\s*tr\b", html, flags=_re.IGNORECASE))
    row_blocks = _re.findall(
        r"<\s*tr\b[^>]*>(.*?)</\s*tr\s*>",
        html,
        flags=_re.IGNORECASE | _re.DOTALL,
    )
    col_counts = []
    top_values: List[Dict[str, str]] = []
    for r_i, row_html in enumerate(row_blocks):
        cells = _re.findall(
            r"<\s*(td|th)\b[^>]*>(.*?)</\s*(td|th)\s*>",
            row_html,
            flags=_re.IGNORECASE | _re.DOTALL,
        )
        col_counts.append(len(cells))
        if r_i < 2:
            for c_i, cell_match in enumerate(cells):
                raw_cell = cell_match[1]
                cell_txt = _html_to_text(raw_cell)
                if cell_txt:
                    top_values.append({"col": str(c_i), "val": cell_txt})
                if len(top_values) >= 5:
                    break
        if len(top_values) >= 5:
            break
    cols = max(col_counts) if col_counts else 0
    return {"rows": rows, "cols": cols, "top_values": top_values}


def _extract_layout_pages(reserved_json: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract layout pages from worker payload.

    Supports:
      - raw_json.layout (single page)
      - raw_json.pages[].layout
      - raw_json.pages[].text where text is a JSON string containing {"layout":[...]}
      - raw_json.files[].pages[].layout (LlamaParser case)
      - raw_json.files[].pages[].text/md containing JSON string {"layout":[...]}
    """
    out: List[Dict[str, Any]] = []

    raw = reserved_json.get("raw_json")
    if raw is None:
        return out

    # Sometimes becomes string after roundtrips
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return out

    if not isinstance(raw, dict):
        return out

    # Helper: process a list of "pages"-like dicts
    def _collect_from_pages(pages_obj: Any):
        local_out: List[Dict[str, Any]] = []
        if not isinstance(pages_obj, list):
            return local_out

        for p in pages_obj:
            if not isinstance(p, dict):
                continue

            pn = p.get("page_number") or p.get("page") or 1

            # pages[].layout
            if isinstance(p.get("layout"), list):
                local_out.append({"page_number": pn, "layout": p["layout"]})
                continue

            # pages[].text / md holding JSON string with {"layout":[...]}
            txt = p.get("text") or p.get("md")
            if isinstance(txt, str):
                s = txt.lstrip("\ufeff").strip()
                if s.startswith("{") or s.startswith("["):
                    try:
                        parsed = json.loads(s)
                        if isinstance(parsed, dict) and isinstance(parsed.get("layout"), list):
                            local_out.append({"page_number": pn, "layout": parsed["layout"]})
                            continue
                    except Exception:
                        pass
        return local_out

    # A) Top-level layout
    if isinstance(raw.get("layout"), list):
        return [{"page_number": 1, "layout": raw["layout"]}]

    # B) Top-level pages list
    pages_top = raw.get("pages")
    if isinstance(pages_top, list):
        out.extend(_collect_from_pages(pages_top))

    # C) LlamaParser-style: raw_json.files[].pages
    files = raw.get("files")
    if isinstance(files, list):
        for f in files:
            if not isinstance(f, dict):
                continue
            pages_f = f.get("pages")
            if isinstance(pages_f, list):
                out.extend(_collect_from_pages(pages_f))

    return out


def _layout_pages_to_parser_output(
    pages: List[Dict[str, Any]],
    parser_name: Optional[str],
    filename: Optional[str],
) -> List[Dict[str, Any]]:
    """
    Convert extracted layout pages -> unified parser_output schema.

    Accepts layout element examples:
      { "type":"text", "bbox":[...], "text":"..." }
      { "type":"title", ... }
      { "type":"figure", ... }
      { "type":"table", "html":"<table>...</table>" }  (optional)
    """
    out: List[Dict[str, Any]] = []
    seen_title = False

    for p in pages:
        page_no = p.get("page_number") or 1
        layout = p.get("layout")
        if not isinstance(layout, list):
            continue

        for el in layout:
            if not isinstance(el, dict):
                continue

            et_raw = (el.get("type") or el.get("element_type") or "text")
            et = str(et_raw).strip().lower()

            bbox = el.get("bbox") or el.get("bounding_box")
            if not (isinstance(bbox, list) and len(bbox) == 4):
                bbox = None

            text_val = el.get("text") or el.get("content") or ""
            if text_val is None:
                text_val = ""
            text_val = str(text_val)

            html_val = el.get("html")
            if html_val is not None:
                html_val = str(html_val)

            if et in ("title", "heading", "header"):
                out_type = "heading"
                role = "title" if (not seen_title and str(page_no).isdigit() and int(page_no) == 1) else "section_heading"
                seen_title = True
                out_text = _html_to_text(f"<heading>{text_val}</heading>")
                table_summary = None

            elif et == "table" or (isinstance(html_val, str) and "<table" in html_val.lower()):
                out_type = "table"
                role = "body"
                out_text = (html_val or text_val or "").strip()
                table_summary = _summarize_table(out_text) if "<table" in out_text.lower() else {}

            elif et in ("figure", "image", "chart"):
                out_type = "figure"
                role = "body"
                out_text = _html_to_text(text_val)
                table_summary = None

            else:
                # includes "text", "reference", etc.
                out_type = "paragraph"
                role = "body"
                out_text = _html_to_text(f"<paragraph>{text_val}</paragraph>")
                table_summary = None

            item: Dict[str, Any] = {
                "element_id": str(_uuid.uuid4()),
                "type": out_type,
                "role": role,
                "text": out_text,
                "page": int(page_no) if str(page_no).isdigit() else 1,
                "bbox": bbox,
                "kv_pairs": [],
                "source": {"parser": parser_name or "unknown", "filename": filename or ""},
            }
            if out_type == "table":
                item["table_summary"] = table_summary or {}

            out.append(item)

    return out


def _sanitize_parser_output(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    allowed = {"element_id", "type", "role", "text", "page", "bbox", "kv_pairs", "table_summary", "source"}
    sanitized: List[Dict[str, Any]] = []

    for it in items:
        base = {k: it.get(k) for k in allowed}
        if not base.get("element_id"):
            base["element_id"] = str(_uuid.uuid4())
        if not isinstance(base.get("text"), str):
            base["text"] = "" if base.get("text") is None else str(base.get("text"))
        if not isinstance(base.get("kv_pairs"), list):
            base["kv_pairs"] = []
        if not isinstance(base.get("source"), dict):
            base["source"] = {"parser": "", "filename": ""}
        if base.get("type") != "table":
            if not isinstance(base.get("table_summary"), dict):
                base["table_summary"] = {}
        sanitized.append(base)

    # A) Drop empty/whitespace-only text elements and backend page-marker artifacts.
    # Keep real tables even if text is HTML.
    page_marker_re = re.compile(r"^<<<PAGE:(\d+)>>>$", flags=re.IGNORECASE)
    filtered: List[Dict[str, Any]] = []
    for it in sanitized:
        t = it.get("type")
        txt = it.get("text")
        if not isinstance(txt, str):
            txt = "" if txt is None else str(txt)

        # Drop page markers like <<<PAGE:1>>> (injected by plain-text fallback).
        if page_marker_re.match(txt.strip()):
            continue

        # Drop standalone page-number artifacts (common headers/footers from OCR/parsers).
        # Keep multi-digit numeric text to avoid accidentally removing real numeric content.
        stripped = txt.strip()
        if t != "table" and stripped.isdigit() and len(stripped) == 1:
            continue

        # Keep tables if they contain HTML or any text at all.
        if t == "table":
            if txt.strip():
                filtered.append(it)
            continue

        if txt.strip() == "":
            continue
        filtered.append(it)

    # B) Stable sort by page then bbox (y1,x1,y2,x2); bbox-less items last.
    def _sort_key(it: Dict[str, Any]):
        try:
            p = int(it.get("page") or 1)
        except Exception:
            p = 1
        bb = it.get("bbox")
        if isinstance(bb, list) and len(bb) == 4:
            try:
                x1, y1, x2, y2 = float(bb[0]), float(bb[1]), float(bb[2]), float(bb[3])
                return (p, 0, y1, x1, y2, x2)
            except Exception:
                pass
        return (p, 1, 0.0, 0.0, 0.0, 0.0)

    filtered.sort(key=_sort_key)
    return filtered


def _ensure_dir(p: Path) -> None:
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        raise RuntimeError(f"Cannot create output directory: {p} ({e})")


def _plain_text_to_parser_output(
    text_val: str,
    parser_name: Optional[str],
    filename: Optional[str],
    default_page: int = 1,
) -> List[Dict[str, Any]]:
    """
    Fallback: normalize pure plain text into paragraph elements.

        Strategy:
            - Preserve HTML tables as dedicated `table` elements.
            - Prefer Markdown-style headings (#, ##, ...) when present.
            - Split remaining text into blocks by blank lines.
    """
    out: List[Dict[str, Any]] = []

    if not isinstance(text_val, str):
        text_val = "" if text_val is None else str(text_val)

    # Normalize newlines
    raw = text_val.replace("\r\n", "\n").replace("\r", "\n")

    def _split_preserving_tables(s: str) -> List[Dict[str, str]]:
        """Return ordered parts: {'kind': 'text'|'table', 'value': ...}."""
        parts_local: List[Dict[str, str]] = []
        pos = 0
        lowered = s.lower()
        while True:
            start = lowered.find("<table", pos)
            if start == -1:
                tail = s[pos:]
                if tail.strip():
                    parts_local.append({"kind": "text", "value": tail})
                break
            before = s[pos:start]
            if before.strip():
                parts_local.append({"kind": "text", "value": before})
            end = lowered.find("</table>", start)
            if end == -1:
                # If malformed, treat the rest as text
                rest = s[start:]
                if rest.strip():
                    parts_local.append({"kind": "text", "value": rest})
                break
            end = end + len("</table>")
            table_html = s[start:end]
            parts_local.append({"kind": "table", "value": table_html.strip()})
            pos = end
        return parts_local

    def _blocks_from_text(text_chunk: str) -> List[str]:
        # Split into blocks separated by 1+ blank lines; join intra-block lines with spaces
        blocks_local: List[str] = []
        current_local: List[str] = []
        for line in text_chunk.split("\n"):
            stripped = line.strip()
            if stripped:
                current_local.append(stripped)
            else:
                if current_local:
                    blocks_local.append(" ".join(current_local))
                    current_local = []
        if current_local:
            blocks_local.append(" ".join(current_local))
        return blocks_local

    def _append_markdownish_blocks(blocks_in: List[str]) -> None:
        nonlocal out
        for blk in blocks_in:
            blk = blk.strip()
            if not blk:
                continue

            md = blk.lstrip()
            if md.startswith("#"):
                # Basic markdown heading detection
                hashes = 0
                for ch in md:
                    if ch == "#":
                        hashes += 1
                    else:
                        break
                title = md[hashes:].strip()
                if title:
                    role = "title" if hashes == 1 else "section"
                    out.append({
                        "element_id": str(_uuid.uuid4()),
                        "type": "heading",
                        "role": role,
                        "text": title,
                        "page": page,
                        "bbox": None,
                        "kv_pairs": [],
                        "source": {"parser": parser_name or "unknown", "filename": filename or ""},
                    })
                    continue

            # Fallback paragraph
            out.append({
                "element_id": str(_uuid.uuid4()),
                "type": "paragraph",
                "role": "body",
                "text": blk,
                "page": page,
                "bbox": None,
                "kv_pairs": [],
                "source": {"parser": parser_name or "unknown", "filename": filename or ""},
            })

    page = default_page or 1

    for part in _split_preserving_tables(raw):
        if part["kind"] == "table":
            out.append({
                "element_id": str(_uuid.uuid4()),
                "type": "table",
                "role": "content",
                "text": part["value"],
                "page": page,
                "bbox": None,
                "kv_pairs": [],
                "table_summary": {},
                "source": {"parser": parser_name or "unknown", "filename": filename or ""},
            })
            continue

        blocks = _blocks_from_text(part["value"])
        _append_markdownish_blocks(blocks)

    return out


# ----------------------------
# Models
# ----------------------------

class ParserRequest(BaseModel):
    dag_id: str
    run_id: str
    folder_id: str
    parser_config: Dict[str, Any] = Field(default_factory=dict, alias="ParserConfig")
    model_config = ConfigDict(extra="allow")


class FolderResult(BaseModel):
    folder_id: str
    document_name: Optional[str] = None


class ParserWorkerResult(BaseModel):
    task_id: str
    status: str
    process_name: Optional[str] = None
    job_id: Optional[str] = None
    error_message: Optional[str] = None
    folder_id: Optional[str] = None

    # ✅ IMPORTANT: ensure raw_json is kept
    raw_json: Optional[Dict[str, Any]] = None

    model_config = ConfigDict(extra="allow")


# ----------------------------
# Endpoints
# ----------------------------

@router.post("/parse")
def submit_parse_task(req: ParserRequest):
    session = SessionLocal()
    try:
        cfg = req.parser_config or {}
        parser_name = (cfg.get("ParserName") or cfg.get("parser_name") or cfg.get("name") or "").strip()
        if not parser_name:
            return {"status": "error", "message": "ParserName is required in ParserConfig"}

        parser_key = parser_name.lower()

        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, started_at, job_id, payload
            ) VALUES (
                :id, :process_name, :task_type, :status, now(), :job_id, CAST(:payload AS JSONB)
            )
            """
        )

        MAX_RETRIES = 5
        task_id = None
        for _ in range(MAX_RETRIES):
            candidate = str(uuid.uuid4())
            try:
                session.execute(
                    insert_sql,
                    {
                        "id": candidate,
                        "process_name": req.dag_id,
                        "task_type": "Parse",
                        "status": "submitted",
                        "job_id": req.run_id,
                        "payload": json.dumps(cfg),
                    },
                )
                session.commit()
                task_id = candidate
                break
            except IntegrityError:
                session.rollback()
                continue

        if not task_id:
            return {"status": "error", "message": "Could not allocate unique task id after retries"}

        worker_name = f"{parser_key}_worker.{parser_key}_task".lower()
        queue_name = parser_key.lower()

        session.execute(
            text(
                """
                UPDATE public.task_details
                SET worker_name = :worker_name,
                    queue_name = :queue_name
                WHERE id = :id
                """
            ),
            {"worker_name": worker_name, "queue_name": queue_name, "id": task_id},
        )
        session.commit()

        celery_app.send_task(
            worker_name,
            args=[task_id, req.folder_id, cfg, req.dag_id, req.run_id],
            queue=queue_name,
        )

        return {"task_id": task_id, "status": "submitted"}

    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Parser endpoint error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.post("/worker-results")
def worker_results(body: ParserWorkerResult):
    session = SessionLocal()
    try:
        status_raw = (body.status or "").strip().lower()
        status_norm = "success" if status_raw in ("success", "succeeded", "completed") else (
            "failed" if status_raw in ("error", "failed") else status_raw
        )

        # Build reserved_json including extras
        reserved_json: Dict[str, Any] = body.model_dump(exclude_none=True)

        # Pydantic v2 extra fields (safety)
        try:
            extra = getattr(body, "__pydantic_extra__", None)
            if isinstance(extra, dict):
                reserved_json.update(extra)
        except Exception:
            pass

        # Update DB status + reserved
        upd = text(
            """
            UPDATE public.task_details
            SET status = :st,
                reserved = CAST(:reserved AS JSONB),
                completed_at = now()
            WHERE id = :id
            """
        )
        res = session.execute(
            upd,
            {"id": body.task_id, "st": status_norm or "success", "reserved": json.dumps(reserved_json)},
        )
        session.commit()

        try:
            rowcount = getattr(res, "rowcount", None)
        except Exception:
            rowcount = None
        if rowcount == 0:
            return {"status": "error", "message": f"task_id not found: {body.task_id}"}

        if status_norm != "success":
            return {"status": "ok", "message": "stored failed result"}

        # Determine folder_id effective (for output dir)
        folder_id_eff: Optional[str] = body.folder_id
        if not folder_id_eff:
            try:
                folders = reserved_json.get("folders")
                if isinstance(folders, list):
                    for item in folders:
                        if isinstance(item, dict) and item.get("folder_id"):
                            folder_id_eff = str(item.get("folder_id"))
                            break
                if not folder_id_eff and reserved_json.get("folder_id"):
                    folder_id_eff = str(reserved_json.get("folder_id"))
                if not folder_id_eff and isinstance(reserved_json.get("folder_ids"), list) and reserved_json["folder_ids"]:
                    folder_id_eff = str(reserved_json["folder_ids"][0])
            except Exception:
                folder_id_eff = None

        # Resolve base root + folder path
        base_root: Path = get_shared_path("DATA_BACKBONE_DIR", settings.data_backbone_dir)

        fpath: Optional[Path] = None
        if folder_id_eff:
            fpath = Path(folder_id_eff)
            if not (fpath.is_absolute() or str(fpath).startswith("\\") or str(fpath).startswith("//")):
                fpath = base_root / folder_id_eff

        # Runtime fallback
        if fpath is None or not fpath.exists():
            rt = reserved_json.get("runtime_folder")
            if isinstance(rt, str) and rt.strip():
                fpath = Path(rt)

        # Final fallback
        if fpath is None:
            fpath = base_root

        # Derive parser_name + filename for source info
        worker_row = session.execute(
            text("SELECT worker_name FROM public.task_details WHERE id = :id"),
            {"id": body.task_id},
        ).mappings().first()

        parser_name = None
        if worker_row and worker_row.get("worker_name"):
            wn = str(worker_row.get("worker_name"))
            parser_name = wn.split("_worker", 1)[0].strip().lower()

        filename = None
        try:
            folders = reserved_json.get("folders")
            if isinstance(folders, list) and folders and isinstance(folders[0], dict):
                filename = folders[0].get("document_name")
        except Exception:
            filename = None

        if not filename and isinstance(fpath, Path) and fpath.is_dir():
            try:
                pdfs = [p.name for p in fpath.iterdir() if p.is_file() and p.suffix.lower() == ".pdf"]
                if pdfs:
                    filename = pdfs[0]
            except Exception:
                filename = None

        # Update document_details on success (if columns exist)
        if folder_id_eff:
            cols_info = session.execute(
                text(
                    """
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_schema = 'public' AND table_name = 'document_details'
                    """
                )
            ).mappings().all()
            col_names = {c.get("column_name"): c.get("data_type") for c in cols_info if c.get("column_name")}
            sets = []
            params = {"fid": folder_id_eff}
            if "parsing_status" in col_names:
                sets.append("parsing_status = :ps"); params["ps"] = "success"
            if "last_successful_stage" in col_names:
                sets.append("last_successful_stage = :lss"); params["lss"] = "parser"
            if "updated_at" in col_names:
                dt = (col_names.get("updated_at") or "").lower()
                if "timestamp" in dt:
                    sets.append("updated_at = now()")
                else:
                    sets.append("updated_at = :ua"); params["ua"] = None

            if sets:
                upd_doc = text(f"UPDATE public.document_details SET {', '.join(sets)} WHERE folder_id = :fid")
                session.execute(upd_doc, params)
                session.commit()
            else:
                logger.info("parser worker-results: no matching columns to update in document_details for folder_id=%s", folder_id_eff)
        else:
            logger.info("parser worker-results: folder_id not found in payload; skipping document_details update")

        # ✅ Extract layout from raw_json (handles Paddle, Llama files[].pages[].layout)
        pages = _extract_layout_pages(reserved_json)
        parser_output: List[Dict[str, Any]] = []
        sanitized: List[Dict[str, Any]] = []

        # Fallback helpers for MinerU / text-based outputs
        def _list_txt_files(folder: Path) -> List[Path]:
            try:
                return sorted([p for p in folder.iterdir() if p.is_file() and p.suffix.lower() == ".txt"])
            except Exception:
                return []

        def _file_has_tags(p: Path) -> bool:
            try:
                with open(p, "r", encoding="utf-8", errors="ignore") as fh:
                    sample = fh.read(262_144)
                lowered = sample.lower()
                return any(t in lowered for t in ("<heading", "<paragraph", "<table")) and not lowered.strip().startswith("{")
            except Exception:
                return False

        def _split_layout_txt(text_val: str) -> List[str]:
            import re as _re
            chunks: List[str] = []
            lines = [l.strip() for l in (text_val or "").splitlines() if l.strip()]
            i = 0
            while i < len(lines):
                line = lines[i]
                low = line.lower()
                if low.startswith("<heading") or low.startswith("<paragraph"):
                    chunks.append(line)
                    i += 1
                    continue
                if low.startswith("<table"):
                    buf = [line]
                    open_tables = len(_re.findall(r"<table\\b", low))
                    close_tables = len(_re.findall(r"</table>", low))
                    j = i + 1
                    while j < len(lines) and open_tables > close_tables:
                        t = lines[j]
                        buf.append(t)
                        tl = t.lower()
                        open_tables += len(_re.findall(r"<table\\b", tl))
                        close_tables += len(_re.findall(r"</table>", tl))
                        j += 1
                    chunks.append("\n".join(buf))
                    i = j
                    continue
                chunks.append(line)
                i += 1
            return chunks

        def _normalize_tagged_text_to_parser_output(content: str, parser_name: Optional[str], filename: Optional[str]) -> List[Dict[str, Any]]:
            import re as _re
            out: List[Dict[str, Any]] = []
            seen_first_heading = False
            parts = _split_layout_txt(content)
            for blk in parts:
                bl = blk.lower()
                page_no = None
                # parse attrs
                m_page = _re.search(r"page=\"(\d+)\"", blk)
                if m_page:
                    try:
                        page_no = int(m_page.group(1))
                    except Exception:
                        page_no = None
                if bl.startswith("<heading"):
                    role = "title" if not seen_first_heading and (page_no in (None, 1)) else "section_heading"
                    seen_first_heading = True
                    out.append({
                        "element_id": str(_uuid.uuid4()),
                        "type": "heading",
                        "role": role,
                        "text": _html_to_text(blk),
                        "page": page_no if page_no is not None else 1,
                        "bbox": None,
                        "kv_pairs": [],
                        "source": {"parser": parser_name or "unknown", "filename": filename or ""},
                    })
                elif bl.startswith("<paragraph"):
                    out.append({
                        "element_id": str(_uuid.uuid4()),
                        "type": "paragraph",
                        "role": "body",
                        "text": _html_to_text(blk),
                        "page": page_no if page_no is not None else 1,
                        "bbox": None,
                        "kv_pairs": [],
                        "source": {"parser": parser_name or "unknown", "filename": filename or ""},
                    })
                elif bl.startswith("<table"):
                    html_block = blk.strip()
                    out.append({
                        "element_id": str(_uuid.uuid4()),
                        "type": "table",
                        "role": "body",
                        "text": html_block,
                        "page": page_no if page_no is not None else 1,
                        "bbox": None,
                        "kv_pairs": [],
                        "table_summary": _summarize_table(html_block),
                        "source": {"parser": parser_name or "unknown", "filename": filename or ""},
                    })
                elif blk.strip():
                    out.append({
                        "element_id": str(_uuid.uuid4()),
                        "type": "paragraph",
                        "role": "body",
                        "text": blk.strip(),
                        "page": page_no if page_no is not None else 1,
                        "bbox": None,
                        "kv_pairs": [],
                        "source": {"parser": parser_name or "unknown", "filename": filename or ""},
                    })
            return out

        # 🔁 Direct payloads: prefer 'tagged_text' or 'segments' if present
        tagged_text_payload = reserved_json.get("tagged_text") if isinstance(reserved_json, dict) else None
        segments_payload = reserved_json.get("segments") if isinstance(reserved_json, dict) else None

        def _normalize_segments_to_parser_output(segs: List[Dict[str, Any]], parser_name: Optional[str], filename: Optional[str]) -> List[Dict[str, Any]]:
            out: List[Dict[str, Any]] = []
            seen_title = False
            for seg in segs:
                if not isinstance(seg, dict):
                    continue
                s_type = str(seg.get("type") or seg.get("element_type") or "paragraph").lower()
                pg = seg.get("page") or seg.get("page_number")
                raw = seg.get("text") or seg.get("content") or ""
                html_val = seg.get("html") if isinstance(seg, dict) else None
                bbox = seg.get("bbox") or seg.get("bounding_box")
                if not (isinstance(bbox, list) and len(bbox) == 4):
                    bbox = None
                if s_type in ("title", "heading", "header"):
                    role = "title" if not seen_title and (pg in (None, 1)) else "section_heading"
                    seen_title = True
                    text_val = _html_to_text(f"<heading>{raw}</heading>")
                    item = {
                        "element_id": str(_uuid.uuid4()),
                        "type": "heading",
                        "role": role,
                        "text": text_val,
                        "page": int(pg) if isinstance(pg, int) else (int(pg) if isinstance(pg, str) and pg.isdigit() else None),
                        "bbox": bbox,
                        "kv_pairs": [],
                        "source": {"parser": parser_name or "unknown", "filename": filename or ""},
                    }
                elif s_type == "table" or (isinstance(html_val, str) and "<table" in html_val.lower()):
                    raw_html = str(html_val or raw or "")
                    if "<table" not in raw_html.lower():
                        raw_html = f"<table>{raw_html}</table>"
                    item = {
                        "element_id": str(_uuid.uuid4()),
                        "type": "table",
                        "role": "body",
                        "text": raw_html.strip(),
                        "page": int(pg) if isinstance(pg, int) else (int(pg) if isinstance(pg, str) and pg.isdigit() else None),
                        "bbox": bbox,
                        "kv_pairs": [],
                        "table_summary": _summarize_table(raw_html),
                        "source": {"parser": parser_name or "unknown", "filename": filename or ""},
                    }
                else:
                    text_val = _html_to_text(f"<paragraph>{raw}</paragraph>")
                    item = {
                        "element_id": str(_uuid.uuid4()),
                        "type": "paragraph",
                        "role": "body",
                        "text": text_val,
                        "page": int(pg) if isinstance(pg, int) else (int(pg) if isinstance(pg, str) and pg.isdigit() else None),
                        "bbox": bbox,
                        "kv_pairs": [],
                        "source": {"parser": parser_name or "unknown", "filename": filename or ""},
                    }
                out.append(item)
            return out

        if isinstance(tagged_text_payload, str) and any(t in tagged_text_payload.lower() for t in ("<heading", "<paragraph", "<table")):
            parser_output = _normalize_tagged_text_to_parser_output(tagged_text_payload, parser_name, filename)
            sanitized = _sanitize_parser_output(parser_output)
        elif isinstance(segments_payload, list) and segments_payload:
            parser_output = _normalize_segments_to_parser_output(segments_payload, parser_name, filename)
            sanitized = _sanitize_parser_output(parser_output)
        elif pages:
            # ✅ Normalize directly from layout -> parser_output
            parser_output = _layout_pages_to_parser_output(pages, parser_name, filename)
            sanitized = _sanitize_parser_output(parser_output)
        else:
            # 🔁 MinerU-style fallback: read tagged text or layout.json from folder
            if isinstance(fpath, Path) and fpath.is_dir():
                txts = _list_txt_files(fpath)
                layout_txts = [p for p in txts if p.name.lower().endswith(".layout.txt")]
                chosen_txt: Optional[Path] = layout_txts[0] if layout_txts else None
                if chosen_txt is None:
                    for p in txts:
                        if _file_has_tags(p):
                            chosen_txt = p
                            break
                if chosen_txt:
                    try:
                        with open(chosen_txt, "r", encoding="utf-8", errors="ignore") as fh:
                            content = fh.read()
                        parser_output = _normalize_tagged_text_to_parser_output(content, parser_name, chosen_txt.name)
                        sanitized = _sanitize_parser_output(parser_output)
                    except Exception:
                        sanitized = []
                if not sanitized:
                    # Try layout.json
                    try:
                        lj = [p for p in fpath.iterdir() if p.is_file() and p.suffix.lower() == ".json" and p.name.lower().endswith(".layout.json")]
                        if lj:
                            with open(lj[0], "r", encoding="utf-8", errors="ignore") as fh:
                                data = json.load(fh)
                            # Accept either top-level layout or pages[].layout
                            lpages = []
                            if isinstance(data, dict) and isinstance(data.get("layout"), list):
                                lpages = [{"page_number": 1, "layout": data["layout"]}]
                            elif isinstance(data, dict) and isinstance(data.get("pages"), list):
                                for p in data["pages"]:
                                    if isinstance(p, dict) and isinstance(p.get("layout"), list):
                                        lpages.append({"page_number": p.get("page_number") or 1, "layout": p["layout"]})
                            if lpages:
                                parser_output = _layout_pages_to_parser_output(lpages, parser_name, filename)
                                sanitized = _sanitize_parser_output(parser_output)
                    except Exception:
                        sanitized = []

        # ---- FINAL FALLBACK: pure plain text normalisation (incl. Llama JSON) ----
        if not sanitized:
            plain_text_val: Optional[str] = None

            # 1) Look for 'plain_text' / 'text' / 'content' in reserved_json (in case worker posted it)
            if isinstance(reserved_json, dict):
                for key in ("plain_text", "text", "content"):
                    v = reserved_json.get(key)
                    if isinstance(v, str) and v.strip():
                        plain_text_val = v
                        break

            # 1b) If worker stored Llama-like JSON in raw_json, use pages[].md/text or files[].pages[].md/text.
            # Accept nested wrappers (result/data/payload) and list-shaped raw_json as well.
            if plain_text_val is None and isinstance(reserved_json, dict):
                raw: Any = reserved_json.get("raw_json")
                if isinstance(raw, str):
                    try:
                        raw = json.loads(raw)
                    except Exception:
                        raw = None

                def _collect_text_from_pages(pages_obj: Any) -> List[str]:
                    parts_local: List[str] = []
                    if isinstance(pages_obj, list):
                        for pg in pages_obj:
                            if not isinstance(pg, dict):
                                continue
                            val = pg.get("md") or pg.get("text")
                            if isinstance(val, str) and val.strip():
                                pn = pg.get("page") or pg.get("page_number")
                                if isinstance(pn, int) and pn > 0:
                                    parts_local.append(f"\n\n<<<PAGE:{pn}>>>\n\n{val.strip()}")
                                elif isinstance(pn, str) and pn.isdigit() and int(pn) > 0:
                                    parts_local.append(f"\n\n<<<PAGE:{int(pn)}>>>\n\n{val.strip()}")
                                else:
                                    parts_local.append(val.strip())
                    return parts_local

                def _unwrap_possible_container(obj: Any) -> Any:
                    if isinstance(obj, dict):
                        for key in ("result", "data", "payload"):
                            inner = obj.get(key)
                            if isinstance(inner, (dict, list)):
                                return inner
                    return obj

                raw_unwrapped = _unwrap_possible_container(raw)

                parts: List[str] = []
                if isinstance(raw_unwrapped, dict):
                    # Top-level pages
                    parts.extend(_collect_text_from_pages(raw_unwrapped.get("pages")))
                    # Llama-style files[].pages
                    files_raw = raw_unwrapped.get("files")
                    if isinstance(files_raw, list):
                        for f_raw in files_raw:
                            if not isinstance(f_raw, dict):
                                continue
                            parts.extend(_collect_text_from_pages(f_raw.get("pages")))
                elif isinstance(raw_unwrapped, list):
                    # Sometimes raw_json is a list of file objects
                    for item in raw_unwrapped:
                        if not isinstance(item, dict):
                            continue
                        parts.extend(_collect_text_from_pages(item.get("pages")))
                        files_raw = item.get("files")
                        if isinstance(files_raw, list):
                            for f_raw in files_raw:
                                if not isinstance(f_raw, dict):
                                    continue
                                parts.extend(_collect_text_from_pages(f_raw.get("pages")))

                if parts:
                    plain_text_val = "\n\n".join(parts)

            # If plain_text_val contains explicit page markers, split and normalize per-page
            if plain_text_val and "<<<PAGE:" in plain_text_val:
                try:
                    chunks = re.split(r"\n\s*<<<PAGE:(\d+)>>>\s*\n", "\n" + plain_text_val)
                    # chunks: [prefix, pageNo1, text1, pageNo2, text2, ...]
                    combined: List[Dict[str, Any]] = []
                    if len(chunks) >= 3:
                        it = iter(chunks[1:])
                        for page_s, txt in zip(it, it):
                            if isinstance(page_s, str) and page_s.isdigit():
                                pn = int(page_s)
                            else:
                                pn = 1
                            if isinstance(txt, str) and txt.strip():
                                combined.extend(_plain_text_to_parser_output(txt, parser_name, filename, default_page=pn))
                        if combined:
                            sanitized = _sanitize_parser_output(combined)
                except Exception:
                    pass

            # 2) If not found, read any .txt file in the folder (even without tags)
            if plain_text_val is None and isinstance(fpath, Path) and fpath.is_dir():
                try:
                    txts_all = [p for p in fpath.iterdir() if p.is_file() and p.suffix.lower() == ".txt"]
                    if txts_all:
                        # Prefer a file that is NOT .layout.txt
                        chosen_plain_txt = None
                        for p in txts_all:
                            if not p.name.lower().endswith(".layout.txt"):
                                chosen_plain_txt = p
                                break
                        if chosen_plain_txt is None:
                            chosen_plain_txt = txts_all[0]

                        with open(chosen_plain_txt, "r", encoding="utf-8", errors="ignore") as fh:
                            plain_text_val = fh.read()
                except Exception:
                    plain_text_val = None

            # 2b) If still nothing, look for a Llama-style JSON file in the folder
            if plain_text_val is None and isinstance(fpath, Path) and fpath.is_dir():
                try:
                    json_files = [
                        p for p in fpath.iterdir()
                        if p.is_file() and p.suffix.lower() == ".json"
                    ]
                    for jp in json_files:
                        with open(jp, "r", encoding="utf-8", errors="ignore") as fh:
                            data = json.load(fh)
                        if not isinstance(data, dict):
                            continue

                        def _collect_text_from_data(d: Dict[str, Any]) -> List[str]:
                            collected: List[str] = []
                            # direct pages
                            collected.extend(_collect_text_from_pages(d.get("pages")))
                            # files[].pages
                            files_in = d.get("files")
                            if isinstance(files_in, list):
                                for f_in in files_in:
                                    if not isinstance(f_in, dict):
                                        continue
                                    collected.extend(_collect_text_from_pages(f_in.get("pages")))
                            return collected

                        parts = _collect_text_from_data(data)
                        if parts:
                            plain_text_val = "\n\n".join(parts)
                            break
                except Exception:
                    pass

            # 3) If we have any plain text, normalize it
            if plain_text_val:
                parser_output = _plain_text_to_parser_output(
                    plain_text_val,
                    parser_name,
                    filename,
                )
                sanitized = _sanitize_parser_output(parser_output)

        # If after all attempts, still nothing, log error and exit
        if not sanitized:
            reserved_json["normalized_write_error"] = "No layout or text extracted from raw_json or files"
            session.execute(
                text("UPDATE public.task_details SET reserved = CAST(:reserved AS JSONB) WHERE id = :id"),
                {"id": body.task_id, "reserved": json.dumps(reserved_json)},
            )
            session.commit()
            return {"status": "ok", "normalized_parser_output_file": None, "note": "no layout or text extracted"}

        preferred_pdf_name: Optional[str] = None
        pdf_file_val = reserved_json.get("pdf_file")
        if isinstance(pdf_file_val, str) and pdf_file_val.lower().endswith(".pdf"):
            preferred_pdf_name = Path(pdf_file_val).name
        if not preferred_pdf_name and isinstance(filename, str) and filename.lower().endswith(".pdf"):
            preferred_pdf_name = filename

        base_name = preferred_pdf_name or filename or (fpath.name if isinstance(fpath, Path) else "document")
        base_stem = Path(base_name).stem

        out_dir = fpath if (isinstance(fpath, Path) and fpath.is_dir()) else base_root
        _ensure_dir(out_dir)

        out_path = out_dir / f"{base_stem}.parser_output.json"
        with open(out_path, "w", encoding="utf-8") as oh:
            json.dump({"parser_output": sanitized}, oh, ensure_ascii=False, indent=2)

        reserved_json["normalized_parser_output_file"] = str(out_path)

        session.execute(
            text("UPDATE public.task_details SET reserved = CAST(:reserved AS JSONB) WHERE id = :id"),
            {"id": body.task_id, "reserved": json.dumps(reserved_json)},
        )
        session.commit()

        return {"status": "ok", "normalized_parser_output_file": str(out_path)}

    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Parser worker-results error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.get("/status/{task_id}")
def get_parse_status(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text("SELECT id, status, reserved FROM public.task_details WHERE id = :id"),
            {"id": task_id},
        ).mappings().first()

        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        status = (row.get("status") or "").strip().lower() or "pending"
        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        folder_ids: List[str] = []
        reserved_val = row.get("reserved")

        try:
            data = reserved_val if isinstance(reserved_val, dict) else json.loads(reserved_val)  # type: ignore
        except Exception:
            data = None

        if isinstance(data, dict):
            folders = data.get("folders")
            if isinstance(folders, list):
                folder_ids = [str(it.get("folder_id")) for it in folders if isinstance(it, dict) and it.get("folder_id")]
            if not folder_ids and data.get("folder_id"):
                folder_ids = [str(data.get("folder_id"))]

        return {"task_id": task_id, "status": "success", "folder_ids": folder_ids or []}

    except Exception as e:  # noqa: BLE001
        logger.error(f"Parser status error: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e), "folder_ids": []}
    finally:
        session.close()


@router.post("/runtime-parse")
def runtime_parse(
    file: UploadFile = File(...),
    parser_profile: str = Form(...),
):
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT profile_config
                FROM public.profiles
                WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
                  AND LOWER(TRIM(step_type)) = LOWER(TRIM('Parser'))
                LIMIT 1
                """
            ),
            {"name": parser_profile},
        ).first()
        if not row:
            return {"status": "error", "message": f"Parser profile not found: {parser_profile}"}

        raw_cfg = row[0]
        cfg: Dict[str, Any] = {}
        try:
            if isinstance(raw_cfg, dict):
                cfg = raw_cfg
            elif isinstance(raw_cfg, (bytes, bytearray, memoryview)):
                cfg = json.loads(bytes(raw_cfg).decode("utf-8"))
            elif isinstance(raw_cfg, str):
                cfg = json.loads(raw_cfg)
        except Exception as je:  # noqa: BLE001
            return {"status": "error", "message": f"Invalid profile config JSON: {je}"}

        parser_name = (cfg.get("ParserName") or cfg.get("parser_name") or cfg.get("name") or "").strip()
        if not parser_name:
            return {"status": "error", "message": "ParserName is required in profile config"}

        parser_key = parser_name.lower()
        worker_name = f"{parser_key}_worker.{parser_key}_task"
        queue_name = f"runtime_{parser_key}"

        base_root: Path = get_shared_path("DATA_BACKBONE_DIR", settings.data_backbone_dir)
        if not base_root.exists() or not base_root.is_dir():
            return {"status": "error", "message": f"DataBackBone not accessible: {base_root}"}

        task_id = str(uuid.uuid4())
        folder_id = str(uuid.uuid4())
        folder_name = f"Runtime_{folder_id}"

        runtime_dir: Path = base_root / folder_name
        runtime_dir.mkdir(parents=True, exist_ok=True)

        safe_name = os.path.basename(file.filename) if file.filename else f"upload_{task_id}"
        file_path: Path = runtime_dir / safe_name
        file.file.seek(0)
        with open(file_path, "wb") as out_f:
            shutil.copyfileobj(file.file, out_f)

        session.execute(
            text(
                """
                INSERT INTO public.task_details (
                    id, process_name, task_type, status, worker_name, queue_name, started_at, job_id, payload
                ) VALUES (
                    :id, :process_name, :task_type, :status, :worker_name, :queue_name, now(), :job_id, CAST(:payload AS JSONB)
                )
                """
            ),
            {
                "id": task_id,
                "process_name": "TestParserProfile",
                "task_type": "Parse",
                "status": TaskStatus.SUBMITTED.value if hasattr(TaskStatus, "SUBMITTED") else "submitted",
                "worker_name": worker_name,
                "queue_name": queue_name,
                "job_id": "RuntimeTesting",
                "payload": json.dumps(cfg),
            },
        )
        session.commit()

        reserved_payload = {
            "runtime_folder": str(runtime_dir),
            "pdf_file": str(file_path) if file_path.suffix.lower() == ".pdf" else None,
        }
        session.execute(
            text("UPDATE public.task_details SET reserved = CAST(:reserved AS JSONB) WHERE id = :id"),
            {"id": task_id, "reserved": json.dumps(reserved_payload)},
        )
        session.commit()

        celery_app.send_task(
            worker_name,
            args=[task_id, str(runtime_dir), cfg, "RuntimeTesting", "RuntimeTesting"],
            queue=queue_name,
        )

        return {"task_id": task_id, "status": "submitted", "runtime_folder": str(runtime_dir)}

    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Runtime parse endpoint error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.get("/runtime_status/{task_id}")
def get_runtime_status(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text("SELECT id, status, reserved FROM public.task_details WHERE id = :id"),
            {"id": task_id},
        ).mappings().first()

        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "parser_output": []}

        status = (row.get("status") or "").strip().lower() or "pending"
        
        if status in ("failed", "error", "revoked"):
            reserved_val = row.get("reserved")
            msg = "Task failed."
            try:
                data = reserved_val if isinstance(reserved_val, dict) else json.loads(reserved_val)
                if isinstance(data, dict):
                     msg = data.get("message") or data.get("error") or msg
            except Exception:
                pass
            return {"task_id": task_id, "status": "failed", "message": msg, "parser_output": []}

        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "parser_output": []}

        reserved_val = row.get("reserved")
        try:
            data = reserved_val if isinstance(reserved_val, dict) else json.loads(reserved_val)  # type: ignore
        except Exception:
            data = None

        parser_output: List[Dict[str, Any]] = []
        if isinstance(data, dict):
            out_file = data.get("normalized_parser_output_file")
            if isinstance(out_file, str) and out_file and Path(out_file).is_file():
                with open(out_file, "r", encoding="utf-8", errors="ignore") as fh:
                    obj = json.load(fh)
                if isinstance(obj, dict) and isinstance(obj.get("parser_output"), list):
                    parser_output = obj["parser_output"]

        return {"task_id": task_id, "status": "success", "parser_output": parser_output}

    except Exception as e:  # noqa: BLE001
        logger.error(f"Runtime status check failed: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e), "parser_output": []}
    finally:
        session.close()


@router.get("/debug_reserved/{task_id}")
def get_debug_reserved(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text("SELECT id, status, reserved FROM public.task_details WHERE id = :id"),
            {"id": task_id},
        ).mappings().first()

        if not row:
            return {"task_id": task_id, "status": "not-found"}

        reserved_val = row.get("reserved")
        try:
            data = reserved_val if isinstance(reserved_val, dict) else json.loads(reserved_val)  # type: ignore
        except Exception:
            data = None

        return {
            "task_id": row.get("id"),
            "status": row.get("status"),
            "reserved": data,
            "normalized_parser_output_file": (data or {}).get("normalized_parser_output_file") if isinstance(data, dict) else None,
            "normalized_write_error": (data or {}).get("normalized_write_error") if isinstance(data, dict) else None,
        }

    except Exception as e:  # noqa: BLE001
        logger.error(f"Debug reserved fetch failed: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e)}
    finally:
        session.close()
