from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
import requests
import logging
from database import get_async_session
from config import settings
from airflow_token import get_airflow_token  # NEW
from datetime import datetime, timezone, timedelta

router = APIRouter(prefix="/metrics", tags=["Metrics"])

@router.get("/logs/count")
async def get_total_api_calls(session: AsyncSession = Depends(get_async_session)):
    result = await session.execute(text("SELECT COUNT(*) FROM search_api_logs"))
    total = result.scalar()
    return {"total_api_calls": total}

@router.get("/vectorized-documents/count")
async def vectorized_documents_count(session: AsyncSession = Depends(get_async_session)):
    # Count documents that have completed export successfully
    result = await session.execute(
        text("SELECT COUNT(*) FROM public.document_details WHERE export_status = 'success'")
    )
    total = result.scalar() or 0
    return {"total_vectorized_documents": total}

# @router.get("/active-pipelines/count")
# async def active_pipelines_count(session: AsyncSession = Depends(get_async_session)):
#     result = await session.execute(text("SELECT COUNT(*) FROM vectorized_documents where status != 'success'"))
#     total = result.scalar()
#     return {"total_vectorized_documents": total}


@router.get("/api/bi")
async def get_business_intelligence(session: AsyncSession = Depends(get_async_session)):
    """
    Get business intelligence metrics for search APIs.

    Returns:
        - average_response_time_ms: Average response time in milliseconds
        - average_top_result_score: Average top result score
        - recent_queries: List of recent queries with metadata
        - keyword_cloud: Dictionary of keywords and their frequencies
    """
    try:
        # Get average response time and top result score
        metrics_query = text("""
            SELECT
                AVG(response_time_ms) as avg_response_time,
                AVG(top_result_score) as avg_top_result_score,
                COUNT(*) as total_queries
            FROM search_api_logs
            
        """)

        metrics_result = await session.execute(metrics_query)
        metrics_row = metrics_result.first()

        # Get recent queries (last 50)
        recent_queries_query = text("""
            SELECT
                api_name,
                query_text,
                response_time_ms,
                top_result_score,
                num_results,
                called_at,
                is_success
            FROM search_api_logs
            ORDER BY called_at DESC
            LIMIT 50
        """)

        recent_result = await session.execute(recent_queries_query)
        # Return recent queries as a table-friendly payload: columns + rows
        recent_columns = [
            "api_name",
            "query_text",
            "response_time_ms",
            "top_result_score",
            "num_results",
            "called_at",
            "is_success",
        ]

        recent_rows = []
        recent_count = 0
        for row in recent_result:
            recent_count += 1
            recent_rows.append([
                row.api_name,
                row.query_text,
                float(row.response_time_ms) if row.response_time_ms is not None else None,
                float(row.top_result_score) if row.top_result_score is not None else None,
                int(row.num_results) if row.num_results is not None else None,
                (row.called_at.isoformat() if row.called_at else None),
                bool(row.is_success) if row.is_success is not None else None,
            ])

        recent_queries = {
            "columns": recent_columns,
            "rows": recent_rows,
            "total": recent_count,
        }

        # Generate keyword cloud from query_text
        # Split queries into words, count frequencies
        keyword_query = text("""
            SELECT query_text
            FROM search_api_logs
            WHERE query_text IS NOT NULL
            AND LENGTH(query_text) > 0
            ORDER BY called_at DESC
            LIMIT 1000
        """)

        keyword_result = await session.execute(keyword_query)
        keyword_counts = {}

        for row in keyword_result:
            if row.query_text:
                # Simple tokenization: split by spaces and filter common words
                words = row.query_text.lower().split()
                stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'what', 'when', 'where', 'how', 'why', 'who', 'which'}

                for word in words:
                    # Clean word: remove punctuation and filter
                    clean_word = ''.join(c for c in word if c.isalnum())
                    if len(clean_word) > 2 and clean_word not in stop_words:
                        keyword_counts[clean_word] = keyword_counts.get(clean_word, 0) + 1

        # Sort keywords by frequency and take top 50, then convert to list suitable for a word-cloud
        sorted_keywords = sorted(keyword_counts.items(), key=lambda x: x[1], reverse=True)[:50]
        if sorted_keywords:
            max_count = sorted_keywords[0][1]
        else:
            max_count = 1

        # word cloud items: { text, count, weight } where weight is 1..100 for frontend sizing
        keyword_cloud = [
            {
                "text": word,
                "count": count,
                "weight": int((count / max_count) * 100) if max_count > 0 else 0,
            }
            for word, count in sorted_keywords
        ]

        # Time-series aggregates for average response time (and top score)
        # Hourly buckets for the last 24 hours
        hourly_query = text("""
            SELECT date_trunc('hour', called_at) AS bucket,
                   AVG(response_time_ms) as avg_response_time,
                   AVG(top_result_score) as avg_top_result_score,
                   COUNT(*) as total_queries
            FROM search_api_logs
            WHERE called_at >= NOW() - interval '24 hours'
            GROUP BY bucket
            ORDER BY bucket ASC
        """)
        hourly_result = await session.execute(hourly_query)
        # Build a map from bucket (UTC datetime) -> row for easy lookups
        hourly_map = {}
        for row in hourly_result:
            if row.bucket is None:
                continue
            b = row.bucket
            # normalize to UTC-aware datetime
            if b.tzinfo is None:
                b = b.replace(tzinfo=timezone.utc)
            else:
                b = b.astimezone(timezone.utc)
            # ensure bucket minutes/seconds are zero (date_trunc should have done this)
            b = b.replace(minute=0, second=0, microsecond=0)
            hourly_map[b] = row

        # Generate contiguous hourly buckets (last 24 hours) so frontend gets a continuous line
        end_hour = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
        start_hour = end_hour - timedelta(hours=23)
        hourly_series = []
        cur = start_hour
        while cur <= end_hour:
            row = hourly_map.get(cur)
            hourly_series.append({
                "timestamp": cur.isoformat(),
                "average_response_time_ms": float(row.avg_response_time) if (row and row.avg_response_time is not None) else 0.0,
                "average_top_result_score": float(row.avg_top_result_score) if (row and row.avg_top_result_score is not None) else 0.0,
                "total_queries": int(row.total_queries or 0) if row else 0,
            })
            cur = cur + timedelta(hours=1)

        # Daily buckets for the last 30 days
        daily_query = text("""
            SELECT date_trunc('day', called_at) AS bucket,
                   AVG(response_time_ms) as avg_response_time,
                   AVG(top_result_score) as avg_top_result_score,
                   COUNT(*) as total_queries
            FROM search_api_logs
            WHERE called_at >= NOW() - interval '30 days'
            GROUP BY bucket
            ORDER BY bucket ASC
        """)
        daily_result = await session.execute(daily_query)
        # Map daily buckets to rows
        daily_map = {}
        for row in daily_result:
            if row.bucket is None:
                continue
            b = row.bucket
            if b.tzinfo is None:
                b = b.replace(tzinfo=timezone.utc)
            else:
                b = b.astimezone(timezone.utc)
            b = b.replace(hour=0, minute=0, second=0, microsecond=0)
            daily_map[b] = row

        # Generate contiguous daily buckets (last 30 days)
        end_day = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        start_day = end_day - timedelta(days=29)
        daily_series = []
        cur_day = start_day
        while cur_day <= end_day:
            row = daily_map.get(cur_day)
            daily_series.append({
                "timestamp": cur_day.isoformat(),
                "average_response_time_ms": float(row.avg_response_time) if (row and row.avg_response_time is not None) else 0.0,
                "average_top_result_score": float(row.avg_top_result_score) if (row and row.avg_top_result_score is not None) else 0.0,
                "total_queries": int(row.total_queries or 0) if row else 0,
            })
            cur_day = cur_day + timedelta(days=1)

        # Peak usage per hour (distribution by hour-of-day over entire log history, counting all queries)
        hourly_of_day_query = text("""
            SELECT EXTRACT(HOUR FROM called_at) AS hour_of_day,
                   COUNT(*) AS total_queries
            FROM search_api_logs
            GROUP BY hour_of_day
            ORDER BY hour_of_day ASC
        """)
        hod_result = await session.execute(hourly_of_day_query)
        hour_distribution = []  # [ { hour: 0-23, total_queries: int, percentage: float, window: "HH:00–HH+1:00" } ]
        total_hod_queries = 0
        for row in hod_result:
            total_hod_queries += int(row.total_queries or 0)
            h = int(row.hour_of_day)
            window_label = f"{h:02d}:00–{((h + 1) % 24):02d}:00"
            hour_distribution.append({
                "hour": h,
                "total_queries": int(row.total_queries or 0),
                "window": window_label,
            })

        # Compute percentage and peak hour
        peak_hour = None
        peak_count = 0
        for item in hour_distribution:
            count = item["total_queries"]
            if count > peak_count:
                peak_count = count
                peak_hour = item["hour"]
        for item in hour_distribution:
            if total_hod_queries > 0:
                item["percentage"] = round((item["total_queries"] / total_hod_queries) * 100.0, 2)
            else:
                item["percentage"] = 0.0

        # Determine the single busiest hour bucket across the entire history (to include date with peak window)
        peak_window_bucket_ts = None
        peak_window_label = None
        try:
            peak_window_query = text("""
                SELECT date_trunc('hour', called_at) AS hour_bucket,
                       COUNT(*) AS total_queries
                FROM search_api_logs
                GROUP BY hour_bucket
                ORDER BY total_queries DESC
                LIMIT 1
            """)
            pw_res = await session.execute(peak_window_query)
            pw_row = pw_res.first()
            if pw_row and pw_row.hour_bucket is not None:
                b = pw_row.hour_bucket
                # Normalize to UTC aware
                if b.tzinfo is None:
                    b = b.replace(tzinfo=timezone.utc)
                else:
                    b = b.astimezone(timezone.utc)
                peak_window_bucket_ts = b.isoformat()
                # Build window label with date
                start_h = b.hour
                end_h = (start_h + 1) % 24
                peak_window_label = f"{b.date().isoformat()} {start_h:02d}:00–{end_h:02d}:00 UTC"
        except Exception:
            # Non-fatal; omit if aggregation fails
            peak_window_bucket_ts = None
            peak_window_label = None

        # Most active API (by total calls across entire log history)
        most_active_query = text("""
            SELECT api_name, COUNT(*) AS total_calls
            FROM search_api_logs
            GROUP BY api_name
            ORDER BY total_calls DESC
            LIMIT 1
        """)
        most_active_result = await session.execute(most_active_query)
        most_active_row = most_active_result.first()
        most_active_api = {
            "api_name": most_active_row.api_name if most_active_row and most_active_row.api_name is not None else None,
            "total_calls": int(most_active_row.total_calls or 0) if most_active_row else 0,
        }

        return {
            "average_response_time_ms": float(metrics_row.avg_response_time) if metrics_row.avg_response_time else 0,
            "average_top_result_score": float(metrics_row.avg_top_result_score) if metrics_row.avg_top_result_score else 0,
            "total_queries_analyzed": metrics_row.total_queries or 0,
            "recent_queries": recent_queries,
            "keyword_cloud": keyword_cloud,
            "time_series": {
                "hourly": hourly_series,
                "daily": daily_series,
            },
            "usage": {
                "hour_of_day_distribution": hour_distribution,
                "peak_hour": peak_hour,
                "peak_hour_window": (f"{peak_hour:02d}:00–{((peak_hour + 1) % 24):02d}:00" if peak_hour is not None else None),
                "peak_window_timestamp": peak_window_bucket_ts,
                "peak_window_label": peak_window_label,
                "peak_hour_total_queries": peak_count,
                "distribution_total_queries": total_hod_queries,
                "most_active_api": most_active_api,
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }

    except Exception as e:
        logging.error(f"Failed to generate BI metrics: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "error": "Failed to generate business intelligence metrics",
                "details": str(e)
            }
        )

@router.get("/documentvectorized")
async def document_vectorized_metrics(session: AsyncSession = Depends(get_async_session)):
    """Document vectorization / pipeline quality metrics.

    Implements exact requested queries:
    1. Success Rate (%)
       SELECT 100 * SUM(CASE WHEN export_status='success' THEN 1 ELSE 0 END)/COUNT(*) FROM document_details;
       (End-to-end pipeline reliability based on export_status.)

    2. Failure Rate per Stage
       SELECT parsing_status, COUNT(*) FROM document_details WHERE parsing_status!='success' GROUP BY parsing_status;
       (Similarly for other stages: chunking_status, embedding_status, export_status, etc. if present.)

    3. Documents per Process
       SELECT process_name, COUNT(*) FROM document_details GROUP BY process_name;

    4. Average Chunks per Document
       SELECT AVG(cnt) FROM (SELECT COUNT(*) AS cnt FROM document_chunk GROUP BY doc_id) t;
    """
    try:
        # 1. Success Rate (%) based on export_status success vs total
        success_rate_row = await session.execute(text("""
            SELECT 100 * SUM(CASE WHEN export_status='success' THEN 1 ELSE 0 END)/NULLIF(COUNT(*),0)
            FROM public.document_details
        """))
        success_rate = float(success_rate_row.scalar() or 0.0)

        # 2. Failure Rate per Stage (parsing, chunking, embedding, export, etc.)
        # We will attempt these status columns if they exist. Query non-success rows grouped by status value.
        stage_columns = ['parsing_status','chunking_status','embedding_status','export_status']
        failure_rates_per_stage = {}
        for col in stage_columns:
            rows = await session.execute(text(f"""
                SELECT {col} AS status_value, COUNT(*) AS total
                FROM public.document_details
                WHERE {col} IS NOT NULL AND {col}!='success'
                GROUP BY {col}
            """))
            stage_fail_list = []
            for r in rows:
                stage_fail_list.append({'status': r.status_value, 'count': int(r.total or 0)})
            # Only include if we got data
            if stage_fail_list:
                failure_rates_per_stage[col.replace('_status','')] = stage_fail_list

        # 3. Documents per Process
        docs_per_process_rows = await session.execute(text("""
            SELECT process_name, COUNT(*) AS total
            FROM public.document_details
            GROUP BY process_name
            ORDER BY total DESC
        """))
        documents_per_process = [
            {'process_name': r.process_name, 'total_documents': int(r.total or 0)}
            for r in docs_per_process_rows
        ]

        # 4. Average Chunks per Document using document_chunk table
        avg_chunks_row = await session.execute(text("""
            SELECT AVG(cnt) FROM (
                SELECT COUNT(*) AS cnt FROM public.document_chunk GROUP BY doc_id
            ) t
        """))
        average_chunks_per_document = float(avg_chunks_row.scalar() or 0.0)

        total_docs_row = await session.execute(text("SELECT COUNT(*) FROM public.document_details WHERE export_status = 'success'"))
        total_documents = int(total_docs_row.scalar() or 0)

        return {
            'success_rate_percent': round(success_rate, 2),
            'failure_rate_per_stage': failure_rates_per_stage,
            'documents_per_process': documents_per_process,
            'average_chunks_per_document': round(average_chunks_per_document, 2),
            'total_documents': total_documents,
            'generated_at': datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:  # noqa: BLE001
        logging.error(f"Failed to generate document vectorization metrics: {e}")
        return JSONResponse(status_code=500, content={'error': 'Failed to generate document vectorization metrics', 'details': str(e)})
