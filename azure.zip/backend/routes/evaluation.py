import os
import hashlib
import json
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from sqlalchemy import text
from celery import Celery

from database import SessionLocal
from config import settings
from utils.path_utils import get_shared_path

router = APIRouter(prefix="/search-api/evaluation", tags=["SearchAPI Evaluation"])

logger = logging.getLogger("evaluation_api")

celery_app = Celery(broker=settings.celery_broker_url)


ACCURACY_BANDS = [
    (0.9, "Excellent"),
    (0.8, "Good"),
    (0.7, "Needs tuning"),
    (0.0, "Weak"),
]

BASELINE_HISTORY_LIMIT = 10
DEFAULT_GATE_K = 5


def _safe_json_loads(value: Any) -> Optional[Any]:
    if value is None:
        return None
    if isinstance(value, (dict, list)):
        return value
    if isinstance(value, (bytes, bytearray)):
        value = value.decode("utf-8", errors="ignore")
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return None
        try:
            return json.loads(value)
        except Exception:
            logger.debug("Failed to parse JSON payload", exc_info=True)
            return None
    return None


def _accuracy_label(value: Optional[float]) -> str:
    if value is None:
        return "Unknown"
    for threshold, label in ACCURACY_BANDS:
        if value >= threshold:
            return label
    return "Unknown"


# ---- Low-level DB helpers for evaluation runs ----


def _now_utc() -> datetime:
    return datetime.utcnow()


def _generate_run_id() -> str:
    date_str = datetime.utcnow().strftime("%Y%m%d")
    random_suffix = uuid.uuid4().hex[:4].upper()
    return f"EVAL-{date_str}-{random_suffix}"


def _resolve_data_backbone_dir() -> str:
    resolved = get_shared_path("DATA_BACKBONE_DIR", settings.data_backbone_dir or "")
    if not str(resolved):
        raise ValueError("DATA_BACKBONE_DIR is not configured")
    return str(resolved)


def _evaluation_run_folder(run_id: str) -> str:
    data_backbone_dir = _resolve_data_backbone_dir()
    return os.path.join(data_backbone_dir, f"evaluation_run_{run_id}")

def start_evaluation_run_impl(
    *,
    search_api_name: str,
    dataset: List[Dict[str, Any]],
    file_hash: Optional[str] = None,
    evaluation_type: str = "vector similarity",
) -> str:
    """Create a new evaluation_run row and enqueue task.

    Dataset format (per item):
      {
        "question": str,
        "reference_answer": Optional[str],
                "expected_chunks": Optional[List[str]],
        "expected_documents": Optional[List[str]],
      }
    """
    if not dataset:
        raise ValueError("dataset cannot be empty")

    run_id = _generate_run_id()
    total_queries = len(dataset)

    # Normalize evaluation type
    framework_val = evaluation_type.strip()
    if not framework_val:
        framework_val = "vector similarity"

    if framework_val not in ("vector similarity", "LLM as a judge"):
        pass

    session = SessionLocal()
    try:
        # Resolve and validate target Search API: always use the active version
        row = session.execute(
            text(
                """SELECT id, name, version, config_json
                       FROM search_api
                      WHERE name = :name AND is_active = TRUE
                   ORDER BY version DESC
                      LIMIT 1"""
            ),
            {"name": search_api_name},
        ).mappings().first()
        if not row:
            raise ValueError(
                f"Active search API '{search_api_name}' not found; cannot start evaluation run"
            )
        api_definition_id = row["id"]
        api_name = row["name"]
        resolved_version = row["version"]
        raw_snapshot = row.get("config_json")
        if isinstance(raw_snapshot, (dict, list)):
            api_snapshot = json.dumps(raw_snapshot)
        else:
            api_snapshot = raw_snapshot or "{}"

        # Insert run row, aligned with evaluation_run schema
        session.execute(
            text(
                """INSERT INTO evaluation_run (
                        run_id,
                        framework,
                        dataset_name,
                        dataset_id,
                        api_definition_id,
                        api_name,
                        api_version,
                        api_snapshot,
                        status,
                        total_questions,
                        successful_queries,
                        failed_queries,
                        aggregated_metrics,
                        started_at,
                        completed_at,
                        created_at,
                        updated_at
                    ) VALUES (
                        :run_id,
                        :framework,
                        :dataset_name,
                        :dataset_id,
                        :api_definition_id,
                        :api_name,
                        :api_version,
                        :api_snapshot,
                        'PENDING',
                        :total_questions,
                        0,
                        0,
                        NULL,
                        NULL,
                        NULL,
                        :now,
                        :now
                    )"""
            ),
            {
                "run_id": run_id,
                "framework": framework_val,
                "dataset_name": file_hash,
                "dataset_id": None,
                "api_definition_id": str(api_definition_id),
                "api_name": api_name,
                "api_version": resolved_version,
                "api_snapshot": api_snapshot,
                "total_questions": total_queries,
                "now": _now_utc(),
            },
        )

        # Prepare DataBackBone folder and dataset.json
        dataset_folder = _evaluation_run_folder(run_id)
        os.makedirs(dataset_folder, exist_ok=True)
        dataset_path = os.path.join(dataset_folder, "dataset.json")

        # Inject query_id into each item and ensure expected_chunks is preserved
        for item in dataset:
            item["query_id"] = str(uuid.uuid4())
            # Ensure expected_chunks is populated if expected_chunk_text is present
            if "expected_chunk_text" in item and "expected_chunks" not in item:
                item["expected_chunks"] = item["expected_chunk_text"]
            # Ensure expected_documents is populated if document_name is present
            if "document_name" in item and "expected_documents" not in item:
                item["expected_documents"] = item["document_name"]

        with open(dataset_path, "w", encoding="utf-8") as f:
            json.dump(dataset, f, indent=2)

        session.commit()
        logger.info("Created evaluation_run %s with %d queries", run_id, total_queries)

        # Enqueue task to RabbitMQ
        celery_app.send_task(
            "evaluate_api_task",
            kwargs={
                "run_id": run_id,
                "api_name": api_name,
                "api_version": resolved_version,
                "eval_config": raw_snapshot,
                "evaluation_type": framework_val,
                "dataset_folder": dataset_folder
            },
            queue="evaluation"
        )

        return run_id
    except Exception:
        session.rollback()
        logger.exception("Failed to start evaluation run")
        raise
    finally:
        session.close()



def get_evaluation_run_impl(run_id: str) -> Optional[Dict[str, Any]]:
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """SELECT run_id,
                           api_name AS search_api_name,
                           api_version AS search_api_version,
                           dataset_name AS file_hash,
                           framework AS type,
                           total_questions AS total_queries,
                           successful_queries AS completed_queries,
                           failed_queries,
                           status,
                           aggregated_metrics AS aggregated_metrics_json,
                           started_at,
                           completed_at,
                           created_at,
                           updated_at
                   FROM evaluation_run
                   WHERE run_id = :run_id"""
            ),
            {"run_id": run_id},
        ).mappings().first()
        if not row:
            return None
        data = dict(row)
        if not data.get("type"):
            data["type"] = "vector similarity"
        total = data.get("total_queries") or 0
        completed = data.get("completed_queries") or 0
        data["progress"] = (float(completed) / float(total)) if total else 0.0
        agg = _safe_json_loads(data.get("aggregated_metrics_json")) or {}
        data["accuracy"] = agg.get("accuracy")
        data["success_count"] = agg.get("success_count")
        data["gate_k"] = agg.get("k")
        return data
    finally:
        session.close()


def get_evaluation_run_queries_impl(run_id: str) -> List[Dict[str, Any]]:
    session = SessionLocal()
    try:
        rows = session.execute(
            text(
                """SELECT query_id AS id,
                           run_id,
                           question,
                           reference_answer,
                           expected_documents,
                           status,
                           retrieved_results AS result_json,
                           query_metrics AS metrics_json,
                           error_message,
                           attempt_count,
                           created_at,
                           updated_at
                   FROM evaluation_run_query
                   WHERE run_id = :run_id
                   ORDER BY created_at"""
            ),
            {"run_id": run_id},
        ).mappings().all()
        return [dict(r) for r in rows]
    finally:
        session.close()


def list_evaluation_runs_impl(search_api_name: Optional[str] = None) -> List[Dict[str, Any]]:
    session = SessionLocal()
    try:
        if search_api_name:
            sql = text(
                """SELECT run_id,
                           api_name AS search_api_name,
                           api_version AS search_api_version,
                           framework AS type,
                           total_questions AS total_queries,
                           successful_queries AS completed_queries,
                           failed_queries,
                           status,
                           aggregated_metrics AS aggregated_metrics_json,
                           started_at,
                           completed_at,
                           created_at,
                           updated_at
                   FROM evaluation_run
                   WHERE api_name = :name
                   ORDER BY created_at DESC"""
            )
            params = {"name": search_api_name}
        else:
            sql = text(
                """SELECT run_id,
                           api_name AS search_api_name,
                           api_version AS search_api_version,
                           framework AS type,
                           total_questions AS total_queries,
                           successful_queries AS completed_queries,
                           failed_queries,
                           status,
                           aggregated_metrics AS aggregated_metrics_json,
                           started_at,
                           completed_at,
                           created_at,
                           updated_at
                   FROM evaluation_run
                   ORDER BY created_at DESC"""
            )
            params = {}

        rows = session.execute(sql, params).mappings().all()
        results: List[Dict[str, Any]] = []
        for r in rows:
            data = dict(r)
            if not data.get("type"):
                data["type"] = "vector similarity"
            agg = _safe_json_loads(data.get("aggregated_metrics_json")) or {}
            data["accuracy"] = agg.get("accuracy")
            data["success_count"] = agg.get("success_count")
            data["gate_k"] = agg.get("k")
            results.append(data)
        return results
    finally:
        session.close()


def _fetch_run_queries(session, run_id: str) -> List[Dict[str, Any]]:
    rows = session.execute(
        text(
            """SELECT query_id,
                           status,
                           query_metrics,
                           created_at,
                           updated_at
                   FROM evaluation_run_query
                  WHERE run_id = :run_id
               ORDER BY created_at"""
        ),
        {"run_id": run_id},
    ).mappings().all()
    return [dict(r) for r in rows]


def _compute_run_stats(query_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    total = len(query_rows)
    success = 0
    duration_sum = 0.0
    duration_samples = 0

    for row in query_rows:
        if (row.get("status") or "").upper() == "COMPLETED":
            success += 1

        started_at = row.get("started_at") or row.get("created_at")
        completed_at = row.get("completed_at") or row.get("updated_at")
        if started_at and completed_at:
            duration_sum += max(0.0, (completed_at - started_at).total_seconds())
            duration_samples += 1

    success_rate = (success / total) if total else None
    avg_response = (duration_sum / duration_samples) if duration_samples else None

    return {
        "total_queries": total,
        "success_rate": success_rate,
        "avg_response_time_seconds": avg_response,
    }


def _format_datetime(value: Optional[datetime]) -> Optional[str]:
    if not value:
        return None
    return value.isoformat()


def _build_timeline(run_row: Dict[str, Any], query_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    events: List[Dict[str, Any]] = []
    started_at = run_row.get("started_at")
    completed_at = run_row.get("completed_at")

    if started_at:
        events.append({"timestamp": _format_datetime(started_at), "event": "Evaluation started"})

    if query_rows:
        first_completion = min(
            (row.get("updated_at") for row in query_rows if row.get("updated_at")), default=None
        )
        if first_completion:
            events.append({"timestamp": _format_datetime(first_completion), "event": "First query completed"})

        half_index = max(0, (len(query_rows) // 2) - 1)
        midpoint = None
        sorted_rows = sorted(
            (row for row in query_rows if row.get("updated_at")),
            key=lambda r: r["updated_at"],
        )
        if sorted_rows:
            midpoint = sorted_rows[min(half_index, len(sorted_rows) - 1)]["updated_at"]
        if midpoint:
            events.append({"timestamp": _format_datetime(midpoint), "event": "50% of queries processed"})

    if completed_at:
        events.append({"timestamp": _format_datetime(completed_at), "event": "Evaluation completed"})

    return events


def _average(values: List[Optional[float]]) -> Optional[float]:
    numeric = [float(v) for v in values if isinstance(v, (int, float))]
    if not numeric:
        return None
    return sum(numeric) / len(numeric)


def _build_metric_comparison(
    current_value: Optional[float],
    previous_value: Optional[float],
    baseline_value: Optional[float],
) -> Dict[str, Optional[float]]:
    change = None
    if current_value is not None and previous_value is not None:
        change = current_value - previous_value
    return {
        "current": current_value,
        "previous": previous_value,
        "baseline": baseline_value,
        "change_from_previous": change,
    }


def resume_evaluation_run_impl(run_id: str) -> bool:
    """Reset a run back to PENDING and make FAILED/RUNNING queries retryable.

    COMPLETED queries are never touched.
    """
    session = SessionLocal()
    try:
        session.execute(
            text(
                """UPDATE evaluation_run
                       SET status = 'PENDING', updated_at = :now
                     WHERE run_id = :run_id"""
            ),
            {"run_id": run_id, "now": _now_utc()},
        )
        # Any FAILED or RUNNING queries become PENDING again
        session.execute(
            text(
                """UPDATE evaluation_run_query
                       SET status = 'PENDING', error_message = NULL, updated_at = :now
                     WHERE run_id = :run_id AND status IN ('FAILED', 'RUNNING')"""
            ),
            {"run_id": run_id, "now": _now_utc()},
        )
        session.commit()
        return True
    except Exception:
        session.rollback()
        logger.exception("Failed to resume evaluation run %s", run_id)
        return False
    finally:
        session.close()


def get_next_runnable_run_impl() -> Optional[Dict[str, Any]]:
    """Return the next run that has pending or failed queries."""
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """SELECT er.run_id,
                           er.api_name AS search_api_name,
                           er.api_version AS search_api_version,
                           er.total_questions AS total_queries,
                           er.successful_queries AS completed_queries,
                           er.failed_queries,
                           er.status
                   FROM evaluation_run er
                  WHERE (er.status IN ('PENDING', 'RUNNING'))
                    AND EXISTS (
                        SELECT 1
                          FROM evaluation_run_query q
                         WHERE q.run_id = er.run_id
                           AND q.status IN ('PENDING', 'FAILED')
                    )
               ORDER BY er.created_at
                  LIMIT 1"""
            )
        ).mappings().first()
        return dict(row) if row else None
    finally:
        session.close()


def get_pending_queries_impl(run_id: str, limit: int = 50) -> List[Dict[str, Any]]:
    """Return pending/failed queries ordered by query_index."""
    session = SessionLocal()
    try:
        rows = session.execute(
            text(
                """SELECT query_id AS id,
                           run_id,
                           question,
                           reference_answer,
                           expected_documents,
                           status,
                           attempt_count
                   FROM evaluation_run_query
                  WHERE run_id = :run_id
                    AND status IN ('PENDING', 'FAILED')
                             ORDER BY created_at
                  LIMIT :limit"""
            ),
            {"run_id": run_id, "limit": limit},
        ).mappings().all()
        return [dict(r) for r in rows]
    finally:
        session.close()


def mark_query_running_impl(run_id: str, query_id: str) -> bool:
    session = SessionLocal()
    try:
        result = session.execute(
            text(
                """UPDATE evaluation_run_query
                       SET status = 'RUNNING',
                           attempt_count = attempt_count + 1,
                           updated_at = :now
                     WHERE run_id = :run_id AND query_id = :query_id"""
            ),
            {"run_id": run_id, "query_id": query_id, "now": _now_utc()},
        )
        session.commit()
        return result.rowcount > 0
    except Exception:
        session.rollback()
        logger.exception("Failed to mark query %s running", query_id)
        return False
    finally:
        session.close()


def complete_query_impl(
    *,
    run_id: str,
    query_id: str,
    retrieved_results: Optional[List[Dict[str, Any]]],
    query_metrics: Optional[Dict[str, Any]],
) -> bool:
    session = SessionLocal()
    try:
        session.execute(
            text(
                """UPDATE evaluation_run_query
                       SET status = 'COMPLETED',
                           retrieved_results = CAST(:result_json AS JSONB),
                           query_metrics = CAST(:metrics_json AS JSONB),
                           error_message = NULL,
                           updated_at = :now
                     WHERE run_id = :run_id AND query_id = :query_id"""
            ),
            {
                "run_id": run_id,
                "query_id": query_id,
                "result_json": json.dumps(retrieved_results or []),
                "metrics_json": json.dumps(query_metrics or {}),
                "now": _now_utc(),
            },
        )

        # Increment successful_queries counter
        session.execute(
            text(
                """UPDATE evaluation_run
                       SET successful_queries = successful_queries + 1,
                           updated_at = :now
                     WHERE run_id = :run_id"""
            ),
            {"run_id": run_id, "now": _now_utc()},
        )

        session.commit()
        return True
    except Exception:
        session.rollback()
        logger.exception("Failed to complete query %s", query_id)
        return False
    finally:
        session.close()


def fail_query_impl(*, run_id: str, query_id: str, error_message: str) -> bool:
    session = SessionLocal()
    try:
        session.execute(
            text(
                """UPDATE evaluation_run_query
                       SET status = 'FAILED',
                           error_message = :msg,
                           updated_at = :now
                     WHERE run_id = :run_id AND query_id = :query_id"""
            ),
            {"run_id": run_id, "query_id": query_id, "msg": error_message[:2000], "now": _now_utc()},
        )

        session.execute(
            text(
                """UPDATE evaluation_run
                       SET failed_queries = failed_queries + 1,
                           updated_at = :now
                     WHERE run_id = :run_id"""
            ),
            {"run_id": run_id, "now": _now_utc()},
        )

        session.commit()
        return True
    except Exception:
        session.rollback()
        logger.exception("Failed to mark query %s failed", query_id)
        return False
    finally:
        session.close()


# ---- Aggregation logic ----


def _resolve_gate_k(metrics_list: List[Dict[str, Any]]) -> int:
    """Infer the gating cutoff used by the worker (defaults to 5 when missing)."""
    for metrics in metrics_list:
        gate_val = metrics.get("gate_k") or metrics.get("k")
        if gate_val is None:
            continue
        try:
            gate_int = int(gate_val)
            if gate_int > 0:
                return gate_int
        except (TypeError, ValueError):
            continue
    return DEFAULT_GATE_K


def _is_retrieval_pass(metrics: Dict[str, Any], gate_k: int) -> bool:
    """Canonical PASS rule: found_expected_doc -> gate_reason -> first_relevant_position."""
    if "found_expected_doc" in metrics:
        return bool(metrics.get("found_expected_doc"))
    gate_reason = metrics.get("gate_reason")
    if gate_reason is not None:
        return str(gate_reason).lower() == "passed"
    first_pos = metrics.get("first_relevant_position")
    if first_pos is None:
        return False
    try:
        return int(first_pos) <= gate_k
    except (TypeError, ValueError):
        return False


def _load_query_metrics(session, run_id: str) -> List[Dict[str, Any]]:
    rows = session.execute(
        text(
            """SELECT query_metrics AS metrics_json
                   FROM evaluation_run_query
                  WHERE run_id = :run_id AND status = 'COMPLETED'"""
        ),
        {"run_id": run_id},
    ).mappings().all()
    metrics_list: List[Dict[str, Any]] = []
    for r in rows:
        mj = r.get("metrics_json")
        if isinstance(mj, dict):
            metrics_list.append(mj)
        elif mj:
            try:
                metrics_list.append(json.loads(mj))
            except Exception:
                logger.warning("Failed to decode metrics_json row for run %s", run_id)
    return metrics_list


def aggregate_run_metrics(run_id: str) -> Optional[Dict[str, Any]]:
    """Compute aggregated metrics for a run and persist them.

    Returns the aggregated metrics dict or None if nothing to aggregate.
    """
    session = SessionLocal()
    try:
        rows = session.execute(
            text(
                """SELECT query_metrics AS metrics_json,
                           started_at,
                           completed_at,
                           created_at,
                           updated_at
                   FROM evaluation_run_query
                  WHERE run_id = :run_id
                    AND status = 'COMPLETED'"""
            ),
            {"run_id": run_id},
        ).mappings().all()

        run_row = session.execute(
            text("""SELECT total_questions FROM evaluation_run WHERE run_id = :run_id"""),
            {"run_id": run_id},
        ).mappings().first()
        total_queries = (run_row or {}).get("total_questions") or 0

        sums: Dict[str, float] = {
            "precision": 0.0,
            "recall": 0.0,
            "mrr": 0.0,
            "coverage": 0.0,
        }
        counts: Dict[str, int] = {
            "precision": 0,
            "recall": 0,
            "mrr": 0,
            "coverage": 0,
        }

        duration_sum = 0.0
        duration_count = 0

        for row in rows:
            metrics_obj = _safe_json_loads(row.get("metrics_json")) or {}
            for key in ("precision", "recall", "mrr", "coverage"):
                value = metrics_obj.get(key)
                if value is None:
                    continue
                try:
                    sums[key] += float(value)
                    counts[key] += 1
                except Exception:
                    pass

            started_at = row.get("started_at") or row.get("created_at")
            completed_at = row.get("completed_at") or row.get("updated_at")
            if started_at and completed_at:
                duration = max(0.0, (completed_at - started_at).total_seconds())
                duration_sum += duration
                duration_count += 1

        avg_query_response_time_seconds = (
            round(duration_sum / duration_count, 4) if duration_count else None
        )

        agg: Dict[str, Any] = {
            "final_avg_precision": round(sums["precision"] / counts["precision"], 4)
            if counts["precision"]
            else 0.0,
            "final_avg_recall": round(sums["recall"] / counts["recall"], 4)
            if counts["recall"]
            else 0.0,
            "final_avg_mrr": round(sums["mrr"] / counts["mrr"], 4)
            if counts["mrr"]
            else 0.0,
            "final_avg_coverage": round(sums["coverage"] / counts["coverage"], 4)
            if counts["coverage"]
            else 0.0,
            "final_total_queries": total_queries,
            "final_avg_response_time_seconds": avg_query_response_time_seconds,
            "final_avg_query_response_time_seconds": avg_query_response_time_seconds,
        }

        session.execute(
            text(
                """UPDATE evaluation_run
                       SET aggregated_metrics = :agg,
                           updated_at = :now,
                           completed_at = COALESCE(completed_at, :now)
                     WHERE run_id = :run_id"""
            ),
            {
                "run_id": run_id,
                "agg": json.dumps(agg) if agg else None,
                "now": _now_utc(),
            },
        )
        session.commit()
        return agg
    except Exception:
        session.rollback()
        logger.exception("Failed to aggregate metrics for run %s", run_id)
        return None
    finally:
        session.close()

def finalize_run_impl(run_id: str) -> bool:
    """Finalize a run after all queries processed.

    Sets status to COMPLETED or PARTIAL_FAILED depending on failed_queries
    and computes aggregated metrics.
    """
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """SELECT total_questions, successful_queries, failed_queries
                       FROM evaluation_run
                      WHERE run_id = :run_id"""
            ),
            {"run_id": run_id},
        ).mappings().first()
        if not row:
            return False
        total = row["total_questions"] or 0
        completed = row["successful_queries"] or 0
        failed = row["failed_queries"] or 0

        status = "COMPLETED"
        if failed > 0 and completed > 0:
            status = "PARTIAL_FAILED"
        elif failed > 0 and completed == 0:
            status = "FAILED"

        # Aggregate metrics first
        agg = aggregate_run_metrics(run_id)

        session.execute(
            text(
                """UPDATE evaluation_run
                       SET status = :status,
                           updated_at = :now,
                           completed_at = :now
                     WHERE run_id = :run_id"""
            ),
            {"run_id": run_id, "status": status, "now": _now_utc()},
        )
        session.commit()
        logger.info(
            "Finalized run %s: total=%s completed=%s failed=%s status=%s agg=%s",
            run_id,
            total,
            completed,
            failed,
            status,
            agg,
        )

        return True
    except Exception:
        session.rollback()
        logger.exception("Failed to finalize run %s", run_id)
        return False
    finally:
        session.close()


def get_run_summary_impl(run_id: str) -> Optional[Dict[str, Any]]:
    session = SessionLocal()
    try:
        run = session.execute(
            text(
                """SELECT run_id,
                               framework,
                               dataset_name,
                               api_definition_id,
                               api_name,
                               api_version,
                               api_snapshot,
                               total_questions,
                               successful_queries,
                               failed_queries,
                               status,
                               aggregated_metrics,
                               started_at,
                               completed_at,
                               created_at,
                               updated_at
                       FROM evaluation_run
                      WHERE run_id = :run_id"""
            ),
            {"run_id": run_id},
        ).mappings().first()
        if not run:
            return None

        query_rows = _fetch_run_queries(session, run_id)
        stats = _compute_run_stats(query_rows)
        aggregated_metrics = _safe_json_loads(run.get("aggregated_metrics")) or {}
        api_snapshot = _safe_json_loads(run.get("api_snapshot")) or {}

        response_time_metric = aggregated_metrics.get("final_avg_response_time_seconds")
        if response_time_metric is None:
            response_time_metric = aggregated_metrics.get("final_avg_query_response_time_seconds")

        summary_aggregated_metrics = {
            "final_avg_precision": aggregated_metrics.get("final_avg_precision"),
            "final_avg_recall": aggregated_metrics.get("final_avg_recall"),
            "final_avg_mrr": aggregated_metrics.get("final_avg_mrr"),
            "final_avg_coverage": aggregated_metrics.get("final_avg_coverage"),
            "final_total_queries": aggregated_metrics.get("final_total_queries"),
            "final_avg_response_time_seconds": response_time_metric,
            "final_avg_query_response_time_seconds": response_time_metric,
        }

        started_at = run.get("started_at")
        completed_at = run.get("completed_at")
        duration_seconds = None
        if started_at and completed_at:
            duration_seconds = max(0.0, (completed_at - started_at).total_seconds())

        metrics_section = {
            "success_rate": stats.get("success_rate"),
            "avg_response_time_seconds": stats.get("avg_response_time_seconds"),
            "aggregated": summary_aggregated_metrics,
        }

        summary = {
            "run": {
                "run_id": run_id,
                "status": run.get("status"),
                "api_name": run.get("api_name"),
                "api_version": run.get("api_version"),
                "type": run.get("framework") or "vector_similarity",
                "evaluation_type": run.get("framework") or "vector_similarity",
                "started_at": _format_datetime(started_at),
                "completed_at": _format_datetime(completed_at),
                "duration_seconds": duration_seconds,
                "successful_queries": run.get("successful_queries"),
                "failed_queries": run.get("failed_queries"),
            },
            "dataset": {
                "name": run.get("dataset_name"),
                "total_queries": stats.get("total_queries"),
            },
            "configuration": {
                "raw_snapshot": api_snapshot,
                "retrieval_mode": api_snapshot.get("retrieval_mode"),
                "embedding_model": api_snapshot.get("embedding_model")
                or (api_snapshot.get("embedding") or {}).get("model"),
                "vector_weight": api_snapshot.get("vector_weight"),
            },
            "metrics": metrics_section,
            "timeline": _build_timeline(run, query_rows),
        }

        return summary
    finally:
        session.close()


# ---- Comparison logic ----


def get_run_data_for_comparison(run_id: str) -> Dict[str, Any]:
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """SELECT aggregated_metrics,
                           api_snapshot,
                           api_name,
                           api_version
                       FROM evaluation_run
                      WHERE run_id = :run_id"""
            ),
            {"run_id": run_id},
        ).mappings().first()
        if not row:
            return {"metrics": {}, "config": {}, "info": {}}
        
        mj = row.get("aggregated_metrics")
        metrics = _safe_json_loads(mj) or {}

        sj = row.get("api_snapshot")
        config = _safe_json_loads(sj) or {}

        info = {
            "api_name": row.get("api_name"),
            "api_version": row.get("api_version")
        }

        return {"metrics": metrics, "config": config, "info": info}
    finally:
        session.close()


def compare_runs_impl(run_id_1: str, run_id_2: str) -> Dict[str, Any]:
    """Compare aggregated metrics and configurations between two runs.

    Returns structure with metrics, configs, and a simple winner per metric.
    """
    d1 = get_run_data_for_comparison(run_id_1)
    d2 = get_run_data_for_comparison(run_id_2)

    m1 = d1["metrics"]
    m2 = d2["metrics"]

    # Metrics list with descriptive labels for UI
    metrics_of_interest = [
        # (Key, Display Name)
        ("avg_precision@1", "Precision@1"),
        ("avg_precision@5", "Precision@5"),
        ("avg_recall@5", "Recall@5"),
        ("avg_f1@5", "F1@5"),
        ("avg_mrr", "MRR"),
        ("avg_semantic_similarity", "Semantic Similarity"),
        ("avg_answer_match_score", "Answer Match"),
        ("accuracy", "Overall Accuracy"),
    ]

    comparison: Dict[str, Any] = {
        "run_id_1": run_id_1,
        "run_id_2": run_id_2,
        "info_1": d1["info"],
        "info_2": d2["info"],
        "metrics_1": m1,
        "metrics_2": m2,
        "config_1": d1["config"],
        "config_2": d2["config"],
        "winners": {},
    }

    for key, _ in metrics_of_interest:
        v1 = m1.get(key)
        v2 = m2.get(key)
        winner: Optional[str]
        if v1 is None and v2 is None:
            winner = None
        elif v1 is None:
            winner = run_id_2
        elif v2 is None:
            winner = run_id_1
        else:
            try:
                f1 = float(v1)
                f2 = float(v2)
            except Exception:
                winner = None
            else:
                if abs(f1 - f2) < 1e-6:
                    winner = "tie"
                elif f1 > f2:
                    winner = run_id_1
                else:
                    winner = run_id_2
        comparison["winners"][key] = winner

    return comparison


class EvaluationQuery(BaseModel):
    question: str
    reference_answer: Optional[str] = None
    # Optional alias commonly used in datasets; mapped to reference_answer downstream
    answer: Optional[str] = None
    expected_chunks: Optional[List[str]] = None
    expected_documents: Optional[List[str]] = None
    expected_chunk_text: Optional[List[str]] = None
    document_name: Optional[str] = None


class StartEvaluationRequest(BaseModel):
    search_api_name: str
    dataset: List[EvaluationQuery]
    type: Optional[str] = "vector similarity"  # "vector similarity" or "LLM as a judge"


@router.post(
    "/run",
    summary="Start Evaluation Run",
    description="Initiate a new evaluation run for a specified Search API using a provided dataset.",
)
async def start_evaluation_run(payload: StartEvaluationRequest):
    """Start a new evaluation run.

    Creates evaluation_run and evaluation_run_query rows and returns run_id.
    """
    try:
        dataset_dicts = [q.model_dump() for q in payload.dataset]
        # Stable hash of dataset for traceability (no duplicate detection yet)
        file_hash = hashlib.sha256(json.dumps(dataset_dicts, sort_keys=True).encode("utf-8")).hexdigest()
        run_id = start_evaluation_run_impl(
            search_api_name=payload.search_api_name,
            dataset=dataset_dicts,
            file_hash=file_hash,
            evaluation_type=payload.type or "vector similarity",
        )
        return {"run_id": str(run_id)}
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))


@router.post(
    "/run/upload",
    summary="Start Evaluation from File",
    description="Start a new evaluation run by uploading a JSON file containing the dataset queries.",
)
async def start_evaluation_run_from_file(
    search_api_name: str = Form(...),
    type: Optional[str] = Form("vector similarity"),
    file: UploadFile = File(...),
):
    """Start a new evaluation run by uploading a JSON file of queries.

    The uploaded JSON may be either:
            - a top-level list of {question, reference_answer?, expected_chunks?, expected_documents?}
      - or an object with a "dataset" key containing such a list.
    """
    try:
        content = await file.read()
        try:
            parsed = json.loads(content.decode("utf-8"))
        except Exception:
            raise HTTPException(status_code=400, detail="Uploaded file is not valid JSON")

        if isinstance(parsed, list):
            raw_dataset = parsed
        elif isinstance(parsed, dict) and "dataset" in parsed:
            raw_dataset = parsed["dataset"]
        else:
            raise HTTPException(
                status_code=400,
                detail="JSON must be a list of queries or an object with a 'dataset' list",
            )

        if not isinstance(raw_dataset, list) or not raw_dataset:
            raise HTTPException(status_code=400, detail="Dataset must be a non-empty list")

        # Validate and normalize using the Pydantic model
        dataset_models: List[EvaluationQuery] = []
        for idx, item in enumerate(raw_dataset, start=1):
            if not isinstance(item, dict):
                raise HTTPException(
                    status_code=400,
                    detail=f"Dataset item #{idx} is not an object",
                )
            try:
                dataset_models.append(EvaluationQuery(**item))
            except Exception as e:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid query at index {idx}: {e}",
                )

        dataset_dicts = [q.model_dump() for q in dataset_models]
        file_hash = hashlib.sha256(json.dumps(dataset_dicts, sort_keys=True).encode("utf-8")).hexdigest()

        run_id = start_evaluation_run_impl(
            search_api_name=search_api_name,
            dataset=dataset_dicts,
            file_hash=file_hash,
            evaluation_type=type or "vector similarity",
        )
        return {"run_id": str(run_id)}
    except HTTPException:
        # Re-raise FastAPI HTTPException as-is
        raise
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to start evaluation run: {e}")


@router.get(
    "/run/{run_id}",
    summary="Get Run Details",
    description="Retrieve the details and current status of a specific evaluation run.",
)
async def get_run(run_id: str):
    run = get_evaluation_run_impl(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return run


@router.get(
    "/run/{run_id}/queries",
    summary="Get Run Queries",
    description="Retrieve all the individual queries (questions) associated with a specific evaluation run, including their status and results.",
)
async def get_run_queries(run_id: str):
    # Returns all queries with statuses and metrics/results
    return {"run_id": run_id, "queries": get_evaluation_run_queries_impl(run_id)}


@router.get(
    "/run/{run_id}/summary",
    summary="Get Run Summary",
    description="Get a comprehensive summary of an evaluation run, including aggregated metrics, comparison with previous runs, and execution timeline.",
)
async def get_run_summary(run_id: str):
    summary = get_run_summary_impl(run_id)
    if not summary:
        raise HTTPException(status_code=404, detail="Run not found")
    return summary


@router.get(
    "/runs",
    summary="List Evaluation Runs",
    description="List all evaluation runs, optionally filtering by the Search API name.",
)
async def list_runs(search_api_name: Optional[str] = None):
    runs = list_evaluation_runs_impl(search_api_name=search_api_name)
    return {"runs": runs}


@router.post(
    "/run/{run_id}/resume",
    summary="Resume Evaluation Run",
    description="Resets any failed or stuck queries in an evaluation run to 'PENDING' so they can be re-executed by workers.",
)
async def resume_run(run_id: str):
    ok = resume_evaluation_run_impl(run_id)
    if not ok:
        raise HTTPException(status_code=500, detail="Failed to resume run")
    return {"run_id": run_id, "status": "resumed"}



@router.get(
    "/compare",
    summary="Compare Evaluation Runs",
    description="Compare runs. If both IDs provided, compares them directly. If only run_id_1 is provided, compares it against the last 2 runs for the same API.",
)
async def compare_runs(
    run_id_1: str,
    run_id_2: Optional[str] = None,
):
    """
    Compare evaluation runs.

    If run_id_1 and run_id_2 are provided, compares those two specific runs.
    If only run_id_1 is provided, compares it against the last two runs.
    """
    if run_id_1 and run_id_2:
        return compare_runs_impl(run_id_1, run_id_2)
    elif run_id_1 and not run_id_2:
        # Compare run_id_1 against last 2 runs
        session = SessionLocal()
        try:
            # Fetch current run details
            current_run = session.execute(
                text("SELECT api_name FROM evaluation_run WHERE run_id = :rid"),
                {"rid": run_id_1}
            ).mappings().first()
            
            if not current_run:
                raise HTTPException(status_code=404, detail="Run 1 not found")

            # Fetch last 2 runs for same API
            history = session.execute(
                text("""
                    SELECT run_id 
                    FROM evaluation_run 
                    WHERE api_name = :api_name
                      AND run_id != :rid
                    ORDER BY created_at DESC 
                    LIMIT 2
                """),
                {"api_name": current_run["api_name"], "rid": run_id_1}
            ).mappings().all()

            results = []
            for h in history:
                results.append(compare_runs_impl(run_id_1, h["run_id"]))
            
            return {"comparisons": results}
        finally:
            session.close()
    else:
        raise HTTPException(status_code=400, detail="Must provide at least run_id_1")


# ---- Worker-facing internal APIs ----


@router.get(
    "/worker/next-run",
    summary="Worker: Poll Next Run",
    description="Endpoint for workers to poll for the next available evaluation run that has pending queries.",
)
async def worker_next_run():
    run = get_next_runnable_run_impl()
    if not run:
        return {"status": "idle"}
    return {"status": "success", "run": run}


@router.get(
    "/worker/run/{run_id}/pending-queries",
    summary="Worker: Get Pending Queries",
    description="Endpoint for workers to fetch a batch of PENDING (or FAILED) queries for a specific run ID.",
)
async def worker_pending_queries(run_id: str, limit: int = 50):
    queries = get_pending_queries_impl(run_id, limit=limit)
    return {"status": "success", "queries": queries}


@router.post(
    "/worker/run/{run_id}/query/{query_id}/start",
    summary="Worker: Start Query",
    description="Mark a specific query as 'RUNNING', preventing other workers from picking it up.",
)
async def worker_mark_query_running(run_id: str, query_id: str):
    ok = mark_query_running_impl(run_id, query_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Query not found or cannot be marked running")
    return {"status": "success"}


class WorkerCompletePayload(BaseModel):
    question: str
    reference_answer: Optional[str] = None
    expected_documents: Optional[List[str]] = None
    retrieved_results: Optional[List[Dict[str, Any]]] = None
    query_metrics: Optional[Dict[str, Any]] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


@router.post(
    "/worker/run/{run_id}/query/{query_id}/complete",
    summary="Worker: Complete Query",
    description="Submit the final results and metrics for a completed query.",
)
async def worker_complete_query(run_id: str, query_id: str, payload: WorkerCompletePayload):
    session = SessionLocal()
    try:
        started_at = payload.started_at or _now_utc()
        completed_at = payload.completed_at or _now_utc()

        # Upsert evaluation_run_query
        session.execute(
            text(
                """INSERT INTO evaluation_run_query (
                        query_id, run_id, question, reference_answer, expected_documents,
                        status, attempt_count, retrieved_results, query_metrics,
                        started_at, created_at, updated_at, completed_at
                    ) VALUES (
                        :query_id, :run_id, :question, :reference_answer, CAST(:expected_documents AS JSONB),
                        'COMPLETED', 1, CAST(:result_json AS JSONB), CAST(:metrics_json AS JSONB),
                        :started_at, :created_at, :updated_at, :completed_at
                    ) ON CONFLICT (query_id) DO UPDATE SET
                        status = 'COMPLETED',
                        retrieved_results = EXCLUDED.retrieved_results,
                        query_metrics = EXCLUDED.query_metrics,
                        started_at = COALESCE(evaluation_run_query.started_at, EXCLUDED.started_at),
                        updated_at = EXCLUDED.updated_at,
                        completed_at = EXCLUDED.completed_at"""
            ),
            {
                "query_id": query_id,
                "run_id": run_id,
                "question": payload.question,
                "reference_answer": payload.reference_answer,
                "expected_documents": json.dumps(payload.expected_documents or []),
                "result_json": json.dumps(payload.retrieved_results or []),
                "metrics_json": json.dumps(payload.query_metrics or {}),
                "started_at": started_at,
                "created_at": started_at,
                "updated_at": completed_at,
                "completed_at": completed_at,
            },
        )

        # Increment successful_queries counter
        session.execute(
            text(
                """UPDATE evaluation_run
                       SET successful_queries = successful_queries + 1,
                           updated_at = :now
                     WHERE run_id = :run_id"""
            ),
            {"run_id": run_id, "now": _now_utc()},
        )

        session.commit()
        return {"status": "success"}
    except Exception:
        session.rollback()
        logger.exception("Failed to complete query %s", query_id)
        raise HTTPException(status_code=500, detail="Failed to complete query")
    finally:
        session.close()


class WorkerFailPayload(BaseModel):
    question: str
    reference_answer: Optional[str] = None
    expected_documents: Optional[List[str]] = None
    error_message: str
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


@router.post(
    "/worker/run/{run_id}/query/{query_id}/fail",
    summary="Worker: Fail Query",
    description="Mark a query as FAILED with an error message.",
)
async def worker_fail_query(run_id: str, query_id: str, payload: WorkerFailPayload):
    session = SessionLocal()
    try:
        started_at = payload.started_at or _now_utc()
        completed_at = payload.completed_at or _now_utc()

        # Upsert evaluation_run_query
        session.execute(
            text(
                """INSERT INTO evaluation_run_query (
                        query_id, run_id, question, reference_answer, expected_documents,
                        status, attempt_count, error_message,
                        started_at, created_at, updated_at, completed_at
                    ) VALUES (
                        :query_id, :run_id, :question, :reference_answer, CAST(:expected_documents AS JSONB),
                        'FAILED', 1, :msg,
                        :started_at, :created_at, :updated_at, :completed_at
                    ) ON CONFLICT (query_id) DO UPDATE SET
                        status = 'FAILED',
                        error_message = EXCLUDED.error_message,
                        started_at = COALESCE(evaluation_run_query.started_at, EXCLUDED.started_at),
                        updated_at = EXCLUDED.updated_at,
                        completed_at = EXCLUDED.completed_at"""
            ),
            {
                "query_id": query_id,
                "run_id": run_id,
                "question": payload.question,
                "reference_answer": payload.reference_answer,
                "expected_documents": json.dumps(payload.expected_documents or []),
                "msg": payload.error_message[:2000],
                "started_at": started_at,
                "created_at": started_at,
                "updated_at": completed_at,
                "completed_at": completed_at,
            },
        )

        session.execute(
            text(
                """UPDATE evaluation_run
                       SET failed_queries = failed_queries + 1,
                           updated_at = :now
                     WHERE run_id = :run_id"""
            ),
            {"run_id": run_id, "now": _now_utc()},
        )

        session.commit()
        return {"status": "success"}
    except Exception:
        session.rollback()
        logger.exception("Failed to mark query %s failed", query_id)
        raise HTTPException(status_code=500, detail="Failed to mark query failed")
    finally:
        session.close()


@router.post(
    "/worker/run/{run_id}/start",
    summary="Worker: Start Run",
    description="Mark an evaluation run as RUNNING.",
)
async def worker_start_run(run_id: str):
    session = SessionLocal()
    try:
        session.execute(
            text(
                """UPDATE evaluation_run
                       SET status = 'RUNNING',
                           started_at = COALESCE(started_at, :now),
                           updated_at = :now
                     WHERE run_id = :run_id"""
            ),
            {"run_id": run_id, "now": _now_utc()},
        )
        session.commit()
        return {"status": "success"}
    except Exception:
        session.rollback()
        logger.exception("Failed to start run %s", run_id)
        raise HTTPException(status_code=500, detail="Failed to start run")
    finally:
        session.close()

@router.post(
    "/worker/run/{run_id}/finalize",
    summary="Worker: Finalize Run",
    description="Trigger aggregation of results and mark the run as COMPLETED.",
)
async def worker_finalize_run(run_id: str):
    ok = finalize_run_impl(run_id)
    if not ok:
        raise HTTPException(status_code=500, detail="Failed to finalize run")
    return {"status": "success"}
