from fastapi import APIRouter, Form, UploadFile, File
from typing import List, Optional, Dict, Any
import uuid
import logging
from database import SessionLocal
from celery import Celery
from config import settings
from sqlalchemy import text
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.exc import IntegrityError
import json
import os
from pathlib import Path
from utils.path_utils import get_shared_path

logger = logging.getLogger("chunking")
logging.basicConfig(level=logging.INFO)

router = APIRouter(prefix="/chunking", tags=["Chunking"])
# Celery app for sending tasks
celery_app = Celery(broker=settings.celery_broker_url)


def _normalize_strategy_name(strategy: str) -> str:
    s = (strategy or "").strip().lower()
    s = s.replace("-", "_")
    s = s.replace(" ", "_")
    # common aliases
    if s in {"fixed_characters", "fixed_character", "fixedcharacter", "fixed_char"}:
        return "fixed_characters"
    if s in {"semantic", "semantic_chunk", "semantic_chunker"}:
        return "semantic_chunking"
    if s in {"hierarchical_chunking", "hierarchical_chunk"}:
        return "hierarchical"
    return s


def _resolve_chunking_task(strategy_raw: str) -> tuple[str, str]:
    """Return (celery_task_name, queue_name) for a chunking strategy."""
    strategy = _normalize_strategy_name(strategy_raw)

    # explicit mapping for known workers
    mapping = {
        "fixed_characters": ("fixedcharacters_worker.fixedcharacters_task", "fixed_characters"),
        "semantic_chunking": ("semantic_chunking_worker.semantic_chunking_task", "semantic_chunking"),
        "recursive_chunking": ("recursive_chunking_worker.recursive_chunking_task", "recursive_chunking"),
        "page_chunking": ("page_chunking_worker.page_chunking_task", "page_chunking"),
        "hierarchical": ("hierarchical_worker.hierarchical_task", "hierarchical"),
    }
    if strategy in mapping:
        return mapping[strategy]

    # fallback to legacy convention
    worker_name = f"{strategy}_worker.{strategy}_task".lower()
    queue_name = strategy.lower()
    return worker_name, queue_name
# ---- Models ----
class ChunkingRequest(BaseModel):
    dag_id: str
    run_id: str
    folder_id: str
    chunking_config: Dict[str, Any] = Field(default_factory=dict, alias="ChunkingConfig")
    model_config = ConfigDict(extra="allow")

class ChunkingWorkerResult(BaseModel):
    task_id: str
    status: str
    process_name: Optional[str] = None
    job_id: Optional[str] = None
    error_message: Optional[str] = None
    folder_id: Optional[str] = None
    model_config = ConfigDict(extra="allow")


@router.post("/chunk")
def submit_chunking_task(
    req: ChunkingRequest,
):
    session = SessionLocal()
    try:
        cfg = req.chunking_config or {}
        strategy = cfg.get("ChunkingStrategy") or cfg.get("chunking_strategy") or cfg.get("strategy")
        if not strategy:
            return {"status": "error", "message": "ChunkingStrategy is required in ChunkingConfig"}

        # Insert into public.task_details with UUID collision retry
        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, started_at, job_id, payload
            ) VALUES (
                :id, :process_name, :task_type, :status, now(), :job_id, CAST(:payload AS JSONB)
            )
            """
        )
        MAX_RETRIES = 5
        task_id = None
        for _ in range(MAX_RETRIES):
            candidate = str(uuid.uuid4())
            try:
                session.execute(
                    insert_sql,
                    {
                        "id": candidate,
                        "process_name": req.dag_id,
                        "task_type": "Chunking",
                        "status": "submitted",
                        "job_id": req.run_id,
                        "payload": json.dumps(cfg),
                    },
                )
                session.commit()
                task_id = candidate
                break
            except IntegrityError:
                session.rollback()
                continue
        if not task_id:
            return {"status": "error", "message": "Could not allocate unique task id after retries"}

        # Determine worker and queue names per strategy (canonical mapping)
        worker_name, queue_name = _resolve_chunking_task(str(strategy))
        # Update task_details with worker & queue
        session.execute(
            text(
                """
                UPDATE public.task_details
                SET worker_name = :worker_name,
                    queue_name = :queue_name
                WHERE id = :id
                """
            ),
            {"worker_name": worker_name, "queue_name": queue_name, "id": task_id},
        )
        session.commit()

        # Enqueue Celery task
        celery_app.send_task(
            worker_name,
            args=[task_id, req.folder_id, cfg, req.dag_id, req.run_id],
            queue=queue_name,
        )

        return {"task_id": task_id, "status": "submitted"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Chunking endpoint error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

@router.post("/worker-results")
def worker_results(body: ChunkingWorkerResult):
    """Store chunking worker results JSON into task_details.reserved and finalize task status.

    On success, update public.document_details for the matching folder_id to set
    chunking_status and last_successful_stage.
    """
    session = SessionLocal()
    try:
        status_raw = (body.status or "").strip().lower()
        status_norm = "success" if status_raw in ("success", "succeeded", "completed") else (
            "failed" if status_raw in ("error", "failed") else status_raw
        )

        reserved_json = body.model_dump(exclude_none=True)
        if isinstance(body, BaseModel):
            try:
                extra_items = {k: v for k, v in body.__dict__.items() if k not in reserved_json}
                reserved_json.update(extra_items)
            except Exception:
                pass

        upd = text(
            """
            UPDATE public.task_details
            SET status = :st,
                reserved = CAST(:reserved AS JSONB),
                completed_at = now()
            WHERE id = :id
            """
        )
        res = session.execute(
            upd,
            {"id": body.task_id, "st": status_norm or "success", "reserved": json.dumps(reserved_json)},
        )
        session.commit()

        rowcount = getattr(res, "rowcount", None)
        if rowcount == 0:
            return {"status": "error", "message": f"task_id not found: {body.task_id}"}

        # Skip document_details updates for runtime/testing runs
        process_name_eff = (body.process_name or (reserved_json.get("process_name") if isinstance(reserved_json, dict) else "") or "").strip()
        if process_name_eff.lower() in ("runtimetesting", "runtimechunking"):
            return {"status": "ok"}

        # Determine folder_id from payload
        folder_id_eff: Optional[str] = body.folder_id
        if not folder_id_eff:
            try:
                if isinstance(reserved_json, dict):
                    if not folder_id_eff and isinstance(reserved_json.get("folders"), list):
                        for item in reserved_json.get("folders"):
                            if isinstance(item, dict) and item.get("folder_id"):
                                folder_id_eff = str(item.get("folder_id"))
                                break
                    if not folder_id_eff and reserved_json.get("folder_id"):
                        folder_id_eff = str(reserved_json.get("folder_id"))
                    if not folder_id_eff and isinstance(reserved_json.get("folder_ids"), list) and reserved_json["folder_ids"]:
                        folder_id_eff = str(reserved_json["folder_ids"][0])
            except Exception:
                folder_id_eff = None

        # On success, update document_details
        if status_norm == "success" and folder_id_eff:
            cols_info = session.execute(
                text(
                    """
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_schema = 'public' AND table_name = 'document_details'
                    """
                )
            ).mappings().all()
            col_names = {c["column_name"]: c.get("data_type") for c in cols_info}

            sets = []
            params = {"fid": folder_id_eff}
            if "chunking_status" in col_names:
                sets.append("chunking_status = :cs"); params["cs"] = "success"
            if "last_successful_stage" in col_names:
                sets.append("last_successful_stage = :lss"); params["lss"] = "chunking"
            if "updated_at" in col_names:
                dt = (col_names.get("updated_at") or "").lower()
                if "timestamp" in dt:
                    sets.append("updated_at = now()")
                else:
                    sets.append("updated_at = :ua"); params["ua"] = None

            if sets:
                upd_doc = text(
                    f"""
                    UPDATE public.document_details
                    SET {', '.join(sets)}
                    WHERE folder_id = :fid
                    """
                )
                session.execute(upd_doc, params)
                session.commit()

        return {"status": "ok"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Chunking worker-results error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()

@router.get("/status/{task_id}")
def get_chunking_status(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT id, status, reserved
                FROM public.task_details
                WHERE id = :id
                """
            ),
            {"id": task_id},
        ).mappings().first()
        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        status = (row.get("status") or "").strip().lower() or "pending"
        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        # Success: extract folder_ids from reserved JSON
        folder_ids: List[str] = []
        reserved_val = row.get("reserved")
        try:
            data = None
            if isinstance(reserved_val, dict):
                data = reserved_val
            elif isinstance(reserved_val, (bytes, bytearray, memoryview)):
                data = json.loads(bytes(reserved_val).decode("utf-8"))
            elif isinstance(reserved_val, str):
                data = json.loads(reserved_val)
            if isinstance(data, dict):
                folders = data.get("folders")
                if isinstance(folders, list):
                    folder_ids = [str(it.get("folder_id")) for it in folders if isinstance(it, dict) and it.get("folder_id")]
                if not folder_ids:
                    ids_val = data.get("folder_ids")
                    if isinstance(ids_val, list):
                        folder_ids = [str(x) for x in ids_val if x]
                if not folder_ids and data.get("folder_id"):
                    folder_ids = [str(data.get("folder_id"))]
        except Exception:  # noqa: BLE001
            folder_ids = []

        return {"task_id": task_id, "status": "success", "folder_ids": folder_ids or []}
    except Exception as e:  # noqa: BLE001
        logger.error(f"Chunking status error: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e), "folder_ids": []}
    finally:
        session.close()

# ---- Runtime testing endpoints ----

@router.post("/runtime-chunk")
def runtime_chunk(
    input_text: str = Form(..., alias="text"),
    chunking_profile: str = Form(...),
):
    """
    Accept raw text and a chunking_profile name, fetch ChunkingConfig from profiles table,
    create a unique runtime folder under DataBackBone, insert into task_details,
    enqueue the appropriate chunking worker, and return the task_id.
    """
    session = SessionLocal()
    try:
        # Fetch profile config
        row = session.execute(
            text(
                """
                SELECT profile_config
                FROM public.profiles
                WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
                  AND LOWER(TRIM(step_type)) = LOWER(TRIM('Chunking'))
                LIMIT 1
                """
            ),
            {"name": chunking_profile},
        ).first()
        if not row:
            return {"status": "error", "message": f"Chunking profile not found: {chunking_profile}"}

        raw_cfg = row[0]
        cfg: Dict[str, Any] = {}
        try:
            if isinstance(raw_cfg, dict):
                cfg = raw_cfg
            elif isinstance(raw_cfg, (bytes, bytearray, memoryview)):
                cfg = json.loads(bytes(raw_cfg).decode("utf-8"))
            elif isinstance(raw_cfg, str):
                cfg = json.loads(raw_cfg)
        except Exception as je:  # noqa: BLE001
            return {"status": "error", "message": f"Invalid profile config JSON: {je}"}

        # Determine strategy and worker/queue
        strategy = cfg.get("ChunkingStrategy") or cfg.get("chunking_strategy") or cfg.get("strategy")
        worker_name, base_queue = _resolve_chunking_task(str(strategy))
        queue_name = f"runtime_{base_queue}".lower()

        # Resolve DataBackBone root using shared path utility (handles UNC on Windows)
        base_root: Path = get_shared_path("DATA_BACKBONE_DIR", settings.data_backbone_dir)

        # Generate IDs and runtime folder
        task_id = str(uuid.uuid4())
        folder_id = str(uuid.uuid4())
        folder_name = f"Runtime_{folder_id}"
        runtime_dir: Path = base_root / folder_name
        runtime_dir.mkdir(parents=True, exist_ok=True)

        # Write provided text to a file in runtime folder
        txt_path = runtime_dir / "input.txt"
        txt_path.write_text(input_text, encoding="utf-8")

        # Insert into task_details
        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, worker_name, queue_name, started_at, job_id, payload
            ) VALUES (
                :id, :process_name, :task_type, :status, :worker_name, :queue_name, now(), :job_id, CAST(:payload AS JSONB)
            )
            """
        )
        session.execute(
            insert_sql,
            {
                "id": task_id,
                "process_name": "RuntimeChunking",
                "task_type": "Chunking",
                "status": "submitted",
                "worker_name": worker_name,
                "queue_name": queue_name,
                "job_id": "RuntimeChunking",
                "payload": json.dumps(cfg),
            },
        )
        session.commit()

        # Enqueue worker with folder path (absolute)
        celery_app.send_task(
            worker_name,
            args=[task_id, folder_name, cfg, "RuntimeChunking", "RuntimeChunking"],
            queue=queue_name,
        )

        return {"task_id": task_id, "status": "submitted"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Runtime chunk endpoint error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.post("/runtime-chunk-json")
def runtime_chunk_json(
    chunking_profile: str = Form(...),
    layout_json: str = Form(..., description="Raw JSON layout or parser_output content as text"),
):
    """Runtime chunking that accepts JSON layout/parser_output content directly instead of a file.

    Steps:
      1. Load profile config by chunking_profile.
      2. Create runtime folder under DataBackBone.
      3. Parse provided JSON string and save with a canonical name so worker can find it:
         - If root has 'layout' list or alt keys, name: input.layout.json
         - If root has 'parser_output' list, name: input.parser_output.json
         - Else attempt heuristic: if root is list of dicts with 'page' or 'text_tag' -> layout
      4. Insert task_details row and enqueue appropriate chunking worker.
    """
    session = SessionLocal()
    try:
        # Fetch profile config
        row = session.execute(
            text(
                """
                SELECT profile_config
                FROM public.profiles
                WHERE LOWER(TRIM(profile_name)) = LOWER(TRIM(:name))
                  AND LOWER(TRIM(step_type)) = LOWER(TRIM('Chunking'))
                LIMIT 1
                """
            ),
            {"name": chunking_profile},
        ).first()
        if not row:
            return {"status": "error", "message": f"Chunking profile not found: {chunking_profile}"}

        raw_cfg = row[0]
        cfg: Dict[str, Any] = {}
        try:
            if isinstance(raw_cfg, dict):
                cfg = raw_cfg
            elif isinstance(raw_cfg, (bytes, bytearray, memoryview)):
                cfg = json.loads(bytes(raw_cfg).decode("utf-8"))
            elif isinstance(raw_cfg, str):
                cfg = json.loads(raw_cfg)
        except Exception as je:  # noqa: BLE001
            return {"status": "error", "message": f"Invalid profile config JSON: {je}"}

        strategy = cfg.get("ChunkingStrategy") or cfg.get("chunking_strategy") or cfg.get("strategy") or "page_chunking"
        worker_name, base_queue = _resolve_chunking_task(str(strategy))
        queue_name = f"runtime_{base_queue}".lower()

        base_root: Path = get_shared_path("DATA_BACKBONE_DIR", settings.data_backbone_dir)
        task_id = str(uuid.uuid4())
        folder_id = str(uuid.uuid4())
        folder_name = f"Runtime_{folder_id}"
        runtime_dir: Path = base_root / folder_name
        runtime_dir.mkdir(parents=True, exist_ok=True)

        # Parse provided JSON layout/parser_output content safely
        try:
            data = json.loads(layout_json)
        except Exception as je:  # noqa: BLE001
            return {"status": "error", "message": f"Provided layout_json is not valid JSON: {je}"}

        # Decide canonical filename
        fname: str

        def _is_layout_like(d: Any) -> bool:
            if isinstance(d, dict):
                if isinstance(d.get("layout"), list):
                    return True
                for k in ("segments", "items", "elements", "data", "pages", "blocks"):
                    if isinstance(d.get(k), list):
                        return True
            if isinstance(d, list):
                # Heuristic: if list of dicts containing 'text_tag' or 'page'
                if any(
                    isinstance(x, dict)
                    and (x.get("text_tag") or x.get("page") or x.get("page_num"))
                    for x in d
                ):
                    return True
            return False

        def _is_parser_output_like(d: Any) -> bool:
            return isinstance(d, dict) and isinstance(d.get("parser_output"), list)

        if _is_parser_output_like(data):
            fname = "input.parser_output.json"
        elif _is_layout_like(data):
            fname = "input.layout.json"
        else:
            # Default to layout form for chunking
            fname = "input.layout.json"

        target_path = runtime_dir / fname
        # Persist JSON exactly (we may normalize later if needed)
        with target_path.open("w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)

        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, worker_name, queue_name, started_at, job_id, payload
            ) VALUES (
                :id, :process_name, :task_type, :status, :worker_name, :queue_name, now(), :job_id, CAST(:payload AS JSONB)
            )
            """
        )
        session.execute(
            insert_sql,
            {
                "id": task_id,
                "process_name": "RuntimeChunking",
                "task_type": "Chunking",
                "status": "submitted",
                "worker_name": worker_name,
                "queue_name": queue_name,
                "job_id": "RuntimeChunking",
                "payload": json.dumps(cfg),
            },
        )
        session.commit()

        # Enqueue worker with relative runtime folder name
        celery_app.send_task(
            worker_name,
            args=[task_id, folder_name, cfg, "RuntimeChunking", "RuntimeChunking"],
            queue=queue_name,
        )

        return {
            "task_id": task_id,
            "status": "submitted",
            "folder_id": folder_name,
            "stored_file": fname,
        }
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Runtime chunk JSON endpoint error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.get("/runtime_status/{task_id}")
def get_runtime_chunk_status(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT id, status, reserved
                FROM public.task_details
                WHERE id = :id
                """
            ),
            {"id": task_id},
        ).mappings().first()
        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "num_chunks": 0, "chunks": []}

        status = (row.get("status") or "").strip().lower() or "pending"
        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "num_chunks": 0, "chunks": []}

        # Extract folder_id/path from reserved JSON
        reserved_val = row.get("reserved")
        folder_id_eff = None
        try:
            data = None
            if isinstance(reserved_val, dict):
                data = reserved_val
            elif isinstance(reserved_val, (bytes, bytearray, memoryview)):
                data = json.loads(bytes(reserved_val).decode("utf-8"))
            elif isinstance(reserved_val, str):
                data = json.loads(reserved_val)
            if isinstance(data, dict):
                if data.get("folder_id"):
                    folder_id_eff = str(data.get("folder_id"))
                elif isinstance(data.get("folders"), list):
                    for it in data.get("folders"):
                        if isinstance(it, dict) and it.get("folder_id"):
                            folder_id_eff = str(it.get("folder_id"))
                            break
        except Exception:  # noqa: BLE001
            folder_id_eff = None

        chunks: List[Dict[str, Any]] = []
        num_chunks = 0
        if folder_id_eff:
            base_root: Path = get_shared_path("DATA_BACKBONE_DIR", settings.data_backbone_dir)
            p = Path(folder_id_eff)
            folder_path: Path = p if p.is_absolute() else (base_root / folder_id_eff)
            try:
                if folder_path.is_dir():
                    # Collect all chunk*.json files
                    json_files = sorted([
                        p
                        for p in folder_path.iterdir()
                        if p.is_file() and p.name.lower().startswith("chunk") and p.suffix.lower() == ".json"
                    ])
                    num_chunks = len(json_files)
                    # Read each chunk file fully and include in response
                    for idx, fp in enumerate(json_files):
                        try:
                            with fp.open('r', encoding='utf-8', errors='ignore') as fh:
                                data = json.load(fh)
                                if isinstance(data, dict):
                                    # Determine chunk index
                                    ci = data.get("chunk_index")
                                    if ci is None:
                                        ci = idx

                                    # Determine human-readable text for this chunk.
                                    # Support multiple writer formats:
                                    #   - legacy: {"text": "..."}
                                    #   - layout-aware: {"chunk_text": {"element": [...]}, "embed_text": "..."}
                                    #   - fixed characters: {"chunk_text": {"element": [...]}, "embed_text": "..."}
                                    txt = data.get("text")

                                    if not isinstance(txt, str) or not txt.strip():
                                        # Try chunk_text.element[0].text or text_tag
                                        ct = data.get("chunk_text")
                                        elem_text = None
                                        if isinstance(ct, dict):
                                            elem = ct.get("element")
                                            if isinstance(elem, list) and elem:
                                                first = elem[0]
                                                if isinstance(first, dict):
                                                    elem_text = first.get("text") or first.get("text_tag")
                                            elif isinstance(elem, dict):
                                                elem_text = elem.get("text") or elem.get("text_tag")

                                        if isinstance(elem_text, str) and elem_text.strip():
                                            txt = elem_text
                                        else:
                                            # Fallback to embed_text if available
                                            emb = data.get("embed_text")
                                            if isinstance(emb, str) and emb.strip():
                                                txt = emb

                                    chunks.append({"chunk_index": ci, "text": txt})
                                else:
                                    chunks.append({"chunk_index": idx, "data": data})
                        except Exception:
                            continue
                # Sort by chunk_index if present
                try:
                    chunks.sort(key=lambda x: x.get('chunk_index', 0))
                except Exception:
                    pass
            except Exception:  # noqa: BLE001
                pass

        # Aggregate combined text from all chunks
        combined_text = "".join([
            c.get('text') for c in chunks if isinstance(c, dict) and isinstance(c.get('text'), str)
        ])

        return {
            "task_id": task_id,
            "status": "success",
            "num_chunks": num_chunks,
            "chunks": chunks,
            "combined_text": combined_text,
        }
    except Exception as e:  # noqa: BLE001
        logger.error(f"Runtime chunk status error: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e), "num_chunks": 0, "chunks": []}
    finally:
        session.close()
