from fastapi import APIRouter, Form
from typing import List, Optional, Dict, Any
import uuid
import logging
from database import SessionLocal
from celery import Celery
from config import settings
from sqlalchemy import text
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.exc import IntegrityError
import json

logger = logging.getLogger("vectorize")
logging.basicConfig(level=logging.INFO)

router = APIRouter(prefix="/vectorize", tags=["Vectorize"])

celery_app = Celery('vectorize_worker', broker=settings.celery_broker_url)

# ---- Models ----
class VectorizeRequest(BaseModel):
    dag_id: str
    run_id: str
    folder_id: str
    vectorize_config: Dict[str, Any] = Field(default_factory=dict, alias="VectorizeConfig")
    model_config = ConfigDict(extra="allow")

class VectorizeWorkerResult(BaseModel):
    task_id: str
    status: str
    process_name: Optional[str] = None
    job_id: Optional[str] = None
    error_message: Optional[str] = None
    folder_id: Optional[str] = None
    model_config = ConfigDict(extra="allow")


def _normalize_model(name: str) -> str:
    n = (name or "").strip().lower()
    n = n.replace(" ", "_").replace("-", "_")
    return n


def _cfg_get(cfg: Dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in cfg and cfg.get(key) is not None:
            return cfg.get(key)
    return None


def _resolve_worker_route(provider_norm: str, model_norm: str) -> tuple[str, str]:
    """Resolve (task_name, queue_name) for vectorize job dispatch.

    Routing strategy:
    - Route by embedding provider using `<provider>_worker.<provider>_task`.
    - Use provider name as queue so provider-specific workers are triggered.
    - Fallback to model-derived route only if provider is unavailable.
    """
    route_key = provider_norm or model_norm
    return f"{route_key}_worker.{route_key}_task".lower(), route_key.lower()


@router.post("/embed")
def submit_vectorize_task(req: VectorizeRequest):
    session = SessionLocal()
    try:
        cfg = req.vectorize_config or {}
        raw_provider = _cfg_get(
            cfg,
            "EmbeddingProvider", "embedding_provider", "embeddingprovider", "embeddingProvider", "provider"
        )
        raw_model = _cfg_get(
            cfg,
            "EmbeddingModel", "embedding_model", "embeddingmodel", "embeddingModel", "model"
        )
        raw_dimension = _cfg_get(
            cfg,
            "EmbeddingDimension", "embedding_dimension", "embeddingdimension", "embeddingDimension",
            "EmbeddingDimensions", "embedding_dimensions", "embeddingdimensions", "embeddingDimensions",
            "dimension"
        )

        provider_norm = _normalize_model(str(raw_provider or ""))
        model_norm = _normalize_model(str(raw_model or ""))

        if not raw_model:
            return {"status": "error", "message": "EmbeddingModel is required in VectorizeConfig"}
        if raw_dimension is None:
            return {"status": "error", "message": "EmbeddingDimension is required in VectorizeConfig"}
        if not provider_norm and not model_norm:
            return {"status": "error", "message": "EmbeddingProvider is required in VectorizeConfig"}

        # Insert into public.task_details with UUID collision retry
        insert_sql = text(
            """
            INSERT INTO public.task_details (
                id, process_name, task_type, status, started_at, job_id, payload
            ) VALUES (
                :id, :process_name, :task_type, :status, now(), :job_id, CAST(:payload AS JSONB)
            )
            """
        )
        MAX_RETRIES = 5
        task_id = None
        for _ in range(MAX_RETRIES):
            candidate = str(uuid.uuid4())
            try:
                session.execute(
                    insert_sql,
                    {
                        "id": candidate,
                        "process_name": req.dag_id,
                        "task_type": "Vectorize",
                        "status": "submitted",
                        "job_id": req.run_id,
                        "payload": json.dumps(cfg),
                    },
                )
                session.commit()
                task_id = candidate
                break
            except IntegrityError:
                session.rollback()
                continue
        if not task_id:
            return {"status": "error", "message": "Could not allocate unique task id after retries"}

        worker_name, queue_name = _resolve_worker_route(provider_norm, model_norm)
        # Update task_details with worker & queue
        session.execute(
            text(
                """
                UPDATE public.task_details
                SET worker_name = :worker_name,
                    queue_name = :queue_name
                WHERE id = :id
                """
            ),
            {"worker_name": worker_name, "queue_name": queue_name, "id": task_id},
        )
        session.commit()

        # Enqueue Celery task
        celery_app.send_task(
            worker_name,
            args=[task_id, req.folder_id, cfg, req.dag_id, req.run_id],
            queue=queue_name,
        )

        return {"task_id": task_id, "status": "submitted"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Vectorize endpoint error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.post("/worker-results")
def worker_results(body: VectorizeWorkerResult):
    """Store vectorize worker results into task_details.reserved and finalize status.

    On success, update public.document_details for the matching folder_id to set
    vectorization/embedding status and last_successful_stage.
    """
    session = SessionLocal()
    try:
        status_raw = (body.status or "").strip().lower()
        status_norm = "success" if status_raw in ("success", "succeeded", "completed") else (
            "failed" if status_raw in ("error", "failed") else status_raw
        )

        reserved_json = body.model_dump(exclude_none=True)
        if isinstance(body, BaseModel):
            try:
                extra_items = {k: v for k, v in body.__dict__.items() if k not in reserved_json}
                reserved_json.update(extra_items)
            except Exception:
                pass

        upd = text(
            """
            UPDATE public.task_details
            SET status = :st,
                reserved = CAST(:reserved AS JSONB),
                completed_at = now()
            WHERE id = :id
            """
        )
        res = session.execute(
            upd,
            {"id": body.task_id, "st": status_norm or "success", "reserved": json.dumps(reserved_json)},
        )
        session.commit()

        rowcount = getattr(res, "rowcount", None)
        if rowcount == 0:
            return {"status": "error", "message": f"task_id not found: {body.task_id}"}

        # Determine folder_id from payload
        folder_id_eff: Optional[str] = body.folder_id
        if not folder_id_eff:
            try:
                if isinstance(reserved_json, dict):
                    if not folder_id_eff and isinstance(reserved_json.get("folders"), list):
                        for item in reserved_json.get("folders"):
                            if isinstance(item, dict) and item.get("folder_id"):
                                folder_id_eff = str(item.get("folder_id"))
                                break
                    if not folder_id_eff and reserved_json.get("folder_id"):
                        folder_id_eff = str(reserved_json.get("folder_id"))
                    if not folder_id_eff and isinstance(reserved_json.get("folder_ids"), list) and reserved_json["folder_ids"]:
                        folder_id_eff = str(reserved_json["folder_ids"][0])
            except Exception:
                folder_id_eff = None

        # On success, update document_details
        if status_norm == "success" and folder_id_eff:
            cols_info = session.execute(
                text(
                    """
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_schema = 'public' AND table_name = 'document_details'
                    """
                )
            ).mappings().all()
            col_names = {c["column_name"]: c.get("data_type") for c in cols_info}

            sets = []
            params = {"fid": folder_id_eff}
            # Prefer vectorization_status, else embedding_status, else vectorize_status
            if "vectorization_status" in col_names:
                sets.append("vectorization_status = :vs"); params["vs"] = "success"
            elif "embedding_status" in col_names:
                sets.append("embedding_status = :es"); params["es"] = "success"
            elif "vectorize_status" in col_names:
                sets.append("vectorize_status = :vss"); params["vss"] = "success"
            if "last_successful_stage" in col_names:
                sets.append("last_successful_stage = :lss"); params["lss"] = "vectorize"
            if "updated_at" in col_names:
                dt = (col_names.get("updated_at") or "").lower()
                if "timestamp" in dt:
                    sets.append("updated_at = now()")
                else:
                    sets.append("updated_at = :ua"); params["ua"] = None

            if sets:
                upd_doc = text(
                    f"""
                    UPDATE public.document_details
                    SET {', '.join(sets)}
                    WHERE folder_id = :fid
                    """
                )
                session.execute(upd_doc, params)
                session.commit()

        return {"status": "ok"}
    except Exception as e:  # noqa: BLE001
        session.rollback()
        logger.error(f"Vectorize worker-results error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
    finally:
        session.close()


@router.get("/status/{task_id}")
def get_vectorize_status(task_id: str):
    session = SessionLocal()
    try:
        row = session.execute(
            text(
                """
                SELECT id, status, reserved
                FROM public.task_details
                WHERE id = :id
                """
            ),
            {"id": task_id},
        ).mappings().first()
        if not row:
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        status = (row.get("status") or "").strip().lower() or "pending"
        if status != "success":
            return {"task_id": task_id, "status": "pending", "message": "No result found yet.", "folder_ids": []}

        # Success: extract folder_ids from reserved JSON
        folder_ids: List[str] = []
        reserved_val = row.get("reserved")
        try:
            data = None
            if isinstance(reserved_val, dict):
                data = reserved_val
            elif isinstance(reserved_val, (bytes, bytearray, memoryview)):
                data = json.loads(bytes(reserved_val).decode("utf-8"))
            elif isinstance(reserved_val, str):
                data = json.loads(reserved_val)
            if isinstance(data, dict):
                folders = data.get("folders")
                if isinstance(folders, list):
                    folder_ids = [str(it.get("folder_id")) for it in folders if isinstance(it, dict) and it.get("folder_id")]
                if not folder_ids:
                    ids_val = data.get("folder_ids")
                    if isinstance(ids_val, list):
                        folder_ids = [str(x) for x in ids_val if x]
                if not folder_ids and data.get("folder_id"):
                    folder_ids = [str(data.get("folder_id"))]
        except Exception:  # noqa: BLE001
            folder_ids = []

        return {"task_id": task_id, "status": "success", "folder_ids": folder_ids or []}
    except Exception as e:  # noqa: BLE001
        logger.error(f"Vectorize status error: {e}", exc_info=True)
        return {"task_id": task_id, "status": "error", "message": str(e), "folder_ids": []}
    finally:
        session.close()
