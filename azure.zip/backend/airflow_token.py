"""Airflow API token management (no expiry field logic).

New table expectation (update your DB manually):

CREATE TABLE airflow_api_token (
    id SERIAL PRIMARY KEY,
    token TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    invalidated_at TIMESTAMPTZ NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

Behavior:
- Load latest active token.
- Validate token (401/403 => invalid).
- If missing/invalid, call auth/token (or AIRFLOW_TOKEN_URL env override) with username/password.
- On refresh: mark existing active tokens inactive, insert new active token row.
- No expires_at usage; validity determined solely by Airflow response (401/403).
"""
from __future__ import annotations

import os
import threading
import logging
from datetime import datetime, timezone
from typing import Optional
import requests
from sqlalchemy import text
from database import SessionLocal
from config import settings

logger = logging.getLogger("airflow_token")

VALIDATION_PATH = "/dags?limit=1"  # lightweight endpoint to verify auth (200 expected)

class AirflowTokenManager:
    def __init__(self):
        self._lock = threading.RLock()
        self._token: Optional[str] = None
        self._loaded = False

    # --- Public API ---
    def get_token(self) -> str:
        with self._lock:
            if not self._loaded:
                self._load_from_db()
            if self._needs_refresh():
                logger.info("Airflow token refresh required (missing or invalid).")
                self._refresh_and_store()
            if not self._token:
                raise RuntimeError("Airflow token unavailable and refresh failed")
            return self._token

    def initialize(self):  # call on startup
        with self._lock:
            if not self._loaded:
                self._load_from_db()
                if self._needs_refresh():
                    self._refresh_and_store()
                else:
                    logger.info("Loaded Airflow token from DB (active & valid).")

    # --- Internal helpers ---
    def _load_from_db(self):
        try:
            session = SessionLocal()
            row = session.execute(
                text("SELECT token FROM airflow_api_token WHERE is_active = true ORDER BY updated_at DESC LIMIT 1")
            ).fetchone()
            session.close()
            if row:
                self._token = row[0]
                logger.info("Active Airflow token loaded from DB.")
            else:
                logger.warning("No active Airflow token found in DB; will attempt to obtain a new one.")
            self._loaded = True
        except Exception as e:  # noqa: BLE001
            logger.error("Failed loading airflow token from DB (table present & migrated?): %s", e)
            self._token = None
            self._loaded = True

    def _needs_refresh(self) -> bool:
        if not self._token:
            return True
        # Validate by calling Airflow; 401/403 => refresh
        return not self._validate_token(self._token)

    def _validate_token(self, token: str) -> bool:
        try:
            url = settings.airflow_api_url.rstrip('/') + VALIDATION_PATH
            headers = {"Authorization": f"Bearer {token}"}
            r = requests.get(url, headers=headers, timeout=10)
            if r.status_code == 200:
                return True
            if r.status_code in (401, 403):
                logger.warning("Airflow token invalid (status=%s).", r.status_code)
                return False
            logger.debug("Validation non-auth status=%s body=%.120s", r.status_code, r.text)
            return True  # treat other errors as non-fatal to avoid loops
        except Exception as e:  # noqa: BLE001
            logger.warning("Airflow token validation error (network?): %s", e)
            return True

    def _refresh_and_store(self):
        try:
            new_token = self._obtain_new_token()
            if not new_token:
                logger.error("Token refresh failed (no token returned); retaining existing token if any.")
                return
            old_token_present = self._token is not None
            self._token = new_token
            self._persist(invalidate_previous=old_token_present)
            logger.info("Refreshed Airflow token.")
        except Exception as e:  # noqa: BLE001
            logger.exception("Failed to refresh Airflow token: %s", e)

    def _persist(self, invalidate_previous: bool):
        try:
            session = SessionLocal()
            if invalidate_previous:
                session.execute(text("UPDATE airflow_api_token SET is_active = false, invalidated_at = now() WHERE is_active = true"))
            session.execute(text("INSERT INTO airflow_api_token (token, is_active) VALUES (:t, true)"), {"t": self._token})
            session.commit()
            session.close()
        except Exception as e:  # noqa: BLE001
            logger.error("Failed persisting airflow token: %s", e)

    def _obtain_new_token(self) -> Optional[str]:
        user = settings.airflow_username
        pwd = settings.airflow_password
        if not (user and pwd):
            logger.error("Username/password not configured for Airflow token acquisition")
            return None
        token_url = settings.airflow_token_url or (settings.airflow_api_url.rstrip('/') + "/auth/token")
        try:
            r = requests.post(token_url, json={"username": user, "password": pwd}, timeout=20)
            if not r.ok:
                logger.error("auth/token endpoint returned %s: %s", r.status_code, r.text[:200])
                return None
            js = r.json()
            token = js.get("access_token") or js.get("token")
            if not token:
                logger.error("auth/token response missing access_token/token field")
                return None
            return token
        except Exception as e:  # noqa: BLE001
            logger.error("Error calling auth/token endpoint: %s", e)
            return None

# Singleton instance
airflow_token_manager = AirflowTokenManager()

def get_airflow_token() -> str:
    return airflow_token_manager.get_token()
