import os
import json
from pathlib import Path
from dotenv import load_dotenv

# Load variables from the backend/.env file (relative to this file) into the
# process environment so the app can rely solely on environment variables.
# Using an explicit path ensures we pick up `.env` even when uvicorn is started
# from the repository root or another working directory.
_HERE = Path(__file__).resolve().parent
dotenv_file = _HERE / ".env"
if dotenv_file.exists():
    load_dotenv(dotenv_path=str(dotenv_file), override=False)
else:
    # Fall back to default behavior (search upwards) if a local .env isn't present
    load_dotenv(override=False)


class Settings:
    """Light-weight settings accessor backed by environment variables.

    Access pattern: settings.database_url -> reads os.environ['DATABASE_URL']
    This keeps configuration entirely in the `.env` file (or real env vars).
    """

    def __getattr__(self, name: str):
        env_key = name.upper()
        val = os.getenv(env_key)
        if val is None:
            # Provide sensible defaults for some common keys
            if name == "debug":
                return False
            if name in ("cors_origins", "allowed_file_types"):
                return []
            return None

        # Handle booleans
        if name == "debug":
            return val.lower() in ("1", "true", "yes")

        # Integers
        if name in ("access_token_expire_minutes",):
            try:
                return int(val)
            except Exception:
                return None

        # Lists (support JSON arrays or comma-separated strings)
        if name in ("cors_origins", "allowed_file_types"):
            v = val.strip()
            if v.startswith("["):
                try:
                    parsed = json.loads(v)
                    if isinstance(parsed, list):
                        return parsed
                except Exception:
                    pass
            return [p.strip() for p in v.split(",") if p.strip()]

        # For other values, return raw string
        return val


# Single shared settings instance used across the codebase
settings = Settings()
