import requests
import os

FASTAPI_URL = os.getenv("CONTEXT_CRAFT_API_URL", "http://localhost:8000")
DEFAULT_API_NAME = os.getenv("CONTEXT_CRAFT_API_NAME")  # optional default for generated API name (slug)

def search_documents(query: str, top_k: int = 5, api_name: str | None = None):
    """
    Call the ContextCraft generated search endpoint at /api/{name}/search.

    Args:
        query: User query text
        top_k: Number of results
        api_name: Optional API name (e.g., "Banking Transformation"). If not provided,
                  uses CONTEXT_CRAFT_API_NAME from the environment.
    """
    try:
        name = api_name or DEFAULT_API_NAME
        if not name:
            return {"error": "Missing api_name. Pass api_name or set CONTEXT_CRAFT_API_NAME."}

        # Ensure the API name used in the URL is slugified (no spaces)
        slug = name.replace(' ', '_').lower()

        # Be permissive: include both possible field names so older and newer
        # generated routers accept the request. Generated routers expect
        # {"search_term": "..."} while some older clients send {"query": "..."}.
        payload = {"search_term": query, "query": query, "top_k": top_k}
        # Generated routers are mounted under /api/{slug}
        url = f"{FASTAPI_URL}/api/{slug}/search"
        resp = requests.post(url, json=payload, timeout=60)
        resp.raise_for_status()
        results = resp.json()

        # Return only relevant info to LLMs
        formatted_results = [
            {
                "doc_id": r.get("doc_id"),
                "chunk_id": r.get("chunk_id"),
                "snippet": (r.get("chunk_text") or "")[:300],
                "score": r.get("rerank_score", r.get("semantic_score")),
            }
            for r in results.get("results", [])
        ]

        return {"results": formatted_results}

    except Exception as e:  # noqa: BLE001
        return {"error": str(e)}
