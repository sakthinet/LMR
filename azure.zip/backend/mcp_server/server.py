from mcp_server.tools.context_tool import search_documents

# Try multiple import paths / names to be compatible with different mcp package versions
MCPServer = None
Tool = None
try:
    # older code expected `MCPServer` at top-level
    from mcp import MCPServer as _MCPServer  # type: ignore
    MCPServer = _MCPServer
    try:
        from mcp.types import Tool as _Tool  # type: ignore
        Tool = _Tool
    except Exception:
        Tool = None
except Exception:
    try:
        # newer mcp exposes a Server / FastMCP in mcp.server
        from mcp.server import FastMCP as _MCPServer  # type: ignore
        MCPServer = _MCPServer
        from mcp.types import Tool as _Tool  # type: ignore
        Tool = _Tool
    except Exception:
        try:
            from mcp.server import Server as _MCPServer  # type: ignore
            MCPServer = _MCPServer
            from mcp.types import Tool as _Tool  # type: ignore
            Tool = _Tool
        except Exception as e:
            raise ImportError(
                "Could not locate MCP server class in installed 'mcp' package. "
                "Tried imports for MCPServer, mcp.server.FastMCP, and mcp.server.Server. "
                f"Underlying error: {e}"
            )


# Instantiate server with a tolerant constructor pattern so we work across versions
def _make_server():
    name = "context-craft-mcp"
    description = "MCP server for Context Craft Search APIs"
    # Try common constructor signatures
    try:
        return MCPServer(name=name, description=description)
    except TypeError:
        try:
            return MCPServer(name)
        except TypeError:
            try:
                return MCPServer()
            except Exception as e:
                raise RuntimeError(f"Failed to instantiate MCP server: {e}")


# Initialize the MCP server
server = _make_server()

# Register tools if Tool is available
if Tool is None:
    # Try to import Tool lazily and continue if not available
    try:
        from mcp.types import Tool as Tool
    except Exception:
        Tool = None

if Tool is not None:
    try:
        server.register_tool(
            Tool(
                name="search_documents",
                description="Search Context Craft documents using hybrid search (Postgres + Qdrant)",
                function=search_documents,
            )
        )
    except Exception:
        # Some MCP server implementations use decorators instead of register_tool; keep tolerant
        try:
            @server.call_tool(name="search_documents")
            async def _search_documents(ctx, args):
                return await search_documents(ctx, args)
        except Exception:
            # Last resort: no-op registration; server may still run without tool binding
            pass

# Prefer FastMCP-style decorator registration when available
try:
    tool_deco = getattr(server, "tool", None)
    if callable(tool_deco):
        # Register an async wrapper compatible with FastMCP
        @server.tool(name="search_documents", description="Search Context Craft documents using hybrid search (Postgres + Qdrant)")
        async def _search_documents_tool(query: str, top_k: int = 5, api_name: str | None = None):
            # The underlying implementation is sync; call directly (OK in small bursts).
            return search_documents(query=query, top_k=top_k, api_name=api_name)
except Exception:
    # Ignore if the current MCP server does not support decorator-based registration
    pass


if __name__ == "__main__":
    try:
        server.run(host="0.0.0.0", port=9000)
    except Exception as e:
        # Some server variants expose different run signatures
        try:
            server.serve()
        except Exception:
            raise
