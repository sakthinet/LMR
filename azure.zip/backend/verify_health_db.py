import asyncio
import sys
import os

# Add current directory to sys.path
sys.path.append(os.getcwd())

from database import get_async_session
from routes.health import SystemService, SystemHealthStatus
from sqlalchemy import select

async def verify_db():
    async for session in get_async_session():
        print("--- System Services ---")
        result = await session.execute(select(SystemService))
        services = result.scalars().all()
        for s in services:
            print(f"Key: {s.service_key}, Name: {s.display_name}")

        print("\n--- System Health Status ---")
        result = await session.execute(select(SystemHealthStatus))
        statuses = result.scalars().all()
        for s in statuses:
            print(f"Key: {s.service_key}, Status: {s.status}, Details: {s.details}")

if __name__ == "__main__":
    asyncio.run(verify_db())
