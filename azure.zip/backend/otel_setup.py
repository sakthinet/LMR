import os
from typing import Optional

from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
try:
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor  # type: ignore
except Exception:  # noqa: BLE001
    FastAPIInstrumentor = None  # type: ignore
try:
    from opentelemetry.instrumentation.requests import RequestsInstrumentor  # type: ignore
except Exception:  # noqa: BLE001
    RequestsInstrumentor = None  # type: ignore
try:
    from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor  # type: ignore
except Exception:  # noqa: BLE001
    HTTPXClientInstrumentor = None  # type: ignore
try:
    from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor  # type: ignore
except Exception:  # noqa: BLE001
    SQLAlchemyInstrumentor = None  # type: ignore
try:
    from opentelemetry.instrumentation.celery import CeleryInstrumentor  # type: ignore
except Exception:  # noqa: BLE001
    CeleryInstrumentor = None  # type: ignore


def init_tracing(app=None, service_name: str = "context-craft-backend", service_version: Optional[str] = None):
    endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317")

    # Resource attributes
    attributes = {"service.name": service_name}
    if service_version:
        attributes["service.version"] = service_version
    env = os.getenv("DEPLOYMENT_ENVIRONMENT") or os.getenv("ENVIRONMENT")
    if env:
        attributes["deployment.environment"] = env

    resource = Resource.create(attributes)

    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)

    # Use insecure (plaintext) connection unless endpoint explicitly starts with https://
    # This resolves SSL handshake errors when the local collector expects plaintext.
    insecure_mode = not endpoint.startswith("https://")
    span_exporter = OTLPSpanExporter(endpoint=endpoint, insecure=insecure_mode)
    span_processor = BatchSpanProcessor(span_exporter)
    provider.add_span_processor(span_processor)
    span_processor = BatchSpanProcessor(span_exporter)
    provider.add_span_processor(span_processor)

    # Ensure we extract/inject both W3C tracecontext and W3C baggage
    try:
        # Preferred imports (newer opentelemetry versions)
        from opentelemetry.propagators.composite import CompositePropagator
        from opentelemetry.propagators.tracecontext import TraceContextTextMapPropagator
        from opentelemetry.baggage.propagation import W3CBaggagePropagator
        from opentelemetry.propagate import set_global_textmap

        set_global_textmap(
            CompositePropagator([TraceContextTextMapPropagator(), W3CBaggagePropagator()])
        )
    except Exception:
        # Best-effort fallback for alternate package layouts
        try:
            from opentelemetry.propagators.composite import CompositePropagator  # type: ignore
            from opentelemetry.propagators.tracecontext import TraceContextPropagator  # type: ignore
            from opentelemetry.baggage.propagation import W3CBaggagePropagator  # type: ignore
            from opentelemetry.propagate import set_global_textmap  # type: ignore

            set_global_textmap(
                CompositePropagator([TraceContextPropagator(), W3CBaggagePropagator()])
            )
        except Exception:
            # If we can't set a composite propagator, continue without failing
            pass

    # Instrument frameworks and libs
    if FastAPIInstrumentor is not None:
        if app is not None:
            try:
                FastAPIInstrumentor.instrument_app(app, tracer_provider=provider)
            except Exception:
                # Fallback without explicit tracer provider (uses global provider)
                try:
                    FastAPIInstrumentor.instrument_app(app)
                except Exception:
                    pass
        else:
            try:
                FastAPIInstrumentor().instrument(tracer_provider=provider)
            except Exception:
                try:
                    FastAPIInstrumentor().instrument()
                except Exception:
                    pass
    if RequestsInstrumentor is not None:
        try:
            RequestsInstrumentor().instrument()
        except Exception:
            pass
    if HTTPXClientInstrumentor is not None:
        try:
            HTTPXClientInstrumentor().instrument()
        except Exception:
            pass
    # SQLAlchemy instrumentation is optional; enable when engines are available
    if SQLAlchemyInstrumentor is not None:
        try:
            # Prefer sync_engine if exported by database.py
            from database import sync_engine as _sync_engine  # type: ignore
            SQLAlchemyInstrumentor().instrument(engine=_sync_engine)
        except Exception:
            try:
                from database import engine as _engine  # type: ignore
                SQLAlchemyInstrumentor().instrument(engine=_engine)
            except Exception:
                try:
                    SQLAlchemyInstrumentor().instrument()
                except Exception:
                    pass

    # Celery instrumentation to propagate trace context via message headers
    if CeleryInstrumentor is not None:
        try:
            CeleryInstrumentor().instrument()
        except Exception:
            pass

    return provider


def add_baggage_to_span_middleware(app, baggage_keys: Optional[list] = None):
    """Install a FastAPI/Starlette middleware that copies selected baggage keys
    into the current span as attributes so they are visible/searchable in
    tracing backends.

    - app: FastAPI app instance
    - baggage_keys: list of baggage keys to copy; if None, copies all baggage keys.
    """
    try:
        from starlette.middleware.base import BaseHTTPMiddleware
        from opentelemetry import trace
        try:
            # new-style API
            from opentelemetry.baggage import get_all as _get_all_baggage
        except Exception:
            # older API fallback
            try:
                from opentelemetry.baggage import get_all as _get_all_baggage  # type: ignore
            except Exception:
                _get_all_baggage = None

        class _BaggageToSpanMiddleware(BaseHTTPMiddleware):
            def __init__(self, app, keys=None):
                super().__init__(app)
                self.keys = keys

            async def dispatch(self, request, call_next):
                span = trace.get_current_span()
                if span is not None and span.is_recording():
                    baggage = {}
                    if _get_all_baggage is not None:
                        try:
                            baggage = dict(_get_all_baggage() or {})
                        except Exception:
                            baggage = {}

                    if self.keys:
                        items = {k: baggage.get(k) for k in self.keys if k in baggage}
                    else:
                        items = baggage

                    for k, v in items.items():
                        if v is None:
                            continue
                        try:
                            span.set_attribute(f"baggage.{k}", str(v))
                        except Exception:
                            # Don't let telemetry middleware break requests
                            pass

                return await call_next(request)

        app.add_middleware(_BaggageToSpanMiddleware, keys=baggage_keys)
    except Exception:
        # If middleware can't be added (missing deps), silently continue
        pass
