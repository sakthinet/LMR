# app/models.py
from sqlalchemy import Column, String, Text, DateTime, JSON, Enum, Integer, Boolean, LargeBinary
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import validates
import enum
import uuid
from sqlalchemy.orm import Session
from database import SessionLocal
from sqlalchemy import text
import json

Base = declarative_base()

class TaskStatus(str, enum.Enum):
    SUBMITTED = "submitted"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"

class TaskType(str, enum.Enum):
    OCR = "ocr"
    CLASSIFY = "classify"


class ConnectionProfile(Base):
    __tablename__ = "connection_profile"

    # Primary key
    connection_id = Column(UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()"))

    # Minimal identity fields
    name = Column(Text, nullable=False, unique=True)
    type = Column(Text, nullable=False)
    connection_type = Column(Text, nullable=False)  # e.g., "postgres"

    # Plain metadata (non-secret)
    metadata_json = Column(JSON, nullable=False)

    # Encrypted password fields (binary)
    ciphertext = Column(LargeBinary, nullable=False)
    nonce = Column(LargeBinary, nullable=False)       # 12 bytes
    tag = Column(LargeBinary, nullable=False)         # 16 bytes
    wrapped_dek = Column(LargeBinary, nullable=False)
    kek_key_id = Column(Text, nullable=False)
    algo = Column(Text, nullable=False, default="AES-256-GCM")



class EvaluationRun(Base):
    """Persistent evaluation run tracking"""
    __tablename__ = "evaluation_run"

    run_id = Column(String(50), primary_key=True)
    
    # API Reference
    api_definition_id = Column(UUID(as_uuid=True), nullable=False)  # FK to search_api.id
    api_name = Column(String(255), nullable=False)
    api_version = Column(Integer, nullable=False)
    api_snapshot = Column(JSON, nullable=False)  # snapshot of config_json at run time
    
    # Metadata
    framework = Column(String(50), nullable=False, default='score')  # e.g., 'score', 'ragas'
    dataset_name = Column(String(255), nullable=True)
    
    # Status tracking
    status = Column(String(50), nullable=False, default='PENDING')  # PENDING, RUNNING, COMPLETED, FAILED, PARTIAL
    
    # Query counts
    total_questions = Column(Integer, nullable=False, default=0)
    successful_queries = Column(Integer, nullable=False, default=0)
    failed_queries = Column(Integer, nullable=False, default=0)
    
    # Aggregated results
    aggregated_metrics = Column(JSON, nullable=True)  # avg_precision@k, avg_recall@k, etc.
    
    # Audit fields
    created_by = Column(String(255), nullable=True)
    created_at = Column(DateTime, nullable=False, server_default=func.now())
    updated_at = Column(DateTime, nullable=False, server_default=func.now())
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)


class EvaluationRunQuery(Base):
    """Query-level results for evaluation runs"""
    __tablename__ = "evaluation_run_query"

    query_id = Column(UUID(as_uuid=True), primary_key=True, server_default=text("gen_random_uuid()"))
    
    # Foreign key to run
    run_id = Column(String(50), nullable=False)  # FK to evaluation_run.run_id
    
    # Input data
    question = Column(Text, nullable=False)
    reference_answer = Column(Text, nullable=True)
    expected_documents = Column(JSON, nullable=True)  # array of document names
    category = Column(String(255), nullable=True)
    
    # Execution tracking
    status = Column(String(50), nullable=False, default='PENDING')  # PENDING, RUNNING, COMPLETED, FAILED
    attempt_count = Column(Integer, nullable=False, default=0)
    
    # Results
    generated_answer = Column(Text, nullable=True)
    retrieved_results = Column(JSON, nullable=True)  # array of retrieved results
    query_metrics = Column(JSON, nullable=True)  # precision@k, recall@k, f1@k, mrr, etc.
    error_message = Column(Text, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime, nullable=False, server_default=func.now())
    updated_at = Column(DateTime, nullable=False, server_default=func.now())
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)


def log_task_execution(
    task_type,
    status,
    queue_name=None,
    metadata=None,
    error_message=None,
    worker_id=None,
    started_at=None,
    completed_at=None
):
    db: Session = SessionLocal()
    # Insert log into cc_task_executions
    db.execute(text("""
        INSERT INTO cc_task_executions (
            task_type, status, queue_name, metadata, error_message, worker_id, started_at, completed_at
        ) VALUES (
            :task_type, :status, :queue_name, :metadata, :error_message, :worker_id, :started_at, :completed_at
        )
    """), {
        "task_type": task_type,
        "status": status,
        "queue_name": queue_name,
        "metadata": json.dumps(metadata) if metadata else json.dumps({}),
        "error_message": error_message,
        "worker_id": worker_id,
        "started_at": started_at,
        "completed_at": completed_at
    })
    db.commit()
    db.close()
